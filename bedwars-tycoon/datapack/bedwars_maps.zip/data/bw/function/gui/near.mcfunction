execute if items entity @s player.cursor *[minecraft:custom_data~{bwgui:{}}] run return run function bw:gui/click
execute if items entity @s container.* *[minecraft:custom_data~{bwgui:{}}] run return run function bw:gui/click
execute if items entity @s weapon.offhand *[minecraft:custom_data~{bwgui:{}}] run return run function bw:gui/click
execute as @e[type=minecraft:marker,tag=bw.gui,distance=..8] at @s if items block ~ ~ ~ container.* *[!minecraft:custom_data~{bwgui:{}}] run function bw:gui/eject
execute as @e[type=minecraft:item,distance=..10] if items entity @s contents *[minecraft:custom_data~{bwgui:{}}] run kill @s
scoreboard players add @s bw.gt 1
execute if score @s bw.gt matches 10.. run function bw:gui/refresh
