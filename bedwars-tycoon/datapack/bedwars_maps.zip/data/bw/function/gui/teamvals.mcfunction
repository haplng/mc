$scoreboard players operation @s bw.vsharp = #sharp$(i) bw
$scoreboard players operation @s bw.vprot = #prot$(i) bw
$scoreboard players operation @s bw.vhaste = #haste$(i) bw
$scoreboard players operation @s bw.vforge = #fl$(i) bw
$scoreboard players operation @s bw.vheal = #heal$(i) bw
$scoreboard players operation @s bw.vtrap = #trap$(i) bw
