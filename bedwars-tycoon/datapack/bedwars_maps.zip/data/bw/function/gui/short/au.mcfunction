$scoreboard players set #need bw $(need)
scoreboard players operation #need bw -= @s bw.au
tellraw @s [{text:""},{text:"금이 부족해! ",color:"red"},{score:{name:"#need",objective:"bw"},color:"red"},{text:"개 더 필요해!",color:"red"}]
playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.5 0.6
