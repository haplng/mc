scoreboard players set @s bw.gt 0
function bw:gui/money
execute at @e[type=minecraft:marker,tag=bw.gui.a,tag=bw.gui.shop,distance=..8] run function bw:gui/shop/paint
execute at @e[type=minecraft:marker,tag=bw.gui.a,tag=bw.gui.team,distance=..8] run function bw:gui/team/paint
execute at @e[type=minecraft:marker,tag=bw.gui.a,tag=bw.gui.unlock,distance=..8] run function bw:gui/unlock/paint
execute at @e[type=minecraft:marker,tag=bw.gui.a,tag=bw.gui.black,distance=..8] run function bw:gui/black/paint
