execute if block ~ ~ ~ minecraft:waxed_copper_chest[type=right] run tag @s add bw.gui.a
execute unless entity @s[tag=bw.gui.a] run tag @s add bw.gui.b
scoreboard players set @s bw.page 1
execute if entity @s[tag=bw.gui.shop] run data modify block ~ ~ ~ CustomName set value {text:"아이템 상점"}
execute if entity @s[tag=bw.gui.team] run data modify block ~ ~ ~ CustomName set value {text:"팀 업그레이드"}
execute if entity @s[tag=bw.gui.unlock] run data modify block ~ ~ ~ CustomName set value {text:"해금 (코인)"}
execute if entity @s[tag=bw.gui.black] run data modify block ~ ~ ~ CustomName set value {text:"암시장"}
