$tellraw @s {text:"$(msg)",color:"red"}
playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.5 0.6
