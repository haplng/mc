execute store result score @s bw.fe run clear @s minecraft:iron_ingot 0
execute store result score @s bw.au run clear @s minecraft:gold_ingot 0
execute store result score @s bw.em run clear @s minecraft:emerald 0
execute store result score @s bw.di run clear @s minecraft:diamond 0
