$tellraw @s [{text:"구매: ",color:"green"},{text:"$(name)",color:"gold"}]
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.8 2
