item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand with minecraft:air
execute if items entity @s player.cursor *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s player.cursor
execute if items entity @s weapon.offhand *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s weapon.offhand
execute if items entity @s container.0 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.0
execute if items entity @s container.1 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.1
execute if items entity @s container.2 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.2
execute if items entity @s container.3 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.3
execute if items entity @s container.4 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.4
execute if items entity @s container.5 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.5
execute if items entity @s container.6 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.6
execute if items entity @s container.7 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.7
execute if items entity @s container.8 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.8
execute if items entity @s container.9 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.9
execute if items entity @s container.10 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.10
execute if items entity @s container.11 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.11
execute if items entity @s container.12 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.12
execute if items entity @s container.13 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.13
execute if items entity @s container.14 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.14
execute if items entity @s container.15 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.15
execute if items entity @s container.16 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.16
execute if items entity @s container.17 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.17
execute if items entity @s container.18 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.18
execute if items entity @s container.19 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.19
execute if items entity @s container.20 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.20
execute if items entity @s container.21 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.21
execute if items entity @s container.22 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.22
execute if items entity @s container.23 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.23
execute if items entity @s container.24 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.24
execute if items entity @s container.25 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.25
execute if items entity @s container.26 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.26
execute if items entity @s container.27 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.27
execute if items entity @s container.28 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.28
execute if items entity @s container.29 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.29
execute if items entity @s container.30 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.30
execute if items entity @s container.31 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.31
execute if items entity @s container.32 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.32
execute if items entity @s container.33 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.33
execute if items entity @s container.34 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.34
execute if items entity @s container.35 *[minecraft:custom_data~{bwgui:{}}] run item replace entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] weapon.mainhand from entity @s container.35
scoreboard players set @s bw.click 0
execute store result score @s bw.click run data get entity @e[type=minecraft:armor_stand,tag=bw.tmp,limit=1] equipment.mainhand.components."minecraft:custom_data".bwgui.id
clear @s *[minecraft:custom_data~{bwgui:{}}]
function bw:gui/money
function bw:gui/do
function bw:gui/refresh
