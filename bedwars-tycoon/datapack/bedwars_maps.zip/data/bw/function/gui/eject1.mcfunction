summon minecraft:item ~ ~1 ~ {Item:{id:"minecraft:stone",count:1},PickupDelay:0s,Tags:["bw","bw.ej"]}
$item replace entity @e[type=minecraft:item,tag=bw.ej,distance=..2,limit=1] contents from block ~ ~ ~ container.$(n)
$item replace block ~ ~ ~ container.$(n) with minecraft:air
tag @e[type=minecraft:item,tag=bw.ej] remove bw.ej
