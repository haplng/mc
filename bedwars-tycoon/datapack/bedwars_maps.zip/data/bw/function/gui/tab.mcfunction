$scoreboard players set @e[type=minecraft:marker,tag=bw.gui.a,tag=bw.gui.$(kind),distance=..8,sort=nearest,limit=1] bw.page $(p)
playsound minecraft:ui.button.click master @s ~ ~ ~ 0.4 1
