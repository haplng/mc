item replace block ~ ~ ~ container.0 with minecraft:gray_stained_glass_pane[custom_data={bwgui:{id:150}},item_name={text:"⬆ 종류   ⬇ 물건",color:"dark_gray"},tooltip_display={hidden_components:["minecraft:attribute_modifiers","minecraft:enchantments","minecraft:potion_contents","minecraft:unbreakable","minecraft:dyed_color","minecraft:can_break","minecraft:can_place_on"]}] 1
item replace block ~ ~ ~ container.1 with minecraft:gray_stained_glass_pane[custom_data={bwgui:{id:150}},item_name={text:"⬆ 종류   ⬇ 물건",color:"dark_gray"},tooltip_display={hidden_components:["minecraft:attribute_modifiers","minecraft:enchantments","minecraft:potion_contents","minecraft:unbreakable","minecraft:dyed_color","minecraft:can_break","minecraft:can_place_on"]}] 1
item replace block ~ ~ ~ container.2 with minecraft:gray_stained_glass_pane[custom_data={bwgui:{id:150}},item_name={text:"⬆ 종류   ⬇ 물건",color:"dark_gray"},tooltip_display={hidden_components:["minecraft:attribute_modifiers","minecraft:enchantments","minecraft:potion_contents","minecraft:unbreakable","minecraft:dyed_color","minecraft:can_break","minecraft:can_place_on"]}] 1
item replace block ~ ~ ~ container.3 with minecraft:gray_stained_glass_pane[custom_data={bwgui:{id:150}},item_name={text:"⬆ 종류   ⬇ 물건",color:"dark_gray"},tooltip_display={hidden_components:["minecraft:attribute_modifiers","minecraft:enchantments","minecraft:potion_contents","minecraft:unbreakable","minecraft:dyed_color","minecraft:can_break","minecraft:can_place_on"]}] 1
item replace block ~ ~ ~ container.4 with minecraft:gray_stained_glass_pane[custom_data={bwgui:{id:150}},item_name={text:"⬆ 종류   ⬇ 물건",color:"dark_gray"},tooltip_display={hidden_components:["minecraft:attribute_modifiers","minecraft:enchantments","minecraft:potion_contents","minecraft:unbreakable","minecraft:dyed_color","minecraft:can_break","minecraft:can_place_on"]}] 1
item replace block ~ ~ ~ container.5 with minecraft:gray_stained_glass_pane[custom_data={bwgui:{id:150}},item_name={text:"⬆ 종류   ⬇ 물건",color:"dark_gray"},tooltip_display={hidden_components:["minecraft:attribute_modifiers","minecraft:enchantments","minecraft:potion_contents","minecraft:unbreakable","minecraft:dyed_color","minecraft:can_break","minecraft:can_place_on"]}] 1
item replace block ~ ~ ~ container.6 with minecraft:gray_stained_glass_pane[custom_data={bwgui:{id:150}},item_name={text:"⬆ 종류   ⬇ 물건",color:"dark_gray"},tooltip_display={hidden_components:["minecraft:attribute_modifiers","minecraft:enchantments","minecraft:potion_contents","minecraft:unbreakable","minecraft:dyed_color","minecraft:can_break","minecraft:can_place_on"]}] 1
item replace block ~ ~ ~ container.7 with minecraft:gray_stained_glass_pane[custom_data={bwgui:{id:150}},item_name={text:"⬆ 종류   ⬇ 물건",color:"dark_gray"},tooltip_display={hidden_components:["minecraft:attribute_modifiers","minecraft:enchantments","minecraft:potion_contents","minecraft:unbreakable","minecraft:dyed_color","minecraft:can_break","minecraft:can_place_on"]}] 1
item replace block ~ ~ ~ container.8 with minecraft:gray_stained_glass_pane[custom_data={bwgui:{id:150}},item_name={text:"⬆ 종류   ⬇ 물건",color:"dark_gray"},tooltip_display={hidden_components:["minecraft:attribute_modifiers","minecraft:enchantments","minecraft:potion_contents","minecraft:unbreakable","minecraft:dyed_color","minecraft:can_break","minecraft:can_place_on"]}] 1
item replace block ~ ~ ~ container.9 with minecraft:air
item replace block ~ ~ ~ container.10 with minecraft:air
item replace block ~ ~ ~ container.11 with minecraft:air
item replace block ~ ~ ~ container.12 with minecraft:air
item replace block ~ ~ ~ container.13 with minecraft:air
item replace block ~ ~ ~ container.14 with minecraft:air
item replace block ~ ~ ~ container.15 with minecraft:air
item replace block ~ ~ ~ container.16 with minecraft:air
item replace block ~ ~ ~ container.17 with minecraft:air
item replace block ~ ~ ~ container.18 with minecraft:air
item replace block ~ ~ ~ container.19 with minecraft:air
item replace block ~ ~ ~ container.20 with minecraft:air
item replace block ~ ~ ~ container.21 with minecraft:air
item replace block ~ ~ ~ container.22 with minecraft:air
item replace block ~ ~ ~ container.23 with minecraft:air
item replace block ~ ~ ~ container.24 with minecraft:air
item replace block ~ ~ ~ container.25 with minecraft:air
item replace block ~ ~ ~ container.26 with minecraft:air
