scoreboard players operation #page bw = @e[type=minecraft:marker,tag=bw.gui.a,distance=..0.6,limit=1] bw.page
execute unless score #page bw matches 1..1 run scoreboard players set #page bw 1
execute store result storage bw:tmp me.i int 1 run scoreboard players get @s bw.team
function bw:gui/teamvals with storage bw:tmp me
function bw:gui/team/a
execute positioned as @e[type=minecraft:marker,tag=bw.gui.b,tag=bw.gui.team,distance=..1.6,sort=nearest,limit=1] run function bw:gui/team/b
