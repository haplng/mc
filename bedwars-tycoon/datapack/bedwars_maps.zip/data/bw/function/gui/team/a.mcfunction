execute if score #page bw matches 1 run function bw:gui/team/p1a
