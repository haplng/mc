$execute if score #fl$(i) bw matches 4.. run return run function bw:gui/no {msg:"이미 다 샀어."}
$execute if score #fl$(i) bw matches 0 unless score @s bw.di matches 2.. run return run function bw:gui/short/di {need:2}
$execute if score #fl$(i) bw matches 0 run return run function bw:gui/up/forge0 {i:$(i)}
$execute if score #fl$(i) bw matches 1 unless score @s bw.di matches 4.. run return run function bw:gui/short/di {need:4}
$execute if score #fl$(i) bw matches 1 run return run function bw:gui/up/forge1 {i:$(i)}
$execute if score #fl$(i) bw matches 2 unless score @s bw.di matches 6.. run return run function bw:gui/short/di {need:6}
$execute if score #fl$(i) bw matches 2 run return run function bw:gui/up/forge2 {i:$(i)}
$execute if score #fl$(i) bw matches 3 unless score @s bw.di matches 8.. run return run function bw:gui/short/di {need:8}
$execute if score #fl$(i) bw matches 3 run return run function bw:gui/up/forge3 {i:$(i)}
