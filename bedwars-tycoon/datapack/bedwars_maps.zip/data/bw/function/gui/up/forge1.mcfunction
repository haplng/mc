clear @s minecraft:diamond 4
$scoreboard players set #fl$(i) bw 2
$scoreboard players set #fs$(i) bw 200
$tellraw @a[tag=bw.play,scores={bw.team=$(i)}] [{selector:"@s"},{text:"이(가) ",color:"green"},{text:"황금 용광로",color:"gold"},{text:"을(를) 구매했어!",color:"green"}]
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.8 2
