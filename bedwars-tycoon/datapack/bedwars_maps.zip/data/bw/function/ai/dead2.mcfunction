execute store result storage bw:tmp loot.fe int 1 run scoreboard players get #wfe2 bw
execute store result storage bw:tmp loot.au int 1 run scoreboard players get #wau2 bw
execute store result storage bw:tmp loot.di int 1 run scoreboard players get #wdi2 bw
execute store result storage bw:tmp loot.em int 1 run scoreboard players get #wem2 bw
execute if score #wfe2 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_fe with storage bw:tmp loot
execute if score #wau2 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_au with storage bw:tmp loot
execute if score #wdi2 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_di with storage bw:tmp loot
execute if score #wem2 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_em with storage bw:tmp loot
scoreboard players set #wfe2 bw 0
scoreboard players set #wau2 bw 0
scoreboard players set #wdi2 bw 0
scoreboard players set #wem2 bw 0
scoreboard players set #bsw2 bw 0
execute if score #btl2 bw matches 2.. run scoreboard players remove #btl2 bw 1
execute if score #final bw matches 0 run scoreboard players set #bres2 bw 100
execute if score #final bw matches 1 run tellraw @a [{text:""},{text:"<",color:"gray"},{selector:"@s"},{text:"> gg",color:"gray"}]
