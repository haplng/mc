scoreboard players set @s bw.st 1
scoreboard players operation @s bw.t1 = #a_think bw
execute unless data storage bw:bot {at7:"g7"} unless data storage bw:bot {at7:"k7"} run return run function bw:ai/away7
execute if data storage bw:bot {at7:"k7"} run return run function bw:ai/to7 {to:"g7",dest:1}
execute if score #bsw7 bw matches 0 if score #wfe7 bw < #a_wait bw run return 0
scoreboard players set #can bw 0
execute if score #bsw7 bw matches 0 if score #wfe7 bw matches 10.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 1.. if score #bar7 bw matches 0 if score #wfe7 bw matches 40.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 2.. if score #btl7 bw matches 0 if score #wfe7 bw matches 20.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 3.. if score #bsw7 bw matches ..1 if score #wau7 bw matches 7.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 4.. if score #bar7 bw matches ..1 if score #wau7 bw matches 12.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 5.. if score #btl7 bw matches 1 if score #wfe7 bw matches 10.. if score #wau7 bw matches 3.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 6.. if score #bsw7 bw matches ..2 if score #wem7 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 8.. if score #bar7 bw matches ..2 if score #wem7 bw matches 6.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 9.. if score #btl7 bw matches 2 if score #wau7 bw matches 6.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 6.. if score #bga7 bw matches ..1 if score #wau7 bw matches 3.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 7.. if score #bfb7 bw matches ..1 if score #wfe7 bw matches 40.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 5.. if score #sharp7 bw matches 0 if score #wdi7 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 6.. if score #prot7 bw matches 0 if score #wdi7 bw matches 2.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 8.. if score #prot7 bw matches 1 if score #wdi7 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 10.. if score #prot7 bw matches 2 if score #wdi7 bw matches 8.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 12.. if score #prot7 bw matches 3 if score #wdi7 bw matches 16.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 7.. if score #fl7 bw matches 0 if score #wdi7 bw matches 2.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 10.. if score #fl7 bw matches 1 if score #wdi7 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 8.. if score #trap7 bw matches 0 if score #wdi7 bw matches 1.. run scoreboard players set #can bw 1
execute if score #can bw matches 1 run return run function bw:ai/to7 {to:"k7",dest:2}
execute if score #bed7 bw matches 1 if score #bdone7 bw matches 0 if data storage bw:bot def7[0] run return run function bw:ai/to7 {to:"b7",dest:3}
execute store result score #rn bw run random value 1..100
execute if score #lvl bw matches 5.. if score #sec bw matches 60.. if score #rn bw matches ..30 run return run function bw:ai/dia7
function bw:ai/pick7
execute if score @s bw.tgt matches 0.. run return run function bw:ai/attack7
