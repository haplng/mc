scoreboard players remove #wfe6 bw 120
function bw:mob/botgolem
