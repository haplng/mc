execute if score #bsw4 bw matches 0 if score #wfe4 bw matches 10.. run function bw:ai/b/4_0
execute if score #lvl bw matches 1.. if score #bar4 bw matches 0 if score #wfe4 bw matches 40.. run function bw:ai/b/4_1
execute if score #lvl bw matches 2.. if score #btl4 bw matches 0 if score #wfe4 bw matches 20.. run function bw:ai/b/4_2
execute if score #lvl bw matches 3.. if score #bsw4 bw matches ..1 if score #wau4 bw matches 7.. run function bw:ai/b/4_3
execute if score #lvl bw matches 4.. if score #bar4 bw matches ..1 if score #wau4 bw matches 12.. run function bw:ai/b/4_4
execute if score #lvl bw matches 5.. if score #btl4 bw matches 1 if score #wfe4 bw matches 10.. if score #wau4 bw matches 3.. run function bw:ai/b/4_5
execute if score #lvl bw matches 6.. if score #bsw4 bw matches ..2 if score #wem4 bw matches 4.. run function bw:ai/b/4_6
execute if score #lvl bw matches 8.. if score #bar4 bw matches ..2 if score #wem4 bw matches 6.. run function bw:ai/b/4_7
execute if score #lvl bw matches 9.. if score #btl4 bw matches 2 if score #wau4 bw matches 6.. run function bw:ai/b/4_8
execute if score #lvl bw matches 6.. if score #bga4 bw matches ..1 if score #wau4 bw matches 3.. run function bw:ai/b/4_9
execute if score #lvl bw matches 7.. if score #bfb4 bw matches ..1 if score #wfe4 bw matches 40.. run function bw:ai/b/4_10
execute if score #lvl bw matches 5.. if score #sharp4 bw matches 0 if score #wdi4 bw matches 4.. run function bw:ai/b/4_11
execute if score #lvl bw matches 6.. if score #prot4 bw matches 0 if score #wdi4 bw matches 2.. run function bw:ai/b/4_12
execute if score #lvl bw matches 8.. if score #prot4 bw matches 1 if score #wdi4 bw matches 4.. run function bw:ai/b/4_13
execute if score #lvl bw matches 10.. if score #prot4 bw matches 2 if score #wdi4 bw matches 8.. run function bw:ai/b/4_14
execute if score #lvl bw matches 12.. if score #prot4 bw matches 3 if score #wdi4 bw matches 16.. run function bw:ai/b/4_15
execute if score #lvl bw matches 7.. if score #fl4 bw matches 0 if score #wdi4 bw matches 2.. run function bw:ai/b/4_16
execute if score #lvl bw matches 10.. if score #fl4 bw matches 1 if score #wdi4 bw matches 4.. run function bw:ai/b/4_17
execute if score #lvl bw matches 8.. if score #tqn4 bw matches 0 if score #wdi4 bw matches 1.. run function bw:ai/b/4_18
execute if score #lvl bw matches 11.. if score #tqn4 bw matches 1 if score #wdi4 bw matches 2.. run function bw:ai/b/4_19
execute if score #lvl bw matches 13.. if score #dbuff4 bw matches 0 if score #wdi4 bw matches 5.. run function bw:ai/b/4_20
