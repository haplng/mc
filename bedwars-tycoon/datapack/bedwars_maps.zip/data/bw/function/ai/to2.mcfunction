$data modify storage bw:tmp rt.to set value "$(to)"
$scoreboard players set @s bw.dest $(dest)
execute store success score #ok bw run function bw:ai/route2
execute if score #ok bw matches 0 run scoreboard players set @s bw.st 1
execute if score #ok bw matches 0 run scoreboard players set @s bw.t1 40
