execute if score #high bw matches 0 if block ~ ~2 ~ #bw:open run return run function bw:ai/jump
execute unless block ^ ^ ^0.7 #bw:open positioned ^ ^ ^0.7 run return run function bw:ai/wall
execute positioned ^0.32 ^ ^0.55 run function bw:ai/wall
