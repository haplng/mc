$data modify storage bw:bot def2 set from storage bw:nav $(m).def2_$(T)
