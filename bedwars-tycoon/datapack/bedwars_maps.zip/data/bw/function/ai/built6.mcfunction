scoreboard players set #bdone6 bw 1
scoreboard players set @s bw.st 0
