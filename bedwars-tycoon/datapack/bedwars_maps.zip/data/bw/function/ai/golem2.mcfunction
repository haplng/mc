scoreboard players remove #wfe2 bw 120
function bw:mob/botgolem
