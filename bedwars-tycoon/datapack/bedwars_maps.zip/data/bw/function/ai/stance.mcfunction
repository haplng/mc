execute if score #a_bridge bw matches 3 run return 0
rotate @s ~180 76
scoreboard players operation @s bw.mf = #a_bridge bw
scoreboard players set @s bw.ms 0
execute if score @s bw.pose matches 0 if score #a_bridge bw matches -2..-1 run function bw:ai/crouch
