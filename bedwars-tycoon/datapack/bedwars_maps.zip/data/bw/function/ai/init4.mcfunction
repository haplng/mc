tag @s remove bw.new
tag @s add bw.fighter
scoreboard players set @s bw.team 4
team join bw.cyan @s
data modify entity @s CustomName set from storage bw:ai n4
scoreboard players set @s bw.st 0
scoreboard players set @s bw.pst 0
scoreboard players set @s bw.dest 0
scoreboard players set @s bw.t1 0
scoreboard players set @s bw.t2 0
scoreboard players set @s bw.atk 0
scoreboard players set @s bw.jc 0
scoreboard players set @s bw.br 0
scoreboard players set @s bw.slow 0
scoreboard players set @s bw.mf 0
scoreboard players set @s bw.ms 0
scoreboard players set @s bw.mine 0
scoreboard players set @s bw.stuck 0
scoreboard players set @s bw.lht 0
scoreboard players set @s bw.pose 0
scoreboard players set @s bw.fbc 0
scoreboard players set @s bw.idle 0
scoreboard players set @s bw.wpt 0
scoreboard players set @s bw.av 0
scoreboard players set @s bw.avs 0
scoreboard players set @s bw.ft 0
scoreboard players set @s bw.calm 0
scoreboard players set @s bw.trc 0
scoreboard players set @s bw.tx 0
scoreboard players set @s bw.tz 0
scoreboard players set @s bw.off 0
scoreboard players set @s bw.offa 0
scoreboard players set @s bw.avf 0
scoreboard players set @s bw.av0 0
scoreboard players set @s bw.avc 0
scoreboard players set @s bw.bgc 0
scoreboard players set @s bw.mfat 0
scoreboard players set @s bw.milk 0
scoreboard players set @s bw.twr 0
scoreboard players set @s bw.rrc 0
scoreboard players set @s bw.nearc 0
scoreboard players set @s bw.avn 25
data modify storage bw:bot tr4 set value []
scoreboard players set @s bw.tgt -1
scoreboard players set @s bw.strafe 1
scoreboard players operation @s bw.sw = #bsw4 bw
scoreboard players operation @s bw.armor = #bar4 bw
scoreboard players operation @s bw.tool = #btl4 bw
execute if score #a_kb bw matches 81..99 run attribute @s minecraft:knockback_resistance base set 0.15
execute if score #a_kb bw matches 51..80 run attribute @s minecraft:knockback_resistance base set 0.4
execute if score #a_kb bw matches 21..50 run attribute @s minecraft:knockback_resistance base set 0.65
execute if score #a_kb bw matches 1..20 run attribute @s minecraft:knockback_resistance base set 0.85
execute if score #a_kb bw matches 0..0 run attribute @s minecraft:knockback_resistance base set 1.0
execute if score #a_hack bw matches 1 run attribute @s minecraft:fall_damage_multiplier base set 0
function bw:ai/equip
data modify storage bw:bot at4 set value "s4"
data modify storage bw:tmp rt.to set value "g4"
function bw:ai/route4
scoreboard players set @s bw.dest 1
