execute if score @s bw.team matches 1 run function bw:ai/buy1
execute if score @s bw.team matches 2 run function bw:ai/buy2
execute if score @s bw.team matches 3 run function bw:ai/buy3
execute if score @s bw.team matches 4 run function bw:ai/buy4
execute if score @s bw.team matches 5 run function bw:ai/buy5
execute if score @s bw.team matches 6 run function bw:ai/buy6
execute if score @s bw.team matches 7 run function bw:ai/buy7
function bw:ai/equip
playsound minecraft:block.note_block.pling player @a ~ ~ ~ 0.3 2
