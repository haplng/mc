scoreboard players operation @s bw.st = @s bw.pst
execute if score @s bw.st matches 3 run scoreboard players set @s bw.st 0
scoreboard players set @s bw.stuck 0
