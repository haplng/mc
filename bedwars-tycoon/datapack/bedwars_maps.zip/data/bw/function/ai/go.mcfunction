execute if score @s bw.team matches 1 positioned ~-0.7 ~-0.6 ~-0.7 if entity @e[type=minecraft:marker,tag=bw.g1,dx=0.4,dy=1.2,dz=0.4] run function bw:ai/next1
execute if score @s bw.team matches 2 positioned ~-0.7 ~-0.6 ~-0.7 if entity @e[type=minecraft:marker,tag=bw.g2,dx=0.4,dy=1.2,dz=0.4] run function bw:ai/next2
execute if score @s bw.team matches 3 positioned ~-0.7 ~-0.6 ~-0.7 if entity @e[type=minecraft:marker,tag=bw.g3,dx=0.4,dy=1.2,dz=0.4] run function bw:ai/next3
execute if score @s bw.team matches 4 positioned ~-0.7 ~-0.6 ~-0.7 if entity @e[type=minecraft:marker,tag=bw.g4,dx=0.4,dy=1.2,dz=0.4] run function bw:ai/next4
execute if score @s bw.team matches 5 positioned ~-0.7 ~-0.6 ~-0.7 if entity @e[type=minecraft:marker,tag=bw.g5,dx=0.4,dy=1.2,dz=0.4] run function bw:ai/next5
execute if score @s bw.team matches 6 positioned ~-0.7 ~-0.6 ~-0.7 if entity @e[type=minecraft:marker,tag=bw.g6,dx=0.4,dy=1.2,dz=0.4] run function bw:ai/next6
execute if score @s bw.team matches 7 positioned ~-0.7 ~-0.6 ~-0.7 if entity @e[type=minecraft:marker,tag=bw.g7,dx=0.4,dy=1.2,dz=0.4] run function bw:ai/next7
execute if score @s bw.team matches 1 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-1 ~ if entity @e[type=minecraft:marker,tag=bw.g1,distance=..0.55] run function bw:ai/next1
execute if score @s bw.team matches 1 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-2 ~ if entity @e[type=minecraft:marker,tag=bw.g1,distance=..0.55] run function bw:ai/next1
execute if score @s bw.team matches 1 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-3 ~ if entity @e[type=minecraft:marker,tag=bw.g1,distance=..0.55] run function bw:ai/next1
execute if score @s bw.team matches 2 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-1 ~ if entity @e[type=minecraft:marker,tag=bw.g2,distance=..0.55] run function bw:ai/next2
execute if score @s bw.team matches 2 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-2 ~ if entity @e[type=minecraft:marker,tag=bw.g2,distance=..0.55] run function bw:ai/next2
execute if score @s bw.team matches 2 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-3 ~ if entity @e[type=minecraft:marker,tag=bw.g2,distance=..0.55] run function bw:ai/next2
execute if score @s bw.team matches 3 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-1 ~ if entity @e[type=minecraft:marker,tag=bw.g3,distance=..0.55] run function bw:ai/next3
execute if score @s bw.team matches 3 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-2 ~ if entity @e[type=minecraft:marker,tag=bw.g3,distance=..0.55] run function bw:ai/next3
execute if score @s bw.team matches 3 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-3 ~ if entity @e[type=minecraft:marker,tag=bw.g3,distance=..0.55] run function bw:ai/next3
execute if score @s bw.team matches 4 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-1 ~ if entity @e[type=minecraft:marker,tag=bw.g4,distance=..0.55] run function bw:ai/next4
execute if score @s bw.team matches 4 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-2 ~ if entity @e[type=minecraft:marker,tag=bw.g4,distance=..0.55] run function bw:ai/next4
execute if score @s bw.team matches 4 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-3 ~ if entity @e[type=minecraft:marker,tag=bw.g4,distance=..0.55] run function bw:ai/next4
execute if score @s bw.team matches 5 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-1 ~ if entity @e[type=minecraft:marker,tag=bw.g5,distance=..0.55] run function bw:ai/next5
execute if score @s bw.team matches 5 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-2 ~ if entity @e[type=minecraft:marker,tag=bw.g5,distance=..0.55] run function bw:ai/next5
execute if score @s bw.team matches 5 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-3 ~ if entity @e[type=minecraft:marker,tag=bw.g5,distance=..0.55] run function bw:ai/next5
execute if score @s bw.team matches 6 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-1 ~ if entity @e[type=minecraft:marker,tag=bw.g6,distance=..0.55] run function bw:ai/next6
execute if score @s bw.team matches 6 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-2 ~ if entity @e[type=minecraft:marker,tag=bw.g6,distance=..0.55] run function bw:ai/next6
execute if score @s bw.team matches 6 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-3 ~ if entity @e[type=minecraft:marker,tag=bw.g6,distance=..0.55] run function bw:ai/next6
execute if score @s bw.team matches 7 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-1 ~ if entity @e[type=minecraft:marker,tag=bw.g7,distance=..0.55] run function bw:ai/next7
execute if score @s bw.team matches 7 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-2 ~ if entity @e[type=minecraft:marker,tag=bw.g7,distance=..0.55] run function bw:ai/next7
execute if score @s bw.team matches 7 if score @s bw.st matches 2 if predicate bw:ground positioned ~ ~-3 ~ if entity @e[type=minecraft:marker,tag=bw.g7,distance=..0.55] run function bw:ai/next7
execute if score @s bw.team matches 1 if score @s bw.st matches 2 if predicate bw:ground if data storage bw:bot r1[1] positioned ~-0.6 ~-30 ~-0.6 if entity @e[type=minecraft:marker,tag=bw.g1,dx=0.2,dy=25.5,dz=0.2] run function bw:ai/next1
execute if score @s bw.team matches 2 if score @s bw.st matches 2 if predicate bw:ground if data storage bw:bot r2[1] positioned ~-0.6 ~-30 ~-0.6 if entity @e[type=minecraft:marker,tag=bw.g2,dx=0.2,dy=25.5,dz=0.2] run function bw:ai/next2
execute if score @s bw.team matches 3 if score @s bw.st matches 2 if predicate bw:ground if data storage bw:bot r3[1] positioned ~-0.6 ~-30 ~-0.6 if entity @e[type=minecraft:marker,tag=bw.g3,dx=0.2,dy=25.5,dz=0.2] run function bw:ai/next3
execute if score @s bw.team matches 4 if score @s bw.st matches 2 if predicate bw:ground if data storage bw:bot r4[1] positioned ~-0.6 ~-30 ~-0.6 if entity @e[type=minecraft:marker,tag=bw.g4,dx=0.2,dy=25.5,dz=0.2] run function bw:ai/next4
execute if score @s bw.team matches 5 if score @s bw.st matches 2 if predicate bw:ground if data storage bw:bot r5[1] positioned ~-0.6 ~-30 ~-0.6 if entity @e[type=minecraft:marker,tag=bw.g5,dx=0.2,dy=25.5,dz=0.2] run function bw:ai/next5
execute if score @s bw.team matches 6 if score @s bw.st matches 2 if predicate bw:ground if data storage bw:bot r6[1] positioned ~-0.6 ~-30 ~-0.6 if entity @e[type=minecraft:marker,tag=bw.g6,dx=0.2,dy=25.5,dz=0.2] run function bw:ai/next6
execute if score @s bw.team matches 7 if score @s bw.st matches 2 if predicate bw:ground if data storage bw:bot r7[1] positioned ~-0.6 ~-30 ~-0.6 if entity @e[type=minecraft:marker,tag=bw.g7,dx=0.2,dy=25.5,dz=0.2] run function bw:ai/next7
execute unless score @s bw.st matches 2 run return 0
execute if score @s bw.team matches 1 if score @s bw.off matches 0 if predicate bw:ground positioned ~-0.6 ~-30 ~-0.6 if entity @e[type=minecraft:marker,tag=bw.g1,dx=0.2,dy=25.5,dz=0.2] run function bw:ai/roof
execute if score @s bw.team matches 2 if score @s bw.off matches 0 if predicate bw:ground positioned ~-0.6 ~-30 ~-0.6 if entity @e[type=minecraft:marker,tag=bw.g2,dx=0.2,dy=25.5,dz=0.2] run function bw:ai/roof
execute if score @s bw.team matches 3 if score @s bw.off matches 0 if predicate bw:ground positioned ~-0.6 ~-30 ~-0.6 if entity @e[type=minecraft:marker,tag=bw.g3,dx=0.2,dy=25.5,dz=0.2] run function bw:ai/roof
execute if score @s bw.team matches 4 if score @s bw.off matches 0 if predicate bw:ground positioned ~-0.6 ~-30 ~-0.6 if entity @e[type=minecraft:marker,tag=bw.g4,dx=0.2,dy=25.5,dz=0.2] run function bw:ai/roof
execute if score @s bw.team matches 5 if score @s bw.off matches 0 if predicate bw:ground positioned ~-0.6 ~-30 ~-0.6 if entity @e[type=minecraft:marker,tag=bw.g5,dx=0.2,dy=25.5,dz=0.2] run function bw:ai/roof
execute if score @s bw.team matches 6 if score @s bw.off matches 0 if predicate bw:ground positioned ~-0.6 ~-30 ~-0.6 if entity @e[type=minecraft:marker,tag=bw.g6,dx=0.2,dy=25.5,dz=0.2] run function bw:ai/roof
execute if score @s bw.team matches 7 if score @s bw.off matches 0 if predicate bw:ground positioned ~-0.6 ~-30 ~-0.6 if entity @e[type=minecraft:marker,tag=bw.g7,dx=0.2,dy=25.5,dz=0.2] run function bw:ai/roof
execute if score @s bw.off matches 1.. run return run function bw:ai/walkoff
execute if score @s bw.team matches 1 facing entity @e[type=minecraft:marker,tag=bw.g1,limit=1] feet rotated ~ 0 run function bw:ai/walk {i:1}
execute if score @s bw.team matches 2 facing entity @e[type=minecraft:marker,tag=bw.g2,limit=1] feet rotated ~ 0 run function bw:ai/walk {i:2}
execute if score @s bw.team matches 3 facing entity @e[type=minecraft:marker,tag=bw.g3,limit=1] feet rotated ~ 0 run function bw:ai/walk {i:3}
execute if score @s bw.team matches 4 facing entity @e[type=minecraft:marker,tag=bw.g4,limit=1] feet rotated ~ 0 run function bw:ai/walk {i:4}
execute if score @s bw.team matches 5 facing entity @e[type=minecraft:marker,tag=bw.g5,limit=1] feet rotated ~ 0 run function bw:ai/walk {i:5}
execute if score @s bw.team matches 6 facing entity @e[type=minecraft:marker,tag=bw.g6,limit=1] feet rotated ~ 0 run function bw:ai/walk {i:6}
execute if score @s bw.team matches 7 facing entity @e[type=minecraft:marker,tag=bw.g7,limit=1] feet rotated ~ 0 run function bw:ai/walk {i:7}
