execute store result storage bw:tmp loot.fe int 1 run scoreboard players get #wfe5 bw
execute store result storage bw:tmp loot.au int 1 run scoreboard players get #wau5 bw
execute store result storage bw:tmp loot.di int 1 run scoreboard players get #wdi5 bw
execute store result storage bw:tmp loot.em int 1 run scoreboard players get #wem5 bw
execute if score #wfe5 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_fe with storage bw:tmp loot
execute if score #wau5 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_au with storage bw:tmp loot
execute if score #wdi5 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_di with storage bw:tmp loot
execute if score #wem5 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_em with storage bw:tmp loot
execute if score #kt bw matches 1 run scoreboard players operation #wfe1 bw += #wfe5 bw
execute if score #kt bw matches 1 run scoreboard players operation #wau1 bw += #wau5 bw
execute if score #kt bw matches 1 run scoreboard players operation #wdi1 bw += #wdi5 bw
execute if score #kt bw matches 1 run scoreboard players operation #wem1 bw += #wem5 bw
execute if score #kt bw matches 2 run scoreboard players operation #wfe2 bw += #wfe5 bw
execute if score #kt bw matches 2 run scoreboard players operation #wau2 bw += #wau5 bw
execute if score #kt bw matches 2 run scoreboard players operation #wdi2 bw += #wdi5 bw
execute if score #kt bw matches 2 run scoreboard players operation #wem2 bw += #wem5 bw
execute if score #kt bw matches 3 run scoreboard players operation #wfe3 bw += #wfe5 bw
execute if score #kt bw matches 3 run scoreboard players operation #wau3 bw += #wau5 bw
execute if score #kt bw matches 3 run scoreboard players operation #wdi3 bw += #wdi5 bw
execute if score #kt bw matches 3 run scoreboard players operation #wem3 bw += #wem5 bw
execute if score #kt bw matches 4 run scoreboard players operation #wfe4 bw += #wfe5 bw
execute if score #kt bw matches 4 run scoreboard players operation #wau4 bw += #wau5 bw
execute if score #kt bw matches 4 run scoreboard players operation #wdi4 bw += #wdi5 bw
execute if score #kt bw matches 4 run scoreboard players operation #wem4 bw += #wem5 bw
execute if score #kt bw matches 6 run scoreboard players operation #wfe6 bw += #wfe5 bw
execute if score #kt bw matches 6 run scoreboard players operation #wau6 bw += #wau5 bw
execute if score #kt bw matches 6 run scoreboard players operation #wdi6 bw += #wdi5 bw
execute if score #kt bw matches 6 run scoreboard players operation #wem6 bw += #wem5 bw
execute if score #kt bw matches 7 run scoreboard players operation #wfe7 bw += #wfe5 bw
execute if score #kt bw matches 7 run scoreboard players operation #wau7 bw += #wau5 bw
execute if score #kt bw matches 7 run scoreboard players operation #wdi7 bw += #wdi5 bw
execute if score #kt bw matches 7 run scoreboard players operation #wem7 bw += #wem5 bw
scoreboard players set #wfe5 bw 0
scoreboard players set #wau5 bw 0
scoreboard players set #wdi5 bw 0
scoreboard players set #wem5 bw 0
scoreboard players set #bsw5 bw 0
execute if score #btl5 bw matches 2.. run scoreboard players remove #btl5 bw 1
execute if score #final bw matches 0 run scoreboard players set #bres5 bw 100
execute if score #final bw matches 1 run tellraw @a [{text:""},{text:"<",color:"gray"},{selector:"@s"},{text:"> gg",color:"gray"}]
