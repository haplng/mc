execute unless entity @e[tag=bw.foe,distance=..16] run return run function bw:ai/disengage
scoreboard players add @s bw.ft 1
execute if score @s bw.ft matches 120.. run return run function bw:ai/giveup
rotate @s facing entity @e[tag=bw.foe,limit=1] eyes
execute if entity @e[tag=bw.foe,distance=2.0..] run scoreboard players set @s bw.mf 3
execute if score @s bw.slow matches 1.. if score @s bw.mf matches 3 run scoreboard players set @s bw.mf 4
execute if score #a_strafe bw matches 1 if entity @e[tag=bw.foe,distance=..4.5] run scoreboard players operation @s bw.ms = @s bw.strafe
execute if score @s bw.t2 matches 0 run function bw:ai/flip
scoreboard players set #drop bw 0
execute positioned ~-64 ~-50 ~-64 if entity @e[tag=bw.foe,dx=128,dy=48.4,dz=128] run scoreboard players set #drop bw 1
execute positioned ~-64 ~-50 ~-64 if entity @e[tag=bw.foe,dx=128,dy=47.4,dz=128] run scoreboard players set #high bw 1
execute rotated as @s rotated ~ 0 run function bw:ai/feet
execute if score @s bw.br matches 1.. run scoreboard players set @s bw.ms 0
execute if score @s bw.team matches 1 if score #bga1 bw matches 1.. if score @s bw.hp matches ..290 run function bw:ai/gapple1
execute if score @s bw.team matches 2 if score #bga2 bw matches 1.. if score @s bw.hp matches ..290 run function bw:ai/gapple2
execute if score @s bw.team matches 3 if score #bga3 bw matches 1.. if score @s bw.hp matches ..290 run function bw:ai/gapple3
execute if score @s bw.team matches 4 if score #bga4 bw matches 1.. if score @s bw.hp matches ..290 run function bw:ai/gapple4
execute if score @s bw.team matches 5 if score #bga5 bw matches 1.. if score @s bw.hp matches ..290 run function bw:ai/gapple5
execute if score @s bw.team matches 6 if score #bga6 bw matches 1.. if score @s bw.hp matches ..290 run function bw:ai/gapple6
execute if score @s bw.team matches 7 if score #bga7 bw matches 1.. if score @s bw.hp matches ..290 run function bw:ai/gapple7
execute if score @s bw.team matches 1 if score #bfb1 bw matches 1.. if score @s bw.fbc matches 0 if entity @e[tag=bw.foe,distance=6..14] run function bw:ai/throw1
execute if score @s bw.team matches 2 if score #bfb2 bw matches 1.. if score @s bw.fbc matches 0 if entity @e[tag=bw.foe,distance=6..14] run function bw:ai/throw2
execute if score @s bw.team matches 3 if score #bfb3 bw matches 1.. if score @s bw.fbc matches 0 if entity @e[tag=bw.foe,distance=6..14] run function bw:ai/throw3
execute if score @s bw.team matches 4 if score #bfb4 bw matches 1.. if score @s bw.fbc matches 0 if entity @e[tag=bw.foe,distance=6..14] run function bw:ai/throw4
execute if score @s bw.team matches 5 if score #bfb5 bw matches 1.. if score @s bw.fbc matches 0 if entity @e[tag=bw.foe,distance=6..14] run function bw:ai/throw5
execute if score @s bw.team matches 6 if score #bfb6 bw matches 1.. if score @s bw.fbc matches 0 if entity @e[tag=bw.foe,distance=6..14] run function bw:ai/throw6
execute if score @s bw.team matches 7 if score #bfb7 bw matches 1.. if score @s bw.fbc matches 0 if entity @e[tag=bw.foe,distance=6..14] run function bw:ai/throw7
execute if score #lvl bw matches 5.. if score @s bw.bgc matches 0 if entity @e[tag=bw.foe,distance=4..11] run function bw:ai/bug
execute if score @s bw.atk matches 0 if score #a_reach bw matches 270 if entity @e[tag=bw.foe,distance=..2.95] run function bw:ai/swing
execute if score @s bw.atk matches 0 if score #a_reach bw matches 280 if entity @e[tag=bw.foe,distance=..3.05] run function bw:ai/swing
execute if score @s bw.atk matches 0 if score #a_reach bw matches 290 if entity @e[tag=bw.foe,distance=..3.15] run function bw:ai/swing
execute if score @s bw.atk matches 0 if score #a_reach bw matches 300 if entity @e[tag=bw.foe,distance=..3.25] run function bw:ai/swing
execute if score @s bw.atk matches 0 if score #a_reach bw matches 310 if entity @e[tag=bw.foe,distance=..3.35] run function bw:ai/swing
execute if score @s bw.atk matches 0 if score #a_reach bw matches 320 if entity @e[tag=bw.foe,distance=..3.45] run function bw:ai/swing
execute if score @s bw.atk matches 0 if score #a_reach bw matches 330 if entity @e[tag=bw.foe,distance=..3.55] run function bw:ai/swing
execute if score @s bw.atk matches 0 if score #a_reach bw matches 340 if entity @e[tag=bw.foe,distance=..3.65] run function bw:ai/swing
execute if score @s bw.atk matches 0 if score #a_reach bw matches 350 if entity @e[tag=bw.foe,distance=..3.75] run function bw:ai/swing
execute if score @s bw.atk matches 0 if score #a_reach bw matches 370 if entity @e[tag=bw.foe,distance=..3.95] run function bw:ai/swing
execute if score @s bw.atk matches 0 if score #a_reach bw matches 380 if entity @e[tag=bw.foe,distance=..4.05] run function bw:ai/swing
execute if score @s bw.atk matches 0 if score #a_reach bw matches 400 if entity @e[tag=bw.foe,distance=..4.25] run function bw:ai/swing
execute if score @s bw.atk matches 0 if score #a_reach bw matches 420 if entity @e[tag=bw.foe,distance=..4.45] run function bw:ai/swing
execute if score @s bw.atk matches 0 if score #a_reach bw matches 450 if entity @e[tag=bw.foe,distance=..4.75] run function bw:ai/swing
