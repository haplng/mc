scoreboard players operation @s bw.avs *= #-1 bw
scoreboard players add @s bw.avf 1
