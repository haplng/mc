scoreboard players set @s bw.st 4
scoreboard players set @s bw.t1 500
scoreboard players set @s bw.mine 0
execute store result storage bw:tmp sg.j int 1 run scoreboard players get @s bw.tgt
data modify storage bw:tmp sg.m set from storage bw:ai ctx.m
execute store result storage bw:tmp sg.i int 1 run scoreboard players get @s bw.team
function bw:ai/siege1 with storage bw:tmp sg
