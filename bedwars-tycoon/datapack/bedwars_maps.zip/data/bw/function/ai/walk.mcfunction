scoreboard players set #drop bw 0
$execute if entity @e[type=minecraft:marker,tag=bw.g$(i),distance=..4.3] positioned ~-64 ~-50 ~-64 if entity @e[type=minecraft:marker,tag=bw.g$(i),dx=128,dy=48.4,dz=128] run scoreboard players set #drop bw 1
$execute positioned ~-128 ~-50 ~-128 if entity @e[type=minecraft:marker,tag=bw.g$(i),dx=256,dy=47.4,dz=256] run scoreboard players set #high bw 1
$execute if entity @e[type=minecraft:marker,tag=bw.g$(i),distance=..16] positioned ~-0.6 ~0.8 ~-0.6 if entity @e[type=minecraft:marker,tag=bw.g$(i),dx=0.2,dy=15,dz=0.2] run return run execute at @s run function bw:ai/tower
$execute if entity @e[type=minecraft:marker,tag=bw.g$(i),distance=..16] positioned ~-1.7 ~1.4 ~-1.7 if entity @e[type=minecraft:marker,tag=bw.g$(i),dx=2.4,dy=15,dz=2.4] run return run execute at @s run function bw:ai/tower
execute if score @s bw.av matches 1.. run return run function bw:ai/around
rotate @s ~ 0
scoreboard players operation @s bw.mf = #a_walk bw
execute if score @s bw.slow matches 1.. run scoreboard players set @s bw.mf 4
function bw:ai/feet
$execute if score #a_walk bw matches 3 if score #high bw matches 0 if score @s bw.br matches 0 if score @s bw.jc matches 0 if predicate bw:ground unless entity @e[type=minecraft:marker,tag=bw.g$(i),distance=..4] unless block ^ ^-1 ^1.5 #bw:open unless block ^ ^-1 ^3 #bw:open if block ^ ^2 ^1 #bw:open run function bw:ai/hop
function bw:ai/unstick
