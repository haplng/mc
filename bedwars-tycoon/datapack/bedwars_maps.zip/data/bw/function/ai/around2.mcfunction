rotate @s ~ 0
execute unless block ^ ^1 ^0.7 #bw:open unless block ^ ^1 ^0.7 #bw:breakable run return run function bw:ai/flipside
execute unless block ^ ^ ^0.7 #bw:open unless block ^ ^ ^0.7 #bw:breakable unless block ~ ~2 ~ #bw:open run return run function bw:ai/flipside
execute unless block ^ ^ ^0.7 #bw:open unless block ^ ^ ^0.7 #bw:breakable if score #high bw matches 1 run return run function bw:ai/flipside
function bw:ai/feet
