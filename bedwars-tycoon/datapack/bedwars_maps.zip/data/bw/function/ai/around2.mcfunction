rotate @s ~ 0
execute unless block ^ ^1 ^0.7 #bw:open positioned ^ ^1 ^0.7 unless predicate bw:built run return run function bw:ai/flipside
execute unless block ^ ^ ^0.7 #bw:open unless block ~ ~2 ~ #bw:open positioned ^ ^ ^0.7 unless predicate bw:built run return run function bw:ai/flipside
execute unless block ^ ^ ^0.7 #bw:open if score #high bw matches 1 positioned ^ ^ ^0.7 unless predicate bw:built run return run function bw:ai/flipside
function bw:ai/feet
