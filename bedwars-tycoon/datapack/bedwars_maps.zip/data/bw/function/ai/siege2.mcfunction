rotate @s ~ ~
$execute unless entity @e[type=minecraft:marker,tag=bw.g$(i),distance=..3.6] run scoreboard players set @s bw.mf 2
$execute unless entity @e[type=minecraft:marker,tag=bw.g$(i),distance=..3.6] anchored feet rotated ~ 0 run function bw:ai/feet
$execute unless entity @e[type=minecraft:marker,tag=bw.g$(i),distance=..3.6] run return 0
scoreboard players set #rs bw 0
scoreboard players set #hit bw 0
execute anchored eyes positioned ^ ^ ^0.3 run function bw:ai/ray
execute if score #hit bw matches 0 run scoreboard players set @s bw.mf 1
