scoreboard players operation #wfe6 bw += #pfe6 bw
scoreboard players set #pfe6 bw 0
scoreboard players operation #wau6 bw += #pau6 bw
scoreboard players set #pau6 bw 0
scoreboard players operation #wem6 bw += #pem6 bw
scoreboard players set #pem6 bw 0
