execute unless entity @e[type=minecraft:marker,tag=bw.gen.iron,tag=bw.t.pink,distance=..6] run return 0
scoreboard players operation #wfe6 bw += #pfe6 bw
scoreboard players set #pfe6 bw 0
scoreboard players operation #wau6 bw += #pau6 bw
scoreboard players set #pau6 bw 0
scoreboard players operation #wem6 bw += #pem6 bw
scoreboard players set #pem6 bw 0
