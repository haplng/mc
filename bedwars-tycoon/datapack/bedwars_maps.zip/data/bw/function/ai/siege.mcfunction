scoreboard players set #gone bw 0
execute if score @s bw.tgt matches 0 if score #bed0 bw matches 0 run scoreboard players set #gone bw 1
execute if score @s bw.tgt matches 1 if score #bed1 bw matches 0 run scoreboard players set #gone bw 1
execute if score @s bw.tgt matches 2 if score #bed2 bw matches 0 run scoreboard players set #gone bw 1
execute if score @s bw.tgt matches 3 if score #bed3 bw matches 0 run scoreboard players set #gone bw 1
execute if score @s bw.tgt matches 4 if score #bed4 bw matches 0 run scoreboard players set #gone bw 1
execute if score @s bw.tgt matches 5 if score #bed5 bw matches 0 run scoreboard players set #gone bw 1
execute if score @s bw.tgt matches 6 if score #bed6 bw matches 0 run scoreboard players set #gone bw 1
execute if score @s bw.tgt matches 7 if score #bed7 bw matches 0 run scoreboard players set #gone bw 1
execute if score #gone bw matches 1 run return run scoreboard players set @s bw.st 0
execute if score @s bw.t1 matches 0 run return run scoreboard players set @s bw.st 0
execute if score @s bw.team matches 1 anchored eyes facing entity @e[type=minecraft:marker,tag=bw.g1,limit=1] feet run function bw:ai/siege2 {i:1}
execute if score @s bw.team matches 2 anchored eyes facing entity @e[type=minecraft:marker,tag=bw.g2,limit=1] feet run function bw:ai/siege2 {i:2}
execute if score @s bw.team matches 3 anchored eyes facing entity @e[type=minecraft:marker,tag=bw.g3,limit=1] feet run function bw:ai/siege2 {i:3}
execute if score @s bw.team matches 4 anchored eyes facing entity @e[type=minecraft:marker,tag=bw.g4,limit=1] feet run function bw:ai/siege2 {i:4}
execute if score @s bw.team matches 5 anchored eyes facing entity @e[type=minecraft:marker,tag=bw.g5,limit=1] feet run function bw:ai/siege2 {i:5}
execute if score @s bw.team matches 6 anchored eyes facing entity @e[type=minecraft:marker,tag=bw.g6,limit=1] feet run function bw:ai/siege2 {i:6}
execute if score @s bw.team matches 7 anchored eyes facing entity @e[type=minecraft:marker,tag=bw.g7,limit=1] feet run function bw:ai/siege2 {i:7}
