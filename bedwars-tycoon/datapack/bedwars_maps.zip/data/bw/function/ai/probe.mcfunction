execute unless block ^ ^1 ^0.7 #bw:open positioned ^ ^1 ^0.7 run return run function bw:ai/wall
execute if block ^0.32 ^1 ^0.55 #bw:breakable positioned ^0.32 ^1 ^0.55 run return run function bw:ai/wall
execute if block ^-0.32 ^1 ^0.55 #bw:breakable positioned ^-0.32 ^1 ^0.55 run return run function bw:ai/wall
execute unless block ^0.32 ^1 ^0.55 #bw:open if block ^-0.32 ^1 ^0.55 #bw:open run return run scoreboard players set @s bw.ms -1
execute unless block ^-0.32 ^1 ^0.55 #bw:open if block ^0.32 ^1 ^0.55 #bw:open run return run scoreboard players set @s bw.ms 1
execute unless block ^0.32 ^1 ^0.55 #bw:open positioned ^0.32 ^1 ^0.55 run return run function bw:ai/wall
