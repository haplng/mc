scoreboard players operation #wfe4 bw += #pfe4 bw
scoreboard players set #pfe4 bw 0
scoreboard players operation #wau4 bw += #pau4 bw
scoreboard players set #pau4 bw 0
scoreboard players operation #wem4 bw += #pem4 bw
scoreboard players set #pem4 bw 0
