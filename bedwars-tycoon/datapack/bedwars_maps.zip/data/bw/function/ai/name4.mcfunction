$data modify storage bw:ai n4 set from storage bw:ai names[$(k)]
