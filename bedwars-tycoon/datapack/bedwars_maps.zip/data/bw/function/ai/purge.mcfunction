tag @e[type=minecraft:mannequin,tag=bw.round] remove bw.bot
tag @e[type=minecraft:mannequin,tag=bw.round] remove bw.fighter
tp @e[type=minecraft:mannequin,tag=bw.round] 0 -400 0
kill @e[type=minecraft:mannequin,tag=bw.round]
