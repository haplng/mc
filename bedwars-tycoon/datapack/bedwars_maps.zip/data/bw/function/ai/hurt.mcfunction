execute unless entity @s[tag=bw.bot] run return 0
scoreboard players set #att bw -1
execute on attacker run scoreboard players operation #att bw = @s bw.team
execute if score #att bw matches 0.. run scoreboard players operation @s bw.lh = #att bw
execute if score #att bw matches 0.. run scoreboard players set @s bw.lht 200
scoreboard players set @s bw.ft 0
scoreboard players set @s bw.calm 0
execute unless score @s bw.st matches 3 run function bw:ai/engage
tag @a remove bw.hitter
execute on attacker run tag @s[type=minecraft:player] add bw.hitter
execute if entity @a[tag=bw.hitter] run function bw:hack/displace
