$data modify storage bw:bot r5 set from storage bw:nav $(m).$(at)_$(to)
$data modify storage bw:bot to5 set value "$(to)"
$execute if data storage bw:bot r5[0] run data modify storage bw:bot r5 prepend from storage bw:nav $(m).n_$(at)
