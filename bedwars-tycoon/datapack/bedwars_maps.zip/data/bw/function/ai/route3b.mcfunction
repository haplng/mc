$data modify storage bw:bot r3 set from storage bw:nav $(m).$(at)_$(to)
$data modify storage bw:bot to3 set value "$(to)"
$execute if data storage bw:bot r3[0] run data modify storage bw:bot r3 prepend from storage bw:nav $(m).n_$(at)
