execute if score #bsw1 bw matches 0 if score #wfe1 bw matches 10.. run function bw:ai/b/1_0
execute if score #lvl bw matches 1.. if score #bar1 bw matches 0 if score #wfe1 bw matches 40.. run function bw:ai/b/1_1
execute if score #lvl bw matches 2.. if score #btl1 bw matches 0 if score #wfe1 bw matches 20.. run function bw:ai/b/1_2
execute if score #lvl bw matches 3.. if score #bsw1 bw matches ..1 if score #wau1 bw matches 7.. run function bw:ai/b/1_3
execute if score #lvl bw matches 4.. if score #bar1 bw matches ..1 if score #wau1 bw matches 12.. run function bw:ai/b/1_4
execute if score #lvl bw matches 5.. if score #btl1 bw matches 1 if score #wfe1 bw matches 10.. if score #wau1 bw matches 3.. run function bw:ai/b/1_5
execute if score #lvl bw matches 6.. if score #bsw1 bw matches ..2 if score #wem1 bw matches 4.. run function bw:ai/b/1_6
execute if score #lvl bw matches 8.. if score #bar1 bw matches ..2 if score #wem1 bw matches 6.. run function bw:ai/b/1_7
execute if score #lvl bw matches 9.. if score #btl1 bw matches 2 if score #wau1 bw matches 6.. run function bw:ai/b/1_8
execute if score #lvl bw matches 6.. if score #bga1 bw matches ..1 if score #wau1 bw matches 3.. run function bw:ai/b/1_9
execute if score #lvl bw matches 7.. if score #bfb1 bw matches ..1 if score #wfe1 bw matches 40.. run function bw:ai/b/1_10
execute if score #lvl bw matches 5.. if score #sharp1 bw matches 0 if score #wdi1 bw matches 4.. run function bw:ai/b/1_11
execute if score #lvl bw matches 6.. if score #prot1 bw matches 0 if score #wdi1 bw matches 2.. run function bw:ai/b/1_12
execute if score #lvl bw matches 8.. if score #prot1 bw matches 1 if score #wdi1 bw matches 4.. run function bw:ai/b/1_13
execute if score #lvl bw matches 10.. if score #prot1 bw matches 2 if score #wdi1 bw matches 8.. run function bw:ai/b/1_14
execute if score #lvl bw matches 12.. if score #prot1 bw matches 3 if score #wdi1 bw matches 16.. run function bw:ai/b/1_15
execute if score #lvl bw matches 7.. if score #fl1 bw matches 0 if score #wdi1 bw matches 2.. run function bw:ai/b/1_16
execute if score #lvl bw matches 10.. if score #fl1 bw matches 1 if score #wdi1 bw matches 4.. run function bw:ai/b/1_17
execute if score #lvl bw matches 8.. if score #tqn1 bw matches 0 if score #wdi1 bw matches 1.. run function bw:ai/b/1_18
execute if score #lvl bw matches 11.. if score #tqn1 bw matches 1 if score #wdi1 bw matches 2.. run function bw:ai/b/1_19
execute if score #lvl bw matches 13.. if score #dbuff1 bw matches 0 if score #wdi1 bw matches 5.. run function bw:ai/b/1_20
