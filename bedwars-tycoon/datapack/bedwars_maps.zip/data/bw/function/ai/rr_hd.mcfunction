execute if score @s bw.team matches 1 store result score #hd bw run data get storage bw:bot ho1.dest
execute if score @s bw.team matches 2 store result score #hd bw run data get storage bw:bot ho2.dest
execute if score @s bw.team matches 3 store result score #hd bw run data get storage bw:bot ho3.dest
execute if score @s bw.team matches 4 store result score #hd bw run data get storage bw:bot ho4.dest
execute if score @s bw.team matches 5 store result score #hd bw run data get storage bw:bot ho5.dest
execute if score @s bw.team matches 6 store result score #hd bw run data get storage bw:bot ho6.dest
execute if score @s bw.team matches 7 store result score #hd bw run data get storage bw:bot ho7.dest
