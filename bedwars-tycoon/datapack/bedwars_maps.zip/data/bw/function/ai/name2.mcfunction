$data modify storage bw:ai n2 set from storage bw:ai names[$(k)]
