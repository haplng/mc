$data modify storage bw:ai n2 set from storage bw:ai pool[$(k)]
$data remove storage bw:ai pool[$(k)]
