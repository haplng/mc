scoreboard players remove #wfe5 bw 120
function bw:mob/botgolem
