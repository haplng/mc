$function bw:ai/to3 {to:"a$(j)",dest:4}
