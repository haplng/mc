execute at @s run function bw:ai/reroute1
