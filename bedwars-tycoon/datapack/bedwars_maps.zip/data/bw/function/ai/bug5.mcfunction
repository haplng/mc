scoreboard players remove #wfe5 bw 24
scoreboard players set @s bw.bgc 400
swing @s mainhand
execute anchored eyes facing entity @e[tag=bw.foe,limit=1] eyes positioned ^ ^ ^0.7 rotated ~ ~-7 run function bw:mob/throw
