execute if function bw:ai/retrace run return 0
scoreboard players set @s bw.off 60
scoreboard players set @s bw.offa 0
