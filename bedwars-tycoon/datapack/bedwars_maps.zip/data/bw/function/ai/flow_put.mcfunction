scoreboard players operation #x2 bw = #fx bw
scoreboard players operation #x2 bw += #fx bw
scoreboard players add #x2 bw 1
scoreboard players operation #z2 bw = #fz bw
scoreboard players operation #z2 bw += #fz bw
scoreboard players add #z2 bw 1
data modify storage bw:tmp fl.path append value [0d,0d,0d]
execute store result storage bw:tmp fl.path[-1][0] double 0.5 run scoreboard players get #x2 bw
execute store result storage bw:tmp fl.path[-1][1] double 1 run scoreboard players get #fy bw
execute store result storage bw:tmp fl.path[-1][2] double 0.5 run scoreboard players get #z2 bw
execute store result storage bw:tmp fl.x int 1 run scoreboard players get #fx bw
execute store result storage bw:tmp fl.y int 1 run scoreboard players get #fy bw
execute store result storage bw:tmp fl.z int 1 run scoreboard players get #fz bw
