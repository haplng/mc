scoreboard players remove #bres1 bw 1
execute if score #bres1 bw matches 0 if score #state bw matches 3 run function bw:ai/spawn1
