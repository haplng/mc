$execute store result score #fc bw run data get storage bwflow:$(f) $(m)."$(x) $(y) $(z)"
