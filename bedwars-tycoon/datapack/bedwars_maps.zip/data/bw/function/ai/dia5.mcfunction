execute if score #map bw matches 1 run function bw:ai/to5 {to:"d0",dest:5}
execute if score #map bw matches 2 run function bw:ai/to5 {to:"d0",dest:5}
execute if score #map bw matches 3 run function bw:ai/to5 {to:"d0",dest:5}
execute if score #map bw matches 4 run function bw:ai/to5 {to:"d0",dest:5}
execute if score #map bw matches 5 run function bw:ai/to5 {to:"d0",dest:5}
