scoreboard players remove #bres2 bw 1
execute if score #bres2 bw matches 0 if score #state bw matches 3 run function bw:ai/spawn2
