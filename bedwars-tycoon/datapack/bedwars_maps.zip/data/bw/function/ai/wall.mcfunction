execute if block ~ ~ ~ #bw:breakable run return run function bw:ai/mine
scoreboard players add @s bw.stuck 2
execute if score @s bw.av matches 0 run function bw:ai/avoid
