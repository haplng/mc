scoreboard players operation @s bw.pst = @s bw.st
scoreboard players set @s bw.st 3
scoreboard players set @s bw.trc 8
scoreboard players set @s bw.tx -99999
scoreboard players set @s bw.mine 0
scoreboard players set @s bw.ft 0
execute store result score @s bw.strafe run random value 0..1
execute if score @s bw.strafe matches 0 run scoreboard players set @s bw.strafe -1
execute store result score @s bw.t2 run random value 12..30
