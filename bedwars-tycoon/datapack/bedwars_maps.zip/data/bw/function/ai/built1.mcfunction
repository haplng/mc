scoreboard players set #bdone1 bw 1
scoreboard players set @s bw.st 0
