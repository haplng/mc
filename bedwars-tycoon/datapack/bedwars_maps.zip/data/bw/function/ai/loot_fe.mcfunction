$give @s minecraft:iron_ingot $(fe)
$tellraw @s {text:"+$(fe) 철",color:"white"}
