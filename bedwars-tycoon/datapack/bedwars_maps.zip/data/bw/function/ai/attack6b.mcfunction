$function bw:ai/to6 {to:"a$(j)",dest:4}
