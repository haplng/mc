$function bw:ai/to4 {to:"a$(j)",dest:4}
