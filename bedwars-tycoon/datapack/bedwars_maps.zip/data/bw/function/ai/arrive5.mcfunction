data modify storage bw:bot at5 set from storage bw:bot to5
function bw:ai/arrive
