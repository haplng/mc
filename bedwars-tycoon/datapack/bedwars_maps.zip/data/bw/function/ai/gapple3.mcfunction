scoreboard players remove #bga3 bw 1
effect give @s minecraft:regeneration 5 1
effect give @s minecraft:absorption 120 0
playsound minecraft:entity.player.burp player @a ~ ~ ~ 0.8 1
particle minecraft:item{item:"minecraft:golden_apple"} ~ ~1.5 ~ 0.2 0.2 0.2 0.05 12
