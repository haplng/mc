scoreboard players set @s bw.st 1
scoreboard players operation @s bw.t1 = #a_think bw
execute unless data storage bw:bot {at1:"g1"} unless data storage bw:bot {at1:"k1"} run return run function bw:ai/away1
execute if data storage bw:bot {at1:"k1"} run return run function bw:ai/to1 {to:"g1",dest:1}
execute if score #bsw1 bw matches 0 if score #wfe1 bw < #a_wait bw run return 0
scoreboard players set #can bw 0
execute if score #bsw1 bw matches 0 if score #wfe1 bw matches 10.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 1.. if score #bar1 bw matches 0 if score #wfe1 bw matches 40.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 2.. if score #btl1 bw matches 0 if score #wfe1 bw matches 20.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 3.. if score #bsw1 bw matches ..1 if score #wau1 bw matches 7.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 4.. if score #bar1 bw matches ..1 if score #wau1 bw matches 12.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 5.. if score #btl1 bw matches 1 if score #wfe1 bw matches 10.. if score #wau1 bw matches 3.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 6.. if score #bsw1 bw matches ..2 if score #wem1 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 8.. if score #bar1 bw matches ..2 if score #wem1 bw matches 6.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 9.. if score #btl1 bw matches 2 if score #wau1 bw matches 6.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 6.. if score #bga1 bw matches ..1 if score #wau1 bw matches 3.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 7.. if score #bfb1 bw matches ..1 if score #wfe1 bw matches 40.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 5.. if score #sharp1 bw matches 0 if score #wdi1 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 6.. if score #prot1 bw matches 0 if score #wdi1 bw matches 2.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 8.. if score #prot1 bw matches 1 if score #wdi1 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 10.. if score #prot1 bw matches 2 if score #wdi1 bw matches 8.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 12.. if score #prot1 bw matches 3 if score #wdi1 bw matches 16.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 7.. if score #fl1 bw matches 0 if score #wdi1 bw matches 2.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 10.. if score #fl1 bw matches 1 if score #wdi1 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 8.. if score #tqn1 bw matches 0 if score #wdi1 bw matches 1.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 11.. if score #tqn1 bw matches 1 if score #wdi1 bw matches 2.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 13.. if score #dbuff1 bw matches 0 if score #wdi1 bw matches 5.. run scoreboard players set #can bw 1
execute if score #can bw matches 1 run return run function bw:ai/to1 {to:"k1",dest:2}
execute if score #bed1 bw matches 1 if score #bdone1 bw matches 0 if data storage bw:bot def1[0] run return run function bw:ai/to1 {to:"b1",dest:3}
execute store result score #rn bw run random value 1..100
execute if score #lvl bw matches 5.. if score #sec bw matches 60.. if score #rn bw matches ..30 run return run function bw:ai/dia1
function bw:ai/pick1
execute if score @s bw.tgt matches 0.. run return run function bw:ai/attack1
