function bw:ai/pick7
execute store result score #rn bw run random value 1..100
execute if data storage bw:bot {at7:"b7"} run return run function bw:ai/to7 {to:"g7",dest:1}
execute if score #wdi7 bw matches 2.. run return run function bw:ai/to7 {to:"g7",dest:1}
execute if score @s bw.hp matches ..300 run return run function bw:ai/to7 {to:"g7",dest:1}
execute if score @s bw.tgt matches 0.. if score #rn bw matches ..75 run return run function bw:ai/attack7
function bw:ai/to7 {to:"g7",dest:1}
