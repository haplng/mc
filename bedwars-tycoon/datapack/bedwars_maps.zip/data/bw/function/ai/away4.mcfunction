function bw:ai/pick4
execute store result score #rn bw run random value 1..100
execute if data storage bw:bot {at4:"b4"} run return run function bw:ai/to4 {to:"g4",dest:1}
execute if score #wdi4 bw matches 2.. run return run function bw:ai/to4 {to:"g4",dest:1}
execute if score @s bw.hp matches ..300 run return run function bw:ai/to4 {to:"g4",dest:1}
execute if score @s bw.tgt matches 0.. if score #rn bw matches ..75 run return run function bw:ai/attack4
function bw:ai/to4 {to:"g4",dest:1}
