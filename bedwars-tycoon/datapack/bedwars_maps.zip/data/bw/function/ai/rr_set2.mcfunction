execute unless score @s bw.dest matches 9 run data modify storage bw:bot ho2 set value {}
execute unless score @s bw.dest matches 9 run data modify storage bw:bot ho2.to set from storage bw:bot to2
execute unless score @s bw.dest matches 9 store result storage bw:bot ho2.dest int 1 run scoreboard players get @s bw.dest
data modify storage bw:bot r2 set from storage bw:tmp fl.path
data modify storage bw:bot to2 set from storage bw:tmp fl.hub
data modify storage bw:bot tr2 set value []
scoreboard players set @s bw.dest 9
scoreboard players set @s bw.st 2
data modify entity @e[type=minecraft:marker,tag=bw.g2,limit=1] Pos set from storage bw:bot r2[0]
