$data modify storage bw:bot r6 set from storage bw:nav $(m).$(at)_$(to)
$data modify storage bw:bot to6 set value "$(to)"
$execute if data storage bw:bot r6[0] run data modify storage bw:bot r6 prepend from storage bw:nav $(m).n_$(at)
