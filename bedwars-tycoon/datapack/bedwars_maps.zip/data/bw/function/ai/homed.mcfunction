execute if score @s bw.team matches 1 run function bw:ai/homed1
execute if score @s bw.team matches 2 run function bw:ai/homed2
execute if score @s bw.team matches 3 run function bw:ai/homed3
execute if score @s bw.team matches 4 run function bw:ai/homed4
execute if score @s bw.team matches 5 run function bw:ai/homed5
execute if score @s bw.team matches 6 run function bw:ai/homed6
execute if score @s bw.team matches 7 run function bw:ai/homed7
