scoreboard players operation #wfe3 bw += #pfe3 bw
scoreboard players set #pfe3 bw 0
scoreboard players operation #wau3 bw += #pau3 bw
scoreboard players set #pau3 bw 0
scoreboard players operation #wem3 bw += #pem3 bw
scoreboard players set #pem3 bw 0
