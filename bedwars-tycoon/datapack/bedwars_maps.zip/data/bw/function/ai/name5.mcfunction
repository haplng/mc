$data modify storage bw:ai n5 set from storage bw:ai names[$(k)]
