$data modify storage bw:ai n5 set from storage bw:ai pool[$(k)]
$data remove storage bw:ai pool[$(k)]
