scoreboard players add #rn bw 1
execute if score #rn bw matches 11.. run return 0
scoreboard players remove #rx bw 1
function bw:ai/ray1b
