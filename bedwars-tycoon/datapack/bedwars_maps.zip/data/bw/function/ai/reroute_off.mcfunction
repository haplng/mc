execute unless entity @e[type=minecraft:marker,tag=bw.hub,sort=nearest,limit=1] run return run function bw:ai/rr_giveup
execute store result score #hy bw run data get entity @e[type=minecraft:marker,tag=bw.hub,sort=nearest,limit=1] Pos[1]
execute store result score #by bw run data get entity @s Pos[1]
scoreboard players operation #hy bw -= #by bw
data modify storage bw:tmp fl.path set value []
data remove storage bw:tmp fl.cp
execute if score #hy bw matches 15.. run scoreboard players set #hy bw 14
execute if score #hy bw matches 2.. run function bw:ai/rr_up
execute if score #hy bw matches 2.. if score #colok bw matches 0 run return run function bw:ai/rr_giveup
data modify storage bw:tmp fl.path append from entity @e[type=minecraft:marker,tag=bw.hub,sort=nearest,limit=1] Pos
data modify storage bw:tmp fl.hub set from entity @e[type=minecraft:marker,tag=bw.hub,sort=nearest,limit=1] data.n
execute if score #dbg bw matches 1 if score @s bw.team matches 1 run tellraw @a ["REROUTE-OFF bot1 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g1,limit=1]"}," to ",{nbt:"to1",storage:"bw:bot"}]
execute if score #dbg bw matches 1 if score @s bw.team matches 2 run tellraw @a ["REROUTE-OFF bot2 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g2,limit=1]"}," to ",{nbt:"to2",storage:"bw:bot"}]
execute if score #dbg bw matches 1 if score @s bw.team matches 3 run tellraw @a ["REROUTE-OFF bot3 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g3,limit=1]"}," to ",{nbt:"to3",storage:"bw:bot"}]
execute if score #dbg bw matches 1 if score @s bw.team matches 4 run tellraw @a ["REROUTE-OFF bot4 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g4,limit=1]"}," to ",{nbt:"to4",storage:"bw:bot"}]
execute if score #dbg bw matches 1 if score @s bw.team matches 5 run tellraw @a ["REROUTE-OFF bot5 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g5,limit=1]"}," to ",{nbt:"to5",storage:"bw:bot"}]
execute if score #dbg bw matches 1 if score @s bw.team matches 6 run tellraw @a ["REROUTE-OFF bot6 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g6,limit=1]"}," to ",{nbt:"to6",storage:"bw:bot"}]
execute if score #dbg bw matches 1 if score @s bw.team matches 7 run tellraw @a ["REROUTE-OFF bot7 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g7,limit=1]"}," to ",{nbt:"to7",storage:"bw:bot"}]
function bw:ai/rr_set
