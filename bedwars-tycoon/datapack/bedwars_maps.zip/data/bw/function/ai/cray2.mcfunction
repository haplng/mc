scoreboard players add #rn bw 1
execute if score #rn bw matches 41.. run return 0
execute unless block ~ ~ ~ #bw:open unless predicate bw:built run return run function bw:ai/cray2up
execute unless block ~ ~1 ~ #bw:open positioned ~ ~1 ~ unless predicate bw:built run return 0
scoreboard players set #up bw 0
function bw:ai/colchk
execute if score #colok bw matches 1 align xyz positioned ~0.5 ~ ~0.5 summon minecraft:marker run return run function bw:ai/colmark
execute positioned ~0 ~ ~1 run function bw:ai/cray2
