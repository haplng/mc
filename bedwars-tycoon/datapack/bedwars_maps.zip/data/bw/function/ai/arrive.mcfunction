scoreboard players set @s bw.mine 0
execute if score @s bw.dest matches 9 run return run function bw:ai/homed
execute if score @s bw.dest matches 1 run scoreboard players set @s bw.st 1
execute if score @s bw.dest matches 1 run scoreboard players operation @s bw.t1 = #a_think bw
execute if score @s bw.dest matches 2 run scoreboard players set @s bw.st 1
execute if score @s bw.dest matches 2 run scoreboard players set @s bw.t1 30
execute if score @s bw.dest matches 3 run scoreboard players set @s bw.st 5
execute if score @s bw.dest matches 4 run function bw:ai/siege0
execute if score @s bw.dest matches 5 run scoreboard players set @s bw.st 6
execute if score @s bw.dest matches 5 run scoreboard players set @s bw.t1 320
