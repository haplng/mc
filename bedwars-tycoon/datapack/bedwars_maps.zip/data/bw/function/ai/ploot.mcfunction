execute store result score #lfe bw run clear @s minecraft:iron_ingot 0
execute store result score #lau bw run clear @s minecraft:gold_ingot 0
execute store result score #ldi bw run clear @s minecraft:diamond 0
execute store result score #lem bw run clear @s minecraft:emerald 0
execute if score #kt bw matches 1 run scoreboard players operation #wfe1 bw += #lfe bw
execute if score #kt bw matches 1 run scoreboard players operation #wau1 bw += #lau bw
execute if score #kt bw matches 1 run scoreboard players operation #wdi1 bw += #ldi bw
execute if score #kt bw matches 1 run scoreboard players operation #wem1 bw += #lem bw
execute if score #kt bw matches 2 run scoreboard players operation #wfe2 bw += #lfe bw
execute if score #kt bw matches 2 run scoreboard players operation #wau2 bw += #lau bw
execute if score #kt bw matches 2 run scoreboard players operation #wdi2 bw += #ldi bw
execute if score #kt bw matches 2 run scoreboard players operation #wem2 bw += #lem bw
execute if score #kt bw matches 3 run scoreboard players operation #wfe3 bw += #lfe bw
execute if score #kt bw matches 3 run scoreboard players operation #wau3 bw += #lau bw
execute if score #kt bw matches 3 run scoreboard players operation #wdi3 bw += #ldi bw
execute if score #kt bw matches 3 run scoreboard players operation #wem3 bw += #lem bw
execute if score #kt bw matches 4 run scoreboard players operation #wfe4 bw += #lfe bw
execute if score #kt bw matches 4 run scoreboard players operation #wau4 bw += #lau bw
execute if score #kt bw matches 4 run scoreboard players operation #wdi4 bw += #ldi bw
execute if score #kt bw matches 4 run scoreboard players operation #wem4 bw += #lem bw
execute if score #kt bw matches 5 run scoreboard players operation #wfe5 bw += #lfe bw
execute if score #kt bw matches 5 run scoreboard players operation #wau5 bw += #lau bw
execute if score #kt bw matches 5 run scoreboard players operation #wdi5 bw += #ldi bw
execute if score #kt bw matches 5 run scoreboard players operation #wem5 bw += #lem bw
execute if score #kt bw matches 6 run scoreboard players operation #wfe6 bw += #lfe bw
execute if score #kt bw matches 6 run scoreboard players operation #wau6 bw += #lau bw
execute if score #kt bw matches 6 run scoreboard players operation #wdi6 bw += #ldi bw
execute if score #kt bw matches 6 run scoreboard players operation #wem6 bw += #lem bw
execute if score #kt bw matches 7 run scoreboard players operation #wfe7 bw += #lfe bw
execute if score #kt bw matches 7 run scoreboard players operation #wau7 bw += #lau bw
execute if score #kt bw matches 7 run scoreboard players operation #wdi7 bw += #ldi bw
execute if score #kt bw matches 7 run scoreboard players operation #wem7 bw += #lem bw
