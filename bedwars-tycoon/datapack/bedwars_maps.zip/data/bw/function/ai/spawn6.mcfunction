execute if score #map bw matches 1 run function bw:m/tea/bot6
execute if score #map bw matches 2 run function bw:m/chess/bot6
execute if score #map bw matches 3 run function bw:m/circus/bot6
execute if score #map bw matches 4 run function bw:m/library/bot6
execute if score #map bw matches 5 run function bw:m/solar/bot6
