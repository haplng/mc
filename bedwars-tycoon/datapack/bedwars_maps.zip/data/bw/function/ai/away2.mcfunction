function bw:ai/pick2
execute store result score #rn bw run random value 1..100
execute if data storage bw:bot {at2:"b2"} run return run function bw:ai/to2 {to:"g2",dest:1}
execute if score #wdi2 bw matches 2.. run return run function bw:ai/to2 {to:"g2",dest:1}
execute if score @s bw.hp matches ..300 run return run function bw:ai/to2 {to:"g2",dest:1}
execute if score @s bw.tgt matches 0.. if score #rn bw matches ..75 run return run function bw:ai/attack2
function bw:ai/to2 {to:"g2",dest:1}
