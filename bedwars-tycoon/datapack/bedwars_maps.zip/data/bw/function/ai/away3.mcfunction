function bw:ai/pick3
execute store result score #rn bw run random value 1..100
execute if data storage bw:bot {at3:"b3"} run return run function bw:ai/to3 {to:"g3",dest:1}
execute if score #wdi3 bw matches 2.. run return run function bw:ai/to3 {to:"g3",dest:1}
execute if score @s bw.hp matches ..300 run return run function bw:ai/to3 {to:"g3",dest:1}
execute if score @s bw.tgt matches 0.. if score #rn bw matches ..75 run return run function bw:ai/attack3
function bw:ai/to3 {to:"g3",dest:1}
