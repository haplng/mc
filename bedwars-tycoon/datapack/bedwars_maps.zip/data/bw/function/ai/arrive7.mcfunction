data modify storage bw:bot at7 set from storage bw:bot to7
function bw:ai/arrive
