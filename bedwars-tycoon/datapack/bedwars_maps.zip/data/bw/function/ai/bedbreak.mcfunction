scoreboard players set @s bw.mine 0
tag @e remove bw.breaker
tag @s add bw.breaker
execute if score @s bw.tgt matches 0 run function bw:ai/bedkill0
execute if score @s bw.tgt matches 1 run function bw:ai/bedkill1
execute if score @s bw.tgt matches 2 run function bw:ai/bedkill2
execute if score @s bw.tgt matches 3 run function bw:ai/bedkill3
execute if score @s bw.tgt matches 4 run function bw:ai/bedkill4
execute if score @s bw.tgt matches 5 run function bw:ai/bedkill5
execute if score @s bw.tgt matches 6 run function bw:ai/bedkill6
execute if score @s bw.tgt matches 7 run function bw:ai/bedkill7
scoreboard players set @s bw.st 0
