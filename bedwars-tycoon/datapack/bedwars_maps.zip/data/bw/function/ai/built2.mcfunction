scoreboard players set #bdone2 bw 1
scoreboard players set @s bw.st 0
