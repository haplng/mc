execute if score @s bw.avn matches 100.. if function bw:ai/retrace run return 0
scoreboard players add @s bw.avc 1
execute if score @s bw.avc matches 7.. run return run function bw:ai/skip
scoreboard players operation @s bw.av = @s bw.avn
scoreboard players operation @s bw.av0 = @s bw.avn
scoreboard players set @s bw.avf 0
execute if score @s bw.avn matches ..90 run scoreboard players operation @s bw.avn += @s bw.avn
execute unless score @s bw.avs matches -1..1 run scoreboard players set @s bw.avs 1
execute if score @s bw.avs matches 0 run scoreboard players set @s bw.avs 1
execute store result score #rn bw run random value 0..1
execute if score @s bw.avn matches 50 if score #rn bw matches 0 run scoreboard players operation @s bw.avs *= #-1 bw
