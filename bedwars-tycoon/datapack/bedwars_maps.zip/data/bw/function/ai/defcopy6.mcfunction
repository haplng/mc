$data modify storage bw:bot def6 set from storage bw:nav $(m).def6_$(T)
