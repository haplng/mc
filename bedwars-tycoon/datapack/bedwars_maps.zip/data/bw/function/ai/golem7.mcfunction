scoreboard players remove #wfe7 bw 120
function bw:mob/botgolem
