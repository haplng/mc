$data modify storage bw:bot r7 set from storage bw:nav $(m).$(at)_$(to)
$data modify storage bw:bot to7 set value "$(to)"
$execute if data storage bw:bot r7[0] run data modify storage bw:bot r7 prepend from storage bw:nav $(m).n_$(at)
