scoreboard players set @s bw.stuck 0
scoreboard players set @s bw.wpt 0
scoreboard players set @s bw.avc 0
scoreboard players set @s bw.av 0
execute if score @s bw.team matches 1 at @e[type=minecraft:marker,tag=bw.g1,limit=1] positioned ~ ~-1 ~ if block ~ ~ ~ #bw:open run function bw:ai/wool
execute if score @s bw.team matches 2 at @e[type=minecraft:marker,tag=bw.g2,limit=1] positioned ~ ~-1 ~ if block ~ ~ ~ #bw:open run function bw:ai/wool
execute if score @s bw.team matches 3 at @e[type=minecraft:marker,tag=bw.g3,limit=1] positioned ~ ~-1 ~ if block ~ ~ ~ #bw:open run function bw:ai/wool
execute if score @s bw.team matches 4 at @e[type=minecraft:marker,tag=bw.g4,limit=1] positioned ~ ~-1 ~ if block ~ ~ ~ #bw:open run function bw:ai/wool
execute if score @s bw.team matches 5 at @e[type=minecraft:marker,tag=bw.g5,limit=1] positioned ~ ~-1 ~ if block ~ ~ ~ #bw:open run function bw:ai/wool
execute if score @s bw.team matches 6 at @e[type=minecraft:marker,tag=bw.g6,limit=1] positioned ~ ~-1 ~ if block ~ ~ ~ #bw:open run function bw:ai/wool
execute if score @s bw.team matches 7 at @e[type=minecraft:marker,tag=bw.g7,limit=1] positioned ~ ~-1 ~ if block ~ ~ ~ #bw:open run function bw:ai/wool
execute if score @s bw.team matches 1 run tp @s @e[type=minecraft:marker,tag=bw.g1,limit=1]
execute if score @s bw.team matches 2 run tp @s @e[type=minecraft:marker,tag=bw.g2,limit=1]
execute if score @s bw.team matches 3 run tp @s @e[type=minecraft:marker,tag=bw.g3,limit=1]
execute if score @s bw.team matches 4 run tp @s @e[type=minecraft:marker,tag=bw.g4,limit=1]
execute if score @s bw.team matches 5 run tp @s @e[type=minecraft:marker,tag=bw.g5,limit=1]
execute if score @s bw.team matches 6 run tp @s @e[type=minecraft:marker,tag=bw.g6,limit=1]
execute if score @s bw.team matches 7 run tp @s @e[type=minecraft:marker,tag=bw.g7,limit=1]
