$function bw:ai/to5 {to:"a$(j)",dest:4}
