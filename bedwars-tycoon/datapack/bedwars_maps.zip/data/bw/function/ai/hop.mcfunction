execute store result score #rn bw run random value 1..10
execute if score #rn bw matches ..3 run function bw:ai/jump
execute if score #rn bw matches 4.. run scoreboard players set @s bw.jc 6
