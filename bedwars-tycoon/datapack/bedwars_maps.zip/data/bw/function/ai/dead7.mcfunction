execute store result storage bw:tmp loot.fe int 1 run scoreboard players get #wfe7 bw
execute store result storage bw:tmp loot.au int 1 run scoreboard players get #wau7 bw
execute store result storage bw:tmp loot.di int 1 run scoreboard players get #wdi7 bw
execute store result storage bw:tmp loot.em int 1 run scoreboard players get #wem7 bw
execute if score #wfe7 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_fe with storage bw:tmp loot
execute if score #wau7 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_au with storage bw:tmp loot
execute if score #wdi7 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_di with storage bw:tmp loot
execute if score #wem7 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_em with storage bw:tmp loot
scoreboard players set #wfe7 bw 0
scoreboard players set #wau7 bw 0
scoreboard players set #wdi7 bw 0
scoreboard players set #wem7 bw 0
scoreboard players set #bsw7 bw 0
execute if score #btl7 bw matches 2.. run scoreboard players remove #btl7 bw 1
execute if score #final bw matches 0 run scoreboard players set #bres7 bw 100
execute if score #final bw matches 1 run tellraw @a [{text:""},{text:"<",color:"gray"},{selector:"@s"},{text:"> gg",color:"gray"}]
