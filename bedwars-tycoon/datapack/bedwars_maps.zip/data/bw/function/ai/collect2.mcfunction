scoreboard players operation #wfe2 bw += #pfe2 bw
scoreboard players set #pfe2 bw 0
scoreboard players operation #wau2 bw += #pau2 bw
scoreboard players set #pau2 bw 0
scoreboard players operation #wem2 bw += #pem2 bw
scoreboard players set #pem2 bw 0
