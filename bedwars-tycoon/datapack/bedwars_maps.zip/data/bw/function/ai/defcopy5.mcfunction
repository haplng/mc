$data modify storage bw:bot def5 set from storage bw:nav $(m).def5_$(T)
