function bw:ai/pick6
execute store result score #rn bw run random value 1..100
execute if data storage bw:bot {at6:"b6"} run return run function bw:ai/to6 {to:"g6",dest:1}
execute if score #wdi6 bw matches 2.. run return run function bw:ai/to6 {to:"g6",dest:1}
execute if score @s bw.hp matches ..300 run return run function bw:ai/to6 {to:"g6",dest:1}
execute if score @s bw.tgt matches 0.. if score #rn bw matches ..75 run return run function bw:ai/attack6
function bw:ai/to6 {to:"g6",dest:1}
