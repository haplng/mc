scoreboard players add #reroutes bw 1
scoreboard players set @s bw.stuck 0
scoreboard players set @s bw.wpt 0
scoreboard players set @s bw.avc 0
scoreboard players set @s bw.av 0
scoreboard players set @s bw.avn 25
scoreboard players add @s bw.rrc 1
execute if score @s bw.rrc matches 4.. run return run function bw:ai/rr_giveup
execute store result score #fx bw run data get entity @s Pos[0]
execute store result score #fy bw run data get entity @s Pos[1]
execute store result score #fz bw run data get entity @s Pos[2]
scoreboard players operation #sx bw = #fx bw
scoreboard players operation #sy bw = #fy bw
scoreboard players operation #sz bw = #fz bw
scoreboard players operation #hd bw = @s bw.dest
execute if score @s bw.dest matches 9 run function bw:ai/rr_hd
scoreboard players set #own bw 0
execute if score #hd bw matches 1 run function bw:ai/rr_home
execute if score #own bw matches 1 run return 1
scoreboard players operation #fx bw = #sx bw
scoreboard players operation #fy bw = #sy bw
scoreboard players operation #fz bw = #sz bw
data modify storage bw:tmp fl set value {path:[],f:"f"}
data modify storage bw:tmp fl.m set from storage bw:ai ctx.m
scoreboard players set #fc bw 0
function bw:ai/flow_find
execute if score #fc bw matches 0 run return run function bw:ai/reroute_off
scoreboard players set #fn bw 0
function bw:ai/flow_put
function bw:ai/flow_walk with storage bw:tmp fl
execute unless data storage bw:tmp fl.hub run return run function bw:ai/reroute_off
execute if score #dbg bw matches 1 if score @s bw.team matches 1 run tellraw @a ["REROUTE bot1 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g1,limit=1]"}," to ",{nbt:"to1",storage:"bw:bot"}]
execute if score #dbg bw matches 1 if score @s bw.team matches 2 run tellraw @a ["REROUTE bot2 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g2,limit=1]"}," to ",{nbt:"to2",storage:"bw:bot"}]
execute if score #dbg bw matches 1 if score @s bw.team matches 3 run tellraw @a ["REROUTE bot3 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g3,limit=1]"}," to ",{nbt:"to3",storage:"bw:bot"}]
execute if score #dbg bw matches 1 if score @s bw.team matches 4 run tellraw @a ["REROUTE bot4 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g4,limit=1]"}," to ",{nbt:"to4",storage:"bw:bot"}]
execute if score #dbg bw matches 1 if score @s bw.team matches 5 run tellraw @a ["REROUTE bot5 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g5,limit=1]"}," to ",{nbt:"to5",storage:"bw:bot"}]
execute if score #dbg bw matches 1 if score @s bw.team matches 6 run tellraw @a ["REROUTE bot6 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g6,limit=1]"}," to ",{nbt:"to6",storage:"bw:bot"}]
execute if score #dbg bw matches 1 if score @s bw.team matches 7 run tellraw @a ["REROUTE bot7 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g7,limit=1]"}," to ",{nbt:"to7",storage:"bw:bot"}]
function bw:ai/rr_set
