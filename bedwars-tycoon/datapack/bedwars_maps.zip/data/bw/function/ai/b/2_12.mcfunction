scoreboard players remove #wdi2 bw 2
scoreboard players set #prot2 bw 1
