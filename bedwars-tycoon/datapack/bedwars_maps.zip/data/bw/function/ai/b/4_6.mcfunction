scoreboard players remove #wem4 bw 4
scoreboard players set #bsw4 bw 3
scoreboard players set @s bw.sw 3
