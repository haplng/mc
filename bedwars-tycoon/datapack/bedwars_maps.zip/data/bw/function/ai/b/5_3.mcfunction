scoreboard players remove #wau5 bw 7
scoreboard players set #bsw5 bw 2
scoreboard players set @s bw.sw 2
