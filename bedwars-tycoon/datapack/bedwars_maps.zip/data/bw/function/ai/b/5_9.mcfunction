scoreboard players remove #wau5 bw 3
scoreboard players add #bga5 bw 1
