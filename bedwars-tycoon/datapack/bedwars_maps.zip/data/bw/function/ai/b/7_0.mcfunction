scoreboard players remove #wfe7 bw 10
scoreboard players set #bsw7 bw 1
scoreboard players set @s bw.sw 1
