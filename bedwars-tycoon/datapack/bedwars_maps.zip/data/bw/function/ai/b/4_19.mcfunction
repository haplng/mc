scoreboard players remove #wdi4 bw 2
function bw:trap/add {i:4,k:4}
