scoreboard players remove #wdi7 bw 2
scoreboard players set #prot7 bw 1
