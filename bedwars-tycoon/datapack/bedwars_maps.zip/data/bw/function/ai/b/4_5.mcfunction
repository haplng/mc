scoreboard players remove #wfe4 bw 10
scoreboard players remove #wau4 bw 3
scoreboard players set #btl4 bw 2
scoreboard players set @s bw.tool 2
