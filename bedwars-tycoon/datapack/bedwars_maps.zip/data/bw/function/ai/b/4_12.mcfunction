scoreboard players remove #wdi4 bw 2
scoreboard players set #prot4 bw 1
