scoreboard players remove #wdi1 bw 4
scoreboard players set #fl1 bw 2
scoreboard players operation #fs1 bw = #a_eff bw
scoreboard players operation #fs1 bw *= #200 bw
scoreboard players operation #fs1 bw /= #100 bw
