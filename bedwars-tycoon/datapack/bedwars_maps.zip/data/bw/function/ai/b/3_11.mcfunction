scoreboard players remove #wdi3 bw 4
scoreboard players set #sharp3 bw 1
