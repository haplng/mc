scoreboard players remove #wdi7 bw 2
scoreboard players set #fl7 bw 1
scoreboard players operation #fs7 bw = #a_eff bw
scoreboard players operation #fs7 bw *= #150 bw
scoreboard players operation #fs7 bw /= #100 bw
