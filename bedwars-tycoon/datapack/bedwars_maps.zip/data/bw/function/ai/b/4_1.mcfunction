scoreboard players remove #wfe4 bw 40
scoreboard players set #bar4 bw 1
scoreboard players set @s bw.armor 1
