scoreboard players remove #wfe3 bw 20
scoreboard players set #btl3 bw 1
scoreboard players set @s bw.tool 1
