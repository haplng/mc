scoreboard players remove #wdi3 bw 2
scoreboard players set #prot3 bw 1
