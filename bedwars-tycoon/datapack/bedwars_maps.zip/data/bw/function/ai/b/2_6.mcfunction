scoreboard players remove #wem2 bw 4
scoreboard players set #bsw2 bw 3
scoreboard players set @s bw.sw 3
