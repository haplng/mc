scoreboard players remove #wdi6 bw 4
scoreboard players set #sharp6 bw 1
