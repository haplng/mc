scoreboard players remove #wau4 bw 3
scoreboard players add #bga4 bw 1
