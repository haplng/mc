scoreboard players remove #wau3 bw 7
scoreboard players set #bsw3 bw 2
scoreboard players set @s bw.sw 2
