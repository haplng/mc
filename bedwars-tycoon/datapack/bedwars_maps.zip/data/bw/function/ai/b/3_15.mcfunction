scoreboard players remove #wdi3 bw 16
scoreboard players set #prot3 bw 4
