scoreboard players remove #wem3 bw 4
scoreboard players set #bsw3 bw 3
scoreboard players set @s bw.sw 3
