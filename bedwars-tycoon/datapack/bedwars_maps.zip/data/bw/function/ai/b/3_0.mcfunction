scoreboard players remove #wfe3 bw 10
scoreboard players set #bsw3 bw 1
scoreboard players set @s bw.sw 1
