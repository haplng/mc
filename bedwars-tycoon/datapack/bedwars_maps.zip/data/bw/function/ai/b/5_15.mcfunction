scoreboard players remove #wdi5 bw 16
scoreboard players set #prot5 bw 4
