scoreboard players remove #wdi2 bw 5
scoreboard players set #dbuff2 bw 1
