scoreboard players remove #wau1 bw 7
scoreboard players set #bsw1 bw 2
scoreboard players set @s bw.sw 2
