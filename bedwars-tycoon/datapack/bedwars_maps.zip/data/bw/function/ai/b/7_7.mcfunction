scoreboard players remove #wem7 bw 6
scoreboard players set #bar7 bw 3
scoreboard players set @s bw.armor 3
