scoreboard players remove #wfe5 bw 10
scoreboard players set #bsw5 bw 1
scoreboard players set @s bw.sw 1
