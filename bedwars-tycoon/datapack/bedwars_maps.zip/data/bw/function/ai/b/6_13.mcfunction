scoreboard players remove #wdi6 bw 4
scoreboard players set #prot6 bw 2
