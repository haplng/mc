scoreboard players remove #wem5 bw 6
scoreboard players set #bar5 bw 3
scoreboard players set @s bw.armor 3
