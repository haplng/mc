scoreboard players remove #wau7 bw 7
scoreboard players set #bsw7 bw 2
scoreboard players set @s bw.sw 2
