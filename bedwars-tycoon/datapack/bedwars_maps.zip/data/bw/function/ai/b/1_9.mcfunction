scoreboard players remove #wau1 bw 3
scoreboard players add #bga1 bw 1
