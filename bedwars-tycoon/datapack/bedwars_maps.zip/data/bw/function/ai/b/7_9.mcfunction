scoreboard players remove #wau7 bw 3
scoreboard players add #bga7 bw 1
