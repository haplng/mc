scoreboard players remove #wdi5 bw 2
scoreboard players set #prot5 bw 1
