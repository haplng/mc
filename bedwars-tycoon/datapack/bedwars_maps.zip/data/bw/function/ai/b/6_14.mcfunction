scoreboard players remove #wdi6 bw 8
scoreboard players set #prot6 bw 3
