scoreboard players remove #wfe2 bw 40
scoreboard players set #bar2 bw 1
scoreboard players set @s bw.armor 1
