scoreboard players remove #wfe4 bw 10
scoreboard players set #bsw4 bw 1
scoreboard players set @s bw.sw 1
