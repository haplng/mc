scoreboard players remove #wfe2 bw 10
scoreboard players set #bsw2 bw 1
scoreboard players set @s bw.sw 1
