scoreboard players remove #wfe3 bw 10
scoreboard players remove #wau3 bw 3
scoreboard players set #btl3 bw 2
scoreboard players set @s bw.tool 2
