scoreboard players remove #wau7 bw 12
scoreboard players set #bar7 bw 2
scoreboard players set @s bw.armor 2
