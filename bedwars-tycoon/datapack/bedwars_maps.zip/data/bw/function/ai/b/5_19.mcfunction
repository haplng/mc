scoreboard players remove #wdi5 bw 2
function bw:trap/add {i:5,k:4}
