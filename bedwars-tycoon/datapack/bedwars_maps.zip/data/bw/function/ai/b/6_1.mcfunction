scoreboard players remove #wfe6 bw 40
scoreboard players set #bar6 bw 1
scoreboard players set @s bw.armor 1
