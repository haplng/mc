scoreboard players remove #wdi4 bw 5
scoreboard players set #dbuff4 bw 1
