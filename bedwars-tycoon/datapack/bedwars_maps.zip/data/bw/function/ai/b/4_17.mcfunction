scoreboard players remove #wdi4 bw 4
scoreboard players set #fl4 bw 2
scoreboard players operation #fs4 bw = #a_eff bw
scoreboard players operation #fs4 bw *= #200 bw
scoreboard players operation #fs4 bw /= #100 bw
