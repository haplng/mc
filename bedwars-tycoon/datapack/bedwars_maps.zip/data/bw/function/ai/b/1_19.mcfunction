scoreboard players remove #wdi1 bw 2
function bw:trap/add {i:1,k:4}
