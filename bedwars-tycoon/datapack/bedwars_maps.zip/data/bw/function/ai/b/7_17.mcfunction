scoreboard players remove #wdi7 bw 4
scoreboard players set #fl7 bw 2
scoreboard players operation #fs7 bw = #a_eff bw
scoreboard players operation #fs7 bw *= #200 bw
scoreboard players operation #fs7 bw /= #100 bw
