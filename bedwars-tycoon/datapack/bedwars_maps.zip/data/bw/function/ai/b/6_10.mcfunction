scoreboard players remove #wfe6 bw 40
scoreboard players add #bfb6 bw 1
