scoreboard players remove #wdi1 bw 16
scoreboard players set #prot1 bw 4
