scoreboard players remove #wfe7 bw 40
scoreboard players add #bfb7 bw 1
