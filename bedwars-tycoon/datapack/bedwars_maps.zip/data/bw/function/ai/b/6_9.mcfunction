scoreboard players remove #wau6 bw 3
scoreboard players add #bga6 bw 1
