scoreboard players remove #wem7 bw 4
scoreboard players set #bsw7 bw 3
scoreboard players set @s bw.sw 3
