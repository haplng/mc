scoreboard players remove #wdi1 bw 8
scoreboard players set #prot1 bw 3
