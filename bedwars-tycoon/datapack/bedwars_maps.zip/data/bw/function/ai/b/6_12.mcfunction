scoreboard players remove #wdi6 bw 2
scoreboard players set #prot6 bw 1
