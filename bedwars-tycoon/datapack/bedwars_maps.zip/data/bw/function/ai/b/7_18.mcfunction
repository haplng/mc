scoreboard players remove #wdi7 bw 1
scoreboard players set #trap7 bw 1
