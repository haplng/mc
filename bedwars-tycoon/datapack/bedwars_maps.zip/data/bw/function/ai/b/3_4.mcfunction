scoreboard players remove #wau3 bw 12
scoreboard players set #bar3 bw 2
scoreboard players set @s bw.armor 2
