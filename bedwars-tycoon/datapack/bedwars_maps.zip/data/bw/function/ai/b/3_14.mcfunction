scoreboard players remove #wdi3 bw 8
scoreboard players set #prot3 bw 3
