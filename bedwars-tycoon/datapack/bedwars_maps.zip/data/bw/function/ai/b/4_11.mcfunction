scoreboard players remove #wdi4 bw 4
scoreboard players set #sharp4 bw 1
