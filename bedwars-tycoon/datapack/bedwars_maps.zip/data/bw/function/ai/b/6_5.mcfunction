scoreboard players remove #wfe6 bw 10
scoreboard players remove #wau6 bw 3
scoreboard players set #btl6 bw 2
scoreboard players set @s bw.tool 2
