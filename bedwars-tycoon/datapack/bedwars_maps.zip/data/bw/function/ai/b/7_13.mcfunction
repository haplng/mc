scoreboard players remove #wdi7 bw 4
scoreboard players set #prot7 bw 2
