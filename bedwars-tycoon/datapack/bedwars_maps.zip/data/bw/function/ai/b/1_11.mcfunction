scoreboard players remove #wdi1 bw 4
scoreboard players set #sharp1 bw 1
