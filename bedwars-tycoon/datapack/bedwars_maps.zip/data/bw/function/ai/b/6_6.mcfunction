scoreboard players remove #wem6 bw 4
scoreboard players set #bsw6 bw 3
scoreboard players set @s bw.sw 3
