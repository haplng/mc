scoreboard players remove #wdi2 bw 4
scoreboard players set #sharp2 bw 1
