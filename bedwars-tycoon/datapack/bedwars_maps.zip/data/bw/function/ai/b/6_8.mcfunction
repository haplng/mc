scoreboard players remove #wau6 bw 6
scoreboard players set #btl6 bw 3
scoreboard players set @s bw.tool 3
