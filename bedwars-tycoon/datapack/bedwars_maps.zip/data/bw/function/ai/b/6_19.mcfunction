scoreboard players remove #wdi6 bw 2
function bw:trap/add {i:6,k:4}
