scoreboard players remove #wdi2 bw 2
function bw:trap/add {i:2,k:4}
