scoreboard players remove #wdi1 bw 2
scoreboard players set #fl1 bw 1
scoreboard players operation #fs1 bw = #a_eff bw
scoreboard players operation #fs1 bw *= #150 bw
scoreboard players operation #fs1 bw /= #100 bw
