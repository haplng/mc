scoreboard players remove #wau2 bw 7
scoreboard players set #bsw2 bw 2
scoreboard players set @s bw.sw 2
