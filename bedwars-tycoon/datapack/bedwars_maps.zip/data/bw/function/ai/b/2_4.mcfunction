scoreboard players remove #wau2 bw 12
scoreboard players set #bar2 bw 2
scoreboard players set @s bw.armor 2
