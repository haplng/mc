scoreboard players remove #wdi4 bw 8
scoreboard players set #prot4 bw 3
