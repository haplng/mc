scoreboard players remove #wfe1 bw 10
scoreboard players remove #wau1 bw 3
scoreboard players set #btl1 bw 2
scoreboard players set @s bw.tool 2
