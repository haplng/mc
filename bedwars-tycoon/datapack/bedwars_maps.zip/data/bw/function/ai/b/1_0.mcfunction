scoreboard players remove #wfe1 bw 10
scoreboard players set #bsw1 bw 1
scoreboard players set @s bw.sw 1
