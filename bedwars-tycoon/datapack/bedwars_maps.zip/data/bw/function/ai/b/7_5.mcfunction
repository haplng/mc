scoreboard players remove #wfe7 bw 10
scoreboard players remove #wau7 bw 3
scoreboard players set #btl7 bw 2
scoreboard players set @s bw.tool 2
