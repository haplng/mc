scoreboard players remove #wdi6 bw 16
scoreboard players set #prot6 bw 4
