scoreboard players remove #wdi5 bw 4
scoreboard players set #prot5 bw 2
