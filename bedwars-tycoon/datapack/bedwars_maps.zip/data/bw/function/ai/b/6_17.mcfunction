scoreboard players remove #wdi6 bw 4
scoreboard players set #fl6 bw 2
scoreboard players operation #fs6 bw = #a_eff bw
scoreboard players operation #fs6 bw *= #200 bw
scoreboard players operation #fs6 bw /= #100 bw
