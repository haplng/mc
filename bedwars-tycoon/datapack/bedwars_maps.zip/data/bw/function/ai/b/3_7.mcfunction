scoreboard players remove #wem3 bw 6
scoreboard players set #bar3 bw 3
scoreboard players set @s bw.armor 3
