scoreboard players remove #wfe1 bw 40
scoreboard players add #bfb1 bw 1
