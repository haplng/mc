scoreboard players remove #wdi5 bw 5
scoreboard players set #dbuff5 bw 1
