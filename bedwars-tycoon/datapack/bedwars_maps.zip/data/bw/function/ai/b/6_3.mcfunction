scoreboard players remove #wau6 bw 7
scoreboard players set #bsw6 bw 2
scoreboard players set @s bw.sw 2
