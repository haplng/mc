scoreboard players remove #wau2 bw 3
scoreboard players add #bga2 bw 1
