scoreboard players remove #wdi4 bw 1
scoreboard players set #trap4 bw 1
