scoreboard players remove #wdi4 bw 1
function bw:trap/add {i:4,k:1}
