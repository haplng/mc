scoreboard players remove #wem6 bw 6
scoreboard players set #bar6 bw 3
scoreboard players set @s bw.armor 3
