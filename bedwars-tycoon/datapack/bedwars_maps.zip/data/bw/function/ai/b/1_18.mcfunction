scoreboard players remove #wdi1 bw 1
function bw:trap/add {i:1,k:1}
