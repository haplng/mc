scoreboard players remove #wdi1 bw 1
scoreboard players set #trap1 bw 1
