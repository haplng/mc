scoreboard players remove #wfe7 bw 20
scoreboard players set #btl7 bw 1
scoreboard players set @s bw.tool 1
