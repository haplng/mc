scoreboard players remove #wdi2 bw 16
scoreboard players set #prot2 bw 4
