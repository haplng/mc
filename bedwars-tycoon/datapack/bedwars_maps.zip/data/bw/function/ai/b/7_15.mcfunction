scoreboard players remove #wdi7 bw 16
scoreboard players set #prot7 bw 4
