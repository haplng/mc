scoreboard players remove #wem2 bw 6
scoreboard players set #bar2 bw 3
scoreboard players set @s bw.armor 3
