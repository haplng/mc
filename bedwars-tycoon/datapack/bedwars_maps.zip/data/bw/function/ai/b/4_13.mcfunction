scoreboard players remove #wdi4 bw 4
scoreboard players set #prot4 bw 2
