scoreboard players remove #wdi1 bw 4
scoreboard players set #prot1 bw 2
