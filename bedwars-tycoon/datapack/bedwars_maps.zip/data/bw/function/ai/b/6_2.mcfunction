scoreboard players remove #wfe6 bw 20
scoreboard players set #btl6 bw 1
scoreboard players set @s bw.tool 1
