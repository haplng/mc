scoreboard players remove #wem4 bw 6
scoreboard players set #bar4 bw 3
scoreboard players set @s bw.armor 3
