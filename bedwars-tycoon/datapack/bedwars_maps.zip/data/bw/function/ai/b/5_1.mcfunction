scoreboard players remove #wfe5 bw 40
scoreboard players set #bar5 bw 1
scoreboard players set @s bw.armor 1
