scoreboard players remove #wau5 bw 12
scoreboard players set #bar5 bw 2
scoreboard players set @s bw.armor 2
