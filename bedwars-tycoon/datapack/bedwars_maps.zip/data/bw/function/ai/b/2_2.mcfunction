scoreboard players remove #wfe2 bw 20
scoreboard players set #btl2 bw 1
scoreboard players set @s bw.tool 1
