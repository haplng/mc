scoreboard players remove #wau4 bw 12
scoreboard players set #bar4 bw 2
scoreboard players set @s bw.armor 2
