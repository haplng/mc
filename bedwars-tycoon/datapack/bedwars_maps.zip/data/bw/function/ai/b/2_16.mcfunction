scoreboard players remove #wdi2 bw 2
scoreboard players set #fl2 bw 1
scoreboard players operation #fs2 bw = #a_eff bw
scoreboard players operation #fs2 bw *= #150 bw
scoreboard players operation #fs2 bw /= #100 bw
