scoreboard players remove #wau4 bw 7
scoreboard players set #bsw4 bw 2
scoreboard players set @s bw.sw 2
