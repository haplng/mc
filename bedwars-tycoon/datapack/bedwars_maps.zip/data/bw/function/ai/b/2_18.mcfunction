scoreboard players remove #wdi2 bw 1
function bw:trap/add {i:2,k:1}
