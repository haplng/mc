scoreboard players remove #wdi2 bw 1
scoreboard players set #trap2 bw 1
