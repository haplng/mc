scoreboard players remove #wfe4 bw 40
scoreboard players add #bfb4 bw 1
