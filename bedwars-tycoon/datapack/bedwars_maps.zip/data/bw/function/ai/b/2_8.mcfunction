scoreboard players remove #wau2 bw 6
scoreboard players set #btl2 bw 3
scoreboard players set @s bw.tool 3
