scoreboard players remove #wau1 bw 12
scoreboard players set #bar1 bw 2
scoreboard players set @s bw.armor 2
