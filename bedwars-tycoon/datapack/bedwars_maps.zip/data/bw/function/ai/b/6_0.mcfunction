scoreboard players remove #wfe6 bw 10
scoreboard players set #bsw6 bw 1
scoreboard players set @s bw.sw 1
