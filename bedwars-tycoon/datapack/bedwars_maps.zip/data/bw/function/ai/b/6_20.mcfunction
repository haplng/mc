scoreboard players remove #wdi6 bw 5
scoreboard players set #dbuff6 bw 1
