scoreboard players remove #wdi3 bw 4
scoreboard players set #prot3 bw 2
