scoreboard players remove #wfe1 bw 20
scoreboard players set #btl1 bw 1
scoreboard players set @s bw.tool 1
