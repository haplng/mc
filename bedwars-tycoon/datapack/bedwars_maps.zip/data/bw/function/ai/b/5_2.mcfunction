scoreboard players remove #wfe5 bw 20
scoreboard players set #btl5 bw 1
scoreboard players set @s bw.tool 1
