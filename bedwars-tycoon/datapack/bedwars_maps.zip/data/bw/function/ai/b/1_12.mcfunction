scoreboard players remove #wdi1 bw 2
scoreboard players set #prot1 bw 1
