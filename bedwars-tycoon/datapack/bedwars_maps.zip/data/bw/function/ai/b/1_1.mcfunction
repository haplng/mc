scoreboard players remove #wfe1 bw 40
scoreboard players set #bar1 bw 1
scoreboard players set @s bw.armor 1
