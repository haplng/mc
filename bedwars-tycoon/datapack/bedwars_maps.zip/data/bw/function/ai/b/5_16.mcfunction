scoreboard players remove #wdi5 bw 2
scoreboard players set #fl5 bw 1
scoreboard players operation #fs5 bw = #a_eff bw
scoreboard players operation #fs5 bw *= #150 bw
scoreboard players operation #fs5 bw /= #100 bw
