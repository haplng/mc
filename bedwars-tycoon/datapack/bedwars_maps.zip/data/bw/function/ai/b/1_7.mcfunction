scoreboard players remove #wem1 bw 6
scoreboard players set #bar1 bw 3
scoreboard players set @s bw.armor 3
