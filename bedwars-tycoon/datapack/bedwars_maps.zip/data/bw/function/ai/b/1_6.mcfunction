scoreboard players remove #wem1 bw 4
scoreboard players set #bsw1 bw 3
scoreboard players set @s bw.sw 3
