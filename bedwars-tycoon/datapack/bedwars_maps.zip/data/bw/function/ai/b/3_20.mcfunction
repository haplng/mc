scoreboard players remove #wdi3 bw 5
scoreboard players set #dbuff3 bw 1
