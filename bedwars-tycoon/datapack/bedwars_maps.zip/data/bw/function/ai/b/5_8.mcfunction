scoreboard players remove #wau5 bw 6
scoreboard players set #btl5 bw 3
scoreboard players set @s bw.tool 3
