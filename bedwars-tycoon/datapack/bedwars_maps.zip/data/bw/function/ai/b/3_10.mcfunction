scoreboard players remove #wfe3 bw 40
scoreboard players add #bfb3 bw 1
