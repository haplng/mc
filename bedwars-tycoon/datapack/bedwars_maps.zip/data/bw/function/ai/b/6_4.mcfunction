scoreboard players remove #wau6 bw 12
scoreboard players set #bar6 bw 2
scoreboard players set @s bw.armor 2
