scoreboard players remove #wdi3 bw 2
scoreboard players set #fl3 bw 1
scoreboard players operation #fs3 bw = #a_eff bw
scoreboard players operation #fs3 bw *= #150 bw
scoreboard players operation #fs3 bw /= #100 bw
