scoreboard players remove #wdi7 bw 8
scoreboard players set #prot7 bw 3
