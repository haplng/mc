scoreboard players remove #wau3 bw 6
scoreboard players set #btl3 bw 3
scoreboard players set @s bw.tool 3
