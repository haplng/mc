scoreboard players remove #wau7 bw 6
scoreboard players set #btl7 bw 3
scoreboard players set @s bw.tool 3
