scoreboard players remove #wau3 bw 3
scoreboard players add #bga3 bw 1
