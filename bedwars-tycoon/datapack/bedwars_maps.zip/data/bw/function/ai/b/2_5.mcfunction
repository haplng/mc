scoreboard players remove #wfe2 bw 10
scoreboard players remove #wau2 bw 3
scoreboard players set #btl2 bw 2
scoreboard players set @s bw.tool 2
