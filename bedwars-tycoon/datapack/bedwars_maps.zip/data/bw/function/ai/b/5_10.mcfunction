scoreboard players remove #wfe5 bw 40
scoreboard players add #bfb5 bw 1
