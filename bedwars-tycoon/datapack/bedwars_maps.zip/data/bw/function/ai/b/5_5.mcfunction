scoreboard players remove #wfe5 bw 10
scoreboard players remove #wau5 bw 3
scoreboard players set #btl5 bw 2
scoreboard players set @s bw.tool 2
