scoreboard players remove #wdi3 bw 1
scoreboard players set #trap3 bw 1
