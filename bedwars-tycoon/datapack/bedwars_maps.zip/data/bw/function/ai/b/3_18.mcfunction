scoreboard players remove #wdi3 bw 1
function bw:trap/add {i:3,k:1}
