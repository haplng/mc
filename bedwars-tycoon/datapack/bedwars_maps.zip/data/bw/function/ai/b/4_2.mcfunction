scoreboard players remove #wfe4 bw 20
scoreboard players set #btl4 bw 1
scoreboard players set @s bw.tool 1
