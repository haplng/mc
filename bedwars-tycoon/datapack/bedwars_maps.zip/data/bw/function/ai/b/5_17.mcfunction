scoreboard players remove #wdi5 bw 4
scoreboard players set #fl5 bw 2
scoreboard players operation #fs5 bw = #a_eff bw
scoreboard players operation #fs5 bw *= #200 bw
scoreboard players operation #fs5 bw /= #100 bw
