scoreboard players remove #wdi2 bw 8
scoreboard players set #prot2 bw 3
