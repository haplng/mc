scoreboard players remove #wfe2 bw 40
scoreboard players add #bfb2 bw 1
