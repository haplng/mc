scoreboard players remove #wdi1 bw 5
scoreboard players set #dbuff1 bw 1
