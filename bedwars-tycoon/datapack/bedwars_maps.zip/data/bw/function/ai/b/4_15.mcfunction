scoreboard players remove #wdi4 bw 16
scoreboard players set #prot4 bw 4
