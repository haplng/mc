scoreboard players remove #wdi5 bw 1
function bw:trap/add {i:5,k:1}
