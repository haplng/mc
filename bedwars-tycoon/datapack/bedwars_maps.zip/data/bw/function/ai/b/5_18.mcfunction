scoreboard players remove #wdi5 bw 1
scoreboard players set #trap5 bw 1
