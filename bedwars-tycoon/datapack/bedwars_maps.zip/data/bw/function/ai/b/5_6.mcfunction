scoreboard players remove #wem5 bw 4
scoreboard players set #bsw5 bw 3
scoreboard players set @s bw.sw 3
