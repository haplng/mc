scoreboard players remove #wdi5 bw 8
scoreboard players set #prot5 bw 3
