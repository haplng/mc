scoreboard players remove #wdi2 bw 4
scoreboard players set #prot2 bw 2
