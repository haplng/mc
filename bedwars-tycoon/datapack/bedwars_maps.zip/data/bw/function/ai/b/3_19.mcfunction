scoreboard players remove #wdi3 bw 2
function bw:trap/add {i:3,k:4}
