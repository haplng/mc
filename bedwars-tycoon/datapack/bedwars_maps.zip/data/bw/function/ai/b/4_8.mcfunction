scoreboard players remove #wau4 bw 6
scoreboard players set #btl4 bw 3
scoreboard players set @s bw.tool 3
