scoreboard players remove #wfe3 bw 40
scoreboard players set #bar3 bw 1
scoreboard players set @s bw.armor 1
