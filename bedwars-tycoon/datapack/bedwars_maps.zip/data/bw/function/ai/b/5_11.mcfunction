scoreboard players remove #wdi5 bw 4
scoreboard players set #sharp5 bw 1
