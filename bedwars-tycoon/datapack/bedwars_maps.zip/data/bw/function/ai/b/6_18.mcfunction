scoreboard players remove #wdi6 bw 1
scoreboard players set #trap6 bw 1
