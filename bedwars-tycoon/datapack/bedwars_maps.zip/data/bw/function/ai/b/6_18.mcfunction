scoreboard players remove #wdi6 bw 1
function bw:trap/add {i:6,k:1}
