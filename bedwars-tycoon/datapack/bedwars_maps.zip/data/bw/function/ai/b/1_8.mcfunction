scoreboard players remove #wau1 bw 6
scoreboard players set #btl1 bw 3
scoreboard players set @s bw.tool 3
