scoreboard players remove #wdi7 bw 4
scoreboard players set #sharp7 bw 1
