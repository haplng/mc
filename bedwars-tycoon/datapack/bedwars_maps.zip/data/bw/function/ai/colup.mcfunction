execute unless block ~ ~ ~ #bw:open unless predicate bw:built run return run scoreboard players set #colok bw 0
scoreboard players remove #cn bw 1
execute if score #cn bw matches 1.. positioned ~ ~1 ~ run function bw:ai/colup
