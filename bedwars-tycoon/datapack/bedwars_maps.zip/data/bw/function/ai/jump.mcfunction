data modify entity @s Motion[1] set value 0.42d
scoreboard players set @s bw.jc 9
