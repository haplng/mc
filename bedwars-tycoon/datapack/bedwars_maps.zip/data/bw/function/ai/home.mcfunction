execute if score @s bw.team matches 1 run function bw:ai/collect1
execute if score @s bw.team matches 2 run function bw:ai/collect2
execute if score @s bw.team matches 3 run function bw:ai/collect3
execute if score @s bw.team matches 4 run function bw:ai/collect4
execute if score @s bw.team matches 5 run function bw:ai/collect5
execute if score @s bw.team matches 6 run function bw:ai/collect6
execute if score @s bw.team matches 7 run function bw:ai/collect7
execute if score @s bw.t1 matches 1.. run return run function bw:ai/idle
execute if score @s bw.dest matches 2 run function bw:ai/shopping
function bw:ai/think
