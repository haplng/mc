execute store result storage bw:tmp loot.fe int 1 run scoreboard players get #wfe1 bw
execute store result storage bw:tmp loot.au int 1 run scoreboard players get #wau1 bw
execute store result storage bw:tmp loot.di int 1 run scoreboard players get #wdi1 bw
execute store result storage bw:tmp loot.em int 1 run scoreboard players get #wem1 bw
execute if score #wfe1 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_fe with storage bw:tmp loot
execute if score #wau1 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_au with storage bw:tmp loot
execute if score #wdi1 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_di with storage bw:tmp loot
execute if score #wem1 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_em with storage bw:tmp loot
execute if score #kt bw matches 2 run scoreboard players operation #wfe2 bw += #wfe1 bw
execute if score #kt bw matches 2 run scoreboard players operation #wau2 bw += #wau1 bw
execute if score #kt bw matches 2 run scoreboard players operation #wdi2 bw += #wdi1 bw
execute if score #kt bw matches 2 run scoreboard players operation #wem2 bw += #wem1 bw
execute if score #kt bw matches 3 run scoreboard players operation #wfe3 bw += #wfe1 bw
execute if score #kt bw matches 3 run scoreboard players operation #wau3 bw += #wau1 bw
execute if score #kt bw matches 3 run scoreboard players operation #wdi3 bw += #wdi1 bw
execute if score #kt bw matches 3 run scoreboard players operation #wem3 bw += #wem1 bw
execute if score #kt bw matches 4 run scoreboard players operation #wfe4 bw += #wfe1 bw
execute if score #kt bw matches 4 run scoreboard players operation #wau4 bw += #wau1 bw
execute if score #kt bw matches 4 run scoreboard players operation #wdi4 bw += #wdi1 bw
execute if score #kt bw matches 4 run scoreboard players operation #wem4 bw += #wem1 bw
execute if score #kt bw matches 5 run scoreboard players operation #wfe5 bw += #wfe1 bw
execute if score #kt bw matches 5 run scoreboard players operation #wau5 bw += #wau1 bw
execute if score #kt bw matches 5 run scoreboard players operation #wdi5 bw += #wdi1 bw
execute if score #kt bw matches 5 run scoreboard players operation #wem5 bw += #wem1 bw
execute if score #kt bw matches 6 run scoreboard players operation #wfe6 bw += #wfe1 bw
execute if score #kt bw matches 6 run scoreboard players operation #wau6 bw += #wau1 bw
execute if score #kt bw matches 6 run scoreboard players operation #wdi6 bw += #wdi1 bw
execute if score #kt bw matches 6 run scoreboard players operation #wem6 bw += #wem1 bw
execute if score #kt bw matches 7 run scoreboard players operation #wfe7 bw += #wfe1 bw
execute if score #kt bw matches 7 run scoreboard players operation #wau7 bw += #wau1 bw
execute if score #kt bw matches 7 run scoreboard players operation #wdi7 bw += #wdi1 bw
execute if score #kt bw matches 7 run scoreboard players operation #wem7 bw += #wem1 bw
scoreboard players set #wfe1 bw 0
scoreboard players set #wau1 bw 0
scoreboard players set #wdi1 bw 0
scoreboard players set #wem1 bw 0
scoreboard players set #bsw1 bw 0
execute if score #btl1 bw matches 2.. run scoreboard players remove #btl1 bw 1
execute if score #final bw matches 0 run scoreboard players set #bres1 bw 100
execute if score #final bw matches 1 run tellraw @a [{text:""},{text:"<",color:"gray"},{selector:"@s"},{text:"> gg",color:"gray"}]
