execute store result storage bw:tmp loot.fe int 1 run scoreboard players get #wfe1 bw
execute store result storage bw:tmp loot.au int 1 run scoreboard players get #wau1 bw
execute store result storage bw:tmp loot.di int 1 run scoreboard players get #wdi1 bw
execute store result storage bw:tmp loot.em int 1 run scoreboard players get #wem1 bw
execute if score #wfe1 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_fe with storage bw:tmp loot
execute if score #wau1 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_au with storage bw:tmp loot
execute if score #wdi1 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_di with storage bw:tmp loot
execute if score #wem1 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_em with storage bw:tmp loot
scoreboard players set #wfe1 bw 0
scoreboard players set #wau1 bw 0
scoreboard players set #wdi1 bw 0
scoreboard players set #wem1 bw 0
scoreboard players set #bsw1 bw 0
execute if score #btl1 bw matches 2.. run scoreboard players remove #btl1 bw 1
execute if score #final bw matches 0 run scoreboard players set #bres1 bw 100
execute if score #final bw matches 1 run tellraw @a [{text:""},{text:"<",color:"gray"},{selector:"@s"},{text:"> gg",color:"gray"}]
