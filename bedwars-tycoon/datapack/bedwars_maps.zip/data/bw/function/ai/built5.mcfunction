scoreboard players set #bdone5 bw 1
scoreboard players set @s bw.st 0
