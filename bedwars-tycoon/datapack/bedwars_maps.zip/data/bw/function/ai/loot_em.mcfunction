$give @s minecraft:emerald $(em)
