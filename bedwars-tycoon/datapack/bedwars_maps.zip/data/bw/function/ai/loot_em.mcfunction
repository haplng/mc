$give @s minecraft:emerald $(em)
$tellraw @s {text:"+$(em) 에메랄드",color:"dark_green"}
