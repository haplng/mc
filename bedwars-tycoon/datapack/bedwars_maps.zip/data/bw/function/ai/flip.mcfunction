scoreboard players operation @s bw.strafe *= #-1 bw
execute store result score @s bw.t2 run random value 12..32
