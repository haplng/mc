$data modify storage bw:bot tr$(i) prepend from entity @s Pos
$execute if data storage bw:bot tr$(i)[60] run data remove storage bw:bot tr$(i)[-1]
