data modify storage bw:tmp fl set value {path:[],f:"g"}
data modify storage bw:tmp fl.m set from storage bw:ai ctx.m
scoreboard players set #fc bw 0
function bw:ai/flow_find
execute if score #fc bw matches 0 run return 0
scoreboard players set #fn bw 0
function bw:ai/flow_put
function bw:ai/flow_walk with storage bw:tmp fl
execute if score @s bw.team matches 1 if data storage bw:tmp fl{hub:"g1"} run scoreboard players set #own bw 1
execute if score @s bw.team matches 2 if data storage bw:tmp fl{hub:"g2"} run scoreboard players set #own bw 1
execute if score @s bw.team matches 3 if data storage bw:tmp fl{hub:"g3"} run scoreboard players set #own bw 1
execute if score @s bw.team matches 4 if data storage bw:tmp fl{hub:"g4"} run scoreboard players set #own bw 1
execute if score @s bw.team matches 5 if data storage bw:tmp fl{hub:"g5"} run scoreboard players set #own bw 1
execute if score @s bw.team matches 6 if data storage bw:tmp fl{hub:"g6"} run scoreboard players set #own bw 1
execute if score @s bw.team matches 7 if data storage bw:tmp fl{hub:"g7"} run scoreboard players set #own bw 1
execute if score #own bw matches 0 run return 0
execute if score #dbg bw matches 1 if score @s bw.team matches 1 run tellraw @a ["REROUTE-HOME bot1 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g1,limit=1]"}," to ",{nbt:"to1",storage:"bw:bot"}]
execute if score #dbg bw matches 1 if score @s bw.team matches 2 run tellraw @a ["REROUTE-HOME bot2 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g2,limit=1]"}," to ",{nbt:"to2",storage:"bw:bot"}]
execute if score #dbg bw matches 1 if score @s bw.team matches 3 run tellraw @a ["REROUTE-HOME bot3 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g3,limit=1]"}," to ",{nbt:"to3",storage:"bw:bot"}]
execute if score #dbg bw matches 1 if score @s bw.team matches 4 run tellraw @a ["REROUTE-HOME bot4 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g4,limit=1]"}," to ",{nbt:"to4",storage:"bw:bot"}]
execute if score #dbg bw matches 1 if score @s bw.team matches 5 run tellraw @a ["REROUTE-HOME bot5 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g5,limit=1]"}," to ",{nbt:"to5",storage:"bw:bot"}]
execute if score #dbg bw matches 1 if score @s bw.team matches 6 run tellraw @a ["REROUTE-HOME bot6 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g6,limit=1]"}," to ",{nbt:"to6",storage:"bw:bot"}]
execute if score #dbg bw matches 1 if score @s bw.team matches 7 run tellraw @a ["REROUTE-HOME bot7 rrc ",{score:{name:"@s",objective:"bw.rrc"}}," st ",{score:{name:"@s",objective:"bw.st"}}," dest ",{score:{name:"@s",objective:"bw.dest"}}," pos ",{nbt:"Pos",entity:"@s"}," goal ",{nbt:"Pos",entity:"@e[type=minecraft:marker,tag=bw.g7,limit=1]"}," to ",{nbt:"to7",storage:"bw:bot"}]
function bw:ai/rr_set
