scoreboard players remove #bres5 bw 1
execute if score #bres5 bw matches 0 if score #state bw matches 3 run function bw:ai/spawn5
