execute if score #map bw matches 1 run function bw:m/tea/bedkill7
execute if score #map bw matches 2 run function bw:m/chess/bedkill7
execute if score #map bw matches 3 run function bw:m/circus/bedkill7
execute if score #map bw matches 4 run function bw:m/library/bedkill7
execute if score #map bw matches 5 run function bw:m/solar/bedkill7
