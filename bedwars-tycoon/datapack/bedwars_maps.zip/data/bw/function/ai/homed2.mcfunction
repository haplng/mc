scoreboard players set @s bw.rrc 0
execute if score #dbg bw matches 1 run tellraw @a ["HOMED bot2 at ",{nbt:"at2",storage:"bw:bot"}," wanted ",{nbt:"ho2.to",storage:"bw:bot"}]
execute store result score @s bw.dest run data get storage bw:bot ho2.dest
data modify storage bw:tmp rt.to set from storage bw:bot ho2.to
data modify storage bw:tmp cmp set from storage bw:bot ho2.to
execute store success score #diff bw run data modify storage bw:tmp cmp set from storage bw:bot at2
execute if score #diff bw matches 0 unless score @s bw.dest matches 9 run return run function bw:ai/arrive
execute store success score #ok bw run function bw:ai/route2
execute if score #ok bw matches 0 run function bw:ai/to2 {to:"g2",dest:1}
