setblock ~ ~ ~ minecraft:air destroy
scoreboard players set @s bw.mine 0
scoreboard players set @s bw.stuck 0
