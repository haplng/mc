$function bw:ai/to7 {to:"a$(j)",dest:4}
