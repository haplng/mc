$data modify storage bw:bot def1 set from storage bw:nav $(m).def1_$(T)
