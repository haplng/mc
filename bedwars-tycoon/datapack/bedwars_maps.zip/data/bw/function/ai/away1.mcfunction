function bw:ai/pick1
execute store result score #rn bw run random value 1..100
execute if data storage bw:bot {at1:"b1"} run return run function bw:ai/to1 {to:"g1",dest:1}
execute if score #wdi1 bw matches 2.. run return run function bw:ai/to1 {to:"g1",dest:1}
execute if score @s bw.hp matches ..300 run return run function bw:ai/to1 {to:"g1",dest:1}
execute if score @s bw.tgt matches 0.. if score #rn bw matches ..75 run return run function bw:ai/attack1
function bw:ai/to1 {to:"g1",dest:1}
