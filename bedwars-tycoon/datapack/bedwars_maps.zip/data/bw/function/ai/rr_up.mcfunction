function bw:ai/colchk
execute if score #colok bw matches 0 run function bw:ai/crays
execute if score #colok bw matches 0 run return 0
execute if data storage bw:tmp fl.cp run data modify storage bw:tmp fl.path append from storage bw:tmp fl.cp
execute unless data storage bw:tmp fl.cp run data modify storage bw:tmp fl.cp set from entity @s Pos
data modify storage bw:tmp fl.path append from storage bw:tmp fl.cp
scoreboard players operation #by bw += #hy bw
execute store result storage bw:tmp fl.path[-1][1] double 1 run scoreboard players get #by bw
