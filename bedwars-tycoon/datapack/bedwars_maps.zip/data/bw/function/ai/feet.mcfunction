execute if score @s bw.jc matches 0 if predicate bw:ground run function bw:ai/step
function bw:ai/probe
execute if block ^ ^1 ^0.7 #bw:open unless block ^ ^ ^0.7 #bw:open unless block ^ ^2 ^0.7 #bw:open positioned ^ ^ ^0.7 if predicate bw:built run function bw:ai/wall
execute if score #drop bw matches 0 if predicate bw:ground if block ^ ^-1 ^0.6 #bw:open positioned ^ ^-1 ^0.6 run function bw:ai/lay
execute if score #drop bw matches 1 if predicate bw:ground if block ^ ^-1 ^0.6 #bw:open if block ^ ^-2 ^0.6 #bw:open if block ^ ^-3 ^0.6 #bw:open if block ^ ^-4 ^0.6 #bw:open positioned ^ ^-1 ^0.6 run function bw:ai/lay
execute if score #drop bw matches 2 if predicate bw:ground if block ^ ^-1 ^0.6 #bw:open if block ^ ^-2 ^0.6 #bw:open if block ^ ^-3 ^0.6 #bw:open if block ^ ^-4 ^0.6 #bw:open if block ^ ^-5 ^0.6 #bw:open if block ^ ^-6 ^0.6 #bw:open if block ^ ^-7 ^0.6 #bw:open if block ^ ^-8 ^0.6 #bw:open if block ^ ^-9 ^0.6 #bw:open if block ^ ^-10 ^0.6 #bw:open if block ^ ^-11 ^0.6 #bw:open if block ^ ^-12 ^0.6 #bw:open positioned ^ ^-1 ^0.6 run function bw:ai/lay
execute if score @s bw.br matches 1.. run function bw:ai/stance
