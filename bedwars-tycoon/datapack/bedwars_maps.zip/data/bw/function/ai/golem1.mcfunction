scoreboard players remove #wfe1 bw 120
function bw:mob/botgolem
