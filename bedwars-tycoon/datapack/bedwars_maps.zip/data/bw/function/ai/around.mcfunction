scoreboard players remove @s bw.av 1
scoreboard players operation @s bw.mf = #a_walk bw
scoreboard players operation #el bw = @s bw.av0
scoreboard players operation #el bw -= @s bw.av
execute if score #el bw matches 6.. if block ^ ^ ^0.7 #bw:open if block ^ ^1 ^0.7 #bw:open if block ^ ^ ^1.4 #bw:open if block ^ ^1 ^1.4 #bw:open if block ^ ^ ^2.1 #bw:open if block ^ ^1 ^2.1 #bw:open if block ^0.32 ^ ^0.55 #bw:open if block ^0.32 ^1 ^0.55 #bw:open if block ^-0.32 ^ ^0.55 #bw:open if block ^-0.32 ^1 ^0.55 #bw:open run return run scoreboard players set @s bw.av 0
execute if score @s bw.avf matches 4.. rotated ~180 0 run function bw:ai/around3
execute unless score @s bw.avf matches 4.. if score @s bw.avs matches 1 rotated ~90 0 run function bw:ai/around2
execute unless score @s bw.avf matches 4.. if score @s bw.avs matches -1 rotated ~-90 0 run function bw:ai/around2
function bw:ai/unstick
