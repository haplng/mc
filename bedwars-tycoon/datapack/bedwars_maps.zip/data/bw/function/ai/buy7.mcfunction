execute if score #bsw7 bw matches 0 if score #wfe7 bw matches 10.. run function bw:ai/b/7_0
execute if score #lvl bw matches 1.. if score #bar7 bw matches 0 if score #wfe7 bw matches 40.. run function bw:ai/b/7_1
execute if score #lvl bw matches 2.. if score #btl7 bw matches 0 if score #wfe7 bw matches 20.. run function bw:ai/b/7_2
execute if score #lvl bw matches 3.. if score #bsw7 bw matches ..1 if score #wau7 bw matches 7.. run function bw:ai/b/7_3
execute if score #lvl bw matches 4.. if score #bar7 bw matches ..1 if score #wau7 bw matches 12.. run function bw:ai/b/7_4
execute if score #lvl bw matches 5.. if score #btl7 bw matches 1 if score #wfe7 bw matches 10.. if score #wau7 bw matches 3.. run function bw:ai/b/7_5
execute if score #lvl bw matches 6.. if score #bsw7 bw matches ..2 if score #wem7 bw matches 4.. run function bw:ai/b/7_6
execute if score #lvl bw matches 8.. if score #bar7 bw matches ..2 if score #wem7 bw matches 6.. run function bw:ai/b/7_7
execute if score #lvl bw matches 9.. if score #btl7 bw matches 2 if score #wau7 bw matches 6.. run function bw:ai/b/7_8
execute if score #lvl bw matches 6.. if score #bga7 bw matches ..1 if score #wau7 bw matches 3.. run function bw:ai/b/7_9
execute if score #lvl bw matches 7.. if score #bfb7 bw matches ..1 if score #wfe7 bw matches 40.. run function bw:ai/b/7_10
execute if score #lvl bw matches 5.. if score #sharp7 bw matches 0 if score #wdi7 bw matches 4.. run function bw:ai/b/7_11
execute if score #lvl bw matches 6.. if score #prot7 bw matches 0 if score #wdi7 bw matches 2.. run function bw:ai/b/7_12
execute if score #lvl bw matches 8.. if score #prot7 bw matches 1 if score #wdi7 bw matches 4.. run function bw:ai/b/7_13
execute if score #lvl bw matches 10.. if score #prot7 bw matches 2 if score #wdi7 bw matches 8.. run function bw:ai/b/7_14
execute if score #lvl bw matches 12.. if score #prot7 bw matches 3 if score #wdi7 bw matches 16.. run function bw:ai/b/7_15
execute if score #lvl bw matches 7.. if score #fl7 bw matches 0 if score #wdi7 bw matches 2.. run function bw:ai/b/7_16
execute if score #lvl bw matches 10.. if score #fl7 bw matches 1 if score #wdi7 bw matches 4.. run function bw:ai/b/7_17
execute if score #lvl bw matches 8.. if score #trap7 bw matches 0 if score #wdi7 bw matches 1.. run function bw:ai/b/7_18
