function bw:ai/pick5
execute store result score #rn bw run random value 1..100
execute if data storage bw:bot {at5:"b5"} run return run function bw:ai/to5 {to:"g5",dest:1}
execute if score #wdi5 bw matches 2.. run return run function bw:ai/to5 {to:"g5",dest:1}
execute if score @s bw.hp matches ..300 run return run function bw:ai/to5 {to:"g5",dest:1}
execute if score @s bw.tgt matches 0.. if score #rn bw matches ..75 run return run function bw:ai/attack5
function bw:ai/to5 {to:"g5",dest:1}
