scoreboard players add @s bw.trc 1
execute if score @s bw.trc matches 8.. run function bw:ai/crumb0
