execute unless block ^ ^ ^0.7 #bw:open if block ^ ^1 ^0.7 #bw:open run return run function bw:ai/stepup
execute unless block ^0.32 ^ ^0.55 #bw:open if block ^0.32 ^1 ^0.55 #bw:open if block ^-0.32 ^ ^0.55 #bw:open run return run scoreboard players set @s bw.ms -1
execute unless block ^-0.32 ^ ^0.55 #bw:open if block ^-0.32 ^1 ^0.55 #bw:open if block ^0.32 ^ ^0.55 #bw:open run return run scoreboard players set @s bw.ms 1
execute unless block ^0.32 ^ ^0.55 #bw:open if block ^0.32 ^1 ^0.55 #bw:open run return run function bw:ai/stepup
