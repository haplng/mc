scoreboard players remove #bres4 bw 1
execute if score #bres4 bw matches 0 if score #state bw matches 3 run function bw:ai/spawn4
