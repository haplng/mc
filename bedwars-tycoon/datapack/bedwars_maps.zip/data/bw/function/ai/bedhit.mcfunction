scoreboard players add @s bw.mine 1
scoreboard players operation #q bw = @s bw.mine
scoreboard players operation #q bw %= #4 bw
execute if score #q bw matches 0 run swing @s mainhand
execute if score #q bw matches 0 run playsound minecraft:block.wood.hit block @a ~ ~ ~ 0.8 1
execute if score @s bw.mine >= #a_bedt bw run function bw:ai/bedbreak
