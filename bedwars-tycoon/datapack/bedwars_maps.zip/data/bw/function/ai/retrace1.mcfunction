data modify storage bw:bot r1 prepend from storage bw:bot tr1[]
data modify storage bw:bot tr1 set value []
data modify entity @e[type=minecraft:marker,tag=bw.g1,limit=1] Pos set from storage bw:bot r1[0]
scoreboard players set @s bw.stuck 0
scoreboard players set @s bw.wpt 0
scoreboard players set @s bw.av 0
scoreboard players set @s bw.avn 25
scoreboard players set @s bw.avc 0
scoreboard players set @s bw.off 0
return 1
