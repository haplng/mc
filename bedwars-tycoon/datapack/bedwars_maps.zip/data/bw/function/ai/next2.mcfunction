scoreboard players set @s bw.nearc 0
data remove storage bw:bot r2[0]
data modify storage bw:bot tr2 set value []
execute unless data storage bw:bot r2[0] run return run function bw:ai/arrive2
data modify entity @e[type=minecraft:marker,tag=bw.g2,limit=1] Pos set from storage bw:bot r2[0]
scoreboard players set @s bw.stuck 0
scoreboard players set @s bw.wpt 0
scoreboard players set @s bw.av 0
scoreboard players set @s bw.avn 25
scoreboard players set @s bw.avc 0
