execute unless block ~ ~ ~ #bw:open run return run function bw:ai/rayhit
scoreboard players add #rs bw 1
execute if score #rs bw matches ..12 positioned ^ ^ ^0.4 run function bw:ai/ray
