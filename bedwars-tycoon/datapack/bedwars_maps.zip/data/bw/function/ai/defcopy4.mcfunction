$data modify storage bw:bot def4 set from storage bw:nav $(m).def4_$(T)
