$data modify entity @e[type=minecraft:marker,tag=bw.g$(i),limit=1] Pos set from storage bw:nav $(m).bed$(j)
