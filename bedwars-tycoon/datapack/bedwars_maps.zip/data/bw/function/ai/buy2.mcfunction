execute if score #bsw2 bw matches 0 if score #wfe2 bw matches 10.. run function bw:ai/b/2_0
execute if score #lvl bw matches 1.. if score #bar2 bw matches 0 if score #wfe2 bw matches 40.. run function bw:ai/b/2_1
execute if score #lvl bw matches 2.. if score #btl2 bw matches 0 if score #wfe2 bw matches 20.. run function bw:ai/b/2_2
execute if score #lvl bw matches 3.. if score #bsw2 bw matches ..1 if score #wau2 bw matches 7.. run function bw:ai/b/2_3
execute if score #lvl bw matches 4.. if score #bar2 bw matches ..1 if score #wau2 bw matches 12.. run function bw:ai/b/2_4
execute if score #lvl bw matches 5.. if score #btl2 bw matches 1 if score #wfe2 bw matches 10.. if score #wau2 bw matches 3.. run function bw:ai/b/2_5
execute if score #lvl bw matches 6.. if score #bsw2 bw matches ..2 if score #wem2 bw matches 4.. run function bw:ai/b/2_6
execute if score #lvl bw matches 8.. if score #bar2 bw matches ..2 if score #wem2 bw matches 6.. run function bw:ai/b/2_7
execute if score #lvl bw matches 9.. if score #btl2 bw matches 2 if score #wau2 bw matches 6.. run function bw:ai/b/2_8
execute if score #lvl bw matches 6.. if score #bga2 bw matches ..1 if score #wau2 bw matches 3.. run function bw:ai/b/2_9
execute if score #lvl bw matches 7.. if score #bfb2 bw matches ..1 if score #wfe2 bw matches 40.. run function bw:ai/b/2_10
execute if score #lvl bw matches 5.. if score #sharp2 bw matches 0 if score #wdi2 bw matches 4.. run function bw:ai/b/2_11
execute if score #lvl bw matches 6.. if score #prot2 bw matches 0 if score #wdi2 bw matches 2.. run function bw:ai/b/2_12
execute if score #lvl bw matches 8.. if score #prot2 bw matches 1 if score #wdi2 bw matches 4.. run function bw:ai/b/2_13
execute if score #lvl bw matches 10.. if score #prot2 bw matches 2 if score #wdi2 bw matches 8.. run function bw:ai/b/2_14
execute if score #lvl bw matches 12.. if score #prot2 bw matches 3 if score #wdi2 bw matches 16.. run function bw:ai/b/2_15
execute if score #lvl bw matches 7.. if score #fl2 bw matches 0 if score #wdi2 bw matches 2.. run function bw:ai/b/2_16
execute if score #lvl bw matches 10.. if score #fl2 bw matches 1 if score #wdi2 bw matches 4.. run function bw:ai/b/2_17
execute if score #lvl bw matches 8.. if score #trap2 bw matches 0 if score #wdi2 bw matches 1.. run function bw:ai/b/2_18
