data modify entity @s pose set value "standing"
scoreboard players set @s bw.pose 0
