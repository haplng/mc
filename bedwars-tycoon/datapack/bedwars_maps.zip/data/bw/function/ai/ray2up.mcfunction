scoreboard players add #up bw 1
execute if score #up bw matches 2.. run return 0
scoreboard players add #ryo bw 1
execute positioned ~ ~1 ~ run function bw:ai/ray2b
