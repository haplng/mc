scoreboard players remove #bres3 bw 1
execute if score #bres3 bw matches 0 if score #state bw matches 3 run function bw:ai/spawn3
