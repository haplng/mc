scoreboard players set @s bw.trc 0
execute unless predicate bw:ground run return 0
execute store result score #x bw run data get entity @s Pos[0] 2
execute store result score #z bw run data get entity @s Pos[2] 2
execute if score #x bw = @s bw.tx if score #z bw = @s bw.tz run return 0
scoreboard players operation @s bw.tx = #x bw
scoreboard players operation @s bw.tz = #z bw
execute if score @s bw.team matches 1 run return run function bw:ai/crumb {i:1}
execute if score @s bw.team matches 2 run return run function bw:ai/crumb {i:2}
execute if score @s bw.team matches 3 run return run function bw:ai/crumb {i:3}
execute if score @s bw.team matches 4 run return run function bw:ai/crumb {i:4}
execute if score @s bw.team matches 5 run return run function bw:ai/crumb {i:5}
execute if score @s bw.team matches 6 run return run function bw:ai/crumb {i:6}
execute if score @s bw.team matches 7 run return run function bw:ai/crumb {i:7}
