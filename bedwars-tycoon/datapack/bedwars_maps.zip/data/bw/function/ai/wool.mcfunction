execute if score @s bw.team matches 1 run setblock ~ ~ ~ minecraft:blue_wool
execute if score @s bw.team matches 2 run setblock ~ ~ ~ minecraft:lime_wool
execute if score @s bw.team matches 3 run setblock ~ ~ ~ minecraft:yellow_wool
execute if score @s bw.team matches 4 run setblock ~ ~ ~ minecraft:cyan_wool
execute if score @s bw.team matches 5 run setblock ~ ~ ~ minecraft:white_wool
execute if score @s bw.team matches 6 run setblock ~ ~ ~ minecraft:pink_wool
execute if score @s bw.team matches 7 run setblock ~ ~ ~ minecraft:gray_wool
