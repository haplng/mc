scoreboard players set @s bw.st 1
scoreboard players operation @s bw.t1 = #a_think bw
execute unless data storage bw:bot {at3:"g3"} unless data storage bw:bot {at3:"k3"} run return run function bw:ai/away3
execute if data storage bw:bot {at3:"k3"} run return run function bw:ai/to3 {to:"g3",dest:1}
execute if score #bsw3 bw matches 0 if score #wfe3 bw < #a_wait bw run return 0
scoreboard players set #can bw 0
execute if score #bsw3 bw matches 0 if score #wfe3 bw matches 10.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 1.. if score #bar3 bw matches 0 if score #wfe3 bw matches 40.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 2.. if score #btl3 bw matches 0 if score #wfe3 bw matches 20.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 3.. if score #bsw3 bw matches ..1 if score #wau3 bw matches 7.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 4.. if score #bar3 bw matches ..1 if score #wau3 bw matches 12.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 5.. if score #btl3 bw matches 1 if score #wfe3 bw matches 10.. if score #wau3 bw matches 3.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 6.. if score #bsw3 bw matches ..2 if score #wem3 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 8.. if score #bar3 bw matches ..2 if score #wem3 bw matches 6.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 9.. if score #btl3 bw matches 2 if score #wau3 bw matches 6.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 6.. if score #bga3 bw matches ..1 if score #wau3 bw matches 3.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 7.. if score #bfb3 bw matches ..1 if score #wfe3 bw matches 40.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 5.. if score #sharp3 bw matches 0 if score #wdi3 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 6.. if score #prot3 bw matches 0 if score #wdi3 bw matches 2.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 8.. if score #prot3 bw matches 1 if score #wdi3 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 10.. if score #prot3 bw matches 2 if score #wdi3 bw matches 8.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 12.. if score #prot3 bw matches 3 if score #wdi3 bw matches 16.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 7.. if score #fl3 bw matches 0 if score #wdi3 bw matches 2.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 10.. if score #fl3 bw matches 1 if score #wdi3 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 8.. if score #tqn3 bw matches 0 if score #wdi3 bw matches 1.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 11.. if score #tqn3 bw matches 1 if score #wdi3 bw matches 2.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 13.. if score #dbuff3 bw matches 0 if score #wdi3 bw matches 5.. run scoreboard players set #can bw 1
execute if score #can bw matches 1 run return run function bw:ai/to3 {to:"k3",dest:2}
execute if score #bed3 bw matches 1 if score #bdone3 bw matches 0 if data storage bw:bot def3[0] run return run function bw:ai/to3 {to:"b3",dest:3}
execute store result score #rn bw run random value 1..100
execute if score #lvl bw matches 5.. if score #sec bw matches 60.. if score #rn bw matches ..30 run return run function bw:ai/dia3
function bw:ai/pick3
execute if score @s bw.tgt matches 0.. run return run function bw:ai/attack3
