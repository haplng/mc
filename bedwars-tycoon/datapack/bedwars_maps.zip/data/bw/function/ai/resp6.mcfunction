scoreboard players remove #bres6 bw 1
execute if score #bres6 bw matches 0 if score #state bw matches 3 run function bw:ai/spawn6
