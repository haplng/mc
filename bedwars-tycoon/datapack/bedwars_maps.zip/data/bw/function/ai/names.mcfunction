data modify storage bw:ai pool set from storage bw:ai names
execute store result storage bw:tmp k int 1 run random value 0..47
function bw:ai/name1 with storage bw:tmp
execute store result storage bw:tmp k int 1 run random value 0..46
function bw:ai/name2 with storage bw:tmp
execute store result storage bw:tmp k int 1 run random value 0..45
function bw:ai/name3 with storage bw:tmp
execute store result storage bw:tmp k int 1 run random value 0..44
function bw:ai/name4 with storage bw:tmp
execute store result storage bw:tmp k int 1 run random value 0..43
function bw:ai/name5 with storage bw:tmp
execute store result storage bw:tmp k int 1 run random value 0..42
function bw:ai/name6 with storage bw:tmp
execute store result storage bw:tmp k int 1 run random value 0..41
function bw:ai/name7 with storage bw:tmp
