execute store result storage bw:tmp loot.fe int 1 run scoreboard players get #wfe3 bw
execute store result storage bw:tmp loot.au int 1 run scoreboard players get #wau3 bw
execute store result storage bw:tmp loot.di int 1 run scoreboard players get #wdi3 bw
execute store result storage bw:tmp loot.em int 1 run scoreboard players get #wem3 bw
execute if score #wfe3 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_fe with storage bw:tmp loot
execute if score #wau3 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_au with storage bw:tmp loot
execute if score #wdi3 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_di with storage bw:tmp loot
execute if score #wem3 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_em with storage bw:tmp loot
execute if score #kt bw matches 1 run scoreboard players operation #wfe1 bw += #wfe3 bw
execute if score #kt bw matches 1 run scoreboard players operation #wau1 bw += #wau3 bw
execute if score #kt bw matches 1 run scoreboard players operation #wdi1 bw += #wdi3 bw
execute if score #kt bw matches 1 run scoreboard players operation #wem1 bw += #wem3 bw
execute if score #kt bw matches 2 run scoreboard players operation #wfe2 bw += #wfe3 bw
execute if score #kt bw matches 2 run scoreboard players operation #wau2 bw += #wau3 bw
execute if score #kt bw matches 2 run scoreboard players operation #wdi2 bw += #wdi3 bw
execute if score #kt bw matches 2 run scoreboard players operation #wem2 bw += #wem3 bw
execute if score #kt bw matches 4 run scoreboard players operation #wfe4 bw += #wfe3 bw
execute if score #kt bw matches 4 run scoreboard players operation #wau4 bw += #wau3 bw
execute if score #kt bw matches 4 run scoreboard players operation #wdi4 bw += #wdi3 bw
execute if score #kt bw matches 4 run scoreboard players operation #wem4 bw += #wem3 bw
execute if score #kt bw matches 5 run scoreboard players operation #wfe5 bw += #wfe3 bw
execute if score #kt bw matches 5 run scoreboard players operation #wau5 bw += #wau3 bw
execute if score #kt bw matches 5 run scoreboard players operation #wdi5 bw += #wdi3 bw
execute if score #kt bw matches 5 run scoreboard players operation #wem5 bw += #wem3 bw
execute if score #kt bw matches 6 run scoreboard players operation #wfe6 bw += #wfe3 bw
execute if score #kt bw matches 6 run scoreboard players operation #wau6 bw += #wau3 bw
execute if score #kt bw matches 6 run scoreboard players operation #wdi6 bw += #wdi3 bw
execute if score #kt bw matches 6 run scoreboard players operation #wem6 bw += #wem3 bw
execute if score #kt bw matches 7 run scoreboard players operation #wfe7 bw += #wfe3 bw
execute if score #kt bw matches 7 run scoreboard players operation #wau7 bw += #wau3 bw
execute if score #kt bw matches 7 run scoreboard players operation #wdi7 bw += #wdi3 bw
execute if score #kt bw matches 7 run scoreboard players operation #wem7 bw += #wem3 bw
scoreboard players set #wfe3 bw 0
scoreboard players set #wau3 bw 0
scoreboard players set #wdi3 bw 0
scoreboard players set #wem3 bw 0
scoreboard players set #bsw3 bw 0
execute if score #btl3 bw matches 2.. run scoreboard players remove #btl3 bw 1
execute if score #final bw matches 0 run scoreboard players set #bres3 bw 100
execute if score #final bw matches 1 run tellraw @a [{text:""},{text:"<",color:"gray"},{selector:"@s"},{text:"> gg",color:"gray"}]
