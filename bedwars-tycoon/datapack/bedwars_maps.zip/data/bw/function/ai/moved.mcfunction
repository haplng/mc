scoreboard players set @s bw.idle 0
execute store result score #x bw run data get entity @s Pos[0] 2
execute store result score #z bw run data get entity @s Pos[2] 2
scoreboard players set #y bw 0
scoreboard players set #same bw 0
execute if score #x bw = @s bw.px if score #z bw = @s bw.pz run scoreboard players set #same bw 1
execute if score #same bw matches 1 run scoreboard players add @s bw.stuck 20
execute if score #same bw matches 0 run scoreboard players set @s bw.stuck 0
scoreboard players operation @s bw.px = #x bw
scoreboard players operation @s bw.py = #y bw
scoreboard players operation @s bw.pz = #z bw
