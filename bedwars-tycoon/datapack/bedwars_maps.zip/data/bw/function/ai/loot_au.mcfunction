$give @s minecraft:gold_ingot $(au)
$tellraw @s {text:"+$(au) 금",color:"gold"}
