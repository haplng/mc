$give @s minecraft:gold_ingot $(au)
