swing @s mainhand
execute store result score #rn bw run random value 0..3
scoreboard players operation @s bw.atk = #a_cd bw
scoreboard players operation @s bw.atk += #rn bw
execute store result score #rn bw run random value 1..100
execute if score #rn bw > #a_acc bw run return 0
execute if score @s bw.slow matches 1.. if score #rn bw matches 40.. run return 0
execute if score @s bw.sw matches 0 run scoreboard players set #dmg bw 400
execute if score @s bw.sw matches 1 run scoreboard players set #dmg bw 500
execute if score @s bw.sw matches 2 run scoreboard players set #dmg bw 600
execute if score @s bw.sw matches 3 run scoreboard players set #dmg bw 700
execute if score @s bw.team matches 1 if score #sharp1 bw matches 1.. run scoreboard players add #dmg bw 125
execute if score @s bw.team matches 2 if score #sharp2 bw matches 1.. run scoreboard players add #dmg bw 125
execute if score @s bw.team matches 3 if score #sharp3 bw matches 1.. run scoreboard players add #dmg bw 125
execute if score @s bw.team matches 4 if score #sharp4 bw matches 1.. run scoreboard players add #dmg bw 125
execute if score @s bw.team matches 5 if score #sharp5 bw matches 1.. run scoreboard players add #dmg bw 125
execute if score @s bw.team matches 6 if score #sharp6 bw matches 1.. run scoreboard players add #dmg bw 125
execute if score @s bw.team matches 7 if score #sharp7 bw matches 1.. run scoreboard players add #dmg bw 125
execute as @e[tag=bw.foe,limit=1] run function bw:ai/soften
execute store result storage bw:tmp hit.d float 0.01 run scoreboard players get #dmg bw
function bw:ai/hit with storage bw:tmp hit
