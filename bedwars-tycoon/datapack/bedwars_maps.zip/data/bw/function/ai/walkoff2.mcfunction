rotate @s ~ 0
scoreboard players operation @s bw.mf = #a_walk bw
function bw:ai/feet
