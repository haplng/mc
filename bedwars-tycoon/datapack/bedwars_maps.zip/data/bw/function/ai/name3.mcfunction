$data modify storage bw:ai n3 set from storage bw:ai names[$(k)]
