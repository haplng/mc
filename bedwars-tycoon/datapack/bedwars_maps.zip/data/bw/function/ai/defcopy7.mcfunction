$data modify storage bw:bot def7 set from storage bw:nav $(m).def7_$(T)
