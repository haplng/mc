$data modify storage bw:bot r1 set from storage bw:nav $(m).$(at)_$(to)
$data modify storage bw:bot to1 set value "$(to)"
$execute if data storage bw:bot r1[0] run data modify storage bw:bot r1 prepend from storage bw:nav $(m).n_$(at)
