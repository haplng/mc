$data modify storage bw:bot r4 set from storage bw:nav $(m).$(at)_$(to)
$data modify storage bw:bot to4 set value "$(to)"
$execute if data storage bw:bot r4[0] run data modify storage bw:bot r4 prepend from storage bw:nav $(m).n_$(at)
