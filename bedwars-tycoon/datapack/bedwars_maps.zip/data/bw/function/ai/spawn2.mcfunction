execute if score #map bw matches 1 run function bw:m/tea/bot2
execute if score #map bw matches 2 run function bw:m/chess/bot2
execute if score #map bw matches 3 run function bw:m/circus/bot2
execute if score #map bw matches 4 run function bw:m/library/bot2
execute if score #map bw matches 5 run function bw:m/solar/bot2
