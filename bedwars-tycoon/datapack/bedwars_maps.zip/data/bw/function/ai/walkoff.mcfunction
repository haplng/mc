scoreboard players remove @s bw.off 1
scoreboard players set #drop bw 2
scoreboard players set #high bw 1
execute if predicate bw:ground if score @s bw.offa matches 7.. run return run scoreboard players set @s bw.off 0
execute if predicate bw:ground run scoreboard players set @s bw.offa 0
execute unless predicate bw:ground run scoreboard players add @s bw.offa 1
execute rotated as @s rotated ~ 0 run function bw:ai/walkoff2
