execute store result storage bw:tmp at.j int 1 run scoreboard players get @s bw.tgt
function bw:ai/attack3b with storage bw:tmp at
