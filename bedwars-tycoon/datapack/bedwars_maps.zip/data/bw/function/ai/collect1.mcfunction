scoreboard players operation #wfe1 bw += #pfe1 bw
scoreboard players set #pfe1 bw 0
scoreboard players operation #wau1 bw += #pau1 bw
scoreboard players set #pau1 bw 0
scoreboard players operation #wem1 bw += #pem1 bw
scoreboard players set #pem1 bw 0
