$function bw:ai/to2 {to:"a$(j)",dest:4}
