scoreboard players operation #wfe5 bw += #pfe5 bw
scoreboard players set #pfe5 bw 0
scoreboard players operation #wau5 bw += #pau5 bw
scoreboard players set #pau5 bw 0
scoreboard players operation #wem5 bw += #pem5 bw
scoreboard players set #pem5 bw 0
