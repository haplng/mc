execute unless entity @e[type=minecraft:marker,tag=bw.gen.iron,tag=bw.t.white,distance=..6] run return 0
scoreboard players operation #wfe5 bw += #pfe5 bw
scoreboard players set #pfe5 bw 0
scoreboard players operation #wau5 bw += #pau5 bw
scoreboard players set #pau5 bw 0
scoreboard players operation #wem5 bw += #pem5 bw
scoreboard players set #pem5 bw 0
