execute if score @s bw.t1 matches 15 run rotate @s ~40 0
