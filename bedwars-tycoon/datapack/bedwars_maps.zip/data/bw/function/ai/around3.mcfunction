rotate @s ~ 0
function bw:ai/feet
