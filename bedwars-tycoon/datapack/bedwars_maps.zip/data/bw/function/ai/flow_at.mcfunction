$scoreboard players set #ax bw $(dx)
$scoreboard players set #ay bw $(dy)
$scoreboard players set #az bw $(dz)
scoreboard players operation #ax bw += #fx bw
scoreboard players operation #ay bw += #fy bw
scoreboard players operation #az bw += #fz bw
execute store result storage bw:tmp fl.x int 1 run scoreboard players get #ax bw
execute store result storage bw:tmp fl.y int 1 run scoreboard players get #ay bw
execute store result storage bw:tmp fl.z int 1 run scoreboard players get #az bw
function bw:ai/flow_get with storage bw:tmp fl
execute if score #fc bw matches 1.. run scoreboard players operation #fx bw = #ax bw
execute if score #fc bw matches 1.. run scoreboard players operation #fy bw = #ay bw
execute if score #fc bw matches 1.. run scoreboard players operation #fz bw = #az bw
