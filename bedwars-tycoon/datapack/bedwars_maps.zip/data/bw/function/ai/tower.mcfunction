scoreboard players set @s bw.mf 0
execute if predicate bw:ground run scoreboard players set @s bw.twr 14
execute unless block ~ ~2 ~ #bw:open positioned ~ ~2 ~ run return run function bw:ai/wall
execute if predicate bw:ground align xz positioned ~0.5 ~ ~0.5 unless entity @s[distance=..0.2] run tp @s ~ ~ ~
execute if score @s bw.jc matches 0 if predicate bw:ground run function bw:ai/jump
execute positioned ~ ~-1.05 ~ if block ~ ~ ~ #bw:open unless predicate bw:ground run function bw:ai/lay
scoreboard players set @s bw.br 0
function bw:ai/unstick
