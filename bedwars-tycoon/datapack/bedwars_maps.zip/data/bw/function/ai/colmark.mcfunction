data modify storage bw:tmp fl.cp set from entity @s Pos
kill @s
