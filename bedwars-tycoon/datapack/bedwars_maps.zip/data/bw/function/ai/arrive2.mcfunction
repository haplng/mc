data modify storage bw:bot at2 set from storage bw:bot to2
function bw:ai/arrive
