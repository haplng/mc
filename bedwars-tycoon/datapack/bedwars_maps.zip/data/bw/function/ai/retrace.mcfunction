execute if score @s bw.team matches 1 if data storage bw:bot tr1[0] run return run function bw:ai/retrace1
execute if score @s bw.team matches 2 if data storage bw:bot tr2[0] run return run function bw:ai/retrace2
execute if score @s bw.team matches 3 if data storage bw:bot tr3[0] run return run function bw:ai/retrace3
execute if score @s bw.team matches 4 if data storage bw:bot tr4[0] run return run function bw:ai/retrace4
execute if score @s bw.team matches 5 if data storage bw:bot tr5[0] run return run function bw:ai/retrace5
execute if score @s bw.team matches 6 if data storage bw:bot tr6[0] run return run function bw:ai/retrace6
execute if score @s bw.team matches 7 if data storage bw:bot tr7[0] run return run function bw:ai/retrace7
return fail
