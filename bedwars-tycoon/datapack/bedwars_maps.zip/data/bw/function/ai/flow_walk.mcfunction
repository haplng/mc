$execute store result score #fc bw run data get storage bwflow:$(f) $(m)."$(x) $(y) $(z)"
execute if score #fc bw matches 40 run return run function bw:ai/flow_hub with storage bw:tmp fl
execute if score #fc bw matches 50 run return run function bw:ai/flow_esc with storage bw:tmp fl
execute unless score #fc bw matches 1..32 run return 0
scoreboard players remove #fc bw 1
scoreboard players operation #fk bw = #fc bw
scoreboard players operation #fk bw /= #8 bw
scoreboard players operation #fc bw %= #8 bw
scoreboard players remove #fc bw 6
execute if score #fk bw matches 0 run scoreboard players add #fx bw 1
execute if score #fk bw matches 1 run scoreboard players remove #fx bw 1
execute if score #fk bw matches 2 run scoreboard players add #fz bw 1
execute if score #fk bw matches 3 run scoreboard players remove #fz bw 1
scoreboard players operation #fy bw += #fc bw
function bw:ai/flow_put
scoreboard players add #fn bw 1
execute if score #fn bw matches 600.. run return 0
function bw:ai/flow_walk with storage bw:tmp fl
