execute if score #fc bw matches 0 run scoreboard players operation #rx bw = #fx bw
execute if score #fc bw matches 0 run scoreboard players operation #rz bw = #fz bw
execute if score #fc bw matches 0 run scoreboard players set #rn bw 0
execute if score #fc bw matches 0 run scoreboard players set #ryo bw 0
execute if score #fc bw matches 0 run scoreboard players set #up bw 0
execute if score #fc bw matches 0 positioned ~1 ~ ~0 run function bw:ai/ray0
execute if score #fc bw matches 0 run scoreboard players operation #rx bw = #fx bw
execute if score #fc bw matches 0 run scoreboard players operation #rz bw = #fz bw
execute if score #fc bw matches 0 run scoreboard players set #rn bw 0
execute if score #fc bw matches 0 run scoreboard players set #ryo bw 0
execute if score #fc bw matches 0 run scoreboard players set #up bw 0
execute if score #fc bw matches 0 positioned ~-1 ~ ~0 run function bw:ai/ray1
execute if score #fc bw matches 0 run scoreboard players operation #rx bw = #fx bw
execute if score #fc bw matches 0 run scoreboard players operation #rz bw = #fz bw
execute if score #fc bw matches 0 run scoreboard players set #rn bw 0
execute if score #fc bw matches 0 run scoreboard players set #ryo bw 0
execute if score #fc bw matches 0 run scoreboard players set #up bw 0
execute if score #fc bw matches 0 positioned ~0 ~ ~1 run function bw:ai/ray2
execute if score #fc bw matches 0 run scoreboard players operation #rx bw = #fx bw
execute if score #fc bw matches 0 run scoreboard players operation #rz bw = #fz bw
execute if score #fc bw matches 0 run scoreboard players set #rn bw 0
execute if score #fc bw matches 0 run scoreboard players set #ryo bw 0
execute if score #fc bw matches 0 run scoreboard players set #up bw 0
execute if score #fc bw matches 0 positioned ~0 ~ ~-1 run function bw:ai/ray3
execute if score #fc bw matches 0 run scoreboard players operation #rx bw = #fx bw
execute if score #fc bw matches 0 run scoreboard players operation #rz bw = #fz bw
execute if score #fc bw matches 0 run scoreboard players set #rn bw 0
execute if score #fc bw matches 0 run scoreboard players set #ryo bw 0
execute if score #fc bw matches 0 run scoreboard players set #up bw 0
execute if score #fc bw matches 0 positioned ~1 ~ ~1 run function bw:ai/ray4
execute if score #fc bw matches 0 run scoreboard players operation #rx bw = #fx bw
execute if score #fc bw matches 0 run scoreboard players operation #rz bw = #fz bw
execute if score #fc bw matches 0 run scoreboard players set #rn bw 0
execute if score #fc bw matches 0 run scoreboard players set #ryo bw 0
execute if score #fc bw matches 0 run scoreboard players set #up bw 0
execute if score #fc bw matches 0 positioned ~1 ~ ~-1 run function bw:ai/ray5
execute if score #fc bw matches 0 run scoreboard players operation #rx bw = #fx bw
execute if score #fc bw matches 0 run scoreboard players operation #rz bw = #fz bw
execute if score #fc bw matches 0 run scoreboard players set #rn bw 0
execute if score #fc bw matches 0 run scoreboard players set #ryo bw 0
execute if score #fc bw matches 0 run scoreboard players set #up bw 0
execute if score #fc bw matches 0 positioned ~-1 ~ ~1 run function bw:ai/ray6
execute if score #fc bw matches 0 run scoreboard players operation #rx bw = #fx bw
execute if score #fc bw matches 0 run scoreboard players operation #rz bw = #fz bw
execute if score #fc bw matches 0 run scoreboard players set #rn bw 0
execute if score #fc bw matches 0 run scoreboard players set #ryo bw 0
execute if score #fc bw matches 0 run scoreboard players set #up bw 0
execute if score #fc bw matches 0 positioned ~-1 ~ ~-1 run function bw:ai/ray7
