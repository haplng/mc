scoreboard players set #bdone4 bw 1
scoreboard players set @s bw.st 0
