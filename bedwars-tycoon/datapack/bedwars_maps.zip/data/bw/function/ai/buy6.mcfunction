execute if score #bsw6 bw matches 0 if score #wfe6 bw matches 10.. run function bw:ai/b/6_0
execute if score #lvl bw matches 1.. if score #bar6 bw matches 0 if score #wfe6 bw matches 40.. run function bw:ai/b/6_1
execute if score #lvl bw matches 2.. if score #btl6 bw matches 0 if score #wfe6 bw matches 20.. run function bw:ai/b/6_2
execute if score #lvl bw matches 3.. if score #bsw6 bw matches ..1 if score #wau6 bw matches 7.. run function bw:ai/b/6_3
execute if score #lvl bw matches 4.. if score #bar6 bw matches ..1 if score #wau6 bw matches 12.. run function bw:ai/b/6_4
execute if score #lvl bw matches 5.. if score #btl6 bw matches 1 if score #wfe6 bw matches 10.. if score #wau6 bw matches 3.. run function bw:ai/b/6_5
execute if score #lvl bw matches 6.. if score #bsw6 bw matches ..2 if score #wem6 bw matches 4.. run function bw:ai/b/6_6
execute if score #lvl bw matches 8.. if score #bar6 bw matches ..2 if score #wem6 bw matches 6.. run function bw:ai/b/6_7
execute if score #lvl bw matches 9.. if score #btl6 bw matches 2 if score #wau6 bw matches 6.. run function bw:ai/b/6_8
execute if score #lvl bw matches 6.. if score #bga6 bw matches ..1 if score #wau6 bw matches 3.. run function bw:ai/b/6_9
execute if score #lvl bw matches 7.. if score #bfb6 bw matches ..1 if score #wfe6 bw matches 40.. run function bw:ai/b/6_10
execute if score #lvl bw matches 5.. if score #sharp6 bw matches 0 if score #wdi6 bw matches 4.. run function bw:ai/b/6_11
execute if score #lvl bw matches 6.. if score #prot6 bw matches 0 if score #wdi6 bw matches 2.. run function bw:ai/b/6_12
execute if score #lvl bw matches 8.. if score #prot6 bw matches 1 if score #wdi6 bw matches 4.. run function bw:ai/b/6_13
execute if score #lvl bw matches 10.. if score #prot6 bw matches 2 if score #wdi6 bw matches 8.. run function bw:ai/b/6_14
execute if score #lvl bw matches 12.. if score #prot6 bw matches 3 if score #wdi6 bw matches 16.. run function bw:ai/b/6_15
execute if score #lvl bw matches 7.. if score #fl6 bw matches 0 if score #wdi6 bw matches 2.. run function bw:ai/b/6_16
execute if score #lvl bw matches 10.. if score #fl6 bw matches 1 if score #wdi6 bw matches 4.. run function bw:ai/b/6_17
execute if score #lvl bw matches 8.. if score #trap6 bw matches 0 if score #wdi6 bw matches 1.. run function bw:ai/b/6_18
