execute unless score @s bw.dest matches 9 run data modify storage bw:bot ho4 set value {}
execute unless score @s bw.dest matches 9 run data modify storage bw:bot ho4.to set from storage bw:bot to4
execute unless score @s bw.dest matches 9 store result storage bw:bot ho4.dest int 1 run scoreboard players get @s bw.dest
data modify storage bw:bot r4 set from storage bw:tmp fl.path
data modify storage bw:bot to4 set from storage bw:tmp fl.hub
data modify storage bw:bot tr4 set value []
scoreboard players set @s bw.dest 9
scoreboard players set @s bw.st 2
data modify entity @e[type=minecraft:marker,tag=bw.g4,limit=1] Pos set from storage bw:bot r4[0]
