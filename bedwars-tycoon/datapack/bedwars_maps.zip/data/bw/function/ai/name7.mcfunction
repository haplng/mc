$data modify storage bw:ai n7 set from storage bw:ai names[$(k)]
