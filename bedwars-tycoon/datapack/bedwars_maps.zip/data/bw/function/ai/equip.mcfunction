execute if score @s bw.sw matches 0 run item replace entity @s weapon.mainhand with minecraft:wooden_sword
execute if score @s bw.sw matches 1 run item replace entity @s weapon.mainhand with minecraft:stone_sword
execute if score @s bw.sw matches 2 run item replace entity @s weapon.mainhand with minecraft:iron_sword
execute if score @s bw.sw matches 3 run item replace entity @s weapon.mainhand with minecraft:diamond_sword
execute if score @s bw.armor matches 3 run item replace entity @s armor.legs with minecraft:diamond_leggings
execute if score @s bw.armor matches 3 run item replace entity @s armor.feet with minecraft:diamond_boots
execute if score @s bw.armor matches 2 run item replace entity @s armor.legs with minecraft:iron_leggings
execute if score @s bw.armor matches 2 run item replace entity @s armor.feet with minecraft:iron_boots
execute if score @s bw.armor matches 1 run item replace entity @s armor.legs with minecraft:chainmail_leggings
execute if score @s bw.armor matches 1 run item replace entity @s armor.feet with minecraft:chainmail_boots
execute if score @s bw.team matches 1 run item replace entity @s armor.head with minecraft:leather_helmet[dyed_color=3949738,enchantments={"bw:bot":1},enchantment_glint_override=false]
execute if score @s bw.team matches 1 run item replace entity @s armor.chest with minecraft:leather_chestplate[dyed_color=3949738]
execute if score @s bw.team matches 1 if score @s bw.armor matches 0 run item replace entity @s armor.legs with minecraft:leather_leggings[dyed_color=3949738]
execute if score @s bw.team matches 1 if score @s bw.armor matches 0 run item replace entity @s armor.feet with minecraft:leather_boots[dyed_color=3949738]
execute if score @s bw.team matches 1 if score #prot1 bw matches 1 run function bw:game/prot1b
execute if score @s bw.team matches 1 if score #prot1 bw matches 2 run function bw:game/prot2b
execute if score @s bw.team matches 1 if score #prot1 bw matches 3 run function bw:game/prot3b
execute if score @s bw.team matches 1 if score #prot1 bw matches 4 run function bw:game/prot4b
execute if score @s bw.team matches 1 if score #sharp1 bw matches 1.. run item modify entity @s weapon.mainhand bw:sharp
execute if score @s bw.team matches 2 run item replace entity @s armor.head with minecraft:leather_helmet[dyed_color=8439583,enchantments={"bw:bot":1},enchantment_glint_override=false]
execute if score @s bw.team matches 2 run item replace entity @s armor.chest with minecraft:leather_chestplate[dyed_color=8439583]
execute if score @s bw.team matches 2 if score @s bw.armor matches 0 run item replace entity @s armor.legs with minecraft:leather_leggings[dyed_color=8439583]
execute if score @s bw.team matches 2 if score @s bw.armor matches 0 run item replace entity @s armor.feet with minecraft:leather_boots[dyed_color=8439583]
execute if score @s bw.team matches 2 if score #prot2 bw matches 1 run function bw:game/prot1b
execute if score @s bw.team matches 2 if score #prot2 bw matches 2 run function bw:game/prot2b
execute if score @s bw.team matches 2 if score #prot2 bw matches 3 run function bw:game/prot3b
execute if score @s bw.team matches 2 if score #prot2 bw matches 4 run function bw:game/prot4b
execute if score @s bw.team matches 2 if score #sharp2 bw matches 1.. run item modify entity @s weapon.mainhand bw:sharp
execute if score @s bw.team matches 3 run item replace entity @s armor.head with minecraft:leather_helmet[dyed_color=16701501,enchantments={"bw:bot":1},enchantment_glint_override=false]
execute if score @s bw.team matches 3 run item replace entity @s armor.chest with minecraft:leather_chestplate[dyed_color=16701501]
execute if score @s bw.team matches 3 if score @s bw.armor matches 0 run item replace entity @s armor.legs with minecraft:leather_leggings[dyed_color=16701501]
execute if score @s bw.team matches 3 if score @s bw.armor matches 0 run item replace entity @s armor.feet with minecraft:leather_boots[dyed_color=16701501]
execute if score @s bw.team matches 3 if score #prot3 bw matches 1 run function bw:game/prot1b
execute if score @s bw.team matches 3 if score #prot3 bw matches 2 run function bw:game/prot2b
execute if score @s bw.team matches 3 if score #prot3 bw matches 3 run function bw:game/prot3b
execute if score @s bw.team matches 3 if score #prot3 bw matches 4 run function bw:game/prot4b
execute if score @s bw.team matches 3 if score #sharp3 bw matches 1.. run item modify entity @s weapon.mainhand bw:sharp
execute if score @s bw.team matches 4 run item replace entity @s armor.head with minecraft:leather_helmet[dyed_color=1481884,enchantments={"bw:bot":1},enchantment_glint_override=false]
execute if score @s bw.team matches 4 run item replace entity @s armor.chest with minecraft:leather_chestplate[dyed_color=1481884]
execute if score @s bw.team matches 4 if score @s bw.armor matches 0 run item replace entity @s armor.legs with minecraft:leather_leggings[dyed_color=1481884]
execute if score @s bw.team matches 4 if score @s bw.armor matches 0 run item replace entity @s armor.feet with minecraft:leather_boots[dyed_color=1481884]
execute if score @s bw.team matches 4 if score #prot4 bw matches 1 run function bw:game/prot1b
execute if score @s bw.team matches 4 if score #prot4 bw matches 2 run function bw:game/prot2b
execute if score @s bw.team matches 4 if score #prot4 bw matches 3 run function bw:game/prot3b
execute if score @s bw.team matches 4 if score #prot4 bw matches 4 run function bw:game/prot4b
execute if score @s bw.team matches 4 if score #sharp4 bw matches 1.. run item modify entity @s weapon.mainhand bw:sharp
execute if score @s bw.team matches 5 run item replace entity @s armor.head with minecraft:leather_helmet[dyed_color=16383998,enchantments={"bw:bot":1},enchantment_glint_override=false]
execute if score @s bw.team matches 5 run item replace entity @s armor.chest with minecraft:leather_chestplate[dyed_color=16383998]
execute if score @s bw.team matches 5 if score @s bw.armor matches 0 run item replace entity @s armor.legs with minecraft:leather_leggings[dyed_color=16383998]
execute if score @s bw.team matches 5 if score @s bw.armor matches 0 run item replace entity @s armor.feet with minecraft:leather_boots[dyed_color=16383998]
execute if score @s bw.team matches 5 if score #prot5 bw matches 1 run function bw:game/prot1b
execute if score @s bw.team matches 5 if score #prot5 bw matches 2 run function bw:game/prot2b
execute if score @s bw.team matches 5 if score #prot5 bw matches 3 run function bw:game/prot3b
execute if score @s bw.team matches 5 if score #prot5 bw matches 4 run function bw:game/prot4b
execute if score @s bw.team matches 5 if score #sharp5 bw matches 1.. run item modify entity @s weapon.mainhand bw:sharp
execute if score @s bw.team matches 6 run item replace entity @s armor.head with minecraft:leather_helmet[dyed_color=15961002,enchantments={"bw:bot":1},enchantment_glint_override=false]
execute if score @s bw.team matches 6 run item replace entity @s armor.chest with minecraft:leather_chestplate[dyed_color=15961002]
execute if score @s bw.team matches 6 if score @s bw.armor matches 0 run item replace entity @s armor.legs with minecraft:leather_leggings[dyed_color=15961002]
execute if score @s bw.team matches 6 if score @s bw.armor matches 0 run item replace entity @s armor.feet with minecraft:leather_boots[dyed_color=15961002]
execute if score @s bw.team matches 6 if score #prot6 bw matches 1 run function bw:game/prot1b
execute if score @s bw.team matches 6 if score #prot6 bw matches 2 run function bw:game/prot2b
execute if score @s bw.team matches 6 if score #prot6 bw matches 3 run function bw:game/prot3b
execute if score @s bw.team matches 6 if score #prot6 bw matches 4 run function bw:game/prot4b
execute if score @s bw.team matches 6 if score #sharp6 bw matches 1.. run item modify entity @s weapon.mainhand bw:sharp
execute if score @s bw.team matches 7 run item replace entity @s armor.head with minecraft:leather_helmet[dyed_color=4673362,enchantments={"bw:bot":1},enchantment_glint_override=false]
execute if score @s bw.team matches 7 run item replace entity @s armor.chest with minecraft:leather_chestplate[dyed_color=4673362]
execute if score @s bw.team matches 7 if score @s bw.armor matches 0 run item replace entity @s armor.legs with minecraft:leather_leggings[dyed_color=4673362]
execute if score @s bw.team matches 7 if score @s bw.armor matches 0 run item replace entity @s armor.feet with minecraft:leather_boots[dyed_color=4673362]
execute if score @s bw.team matches 7 if score #prot7 bw matches 1 run function bw:game/prot1b
execute if score @s bw.team matches 7 if score #prot7 bw matches 2 run function bw:game/prot2b
execute if score @s bw.team matches 7 if score #prot7 bw matches 3 run function bw:game/prot3b
execute if score @s bw.team matches 7 if score #prot7 bw matches 4 run function bw:game/prot4b
execute if score @s bw.team matches 7 if score #sharp7 bw matches 1.. run item modify entity @s weapon.mainhand bw:sharp
