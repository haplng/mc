scoreboard players set @s bw.rrc 0
execute if score #dbg bw matches 1 run tellraw @a ["HOMED bot7 at ",{nbt:"at7",storage:"bw:bot"}," wanted ",{nbt:"ho7.to",storage:"bw:bot"}]
execute store result score @s bw.dest run data get storage bw:bot ho7.dest
data modify storage bw:tmp rt.to set from storage bw:bot ho7.to
data modify storage bw:tmp cmp set from storage bw:bot ho7.to
execute store success score #diff bw run data modify storage bw:tmp cmp set from storage bw:bot at7
execute if score #diff bw matches 0 unless score @s bw.dest matches 9 run return run function bw:ai/arrive
execute store success score #ok bw run function bw:ai/route7
execute if score #ok bw matches 0 run function bw:ai/to7 {to:"g7",dest:1}
