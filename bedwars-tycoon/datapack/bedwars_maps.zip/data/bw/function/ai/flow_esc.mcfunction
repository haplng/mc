$data modify storage bw:tmp fl.path append from storage bwflow:x $(m)."$(x) $(y) $(z)".p[]
$execute store result score #fx bw run data get storage bwflow:x $(m)."$(x) $(y) $(z)".f[0]
$execute store result score #fy bw run data get storage bwflow:x $(m)."$(x) $(y) $(z)".f[1]
$execute store result score #fz bw run data get storage bwflow:x $(m)."$(x) $(y) $(z)".f[2]
scoreboard players add #fn bw 20
execute if score #fn bw matches 600.. run return 0
execute store result storage bw:tmp fl.x int 1 run scoreboard players get #fx bw
execute store result storage bw:tmp fl.y int 1 run scoreboard players get #fy bw
execute store result storage bw:tmp fl.z int 1 run scoreboard players get #fz bw
function bw:ai/flow_walk with storage bw:tmp fl
