scoreboard players add @s bw.nearc 1
execute if score @s bw.nearc matches 15.. run function bw:ai/next3
