scoreboard players set #n bw 0
$execute as @e[tag=bw.fighter,distance=..16] unless score @s bw.team matches $(i) run scoreboard players set #n bw 1
$execute if score #n bw matches 1 as @e[type=minecraft:mannequin,tag=bw.bot,scores={bw.team=$(i)},distance=..20,limit=1] at @s run function bw:ai/golem$(i)
