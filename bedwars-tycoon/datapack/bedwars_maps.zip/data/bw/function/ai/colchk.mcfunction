scoreboard players set #colok bw 1
scoreboard players operation #cn bw = #hy bw
execute positioned ~ ~2 ~ run function bw:ai/colup
