data remove storage bw:bot r5[0]
data modify storage bw:bot tr5 set value []
execute unless data storage bw:bot r5[0] run return run function bw:ai/arrive5
data modify entity @e[type=minecraft:marker,tag=bw.g5,limit=1] Pos set from storage bw:bot r5[0]
scoreboard players set @s bw.stuck 0
scoreboard players set @s bw.wpt 0
scoreboard players set @s bw.av 0
scoreboard players set @s bw.avn 25
scoreboard players set @s bw.avc 0
