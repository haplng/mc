data modify storage bw:bot at4 set from storage bw:bot to4
function bw:ai/arrive
