execute if score @s bw.team matches 1 if score #wfe1 bw matches 24.. run return run function bw:ai/bug1
execute if score @s bw.team matches 2 if score #wfe2 bw matches 24.. run return run function bw:ai/bug2
execute if score @s bw.team matches 3 if score #wfe3 bw matches 24.. run return run function bw:ai/bug3
execute if score @s bw.team matches 4 if score #wfe4 bw matches 24.. run return run function bw:ai/bug4
execute if score @s bw.team matches 5 if score #wfe5 bw matches 24.. run return run function bw:ai/bug5
execute if score @s bw.team matches 6 if score #wfe6 bw matches 24.. run return run function bw:ai/bug6
execute if score @s bw.team matches 7 if score #wfe7 bw matches 24.. run return run function bw:ai/bug7
