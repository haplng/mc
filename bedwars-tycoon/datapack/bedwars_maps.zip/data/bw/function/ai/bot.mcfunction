execute store result score @s bw.hp run data get entity @s Health 10
execute if score @s bw.hp matches ..200 run return run function bw:ai/die
scoreboard players remove @s[scores={bw.atk=1..}] bw.atk 1
scoreboard players remove @s[scores={bw.t1=1..}] bw.t1 1
scoreboard players remove @s[scores={bw.t2=1..}] bw.t2 1
scoreboard players remove @s[scores={bw.jc=1..}] bw.jc 1
scoreboard players remove @s[scores={bw.br=1..}] bw.br 1
scoreboard players remove @s[scores={bw.slow=1..}] bw.slow 1
scoreboard players remove @s[scores={bw.fbc=1..}] bw.fbc 1
scoreboard players remove @s[scores={bw.calm=1..}] bw.calm 1
scoreboard players remove @s[scores={bw.bgc=1..}] bw.bgc 1
scoreboard players set @s bw.mf 0
scoreboard players set @s bw.ms 0
scoreboard players set #drop bw 0
scoreboard players set #high bw 0
scoreboard players operation #me bw = @s bw.team
tag @e[tag=bw.foe] remove bw.foe
execute as @e[tag=bw.mob,distance=..5,sort=nearest] unless score @s bw.team = #me bw unless entity @e[tag=bw.foe,limit=1] run tag @s add bw.foe
execute as @e[tag=bw.fighter,distance=0.01..16,sort=nearest] unless score @s bw.team = #me bw unless predicate bw:invisible unless entity @e[tag=bw.foe,limit=1] run tag @s add bw.foe
execute if score @s bw.br matches 0 if score @s bw.pose matches 1 run function bw:ai/stand
execute unless score @s bw.st matches 3 if score @s bw.calm matches 0 if entity @e[tag=bw.foe,distance=..7] run function bw:ai/engage
execute if score @s bw.st matches 3..6 run function bw:ai/crumbs
execute if score @s bw.st matches 3 run return run function bw:ai/fight
execute if score @s bw.st matches 0 run return run function bw:ai/think
execute if score @s bw.st matches 1 run return run function bw:ai/home
execute if score @s bw.st matches 2 run return run function bw:ai/go
execute if score @s bw.st matches 4 run return run function bw:ai/siege
execute if score @s bw.st matches 5 run return run function bw:ai/build
execute if score @s bw.st matches 6 run return run function bw:ai/gem
