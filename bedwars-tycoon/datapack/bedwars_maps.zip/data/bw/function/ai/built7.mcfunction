scoreboard players set #bdone7 bw 1
scoreboard players set @s bw.st 0
