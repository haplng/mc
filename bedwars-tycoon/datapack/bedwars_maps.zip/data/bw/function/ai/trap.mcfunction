$scoreboard players set #trap$(i) bw 0
scoreboard players set @s[tag=bw.bot] bw.slow 160
effect give @s[type=minecraft:player] minecraft:blindness 8 0
effect give @s[type=minecraft:player] minecraft:slowness 8 1
$title @a[tag=bw.play,scores={bw.team=$(i)}] times 0 40 10
$title @a[tag=bw.play,scores={bw.team=$(i)}] subtitle {text:"적이 침대에 다가왔어",color:"gray"}
$title @a[tag=bw.play,scores={bw.team=$(i)}] title {text:"함정 발동!",color:"red",bold:true}
$execute as @a[tag=bw.play,scores={bw.team=$(i)}] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 0.5
title @s[type=minecraft:player] actionbar {text:"함정에 걸렸어!",color:"red"}
