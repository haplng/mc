scoreboard players set @s bw.st 1
scoreboard players operation @s bw.t1 = #a_think bw
execute unless data storage bw:bot {at4:"g4"} unless data storage bw:bot {at4:"k4"} run return run function bw:ai/away4
execute if data storage bw:bot {at4:"k4"} run return run function bw:ai/to4 {to:"g4",dest:1}
execute if score #bsw4 bw matches 0 if score #wfe4 bw < #a_wait bw run return 0
scoreboard players set #can bw 0
execute if score #bsw4 bw matches 0 if score #wfe4 bw matches 10.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 1.. if score #bar4 bw matches 0 if score #wfe4 bw matches 40.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 2.. if score #btl4 bw matches 0 if score #wfe4 bw matches 20.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 3.. if score #bsw4 bw matches ..1 if score #wau4 bw matches 7.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 4.. if score #bar4 bw matches ..1 if score #wau4 bw matches 12.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 5.. if score #btl4 bw matches 1 if score #wfe4 bw matches 10.. if score #wau4 bw matches 3.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 6.. if score #bsw4 bw matches ..2 if score #wem4 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 8.. if score #bar4 bw matches ..2 if score #wem4 bw matches 6.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 9.. if score #btl4 bw matches 2 if score #wau4 bw matches 6.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 6.. if score #bga4 bw matches ..1 if score #wau4 bw matches 3.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 7.. if score #bfb4 bw matches ..1 if score #wfe4 bw matches 40.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 5.. if score #sharp4 bw matches 0 if score #wdi4 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 6.. if score #prot4 bw matches 0 if score #wdi4 bw matches 2.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 8.. if score #prot4 bw matches 1 if score #wdi4 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 10.. if score #prot4 bw matches 2 if score #wdi4 bw matches 8.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 12.. if score #prot4 bw matches 3 if score #wdi4 bw matches 16.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 7.. if score #fl4 bw matches 0 if score #wdi4 bw matches 2.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 10.. if score #fl4 bw matches 1 if score #wdi4 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 8.. if score #trap4 bw matches 0 if score #wdi4 bw matches 1.. run scoreboard players set #can bw 1
execute if score #can bw matches 1 run return run function bw:ai/to4 {to:"k4",dest:2}
execute if score #bed4 bw matches 1 if score #bdone4 bw matches 0 if data storage bw:bot def4[0] run return run function bw:ai/to4 {to:"b4",dest:3}
execute store result score #rn bw run random value 1..100
execute if score #lvl bw matches 5.. if score #sec bw matches 60.. if score #rn bw matches ..30 run return run function bw:ai/dia4
function bw:ai/pick4
execute if score @s bw.tgt matches 0.. run return run function bw:ai/attack4
