execute unless block ~ ~ ~ #bw:open unless predicate bw:built run return run function bw:ai/ray5up
execute unless block ~ ~1 ~ #bw:open positioned ~ ~1 ~ unless predicate bw:built run return 0
scoreboard players set #up bw 0
function bw:ai/ray_at {dy:0}
execute if score #fc bw matches 0 if block ~ ~-1 ~ #bw:open run function bw:ai/ray_at {dy:-1}
execute if score #fc bw matches 0 if block ~ ~-1 ~ #bw:open if block ~ ~-2 ~ #bw:open run function bw:ai/ray_at {dy:-2}
execute if score #fc bw matches 0 if block ~ ~-1 ~ #bw:open if block ~ ~-2 ~ #bw:open if block ~ ~-3 ~ #bw:open run function bw:ai/ray_at {dy:-3}
execute if score #fc bw matches 0 positioned ~1 ~ ~-1 run function bw:ai/ray5
