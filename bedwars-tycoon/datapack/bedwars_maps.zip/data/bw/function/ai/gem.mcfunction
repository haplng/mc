execute as @e[type=minecraft:item,tag=bw.res,distance=..2.5] run function bw:ai/pickup
execute if score @s bw.t1 matches 100 run rotate @s ~90 0
execute if score @s bw.team matches 1 if score #wdi1 bw matches 4.. run scoreboard players set @s bw.t1 0
execute if score @s bw.team matches 2 if score #wdi2 bw matches 4.. run scoreboard players set @s bw.t1 0
execute if score @s bw.team matches 3 if score #wdi3 bw matches 4.. run scoreboard players set @s bw.t1 0
execute if score @s bw.team matches 4 if score #wdi4 bw matches 4.. run scoreboard players set @s bw.t1 0
execute if score @s bw.team matches 5 if score #wdi5 bw matches 4.. run scoreboard players set @s bw.t1 0
execute if score @s bw.team matches 6 if score #wdi6 bw matches 4.. run scoreboard players set @s bw.t1 0
execute if score @s bw.team matches 7 if score #wdi7 bw matches 4.. run scoreboard players set @s bw.t1 0
execute if score @s bw.t1 matches 0 run scoreboard players set @s bw.st 0
