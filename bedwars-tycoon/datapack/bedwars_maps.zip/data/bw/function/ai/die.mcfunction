scoreboard players set #kt bw -1
execute if score @s bw.lht matches 1.. run scoreboard players operation #kt bw = @s bw.lh
scoreboard players set #final bw 1
execute if score @s bw.team matches 1 if score #bed1 bw matches 1 run scoreboard players set #final bw 0
execute if score @s bw.team matches 2 if score #bed2 bw matches 1 run scoreboard players set #final bw 0
execute if score @s bw.team matches 3 if score #bed3 bw matches 1 run scoreboard players set #final bw 0
execute if score @s bw.team matches 4 if score #bed4 bw matches 1 run scoreboard players set #final bw 0
execute if score @s bw.team matches 5 if score #bed5 bw matches 1 run scoreboard players set #final bw 0
execute if score @s bw.team matches 6 if score #bed6 bw matches 1 run scoreboard players set #final bw 0
execute if score @s bw.team matches 7 if score #bed7 bw matches 1 run scoreboard players set #final bw 0
function bw:game/kill
execute if score @s bw.team matches 1 run function bw:ai/dead1
execute if score @s bw.team matches 2 run function bw:ai/dead2
execute if score @s bw.team matches 3 run function bw:ai/dead3
execute if score @s bw.team matches 4 run function bw:ai/dead4
execute if score @s bw.team matches 5 run function bw:ai/dead5
execute if score @s bw.team matches 6 run function bw:ai/dead6
execute if score @s bw.team matches 7 run function bw:ai/dead7
tag @s remove bw.bot
tag @s remove bw.fighter
particle minecraft:poof ~ ~1 ~ 0.3 0.5 0.3 0.02 12
kill @s
execute if score #final bw matches 1 run function bw:game/check
