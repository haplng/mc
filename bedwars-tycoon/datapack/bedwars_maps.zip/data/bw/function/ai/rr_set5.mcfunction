execute unless score @s bw.dest matches 9 run data modify storage bw:bot ho5 set value {}
execute unless score @s bw.dest matches 9 run data modify storage bw:bot ho5.to set from storage bw:bot to5
execute unless score @s bw.dest matches 9 store result storage bw:bot ho5.dest int 1 run scoreboard players get @s bw.dest
data modify storage bw:bot r5 set from storage bw:tmp fl.path
data modify storage bw:bot to5 set from storage bw:tmp fl.hub
data modify storage bw:bot tr5 set value []
scoreboard players set @s bw.dest 9
scoreboard players set @s bw.st 2
data modify entity @e[type=minecraft:marker,tag=bw.g5,limit=1] Pos set from storage bw:bot r5[0]
