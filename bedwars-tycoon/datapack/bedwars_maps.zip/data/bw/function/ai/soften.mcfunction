execute if entity @s[type=minecraft:player,scores={bw.h_block=1},tag=!bw.off_block] run scoreboard players operation #dmg bw *= #75 bw
execute if entity @s[type=minecraft:player,scores={bw.h_block=2},tag=!bw.off_block] run scoreboard players operation #dmg bw *= #50 bw
execute if entity @s[type=minecraft:player,scores={bw.h_block=1..},tag=!bw.off_block] run scoreboard players operation #dmg bw /= #100 bw
execute if entity @s[type=minecraft:player,scores={bw.h_block=1..},tag=!bw.off_block] at @s run playsound minecraft:item.shield.block player @a ~ ~ ~ 0.5 1.2
