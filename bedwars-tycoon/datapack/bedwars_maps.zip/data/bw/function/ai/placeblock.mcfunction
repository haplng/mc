$rotate @s facing $(x).5 $(y).5 $(z).5
swing @s mainhand
$execute positioned $(x) $(y) $(z) if block ~ ~ ~ #bw:open unless entity @e[tag=bw.fighter,dx=0,dy=0,dz=0] run setblock ~ ~ ~ $(b)
$execute positioned $(x) $(y) $(z) run playsound minecraft:block.stone.place block @a ~ ~ ~ 0.8 1
