execute if score #map bw matches 1 run function bw:m/tea/bedkill5
execute if score #map bw matches 2 run function bw:m/chess/bedkill5
execute if score #map bw matches 3 run function bw:m/circus/bedkill5
execute if score #map bw matches 4 run function bw:m/library/bedkill5
execute if score #map bw matches 5 run function bw:m/solar/bedkill5
