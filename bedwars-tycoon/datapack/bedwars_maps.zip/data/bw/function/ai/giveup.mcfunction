scoreboard players set @s bw.calm 160
function bw:ai/disengage
