scoreboard players remove @s bw.twr 1
function bw:ai/tower
