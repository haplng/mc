scoreboard players operation #wfe7 bw += #pfe7 bw
scoreboard players set #pfe7 bw 0
scoreboard players operation #wau7 bw += #pau7 bw
scoreboard players set #pau7 bw 0
scoreboard players operation #wem7 bw += #pem7 bw
scoreboard players set #pem7 bw 0
