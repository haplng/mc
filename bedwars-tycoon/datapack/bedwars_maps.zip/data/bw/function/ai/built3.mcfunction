scoreboard players set #bdone3 bw 1
scoreboard players set @s bw.st 0
