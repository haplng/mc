execute if score #bsw5 bw matches 0 if score #wfe5 bw matches 10.. run function bw:ai/b/5_0
execute if score #lvl bw matches 1.. if score #bar5 bw matches 0 if score #wfe5 bw matches 40.. run function bw:ai/b/5_1
execute if score #lvl bw matches 2.. if score #btl5 bw matches 0 if score #wfe5 bw matches 20.. run function bw:ai/b/5_2
execute if score #lvl bw matches 3.. if score #bsw5 bw matches ..1 if score #wau5 bw matches 7.. run function bw:ai/b/5_3
execute if score #lvl bw matches 4.. if score #bar5 bw matches ..1 if score #wau5 bw matches 12.. run function bw:ai/b/5_4
execute if score #lvl bw matches 5.. if score #btl5 bw matches 1 if score #wfe5 bw matches 10.. if score #wau5 bw matches 3.. run function bw:ai/b/5_5
execute if score #lvl bw matches 6.. if score #bsw5 bw matches ..2 if score #wem5 bw matches 4.. run function bw:ai/b/5_6
execute if score #lvl bw matches 8.. if score #bar5 bw matches ..2 if score #wem5 bw matches 6.. run function bw:ai/b/5_7
execute if score #lvl bw matches 9.. if score #btl5 bw matches 2 if score #wau5 bw matches 6.. run function bw:ai/b/5_8
execute if score #lvl bw matches 6.. if score #bga5 bw matches ..1 if score #wau5 bw matches 3.. run function bw:ai/b/5_9
execute if score #lvl bw matches 7.. if score #bfb5 bw matches ..1 if score #wfe5 bw matches 40.. run function bw:ai/b/5_10
execute if score #lvl bw matches 5.. if score #sharp5 bw matches 0 if score #wdi5 bw matches 4.. run function bw:ai/b/5_11
execute if score #lvl bw matches 6.. if score #prot5 bw matches 0 if score #wdi5 bw matches 2.. run function bw:ai/b/5_12
execute if score #lvl bw matches 8.. if score #prot5 bw matches 1 if score #wdi5 bw matches 4.. run function bw:ai/b/5_13
execute if score #lvl bw matches 10.. if score #prot5 bw matches 2 if score #wdi5 bw matches 8.. run function bw:ai/b/5_14
execute if score #lvl bw matches 12.. if score #prot5 bw matches 3 if score #wdi5 bw matches 16.. run function bw:ai/b/5_15
execute if score #lvl bw matches 7.. if score #fl5 bw matches 0 if score #wdi5 bw matches 2.. run function bw:ai/b/5_16
execute if score #lvl bw matches 10.. if score #fl5 bw matches 1 if score #wdi5 bw matches 4.. run function bw:ai/b/5_17
execute if score #lvl bw matches 8.. if score #trap5 bw matches 0 if score #wdi5 bw matches 1.. run function bw:ai/b/5_18
