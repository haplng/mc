execute unless score @s bw.dest matches 9 run data modify storage bw:bot ho1 set value {}
execute unless score @s bw.dest matches 9 run data modify storage bw:bot ho1.to set from storage bw:bot to1
execute unless score @s bw.dest matches 9 store result storage bw:bot ho1.dest int 1 run scoreboard players get @s bw.dest
data modify storage bw:bot r1 set from storage bw:tmp fl.path
data modify storage bw:bot to1 set from storage bw:tmp fl.hub
data modify storage bw:bot tr1 set value []
scoreboard players set @s bw.dest 9
scoreboard players set @s bw.st 2
data modify entity @e[type=minecraft:marker,tag=bw.g1,limit=1] Pos set from storage bw:bot r1[0]
