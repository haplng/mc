execute store result score #n bw if items entity @s contents minecraft:diamond
execute if score #me bw matches 1 run scoreboard players operation #wdi1 bw += #n bw
execute if score #me bw matches 2 run scoreboard players operation #wdi2 bw += #n bw
execute if score #me bw matches 3 run scoreboard players operation #wdi3 bw += #n bw
execute if score #me bw matches 4 run scoreboard players operation #wdi4 bw += #n bw
execute if score #me bw matches 5 run scoreboard players operation #wdi5 bw += #n bw
execute if score #me bw matches 6 run scoreboard players operation #wdi6 bw += #n bw
execute if score #me bw matches 7 run scoreboard players operation #wdi7 bw += #n bw
execute store result score #n bw if items entity @s contents minecraft:emerald
execute if score #me bw matches 1 run scoreboard players operation #wem1 bw += #n bw
execute if score #me bw matches 2 run scoreboard players operation #wem2 bw += #n bw
execute if score #me bw matches 3 run scoreboard players operation #wem3 bw += #n bw
execute if score #me bw matches 4 run scoreboard players operation #wem4 bw += #n bw
execute if score #me bw matches 5 run scoreboard players operation #wem5 bw += #n bw
execute if score #me bw matches 6 run scoreboard players operation #wem6 bw += #n bw
execute if score #me bw matches 7 run scoreboard players operation #wem7 bw += #n bw
playsound minecraft:entity.item.pickup player @a ~ ~ ~ 0.3 1.6
kill @s
