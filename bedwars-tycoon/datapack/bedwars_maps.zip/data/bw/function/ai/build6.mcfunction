execute unless data storage bw:bot def6[0] run return run function bw:ai/built6
data modify storage bw:tmp pl set from storage bw:bot def6[0]
data remove storage bw:bot def6[0]
function bw:ai/placeblock with storage bw:tmp pl
