scoreboard players set #hit bw 1
execute if block ~ ~ ~ #minecraft:beds run return run function bw:ai/bedhit
execute if block ~ ~ ~ #bw:breakable align xyz positioned ~0.5 ~ ~0.5 run return run function bw:ai/mine
scoreboard players operation @s bw.ms = @s bw.strafe
scoreboard players add @s bw.stuck 1
execute if score @s bw.stuck matches 60.. run function bw:ai/flip
execute if score @s bw.stuck matches 60.. run scoreboard players set @s bw.stuck 0
