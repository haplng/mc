data modify storage bw:tmp rt.at set from storage bw:bot at1
data modify storage bw:tmp rt.m set from storage bw:ai ctx.m
data modify storage bw:bot r1 set value []
function bw:ai/route1b with storage bw:tmp rt
execute unless data storage bw:bot r1[0] run return fail
data modify entity @e[type=minecraft:marker,tag=bw.g1,limit=1] Pos set from storage bw:bot r1[0]
scoreboard players set @s bw.st 2
scoreboard players set @s bw.stuck 0
scoreboard players set @s bw.wpt 0
scoreboard players set @s bw.av 0
scoreboard players set @s bw.avn 25
scoreboard players set @s bw.avc 0
return 1
