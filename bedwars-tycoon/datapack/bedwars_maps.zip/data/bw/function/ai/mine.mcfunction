scoreboard players set #need bw 9999
execute if block ~ ~ ~ #minecraft:wool if score @s bw.tool matches 0 run scoreboard players set #need bw 22
execute if block ~ ~ ~ #minecraft:wool if score @s bw.tool matches 1 run scoreboard players set #need bw 10
execute if block ~ ~ ~ #minecraft:wool if score @s bw.tool matches 2 run scoreboard players set #need bw 7
execute if block ~ ~ ~ #minecraft:wool if score @s bw.tool matches 3 run scoreboard players set #need bw 5
execute if block ~ ~ ~ minecraft:oak_planks if score @s bw.tool matches 0 run scoreboard players set #need bw 45
execute if block ~ ~ ~ minecraft:oak_planks if score @s bw.tool matches 1 run scoreboard players set #need bw 24
execute if block ~ ~ ~ minecraft:oak_planks if score @s bw.tool matches 2 run scoreboard players set #need bw 14
execute if block ~ ~ ~ minecraft:oak_planks if score @s bw.tool matches 3 run scoreboard players set #need bw 9
execute if block ~ ~ ~ minecraft:ladder if score @s bw.tool matches 0 run scoreboard players set #need bw 12
execute if block ~ ~ ~ minecraft:ladder if score @s bw.tool matches 1 run scoreboard players set #need bw 8
execute if block ~ ~ ~ minecraft:ladder if score @s bw.tool matches 2 run scoreboard players set #need bw 6
execute if block ~ ~ ~ minecraft:ladder if score @s bw.tool matches 3 run scoreboard players set #need bw 5
execute if block ~ ~ ~ minecraft:terracotta if score @s bw.tool matches 0 run scoreboard players set #need bw 50
execute if block ~ ~ ~ minecraft:terracotta if score @s bw.tool matches 1 run scoreboard players set #need bw 20
execute if block ~ ~ ~ minecraft:terracotta if score @s bw.tool matches 2 run scoreboard players set #need bw 12
execute if block ~ ~ ~ minecraft:terracotta if score @s bw.tool matches 3 run scoreboard players set #need bw 8
execute if block ~ ~ ~ #bw:glass if score @s bw.tool matches 0 run scoreboard players set #need bw 9
execute if block ~ ~ ~ #bw:glass if score @s bw.tool matches 1 run scoreboard players set #need bw 9
execute if block ~ ~ ~ #bw:glass if score @s bw.tool matches 2 run scoreboard players set #need bw 9
execute if block ~ ~ ~ #bw:glass if score @s bw.tool matches 3 run scoreboard players set #need bw 9
execute if block ~ ~ ~ minecraft:end_stone if score @s bw.tool matches 0 run scoreboard players set #need bw 150
execute if block ~ ~ ~ minecraft:end_stone if score @s bw.tool matches 1 run scoreboard players set #need bw 60
execute if block ~ ~ ~ minecraft:end_stone if score @s bw.tool matches 2 run scoreboard players set #need bw 30
execute if block ~ ~ ~ minecraft:end_stone if score @s bw.tool matches 3 run scoreboard players set #need bw 18
execute if block ~ ~ ~ minecraft:obsidian if score @s bw.tool matches 0 run scoreboard players set #need bw 9999
execute if block ~ ~ ~ minecraft:obsidian if score @s bw.tool matches 1 run scoreboard players set #need bw 9999
execute if block ~ ~ ~ minecraft:obsidian if score @s bw.tool matches 2 run scoreboard players set #need bw 9999
execute if block ~ ~ ~ minecraft:obsidian if score @s bw.tool matches 3 run scoreboard players set #need bw 55
execute if block ~ ~ ~ minecraft:tnt if score @s bw.tool matches 0 run scoreboard players set #need bw 4
execute if block ~ ~ ~ minecraft:tnt if score @s bw.tool matches 1 run scoreboard players set #need bw 4
execute if block ~ ~ ~ minecraft:tnt if score @s bw.tool matches 2 run scoreboard players set #need bw 4
execute if block ~ ~ ~ minecraft:tnt if score @s bw.tool matches 3 run scoreboard players set #need bw 4
execute if block ~ ~ ~ minecraft:sponge if score @s bw.tool matches 0 run scoreboard players set #need bw 14
execute if block ~ ~ ~ minecraft:sponge if score @s bw.tool matches 1 run scoreboard players set #need bw 14
execute if block ~ ~ ~ minecraft:sponge if score @s bw.tool matches 2 run scoreboard players set #need bw 14
execute if block ~ ~ ~ minecraft:sponge if score @s bw.tool matches 3 run scoreboard players set #need bw 14
execute if block ~ ~ ~ minecraft:wet_sponge if score @s bw.tool matches 0 run scoreboard players set #need bw 14
execute if block ~ ~ ~ minecraft:wet_sponge if score @s bw.tool matches 1 run scoreboard players set #need bw 14
execute if block ~ ~ ~ minecraft:wet_sponge if score @s bw.tool matches 2 run scoreboard players set #need bw 14
execute if block ~ ~ ~ minecraft:wet_sponge if score @s bw.tool matches 3 run scoreboard players set #need bw 14
execute if score #need bw matches 9999 if score @s bw.st matches 4 if score @s bw.t1 matches 61.. run scoreboard players set @s bw.t1 60
execute if score #need bw matches 9999 run return run scoreboard players add @s bw.stuck 2
scoreboard players add @s bw.mine 1
scoreboard players set @s bw.mf 0
scoreboard players operation #q bw = @s bw.mine
scoreboard players operation #q bw %= #4 bw
execute if score #q bw matches 0 run swing @s mainhand
execute if score #q bw matches 0 run playsound minecraft:block.stone.hit block @a ~ ~ ~ 0.6 1
execute if score #q bw matches 0 run particle minecraft:crit ~ ~0.5 ~ 0.3 0.3 0.3 0.1 3
execute if score @s bw.mine >= #need bw run function bw:ai/mined
