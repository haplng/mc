execute align xyz unless entity @e[tag=bw.fighter,dx=0,dy=0,dz=0] run function bw:ai/wool
swing @s mainhand
playsound minecraft:block.wool.place block @a ~ ~ ~ 0.8 1
scoreboard players set @s bw.br 14
