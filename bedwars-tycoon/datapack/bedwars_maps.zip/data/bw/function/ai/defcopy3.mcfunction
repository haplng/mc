$data modify storage bw:bot def3 set from storage bw:nav $(m).def3_$(T)
