$give @s minecraft:diamond $(di)
