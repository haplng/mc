$give @s minecraft:diamond $(di)
$tellraw @s {text:"+$(di) 다이아몬드",color:"aqua"}
