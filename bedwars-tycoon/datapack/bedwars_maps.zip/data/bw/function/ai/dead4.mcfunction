execute store result storage bw:tmp loot.fe int 1 run scoreboard players get #wfe4 bw
execute store result storage bw:tmp loot.au int 1 run scoreboard players get #wau4 bw
execute store result storage bw:tmp loot.di int 1 run scoreboard players get #wdi4 bw
execute store result storage bw:tmp loot.em int 1 run scoreboard players get #wem4 bw
execute if score #wfe4 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_fe with storage bw:tmp loot
execute if score #wau4 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_au with storage bw:tmp loot
execute if score #wdi4 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_di with storage bw:tmp loot
execute if score #wem4 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_em with storage bw:tmp loot
scoreboard players set #wfe4 bw 0
scoreboard players set #wau4 bw 0
scoreboard players set #wdi4 bw 0
scoreboard players set #wem4 bw 0
scoreboard players set #bsw4 bw 0
execute if score #btl4 bw matches 2.. run scoreboard players remove #btl4 bw 1
execute if score #final bw matches 0 run scoreboard players set #bres4 bw 100
execute if score #final bw matches 1 run tellraw @a [{text:""},{text:"<",color:"gray"},{selector:"@s"},{text:"> gg",color:"gray"}]
