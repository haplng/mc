function bw:ai/flow_at {dx:0,dy:0,dz:0}
execute if score #fc bw matches 0 run function bw:ai/flow_at {dx:0,dy:1,dz:0}
execute if score #fc bw matches 0 run function bw:ai/flow_at {dx:0,dy:-1,dz:0}
execute if score #fc bw matches 0 if block ~1 ~1 ~0 #bw:open if block ~1 ~2 ~0 #bw:open if block ~ ~2 ~ #bw:open run function bw:ai/flow_at {dx:1,dy:1,dz:0}
execute if score #fc bw matches 0 if block ~1 ~ ~0 #bw:open if block ~1 ~1 ~0 #bw:open run function bw:ai/flow_at {dx:1,dy:0,dz:0}
execute if score #fc bw matches 0 if block ~1 ~ ~0 #bw:open if block ~1 ~1 ~0 #bw:open if block ~1 ~-1 ~0 #bw:open run function bw:ai/flow_at {dx:1,dy:-1,dz:0}
execute if score #fc bw matches 0 if block ~1 ~ ~0 #bw:open if block ~1 ~1 ~0 #bw:open if block ~1 ~-1 ~0 #bw:open if block ~1 ~-2 ~0 #bw:open run function bw:ai/flow_at {dx:1,dy:-2,dz:0}
execute if score #fc bw matches 0 if block ~1 ~ ~0 #bw:open if block ~1 ~1 ~0 #bw:open if block ~1 ~-1 ~0 #bw:open if block ~1 ~-2 ~0 #bw:open if block ~1 ~-3 ~0 #bw:open run function bw:ai/flow_at {dx:1,dy:-3,dz:0}
execute if score #fc bw matches 0 if block ~1 ~ ~0 #bw:open if block ~1 ~1 ~0 #bw:open if block ~1 ~-1 ~0 #bw:open if block ~1 ~-2 ~0 #bw:open if block ~1 ~-3 ~0 #bw:open if block ~1 ~-4 ~0 #bw:open run function bw:ai/flow_at {dx:1,dy:-4,dz:0}
execute if score #fc bw matches 0 if block ~1 ~ ~0 #bw:open if block ~1 ~1 ~0 #bw:open if block ~1 ~-1 ~0 #bw:open if block ~1 ~-2 ~0 #bw:open if block ~1 ~-3 ~0 #bw:open if block ~1 ~-4 ~0 #bw:open if block ~1 ~-5 ~0 #bw:open run function bw:ai/flow_at {dx:1,dy:-5,dz:0}
execute if score #fc bw matches 0 if block ~1 ~ ~0 #bw:open if block ~1 ~1 ~0 #bw:open if block ~1 ~-1 ~0 #bw:open if block ~1 ~-2 ~0 #bw:open if block ~1 ~-3 ~0 #bw:open if block ~1 ~-4 ~0 #bw:open if block ~1 ~-5 ~0 #bw:open if block ~1 ~-6 ~0 #bw:open run function bw:ai/flow_at {dx:1,dy:-6,dz:0}
execute if score #fc bw matches 0 if block ~-1 ~1 ~0 #bw:open if block ~-1 ~2 ~0 #bw:open if block ~ ~2 ~ #bw:open run function bw:ai/flow_at {dx:-1,dy:1,dz:0}
execute if score #fc bw matches 0 if block ~-1 ~ ~0 #bw:open if block ~-1 ~1 ~0 #bw:open run function bw:ai/flow_at {dx:-1,dy:0,dz:0}
execute if score #fc bw matches 0 if block ~-1 ~ ~0 #bw:open if block ~-1 ~1 ~0 #bw:open if block ~-1 ~-1 ~0 #bw:open run function bw:ai/flow_at {dx:-1,dy:-1,dz:0}
execute if score #fc bw matches 0 if block ~-1 ~ ~0 #bw:open if block ~-1 ~1 ~0 #bw:open if block ~-1 ~-1 ~0 #bw:open if block ~-1 ~-2 ~0 #bw:open run function bw:ai/flow_at {dx:-1,dy:-2,dz:0}
execute if score #fc bw matches 0 if block ~-1 ~ ~0 #bw:open if block ~-1 ~1 ~0 #bw:open if block ~-1 ~-1 ~0 #bw:open if block ~-1 ~-2 ~0 #bw:open if block ~-1 ~-3 ~0 #bw:open run function bw:ai/flow_at {dx:-1,dy:-3,dz:0}
execute if score #fc bw matches 0 if block ~-1 ~ ~0 #bw:open if block ~-1 ~1 ~0 #bw:open if block ~-1 ~-1 ~0 #bw:open if block ~-1 ~-2 ~0 #bw:open if block ~-1 ~-3 ~0 #bw:open if block ~-1 ~-4 ~0 #bw:open run function bw:ai/flow_at {dx:-1,dy:-4,dz:0}
execute if score #fc bw matches 0 if block ~-1 ~ ~0 #bw:open if block ~-1 ~1 ~0 #bw:open if block ~-1 ~-1 ~0 #bw:open if block ~-1 ~-2 ~0 #bw:open if block ~-1 ~-3 ~0 #bw:open if block ~-1 ~-4 ~0 #bw:open if block ~-1 ~-5 ~0 #bw:open run function bw:ai/flow_at {dx:-1,dy:-5,dz:0}
execute if score #fc bw matches 0 if block ~-1 ~ ~0 #bw:open if block ~-1 ~1 ~0 #bw:open if block ~-1 ~-1 ~0 #bw:open if block ~-1 ~-2 ~0 #bw:open if block ~-1 ~-3 ~0 #bw:open if block ~-1 ~-4 ~0 #bw:open if block ~-1 ~-5 ~0 #bw:open if block ~-1 ~-6 ~0 #bw:open run function bw:ai/flow_at {dx:-1,dy:-6,dz:0}
execute if score #fc bw matches 0 if block ~0 ~1 ~1 #bw:open if block ~0 ~2 ~1 #bw:open if block ~ ~2 ~ #bw:open run function bw:ai/flow_at {dx:0,dy:1,dz:1}
execute if score #fc bw matches 0 if block ~0 ~ ~1 #bw:open if block ~0 ~1 ~1 #bw:open run function bw:ai/flow_at {dx:0,dy:0,dz:1}
execute if score #fc bw matches 0 if block ~0 ~ ~1 #bw:open if block ~0 ~1 ~1 #bw:open if block ~0 ~-1 ~1 #bw:open run function bw:ai/flow_at {dx:0,dy:-1,dz:1}
execute if score #fc bw matches 0 if block ~0 ~ ~1 #bw:open if block ~0 ~1 ~1 #bw:open if block ~0 ~-1 ~1 #bw:open if block ~0 ~-2 ~1 #bw:open run function bw:ai/flow_at {dx:0,dy:-2,dz:1}
execute if score #fc bw matches 0 if block ~0 ~ ~1 #bw:open if block ~0 ~1 ~1 #bw:open if block ~0 ~-1 ~1 #bw:open if block ~0 ~-2 ~1 #bw:open if block ~0 ~-3 ~1 #bw:open run function bw:ai/flow_at {dx:0,dy:-3,dz:1}
execute if score #fc bw matches 0 if block ~0 ~ ~1 #bw:open if block ~0 ~1 ~1 #bw:open if block ~0 ~-1 ~1 #bw:open if block ~0 ~-2 ~1 #bw:open if block ~0 ~-3 ~1 #bw:open if block ~0 ~-4 ~1 #bw:open run function bw:ai/flow_at {dx:0,dy:-4,dz:1}
execute if score #fc bw matches 0 if block ~0 ~ ~1 #bw:open if block ~0 ~1 ~1 #bw:open if block ~0 ~-1 ~1 #bw:open if block ~0 ~-2 ~1 #bw:open if block ~0 ~-3 ~1 #bw:open if block ~0 ~-4 ~1 #bw:open if block ~0 ~-5 ~1 #bw:open run function bw:ai/flow_at {dx:0,dy:-5,dz:1}
execute if score #fc bw matches 0 if block ~0 ~ ~1 #bw:open if block ~0 ~1 ~1 #bw:open if block ~0 ~-1 ~1 #bw:open if block ~0 ~-2 ~1 #bw:open if block ~0 ~-3 ~1 #bw:open if block ~0 ~-4 ~1 #bw:open if block ~0 ~-5 ~1 #bw:open if block ~0 ~-6 ~1 #bw:open run function bw:ai/flow_at {dx:0,dy:-6,dz:1}
execute if score #fc bw matches 0 if block ~0 ~1 ~-1 #bw:open if block ~0 ~2 ~-1 #bw:open if block ~ ~2 ~ #bw:open run function bw:ai/flow_at {dx:0,dy:1,dz:-1}
execute if score #fc bw matches 0 if block ~0 ~ ~-1 #bw:open if block ~0 ~1 ~-1 #bw:open run function bw:ai/flow_at {dx:0,dy:0,dz:-1}
execute if score #fc bw matches 0 if block ~0 ~ ~-1 #bw:open if block ~0 ~1 ~-1 #bw:open if block ~0 ~-1 ~-1 #bw:open run function bw:ai/flow_at {dx:0,dy:-1,dz:-1}
execute if score #fc bw matches 0 if block ~0 ~ ~-1 #bw:open if block ~0 ~1 ~-1 #bw:open if block ~0 ~-1 ~-1 #bw:open if block ~0 ~-2 ~-1 #bw:open run function bw:ai/flow_at {dx:0,dy:-2,dz:-1}
execute if score #fc bw matches 0 if block ~0 ~ ~-1 #bw:open if block ~0 ~1 ~-1 #bw:open if block ~0 ~-1 ~-1 #bw:open if block ~0 ~-2 ~-1 #bw:open if block ~0 ~-3 ~-1 #bw:open run function bw:ai/flow_at {dx:0,dy:-3,dz:-1}
execute if score #fc bw matches 0 if block ~0 ~ ~-1 #bw:open if block ~0 ~1 ~-1 #bw:open if block ~0 ~-1 ~-1 #bw:open if block ~0 ~-2 ~-1 #bw:open if block ~0 ~-3 ~-1 #bw:open if block ~0 ~-4 ~-1 #bw:open run function bw:ai/flow_at {dx:0,dy:-4,dz:-1}
execute if score #fc bw matches 0 if block ~0 ~ ~-1 #bw:open if block ~0 ~1 ~-1 #bw:open if block ~0 ~-1 ~-1 #bw:open if block ~0 ~-2 ~-1 #bw:open if block ~0 ~-3 ~-1 #bw:open if block ~0 ~-4 ~-1 #bw:open if block ~0 ~-5 ~-1 #bw:open run function bw:ai/flow_at {dx:0,dy:-5,dz:-1}
execute if score #fc bw matches 0 if block ~0 ~ ~-1 #bw:open if block ~0 ~1 ~-1 #bw:open if block ~0 ~-1 ~-1 #bw:open if block ~0 ~-2 ~-1 #bw:open if block ~0 ~-3 ~-1 #bw:open if block ~0 ~-4 ~-1 #bw:open if block ~0 ~-5 ~-1 #bw:open if block ~0 ~-6 ~-1 #bw:open run function bw:ai/flow_at {dx:0,dy:-6,dz:-1}
execute if score #fc bw matches 0 run function bw:ai/flow_rays
