data modify storage bw:bot at1 set from storage bw:bot to1
function bw:ai/arrive
