data modify storage bw:bot at3 set from storage bw:bot to3
function bw:ai/arrive
