data modify entity @s pose set value "crouching"
scoreboard players set @s bw.pose 1
