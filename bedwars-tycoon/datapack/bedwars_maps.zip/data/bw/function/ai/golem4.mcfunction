scoreboard players remove #wfe4 bw 120
function bw:mob/botgolem
