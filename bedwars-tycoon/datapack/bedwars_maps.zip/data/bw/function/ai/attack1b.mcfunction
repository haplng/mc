$function bw:ai/to1 {to:"a$(j)",dest:4}
