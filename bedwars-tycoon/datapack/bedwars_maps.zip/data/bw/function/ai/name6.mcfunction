$data modify storage bw:ai n6 set from storage bw:ai names[$(k)]
