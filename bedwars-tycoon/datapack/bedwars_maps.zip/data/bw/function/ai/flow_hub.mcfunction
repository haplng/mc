$data modify storage bw:tmp fl.hub set from storage bwflow:h $(m)."$(x) $(y) $(z)"
