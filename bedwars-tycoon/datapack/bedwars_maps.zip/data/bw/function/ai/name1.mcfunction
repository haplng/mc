$data modify storage bw:ai n1 set from storage bw:ai pool[$(k)]
$data remove storage bw:ai pool[$(k)]
