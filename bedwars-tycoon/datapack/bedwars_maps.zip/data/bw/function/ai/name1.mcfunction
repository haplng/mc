$data modify storage bw:ai n1 set from storage bw:ai names[$(k)]
