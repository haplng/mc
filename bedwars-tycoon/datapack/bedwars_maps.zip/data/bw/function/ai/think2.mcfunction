scoreboard players set @s bw.st 1
scoreboard players operation @s bw.t1 = #a_think bw
execute unless data storage bw:bot {at2:"g2"} unless data storage bw:bot {at2:"k2"} run return run function bw:ai/away2
execute if data storage bw:bot {at2:"k2"} run return run function bw:ai/to2 {to:"g2",dest:1}
execute if score #bsw2 bw matches 0 if score #wfe2 bw < #a_wait bw run return 0
scoreboard players set #can bw 0
execute if score #bsw2 bw matches 0 if score #wfe2 bw matches 10.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 1.. if score #bar2 bw matches 0 if score #wfe2 bw matches 40.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 2.. if score #btl2 bw matches 0 if score #wfe2 bw matches 20.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 3.. if score #bsw2 bw matches ..1 if score #wau2 bw matches 7.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 4.. if score #bar2 bw matches ..1 if score #wau2 bw matches 12.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 5.. if score #btl2 bw matches 1 if score #wfe2 bw matches 10.. if score #wau2 bw matches 3.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 6.. if score #bsw2 bw matches ..2 if score #wem2 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 8.. if score #bar2 bw matches ..2 if score #wem2 bw matches 6.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 9.. if score #btl2 bw matches 2 if score #wau2 bw matches 6.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 6.. if score #bga2 bw matches ..1 if score #wau2 bw matches 3.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 7.. if score #bfb2 bw matches ..1 if score #wfe2 bw matches 40.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 5.. if score #sharp2 bw matches 0 if score #wdi2 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 6.. if score #prot2 bw matches 0 if score #wdi2 bw matches 2.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 8.. if score #prot2 bw matches 1 if score #wdi2 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 10.. if score #prot2 bw matches 2 if score #wdi2 bw matches 8.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 12.. if score #prot2 bw matches 3 if score #wdi2 bw matches 16.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 7.. if score #fl2 bw matches 0 if score #wdi2 bw matches 2.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 10.. if score #fl2 bw matches 1 if score #wdi2 bw matches 4.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 8.. if score #tqn2 bw matches 0 if score #wdi2 bw matches 1.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 11.. if score #tqn2 bw matches 1 if score #wdi2 bw matches 2.. run scoreboard players set #can bw 1
execute if score #lvl bw matches 13.. if score #dbuff2 bw matches 0 if score #wdi2 bw matches 5.. run scoreboard players set #can bw 1
execute if score #can bw matches 1 run return run function bw:ai/to2 {to:"k2",dest:2}
execute if score #bed2 bw matches 1 if score #bdone2 bw matches 0 if data storage bw:bot def2[0] run return run function bw:ai/to2 {to:"b2",dest:3}
execute store result score #rn bw run random value 1..100
execute if score #lvl bw matches 5.. if score #sec bw matches 60.. if score #rn bw matches ..30 run return run function bw:ai/dia2
function bw:ai/pick2
execute if score @s bw.tgt matches 0.. run return run function bw:ai/attack2
