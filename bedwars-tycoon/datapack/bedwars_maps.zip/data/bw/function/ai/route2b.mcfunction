$data modify storage bw:bot r2 set from storage bw:nav $(m).$(at)_$(to)
$data modify storage bw:bot to2 set value "$(to)"
$execute if data storage bw:bot r2[0] run data modify storage bw:bot r2 prepend from storage bw:nav $(m).n_$(at)
