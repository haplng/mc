scoreboard players remove #wfe3 bw 120
function bw:mob/botgolem
