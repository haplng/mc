execute store result storage bw:tmp loot.fe int 1 run scoreboard players get #wfe6 bw
execute store result storage bw:tmp loot.au int 1 run scoreboard players get #wau6 bw
execute store result storage bw:tmp loot.di int 1 run scoreboard players get #wdi6 bw
execute store result storage bw:tmp loot.em int 1 run scoreboard players get #wem6 bw
execute if score #wfe6 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_fe with storage bw:tmp loot
execute if score #wau6 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_au with storage bw:tmp loot
execute if score #wdi6 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_di with storage bw:tmp loot
execute if score #wem6 bw matches 1.. as @a[tag=bw.killer] run function bw:ai/loot_em with storage bw:tmp loot
execute if score #kt bw matches 1 run scoreboard players operation #wfe1 bw += #wfe6 bw
execute if score #kt bw matches 1 run scoreboard players operation #wau1 bw += #wau6 bw
execute if score #kt bw matches 1 run scoreboard players operation #wdi1 bw += #wdi6 bw
execute if score #kt bw matches 1 run scoreboard players operation #wem1 bw += #wem6 bw
execute if score #kt bw matches 2 run scoreboard players operation #wfe2 bw += #wfe6 bw
execute if score #kt bw matches 2 run scoreboard players operation #wau2 bw += #wau6 bw
execute if score #kt bw matches 2 run scoreboard players operation #wdi2 bw += #wdi6 bw
execute if score #kt bw matches 2 run scoreboard players operation #wem2 bw += #wem6 bw
execute if score #kt bw matches 3 run scoreboard players operation #wfe3 bw += #wfe6 bw
execute if score #kt bw matches 3 run scoreboard players operation #wau3 bw += #wau6 bw
execute if score #kt bw matches 3 run scoreboard players operation #wdi3 bw += #wdi6 bw
execute if score #kt bw matches 3 run scoreboard players operation #wem3 bw += #wem6 bw
execute if score #kt bw matches 4 run scoreboard players operation #wfe4 bw += #wfe6 bw
execute if score #kt bw matches 4 run scoreboard players operation #wau4 bw += #wau6 bw
execute if score #kt bw matches 4 run scoreboard players operation #wdi4 bw += #wdi6 bw
execute if score #kt bw matches 4 run scoreboard players operation #wem4 bw += #wem6 bw
execute if score #kt bw matches 5 run scoreboard players operation #wfe5 bw += #wfe6 bw
execute if score #kt bw matches 5 run scoreboard players operation #wau5 bw += #wau6 bw
execute if score #kt bw matches 5 run scoreboard players operation #wdi5 bw += #wdi6 bw
execute if score #kt bw matches 5 run scoreboard players operation #wem5 bw += #wem6 bw
execute if score #kt bw matches 7 run scoreboard players operation #wfe7 bw += #wfe6 bw
execute if score #kt bw matches 7 run scoreboard players operation #wau7 bw += #wau6 bw
execute if score #kt bw matches 7 run scoreboard players operation #wdi7 bw += #wdi6 bw
execute if score #kt bw matches 7 run scoreboard players operation #wem7 bw += #wem6 bw
scoreboard players set #wfe6 bw 0
scoreboard players set #wau6 bw 0
scoreboard players set #wdi6 bw 0
scoreboard players set #wem6 bw 0
scoreboard players set #bsw6 bw 0
execute if score #btl6 bw matches 2.. run scoreboard players remove #btl6 bw 1
execute if score #final bw matches 0 run scoreboard players set #bres6 bw 100
execute if score #final bw matches 1 run tellraw @a [{text:""},{text:"<",color:"gray"},{selector:"@s"},{text:"> gg",color:"gray"}]
