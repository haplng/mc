execute if score @s bw.team matches 1 run function bw:ai/think1
execute if score @s bw.team matches 2 run function bw:ai/think2
execute if score @s bw.team matches 3 run function bw:ai/think3
execute if score @s bw.team matches 4 run function bw:ai/think4
execute if score @s bw.team matches 5 run function bw:ai/think5
execute if score @s bw.team matches 6 run function bw:ai/think6
execute if score @s bw.team matches 7 run function bw:ai/think7
