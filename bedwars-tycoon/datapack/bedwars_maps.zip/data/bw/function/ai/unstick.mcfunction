scoreboard players add @s bw.idle 1
execute if score @s bw.idle matches 20.. run function bw:ai/moved
execute if score @s bw.stuck matches 40..44 if score #high bw matches 0 if predicate bw:ground run function bw:ai/jump
execute if score @s bw.stuck matches 60.. if function bw:ai/retrace run return 0
scoreboard players add @s bw.wpt 1
execute if score @s bw.wpt matches 400.. if score @s bw.stuck matches 200.. run return run function bw:ai/reroute
execute if score @s bw.wpt matches 1000.. run function bw:ai/reroute
