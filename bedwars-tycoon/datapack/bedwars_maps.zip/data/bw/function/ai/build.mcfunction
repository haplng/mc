execute if score @s bw.t1 matches 1.. run return 0
scoreboard players operation @s bw.t1 = #a_place bw
execute if score @s bw.team matches 1 run function bw:ai/build1
execute if score @s bw.team matches 2 run function bw:ai/build2
execute if score @s bw.team matches 3 run function bw:ai/build3
execute if score @s bw.team matches 4 run function bw:ai/build4
execute if score @s bw.team matches 5 run function bw:ai/build5
execute if score @s bw.team matches 6 run function bw:ai/build6
execute if score @s bw.team matches 7 run function bw:ai/build7
