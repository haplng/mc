scoreboard players add #up bw 1
execute if score #up bw matches 2.. run return 0
execute positioned ~ ~1 ~ run function bw:ai/cray1
