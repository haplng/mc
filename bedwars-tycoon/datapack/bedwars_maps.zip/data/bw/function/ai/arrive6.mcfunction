data modify storage bw:bot at6 set from storage bw:bot to6
function bw:ai/arrive
