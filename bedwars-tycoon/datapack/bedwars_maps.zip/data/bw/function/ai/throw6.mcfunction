scoreboard players remove #bfb6 bw 1
scoreboard players set @s bw.fbc 120
swing @s mainhand
execute anchored eyes facing entity @e[tag=bw.foe,limit=1] feet positioned ^ ^ ^1.2 run function bw:fb/launch
