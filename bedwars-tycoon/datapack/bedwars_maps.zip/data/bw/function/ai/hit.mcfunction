$damage @e[tag=bw.foe,limit=1] $(d) minecraft:mob_attack by @s
scoreboard players set @s bw.ft 0
scoreboard players operation @e[tag=bw.foe,limit=1] bw.lh = @s bw.team
scoreboard players set @e[tag=bw.foe,limit=1] bw.lht 200
