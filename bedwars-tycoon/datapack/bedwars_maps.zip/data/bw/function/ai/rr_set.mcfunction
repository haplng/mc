execute if score @s bw.team matches 1 run function bw:ai/rr_set1
execute if score @s bw.team matches 2 run function bw:ai/rr_set2
execute if score @s bw.team matches 3 run function bw:ai/rr_set3
execute if score @s bw.team matches 4 run function bw:ai/rr_set4
execute if score @s bw.team matches 5 run function bw:ai/rr_set5
execute if score @s bw.team matches 6 run function bw:ai/rr_set6
execute if score @s bw.team matches 7 run function bw:ai/rr_set7
