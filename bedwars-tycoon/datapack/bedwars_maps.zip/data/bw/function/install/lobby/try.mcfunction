forceload add -88 -58 0 99
forceload add 1 -58 89 99
execute unless loaded -88 64 -58 run return run schedule function bw:install/lobby/try 20t
execute unless loaded 89 64 -58 run return run schedule function bw:install/lobby/try 20t
execute unless loaded -88 64 99 run return run schedule function bw:install/lobby/try 20t
execute unless loaded 89 64 99 run return run schedule function bw:install/lobby/try 20t
execute unless loaded 0 64 20 run return run schedule function bw:install/lobby/try 20t
kill @e[type=!player,tag=bw,x=-88,y=9,z=-58,dx=178,dy=89,dz=158]
place template bw:lobby -88 11 -58
forceload remove -88 -58 0 99
forceload remove 1 -58 89 99
scoreboard players set #installed bw 1
execute if score #first bw matches 1 as @a run function bw:go/lobby
effect clear @a minecraft:slow_falling
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "로비 설치 완료 (1/11)", "color": "gray"}]
schedule function bw:install/sakura/load 10t
