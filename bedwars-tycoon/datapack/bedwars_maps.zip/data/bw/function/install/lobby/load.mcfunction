forceload add -88 -58 89 99
schedule function bw:install/lobby/try 40t
