forceload add -88 -58 0 99
forceload add 1 -58 89 99
schedule function bw:install/lobby/try 40t
