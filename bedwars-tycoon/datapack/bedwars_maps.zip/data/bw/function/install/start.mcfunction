scoreboard players set #installed bw 0
scoreboard players set #ver bw 7
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "로비와 맵 5개를 설치할게. 1분쯤 걸려.", "color": "yellow"}]
function bw:step/lobby/load
