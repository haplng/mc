scoreboard players set #installed bw 0
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "맵 10개와 로비를 설치할게. 1분쯤 걸려.", "color": "yellow"}]
function bw:install/lobby/load
