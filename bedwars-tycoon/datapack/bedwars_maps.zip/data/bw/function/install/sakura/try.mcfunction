forceload add 527 -73 673 73
execute unless loaded 527 64 -73 run return run schedule function bw:install/sakura/try 20t
execute unless loaded 673 64 -73 run return run schedule function bw:install/sakura/try 20t
execute unless loaded 527 64 73 run return run schedule function bw:install/sakura/try 20t
execute unless loaded 673 64 73 run return run schedule function bw:install/sakura/try 20t
execute unless loaded 600 64 0 run return run schedule function bw:install/sakura/try 20t
kill @e[type=!player,tag=bw,x=527,y=28,z=-73,dx=147,dy=57,dz=147]
place template bw:sakura 527 30 -73
forceload remove 527 -73 673 73
scoreboard players set #installed bw 2
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "벚꽃 정원 설치 완료 (2/11)", "color": "gray"}]
schedule function bw:install/oasis/load 10t
