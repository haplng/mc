forceload add 506 -94 600 94
forceload add 601 -94 694 94
execute unless loaded 506 64 -94 run return run schedule function bw:install/sakura/try 20t
execute unless loaded 694 64 -94 run return run schedule function bw:install/sakura/try 20t
execute unless loaded 506 64 94 run return run schedule function bw:install/sakura/try 20t
execute unless loaded 694 64 94 run return run schedule function bw:install/sakura/try 20t
execute unless loaded 600 64 0 run return run schedule function bw:install/sakura/try 20t
kill @e[type=!player,tag=bw,x=506,y=28,z=-94,dx=189,dy=56,dz=189]
place template bw:sakura 506 30 -94
forceload remove 506 -94 600 94
forceload remove 601 -94 694 94
scoreboard players set #installed bw 2
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "벚꽃 정원 설치 완료 (2/11)", "color": "gray"}]
schedule function bw:install/oasis/load 10t
