forceload add 506 -94 600 94
forceload add 601 -94 694 94
schedule function bw:install/sakura/try 40t
