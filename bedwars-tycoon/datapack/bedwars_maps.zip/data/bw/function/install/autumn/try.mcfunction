forceload add 2484 -116 2600 116
forceload add 2601 -116 2716 116
execute unless loaded 2484 64 -116 run return run schedule function bw:install/autumn/try 20t
execute unless loaded 2716 64 -116 run return run schedule function bw:install/autumn/try 20t
execute unless loaded 2484 64 116 run return run schedule function bw:install/autumn/try 20t
execute unless loaded 2716 64 116 run return run schedule function bw:install/autumn/try 20t
execute unless loaded 2600 64 0 run return run schedule function bw:install/autumn/try 20t
kill @e[type=!player,tag=bw,x=2484,y=33,z=-116,dx=233,dy=54,dz=233]
place template bw:autumn 2484 35 -116
forceload remove 2484 -116 2600 116
forceload remove 2601 -116 2716 116
scoreboard players set #installed bw 7
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "가을 농장 설치 완료 (7/11)", "color": "gray"}]
schedule function bw:install/nether/load 10t
