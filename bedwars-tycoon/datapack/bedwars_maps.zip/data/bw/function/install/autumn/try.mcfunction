forceload add 2504 -96 2696 96
execute unless loaded 2504 64 -96 run return run schedule function bw:install/autumn/try 20t
execute unless loaded 2696 64 -96 run return run schedule function bw:install/autumn/try 20t
execute unless loaded 2504 64 96 run return run schedule function bw:install/autumn/try 20t
execute unless loaded 2696 64 96 run return run schedule function bw:install/autumn/try 20t
execute unless loaded 2600 64 0 run return run schedule function bw:install/autumn/try 20t
kill @e[type=!player,tag=bw,x=2504,y=32,z=-96,dx=193,dy=56,dz=193]
place template bw:autumn 2504 34 -96
forceload remove 2504 -96 2696 96
scoreboard players set #installed bw 7
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "가을 농장 설치 완료 (7/11)", "color": "gray"}]
schedule function bw:install/nether/load 10t
