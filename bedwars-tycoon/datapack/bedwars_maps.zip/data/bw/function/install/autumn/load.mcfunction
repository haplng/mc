forceload add 2504 -96 2696 96
schedule function bw:install/autumn/try 40t
