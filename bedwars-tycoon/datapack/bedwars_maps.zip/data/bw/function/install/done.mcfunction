scoreboard players set #first bw 0
scoreboard players set #wipe bw 0
setworldspawn 0 65 9
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "설치 끝! 로비의 문으로 들어가면 맵으로 가. ", "color": "green"}, {"text": "/trigger lobby", "color": "aqua"}, {"text": " 로 로비에 돌아올 수 있어.", "color": "gray"}]
