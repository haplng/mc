scoreboard players set #first bw 0
setworldspawn 0 65 9
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "설치 끝! ", "color": "green"}, {"text": "/function bw:lobby", "color": "aqua"}, {"text": " 로 로비에 갈 수 있어.", "color": "gray"}]
