forceload add 1692 -108 1800 108
forceload add 1801 -108 1908 108
schedule function bw:install/mushroom/try 40t
