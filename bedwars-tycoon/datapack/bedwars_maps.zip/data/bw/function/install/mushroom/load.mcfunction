forceload add 1713 -87 1887 87
schedule function bw:install/mushroom/try 40t
