forceload add 1713 -87 1887 87
execute unless loaded 1713 64 -87 run return run schedule function bw:install/mushroom/try 20t
execute unless loaded 1887 64 -87 run return run schedule function bw:install/mushroom/try 20t
execute unless loaded 1713 64 87 run return run schedule function bw:install/mushroom/try 20t
execute unless loaded 1887 64 87 run return run schedule function bw:install/mushroom/try 20t
execute unless loaded 1800 64 0 run return run schedule function bw:install/mushroom/try 20t
kill @e[type=!player,tag=bw,x=1713,y=33,z=-87,dx=175,dy=50,dz=175]
place template bw:mushroom 1713 35 -87
forceload remove 1713 -87 1887 87
scoreboard players set #installed bw 5
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "버섯 숲 설치 완료 (5/11)", "color": "gray"}]
schedule function bw:install/harbour/load 10t
