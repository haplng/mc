forceload add 1692 -108 1800 108
forceload add 1801 -108 1908 108
execute unless loaded 1692 64 -108 run return run schedule function bw:install/mushroom/try 20t
execute unless loaded 1908 64 -108 run return run schedule function bw:install/mushroom/try 20t
execute unless loaded 1692 64 108 run return run schedule function bw:install/mushroom/try 20t
execute unless loaded 1908 64 108 run return run schedule function bw:install/mushroom/try 20t
execute unless loaded 1800 64 0 run return run schedule function bw:install/mushroom/try 20t
kill @e[type=!player,tag=bw,x=1692,y=34,z=-108,dx=217,dy=49,dz=217]
place template bw:mushroom 1692 36 -108
forceload remove 1692 -108 1800 108
forceload remove 1801 -108 1908 108
scoreboard players set #installed bw 5
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "버섯 숲 설치 완료 (5/11)", "color": "gray"}]
schedule function bw:install/harbour/load 10t
