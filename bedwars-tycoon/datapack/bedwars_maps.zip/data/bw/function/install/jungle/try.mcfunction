forceload add 3277 -123 3400 123
forceload add 3401 -123 3523 123
execute unless loaded 3277 64 -123 run return run schedule function bw:install/jungle/try 20t
execute unless loaded 3523 64 -123 run return run schedule function bw:install/jungle/try 20t
execute unless loaded 3277 64 123 run return run schedule function bw:install/jungle/try 20t
execute unless loaded 3523 64 123 run return run schedule function bw:install/jungle/try 20t
execute unless loaded 3400 64 0 run return run schedule function bw:install/jungle/try 20t
kill @e[type=!player,tag=bw,x=3277,y=29,z=-123,dx=247,dy=53,dz=247]
place template bw:jungle 3277 31 -123
forceload remove 3277 -123 3400 123
forceload remove 3401 -123 3523 123
scoreboard players set #installed bw 9
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "정글 신전 설치 완료 (9/11)", "color": "gray"}]
schedule function bw:install/castle/load 10t
