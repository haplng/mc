forceload add 3297 -103 3503 103
execute unless loaded 3297 64 -103 run return run schedule function bw:install/jungle/try 20t
execute unless loaded 3503 64 -103 run return run schedule function bw:install/jungle/try 20t
execute unless loaded 3297 64 103 run return run schedule function bw:install/jungle/try 20t
execute unless loaded 3503 64 103 run return run schedule function bw:install/jungle/try 20t
execute unless loaded 3400 64 0 run return run schedule function bw:install/jungle/try 20t
kill @e[type=!player,tag=bw,x=3297,y=28,z=-103,dx=207,dy=54,dz=207]
place template bw:jungle 3297 30 -103
forceload remove 3297 -103 3503 103
scoreboard players set #installed bw 9
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "정글 신전 설치 완료 (9/11)", "color": "gray"}]
schedule function bw:install/castle/load 10t
