forceload add 4068 -132 4200 132
forceload add 4201 -132 4332 132
execute unless loaded 4068 64 -132 run return run schedule function bw:install/end/try 20t
execute unless loaded 4332 64 -132 run return run schedule function bw:install/end/try 20t
execute unless loaded 4068 64 132 run return run schedule function bw:install/end/try 20t
execute unless loaded 4332 64 132 run return run schedule function bw:install/end/try 20t
execute unless loaded 4200 64 0 run return run schedule function bw:install/end/try 20t
kill @e[type=!player,tag=bw,x=4068,y=27,z=-132,dx=265,dy=64,dz=265]
place template bw:end 4068 29 -132
forceload remove 4068 -132 4200 132
forceload remove 4201 -132 4332 132
scoreboard players set #installed bw 11
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "엔드 성채 설치 완료 (11/11)", "color": "gray"}]
function bw:install/done
