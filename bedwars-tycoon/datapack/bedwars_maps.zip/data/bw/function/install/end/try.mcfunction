forceload add 4088 -112 4312 112
execute unless loaded 4088 64 -112 run return run schedule function bw:install/end/try 20t
execute unless loaded 4312 64 -112 run return run schedule function bw:install/end/try 20t
execute unless loaded 4088 64 112 run return run schedule function bw:install/end/try 20t
execute unless loaded 4312 64 112 run return run schedule function bw:install/end/try 20t
execute unless loaded 4200 64 0 run return run schedule function bw:install/end/try 20t
kill @e[type=!player,tag=bw,x=4088,y=27,z=-112,dx=225,dy=64,dz=225]
place template bw:end 4088 29 -112
forceload remove 4088 -112 4312 112
scoreboard players set #installed bw 11
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "엔드 성채 설치 완료 (11/11)", "color": "gray"}]
function bw:install/done
