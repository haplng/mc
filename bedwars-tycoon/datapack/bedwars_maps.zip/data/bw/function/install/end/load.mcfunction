forceload add 4068 -132 4200 132
forceload add 4201 -132 4332 132
schedule function bw:install/end/try 40t
