forceload add 4088 -112 4312 112
schedule function bw:install/end/try 40t
