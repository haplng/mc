forceload add 924 -76 1076 76
execute unless loaded 924 64 -76 run return run schedule function bw:install/oasis/try 20t
execute unless loaded 1076 64 -76 run return run schedule function bw:install/oasis/try 20t
execute unless loaded 924 64 76 run return run schedule function bw:install/oasis/try 20t
execute unless loaded 1076 64 76 run return run schedule function bw:install/oasis/try 20t
execute unless loaded 1000 64 0 run return run schedule function bw:install/oasis/try 20t
kill @e[type=!player,tag=bw,x=924,y=25,z=-76,dx=153,dy=54,dz=153]
place template bw:oasis 924 27 -76
forceload remove 924 -76 1076 76
scoreboard players set #installed bw 3
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "사막 오아시스 설치 완료 (3/11)", "color": "gray"}]
schedule function bw:install/frost/load 10t
