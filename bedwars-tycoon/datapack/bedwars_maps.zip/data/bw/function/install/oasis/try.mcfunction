forceload add 903 -97 1000 97
forceload add 1001 -97 1097 97
execute unless loaded 903 64 -97 run return run schedule function bw:install/oasis/try 20t
execute unless loaded 1097 64 -97 run return run schedule function bw:install/oasis/try 20t
execute unless loaded 903 64 97 run return run schedule function bw:install/oasis/try 20t
execute unless loaded 1097 64 97 run return run schedule function bw:install/oasis/try 20t
execute unless loaded 1000 64 0 run return run schedule function bw:install/oasis/try 20t
kill @e[type=!player,tag=bw,x=903,y=25,z=-97,dx=195,dy=53,dz=195]
place template bw:oasis 903 27 -97
forceload remove 903 -97 1000 97
forceload remove 1001 -97 1097 97
scoreboard players set #installed bw 3
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "사막 오아시스 설치 완료 (3/11)", "color": "gray"}]
schedule function bw:install/frost/load 10t
