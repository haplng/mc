forceload add 903 -97 1000 97
forceload add 1001 -97 1097 97
schedule function bw:install/oasis/try 40t
