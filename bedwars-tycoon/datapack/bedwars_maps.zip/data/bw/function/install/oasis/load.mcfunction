forceload add 924 -76 1076 76
schedule function bw:install/oasis/try 40t
