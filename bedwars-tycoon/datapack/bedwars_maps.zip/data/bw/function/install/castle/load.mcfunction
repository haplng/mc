forceload add 3673 -127 3800 127
forceload add 3801 -127 3927 127
schedule function bw:install/castle/try 40t
