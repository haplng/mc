forceload add 3692 -108 3908 108
schedule function bw:install/castle/try 40t
