forceload add 3673 -127 3800 127
forceload add 3801 -127 3927 127
execute unless loaded 3673 64 -127 run return run schedule function bw:install/castle/try 20t
execute unless loaded 3927 64 -127 run return run schedule function bw:install/castle/try 20t
execute unless loaded 3673 64 127 run return run schedule function bw:install/castle/try 20t
execute unless loaded 3927 64 127 run return run schedule function bw:install/castle/try 20t
execute unless loaded 3800 64 0 run return run schedule function bw:install/castle/try 20t
kill @e[type=!player,tag=bw,x=3673,y=24,z=-127,dx=255,dy=68,dz=255]
place template bw:castle 3673 26 -127
forceload remove 3673 -127 3800 127
forceload remove 3801 -127 3927 127
scoreboard players set #installed bw 10
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "천공의 성 설치 완료 (10/11)", "color": "gray"}]
schedule function bw:install/end/load 10t
