forceload add 3692 -108 3908 108
execute unless loaded 3692 64 -108 run return run schedule function bw:install/castle/try 20t
execute unless loaded 3908 64 -108 run return run schedule function bw:install/castle/try 20t
execute unless loaded 3692 64 108 run return run schedule function bw:install/castle/try 20t
execute unless loaded 3908 64 108 run return run schedule function bw:install/castle/try 20t
execute unless loaded 3800 64 0 run return run schedule function bw:install/castle/try 20t
kill @e[type=!player,tag=bw,x=3692,y=23,z=-108,dx=217,dy=69,dz=217]
place template bw:castle 3692 25 -108
forceload remove 3692 -108 3908 108
scoreboard players set #installed bw 10
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "천공의 성 설치 완료 (10/11)", "color": "gray"}]
schedule function bw:install/end/load 10t
