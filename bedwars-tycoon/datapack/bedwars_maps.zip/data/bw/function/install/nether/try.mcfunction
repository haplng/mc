forceload add 2902 -98 3098 98
execute unless loaded 2902 64 -98 run return run schedule function bw:install/nether/try 20t
execute unless loaded 3098 64 -98 run return run schedule function bw:install/nether/try 20t
execute unless loaded 2902 64 98 run return run schedule function bw:install/nether/try 20t
execute unless loaded 3098 64 98 run return run schedule function bw:install/nether/try 20t
execute unless loaded 3000 64 0 run return run schedule function bw:install/nether/try 20t
kill @e[type=!player,tag=bw,x=2902,y=26,z=-98,dx=197,dy=57,dz=197]
place template bw:nether 2902 28 -98
forceload remove 2902 -98 3098 98
scoreboard players set #installed bw 8
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "네더 요새 설치 완료 (8/11)", "color": "gray"}]
schedule function bw:install/jungle/load 10t
