forceload add 2881 -119 3000 119
forceload add 3001 -119 3119 119
execute unless loaded 2881 64 -119 run return run schedule function bw:install/nether/try 20t
execute unless loaded 3119 64 -119 run return run schedule function bw:install/nether/try 20t
execute unless loaded 2881 64 119 run return run schedule function bw:install/nether/try 20t
execute unless loaded 3119 64 119 run return run schedule function bw:install/nether/try 20t
execute unless loaded 3000 64 0 run return run schedule function bw:install/nether/try 20t
kill @e[type=!player,tag=bw,x=2881,y=26,z=-119,dx=239,dy=57,dz=239]
place template bw:nether 2881 28 -119
forceload remove 2881 -119 3000 119
forceload remove 3001 -119 3119 119
scoreboard players set #installed bw 8
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "네더 요새 설치 완료 (8/11)", "color": "gray"}]
schedule function bw:install/jungle/load 10t
