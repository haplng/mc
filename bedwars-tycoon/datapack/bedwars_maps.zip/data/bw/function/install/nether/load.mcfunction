forceload add 2881 -119 3000 119
forceload add 3001 -119 3119 119
schedule function bw:install/nether/try 40t
