forceload add 2902 -98 3098 98
schedule function bw:install/nether/try 40t
