forceload add 2109 -91 2291 91
execute unless loaded 2109 64 -91 run return run schedule function bw:install/harbour/try 20t
execute unless loaded 2291 64 -91 run return run schedule function bw:install/harbour/try 20t
execute unless loaded 2109 64 91 run return run schedule function bw:install/harbour/try 20t
execute unless loaded 2291 64 91 run return run schedule function bw:install/harbour/try 20t
execute unless loaded 2200 64 0 run return run schedule function bw:install/harbour/try 20t
kill @e[type=!player,tag=bw,x=2109,y=31,z=-91,dx=183,dy=63,dz=183]
place template bw:harbour 2109 33 -91
forceload remove 2109 -91 2291 91
scoreboard players set #installed bw 6
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "등대 항구 설치 완료 (6/11)", "color": "gray"}]
schedule function bw:install/autumn/load 10t
