forceload add 2089 -111 2200 111
forceload add 2201 -111 2311 111
execute unless loaded 2089 64 -111 run return run schedule function bw:install/harbour/try 20t
execute unless loaded 2311 64 -111 run return run schedule function bw:install/harbour/try 20t
execute unless loaded 2089 64 111 run return run schedule function bw:install/harbour/try 20t
execute unless loaded 2311 64 111 run return run schedule function bw:install/harbour/try 20t
execute unless loaded 2200 64 0 run return run schedule function bw:install/harbour/try 20t
kill @e[type=!player,tag=bw,x=2089,y=31,z=-111,dx=223,dy=63,dz=223]
place template bw:harbour 2089 33 -111
forceload remove 2089 -111 2200 111
forceload remove 2201 -111 2311 111
scoreboard players set #installed bw 6
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "등대 항구 설치 완료 (6/11)", "color": "gray"}]
schedule function bw:install/autumn/load 10t
