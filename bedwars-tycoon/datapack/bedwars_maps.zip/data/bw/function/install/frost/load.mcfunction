forceload add 1295 -105 1400 105
forceload add 1401 -105 1505 105
schedule function bw:install/frost/try 40t
