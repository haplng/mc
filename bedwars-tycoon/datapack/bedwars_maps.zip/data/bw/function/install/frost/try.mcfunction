forceload add 1295 -105 1400 105
forceload add 1401 -105 1505 105
execute unless loaded 1295 64 -105 run return run schedule function bw:install/frost/try 20t
execute unless loaded 1505 64 -105 run return run schedule function bw:install/frost/try 20t
execute unless loaded 1295 64 105 run return run schedule function bw:install/frost/try 20t
execute unless loaded 1505 64 105 run return run schedule function bw:install/frost/try 20t
execute unless loaded 1400 64 0 run return run schedule function bw:install/frost/try 20t
kill @e[type=!player,tag=bw,x=1295,y=30,z=-105,dx=211,dy=58,dz=211]
place template bw:frost 1295 32 -105
forceload remove 1295 -105 1400 105
forceload remove 1401 -105 1505 105
scoreboard players set #installed bw 4
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "얼음 마을 설치 완료 (4/11)", "color": "gray"}]
schedule function bw:install/mushroom/load 10t
