forceload add 1316 -84 1484 84
execute unless loaded 1316 64 -84 run return run schedule function bw:install/frost/try 20t
execute unless loaded 1484 64 -84 run return run schedule function bw:install/frost/try 20t
execute unless loaded 1316 64 84 run return run schedule function bw:install/frost/try 20t
execute unless loaded 1484 64 84 run return run schedule function bw:install/frost/try 20t
execute unless loaded 1400 64 0 run return run schedule function bw:install/frost/try 20t
kill @e[type=!player,tag=bw,x=1316,y=30,z=-84,dx=169,dy=58,dz=169]
place template bw:frost 1316 32 -84
forceload remove 1316 -84 1484 84
scoreboard players set #installed bw 4
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "얼음 마을 설치 완료 (4/11)", "color": "gray"}]
schedule function bw:install/mushroom/load 10t
