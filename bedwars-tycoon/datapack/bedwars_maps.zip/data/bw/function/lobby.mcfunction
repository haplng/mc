execute as @s[type=player] run function bw:go/lobby
