scoreboard objectives add lobby trigger
scoreboard objectives add bw dummy
scoreboard objectives add bw.death deathCount
scoreboard objectives add bw.side dummy {text:"BED WARS",color:"yellow",bold:true}
scoreboard objectives add bw.lob dummy {text:"배드워즈 타이쿤",color:"yellow",bold:true}
scoreboard objectives add bw.team dummy
scoreboard objectives add bw.resp dummy
scoreboard objectives add bw.rs dummy
scoreboard objectives add bw.coins dummy
scoreboard objectives add bw.stage dummy
scoreboard objectives add bw.wins dummy
scoreboard objectives add bw.gk dummy
scoreboard objectives add bw.gf dummy
scoreboard objectives add bw.gb dummy
scoreboard objectives add bw.armor dummy
scoreboard objectives add bw.pick dummy
scoreboard objectives add bw.axe dummy
scoreboard objectives add bw.shears dummy
scoreboard objectives add bw.lh dummy
scoreboard objectives add bw.lht dummy
scoreboard objectives add bw.t dummy
scoreboard objectives add bw.gcd dummy
team add bw.red
team add bw.blue
team add bw.lime
team add bw.yellow
team add bw.cyan
team add bw.white
team add bw.pink
team add bw.gray
team modify bw.red color red
team modify bw.blue color blue
team modify bw.lime color green
team modify bw.yellow color yellow
team modify bw.cyan color dark_aqua
team modify bw.white color white
team modify bw.pink color light_purple
team modify bw.gray color gray
team modify bw.red friendlyFire false
team modify bw.blue friendlyFire false
team modify bw.lime friendlyFire false
team modify bw.yellow friendlyFire false
team modify bw.cyan friendlyFire false
team modify bw.white friendlyFire false
team modify bw.pink friendlyFire false
team modify bw.gray friendlyFire false
team modify bw.red collisionRule pushOtherTeams
team modify bw.blue collisionRule pushOtherTeams
team modify bw.lime collisionRule pushOtherTeams
team modify bw.yellow collisionRule pushOtherTeams
team modify bw.cyan collisionRule pushOtherTeams
team modify bw.white collisionRule pushOtherTeams
team modify bw.pink collisionRule pushOtherTeams
team modify bw.gray collisionRule pushOtherTeams
scoreboard players set #2 bw 2
scoreboard players set #4 bw 4
scoreboard players set #10 bw 10
scoreboard players set #20 bw 20
scoreboard players set #25 bw 25
scoreboard players set #60 bw 60
scoreboard players set #100 bw 100
scoreboard players set #1000 bw 1000
execute unless score #state bw matches 0.. run scoreboard players set #state bw 0
execute unless score #goal bw matches 1.. run scoreboard players set #goal bw 10000
execute if score #state bw matches 1.. run schedule function bw:game/close 20t
scoreboard objectives add bw.page dummy
scoreboard objectives add bw.click dummy
scoreboard objectives add bw.gt dummy
scoreboard objectives add bw.fe dummy
scoreboard objectives add bw.au dummy
scoreboard objectives add bw.em dummy
scoreboard objectives add bw.di dummy
scoreboard objectives add bw.vsharp dummy
scoreboard objectives add bw.vprot dummy
scoreboard objectives add bw.vhaste dummy
scoreboard objectives add bw.vforge dummy
scoreboard objectives add bw.vheal dummy
scoreboard objectives add bw.vtrap dummy
scoreboard objectives add bw.st dummy
scoreboard objectives add bw.pst dummy
scoreboard objectives add bw.dest dummy
scoreboard objectives add bw.t1 dummy
scoreboard objectives add bw.t2 dummy
scoreboard objectives add bw.atk dummy
scoreboard objectives add bw.jc dummy
scoreboard objectives add bw.br dummy
scoreboard objectives add bw.slow dummy
scoreboard objectives add bw.hp dummy
scoreboard objectives add bw.tgt dummy
scoreboard objectives add bw.mf dummy
scoreboard objectives add bw.ms dummy
scoreboard objectives add bw.mine dummy
scoreboard objectives add bw.stuck dummy
scoreboard objectives add bw.px dummy
scoreboard objectives add bw.py dummy
scoreboard objectives add bw.pz dummy
scoreboard objectives add bw.strafe dummy
scoreboard objectives add bw.sw dummy
scoreboard objectives add bw.tool dummy
scoreboard objectives add bw.pose dummy
scoreboard objectives add bw.fbc dummy
scoreboard objectives add bw.idle dummy
scoreboard objectives add bw.wpt dummy
scoreboard objectives add bw.av dummy
scoreboard objectives add bw.avn dummy
scoreboard objectives add bw.avs dummy
scoreboard objectives add bw.ft dummy
scoreboard objectives add bw.calm dummy
scoreboard objectives add bw.trc dummy
scoreboard objectives add bw.tx dummy
scoreboard objectives add bw.tz dummy
scoreboard objectives add bw.off dummy
scoreboard objectives add bw.offa dummy
scoreboard objectives add bw.avf dummy
scoreboard objectives add bw.av0 dummy
scoreboard objectives add bw.avc dummy
data modify storage bw:ai names set value ["ItzMango","sn0wfall","Kaito_","NotLuca","Zephyrr","qwertyPvP","Mochi_22","BedBreaker12","xRushy","Tofu_Lord","p1nkbean","Deokbokki","KimchiKing","vortexx_","Hanul","Jisoo_BW","lil_creeper","Dalgona","woolwalker","N0tAfk","Seojun07","MinGyu_","sweatyTaco","obbyrusher","Yuna_Luv","BridgeGod99","Haneul_","egg_bridge","doyun2010","clutchmaster","Ramyun","gapple_gobbler","SoraSky","TNTjunho","ttv_wooly","Bada_","fireball_fred","JiHo_zz","voidwalkr","Nabi_","sunbae","RiceCake","oppaPvP","Byeol","laggyboi","Gureum","noobslayer_kr","Hodu"]
function bw:nav/tea
function bw:nav/chess
function bw:nav/circus
function bw:nav/library
function bw:nav/solar
scoreboard objectives add bw.use minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add bw.tnt minecraft.used:minecraft.tnt
scoreboard players set #150 bw 150
scoreboard players set #200 bw 200
scoreboard players set #-1 bw -1
scoreboard objectives add bw.h_velocity dummy
scoreboard objectives add bw.h_reach dummy
scoreboard objectives add bw.h_eagle dummy
scoreboard objectives add bw.h_aim dummy
scoreboard objectives add bw.h_clicker dummy
scoreboard objectives add bw.h_block dummy
scoreboard objectives add bw.h_kbd dummy
scoreboard objectives add bw.h_antifb dummy
scoreboard objectives add bw.h_velocity2 dummy
scoreboard objectives add bw.h_scaffold dummy
scoreboard objectives add bw.h_lag dummy
scoreboard objectives add bw.h_stasis dummy
scoreboard objectives add bw.h_tower dummy
scoreboard objectives add bw.h_nofall dummy
scoreboard objectives add bw.h_fbjump dummy
scoreboard objectives add bw.h_tpaura dummy
scoreboard objectives add bw.hc1 dummy
scoreboard objectives add bw.hc2 dummy
scoreboard objectives add bw.stc dummy
scoreboard objectives add bw.sy dummy
scoreboard objectives add bw.acd dummy
scoreboard objectives add bw.tpc dummy
scoreboard objectives add bw.ecd dummy
scoreboard objectives add bw.hreach dummy
scoreboard players set #75 bw 75
scoreboard players set #50 bw 50
forceload add -1 -1 0 0
execute if score #installed bw matches 0.. unless score #ver bw matches 8.. run function bw:upgrade/prepare
execute unless score #installed bw matches 0.. run scoreboard players set #first bw 1
execute unless score #installed bw matches 0.. run schedule function bw:install/start 1t
