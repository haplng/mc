scoreboard objectives add lobby trigger
scoreboard objectives add bw dummy
execute unless score #installed bw matches 0.. run schedule function bw:install/start 60t
