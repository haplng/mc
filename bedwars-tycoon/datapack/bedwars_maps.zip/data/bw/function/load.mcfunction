scoreboard objectives add lobby trigger
scoreboard objectives add bw dummy
scoreboard objectives add bw.buy trigger
scoreboard objectives add bw.shop trigger
scoreboard objectives add bw.page dummy
scoreboard objectives add bw.team dummy
execute if score #installed bw matches 0.. unless score #ver bw matches 7.. run function bw:upgrade/prepare
execute unless score #installed bw matches 0.. run scoreboard players set #first bw 1
execute unless score #installed bw matches 0.. run schedule function bw:install/start 1t
