scoreboard objectives add lobby trigger
scoreboard objectives add bw dummy
execute if score #installed bw matches 0.. unless score #ver bw matches 3.. run schedule function bw:upgrade/start 20t
execute unless score #installed bw matches 0.. run scoreboard players set #first bw 1
execute unless score #installed bw matches 0.. run schedule function bw:install/start 1t
