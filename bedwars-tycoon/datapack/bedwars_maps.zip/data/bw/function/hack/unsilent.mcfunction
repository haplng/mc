item modify entity @s weapon.mainhand {type:"minecraft:set_components",components:{"!minecraft:attack_range":{}}}
