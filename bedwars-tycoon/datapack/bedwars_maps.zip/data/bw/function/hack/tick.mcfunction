scoreboard players remove @s[scores={bw.stc=1..}] bw.stc 1
scoreboard players remove @s[scores={bw.acd=1..}] bw.acd 1
scoreboard players remove @s[scores={bw.tpc=1..}] bw.tpc 1
scoreboard players remove @s[scores={bw.ecd=1..}] bw.ecd 1
execute if entity @s[scores={bw.h_aim=2},tag=!bw.off_aim] if items entity @s weapon.mainhand #bw:sharp[!minecraft:attack_range] run function bw:hack/silent with storage bw:tmp aim
execute unless entity @s[scores={bw.h_aim=2},tag=!bw.off_aim] if items entity @s weapon.mainhand *[minecraft:attack_range] run function bw:hack/unsilent
execute if entity @s[scores={bw.h_aim=1},tag=!bw.off_aim] if items entity @s weapon.mainhand #bw:sharp run function bw:hack/aim
execute if entity @s[scores={bw.h_clicker=1..},tag=!bw.off_clicker] if score @s bw.acd matches 0 if items entity @s weapon.mainhand #bw:sharp if entity @e[type=minecraft:mannequin,tag=bw.bot,distance=..6] run function bw:hack/click
execute if entity @s[scores={bw.h_tpaura=1..},tag=!bw.off_tpaura] if score @s bw.tpc matches 0 if items entity @s weapon.mainhand #minecraft:swords if entity @e[type=minecraft:mannequin,tag=bw.bot,distance=..14] run function bw:hack/tpaura
execute if entity @s[scores={bw.h_antifb=1..},tag=!bw.off_antifb] as @e[type=minecraft:fireball,tag=bw.fb,tag=!bw.refl,distance=..4.5] unless score @s bw.team = @p bw.team run function bw:hack/reflect
execute if entity @s[scores={bw.h_eagle=1..},tag=!bw.off_eagle] if items entity @s weapon.mainhand #bw:placeable run function bw:hack/eagle
execute unless entity @s[scores={bw.h_eagle=1..},tag=!bw.off_eagle] run attribute @s minecraft:movement_speed modifier remove bw:eagle
execute if entity @s[scores={bw.h_scaffold=1..},tag=!bw.off_scaffold] if items entity @s container.* #bw:scaf run function bw:hack/scaffold
execute if entity @s[scores={bw.h_tower=1..},tag=!bw.off_tower] run function bw:hack/tower
execute if entity @s[tag=bw.lev] unless predicate bw:jump run function bw:hack/towerend
