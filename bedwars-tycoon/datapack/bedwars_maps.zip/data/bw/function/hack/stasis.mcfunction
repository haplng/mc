scoreboard players set @s bw.stc 600
effect give @s minecraft:levitation 3 0 true
effect give @s minecraft:slow_falling 6 0 true
title @s actionbar {text:"Stasis!",color:"light_purple",bold:true}
playsound minecraft:block.beacon.activate player @s ~ ~ ~ 1 1.6
particle minecraft:end_rod ~ ~0.5 ~ 0.4 0.6 0.4 0.02 25
