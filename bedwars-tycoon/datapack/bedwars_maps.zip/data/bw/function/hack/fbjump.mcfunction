clear @s *[minecraft:custom_data~{bw:"fireball"}] 1
execute rotated ~ 0 positioned ^ ^1.3 ^-1.0 run summon minecraft:armor_stand ~ ~ ~ {Marker:1b,Invisible:1b,NoGravity:1b,Tags:["bw","bw.round","bw.boom"],equipment:{head:{id:"minecraft:leather_helmet",count:1,components:{"minecraft:enchantments":{"bw:push":1}}}}}
title @s actionbar {text:"FB Longjump",color:"gold",bold:true}
return 1
