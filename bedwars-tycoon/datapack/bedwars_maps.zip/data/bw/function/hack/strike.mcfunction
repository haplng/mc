execute store result score #dmg bw run attribute @s minecraft:attack_damage get 100
execute if score @s bw.team matches 0 if score #sharp0 bw matches 1.. run scoreboard players add #dmg bw 100
execute if score @s bw.team matches 1 if score #sharp1 bw matches 1.. run scoreboard players add #dmg bw 100
execute if score @s bw.team matches 2 if score #sharp2 bw matches 1.. run scoreboard players add #dmg bw 100
execute if score @s bw.team matches 3 if score #sharp3 bw matches 1.. run scoreboard players add #dmg bw 100
execute if score @s bw.team matches 4 if score #sharp4 bw matches 1.. run scoreboard players add #dmg bw 100
execute if score @s bw.team matches 5 if score #sharp5 bw matches 1.. run scoreboard players add #dmg bw 100
execute if score @s bw.team matches 6 if score #sharp6 bw matches 1.. run scoreboard players add #dmg bw 100
execute if score @s bw.team matches 7 if score #sharp7 bw matches 1.. run scoreboard players add #dmg bw 100
execute store result storage bw:tmp hit.d float 0.01 run scoreboard players get #dmg bw
function bw:hack/strike2 with storage bw:tmp hit
