tag @e[tag=bw.aimt] remove bw.aimt
execute unless entity @e[tag=bw.aimt] anchored eyes positioned ^ ^ ^2 positioned ~ ~-1.4 ~ as @e[type=minecraft:mannequin,tag=bw.bot,distance=..1.9,sort=nearest,limit=1] run tag @s add bw.aimt
execute anchored eyes positioned ^ ^ ^2 positioned ~ ~-1.4 ~ if entity @e[tag=bw.aimt,distance=0.4..1.9] positioned ~ ~1.4 ~ anchored feet facing entity @e[tag=bw.aimt,limit=1] eyes positioned ^ ^ ^0.3 anchored eyes run function bw:hack/aimturn
execute unless entity @e[tag=bw.aimt] anchored eyes positioned ^ ^ ^3 positioned ~ ~-1.4 ~ as @e[type=minecraft:mannequin,tag=bw.bot,distance=..1.9,sort=nearest,limit=1] run tag @s add bw.aimt
execute anchored eyes positioned ^ ^ ^3 positioned ~ ~-1.4 ~ if entity @e[tag=bw.aimt,distance=0.4..1.9] positioned ~ ~1.4 ~ anchored feet facing entity @e[tag=bw.aimt,limit=1] eyes positioned ^ ^ ^0.3 anchored eyes run function bw:hack/aimturn
execute unless entity @e[tag=bw.aimt] anchored eyes positioned ^ ^ ^4 positioned ~ ~-1.4 ~ as @e[type=minecraft:mannequin,tag=bw.bot,distance=..1.9,sort=nearest,limit=1] run tag @s add bw.aimt
execute anchored eyes positioned ^ ^ ^4 positioned ~ ~-1.4 ~ if entity @e[tag=bw.aimt,distance=0.4..1.9] positioned ~ ~1.4 ~ anchored feet facing entity @e[tag=bw.aimt,limit=1] eyes positioned ^ ^ ^0.3 anchored eyes run function bw:hack/aimturn
