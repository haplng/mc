tag @s add bw.refl
execute as @p at @s anchored eyes positioned 0.0 0.0 0.0 run tp @e[type=minecraft:marker,tag=bw.vec,limit=1] ^ ^ ^1.2
data modify entity @s Motion set from entity @e[type=minecraft:marker,tag=bw.vec,limit=1] Pos
data modify entity @s Owner set from entity @p UUID
scoreboard players operation @s bw.team = @p bw.team
execute on passengers run scoreboard players operation @s bw.team = @p bw.team
execute as @p run swing @s mainhand
playsound minecraft:entity.blaze.hurt player @a ~ ~ ~ 1 1.4
particle minecraft:crit ~ ~ ~ 0.3 0.3 0.3 0.3 12
