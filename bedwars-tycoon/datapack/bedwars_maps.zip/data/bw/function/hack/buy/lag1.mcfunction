execute unless score @s bw.coins matches 1200.. run return run function bw:gui/short/coins {need:1200}
scoreboard players remove @s bw.coins 1200
scoreboard players set @s bw.h_lag 2
tag @s remove bw.off_lag
tellraw @s [{text:""},{text:"[암시장] ",color:"dark_purple"},{text:"Lag range (200ms)",color:"gold"},{text:" — 거래 끝. 들키지 마.",color:"gray"}]
playsound minecraft:entity.wandering_trader.yes master @s ~ ~ ~ 0.8 0.8
function bw:hack/apply
