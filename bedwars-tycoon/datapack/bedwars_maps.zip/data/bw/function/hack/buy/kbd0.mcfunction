execute unless score @s bw.coins matches 250.. run return run function bw:gui/short/coins {need:250}
scoreboard players remove @s bw.coins 250
scoreboard players set @s bw.h_kbd 1
tag @s remove bw.off_kbd
tellraw @s [{text:""},{text:"[암시장] ",color:"dark_purple"},{text:"Knockback Displace (90degree)",color:"gold"},{text:" — 거래 끝. 들키지 마.",color:"gray"}]
playsound minecraft:entity.wandering_trader.yes master @s ~ ~ ~ 0.8 0.8
function bw:hack/apply
