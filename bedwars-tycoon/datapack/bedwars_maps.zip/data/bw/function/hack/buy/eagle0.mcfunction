execute unless score @s bw.coins matches 100.. run return run function bw:gui/short/coins {need:100}
scoreboard players remove @s bw.coins 100
scoreboard players set @s bw.h_eagle 1
tag @s remove bw.off_eagle
tellraw @s [{text:""},{text:"[암시장] ",color:"dark_purple"},{text:"Eagle (0.2 80ms)",color:"gold"},{text:" — 거래 끝. 들키지 마.",color:"gray"}]
playsound minecraft:entity.wandering_trader.yes master @s ~ ~ ~ 0.8 0.8
function bw:hack/apply
