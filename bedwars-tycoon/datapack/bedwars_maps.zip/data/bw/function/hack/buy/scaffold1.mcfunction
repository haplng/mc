execute unless score @s bw.coins matches 1500.. run return run function bw:gui/short/coins {need:1500}
scoreboard players remove @s bw.coins 1500
scoreboard players set @s bw.h_scaffold 2
tag @s remove bw.off_scaffold
tellraw @s [{text:""},{text:"[암시장] ",color:"dark_purple"},{text:"Scaffold (Tower(vanilla), Keep Y)",color:"gold"},{text:" — 거래 끝. 들키지 마.",color:"gray"}]
playsound minecraft:entity.wandering_trader.yes master @s ~ ~ ~ 0.8 0.8
function bw:hack/apply
