execute unless score @s bw.coins matches 3500.. run return run function bw:gui/short/coins {need:3500}
scoreboard players remove @s bw.coins 3500
scoreboard players set @s bw.h_tpaura 1
tag @s remove bw.off_tpaura
tellraw @s [{text:""},{text:"[암시장] ",color:"dark_purple"},{text:"TP Aura",color:"gold"},{text:" — 거래 끝. 들키지 마.",color:"gray"}]
playsound minecraft:entity.wandering_trader.yes master @s ~ ~ ~ 0.8 0.8
function bw:hack/apply
