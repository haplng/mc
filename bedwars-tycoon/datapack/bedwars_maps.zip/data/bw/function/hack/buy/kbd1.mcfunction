execute unless score @s bw.coins matches 600.. run return run function bw:gui/short/coins {need:600}
scoreboard players remove @s bw.coins 600
scoreboard players set @s bw.h_kbd 2
tag @s remove bw.off_kbd
tellraw @s [{text:""},{text:"[암시장] ",color:"dark_purple"},{text:"Knockback Displace (void)",color:"gold"},{text:" — 거래 끝. 들키지 마.",color:"gray"}]
playsound minecraft:entity.wandering_trader.yes master @s ~ ~ ~ 0.8 0.8
function bw:hack/apply
