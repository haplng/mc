execute unless score @s bw.coins matches 900.. run return run function bw:gui/short/coins {need:900}
scoreboard players remove @s bw.coins 900
scoreboard players set @s bw.h_velocity2 1
tag @s remove bw.off_velocity2
tellraw @s [{text:""},{text:"[암시장] ",color:"dark_purple"},{text:"Velocity (0 100)",color:"gold"},{text:" — 거래 끝. 들키지 마.",color:"gray"}]
playsound minecraft:entity.wandering_trader.yes master @s ~ ~ ~ 0.8 0.8
function bw:hack/apply
