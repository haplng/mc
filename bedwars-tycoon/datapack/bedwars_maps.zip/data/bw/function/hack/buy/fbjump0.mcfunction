execute unless score @s bw.coins matches 2000.. run return run function bw:gui/short/coins {need:2000}
scoreboard players remove @s bw.coins 2000
scoreboard players set @s bw.h_fbjump 1
tag @s remove bw.off_fbjump
tellraw @s [{text:""},{text:"[암시장] ",color:"dark_purple"},{text:"FB Longjump",color:"gold"},{text:" — 거래 끝. 들키지 마.",color:"gray"}]
playsound minecraft:entity.wandering_trader.yes master @s ~ ~ ~ 0.8 0.8
function bw:hack/apply
