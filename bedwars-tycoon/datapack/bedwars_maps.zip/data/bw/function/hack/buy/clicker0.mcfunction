execute unless score @s bw.coins matches 350.. run return run function bw:gui/short/coins {need:350}
scoreboard players remove @s bw.coins 350
scoreboard players set @s bw.h_clicker 1
tag @s remove bw.off_clicker
tellraw @s [{text:""},{text:"[암시장] ",color:"dark_purple"},{text:"AutoClicker",color:"gold"},{text:" — 거래 끝. 들키지 마.",color:"gray"}]
playsound minecraft:entity.wandering_trader.yes master @s ~ ~ ~ 0.8 0.8
function bw:hack/apply
