execute unless score @s bw.coins matches 800.. run return run function bw:gui/short/coins {need:800}
scoreboard players remove @s bw.coins 800
scoreboard players set @s bw.h_stasis 1
tag @s remove bw.off_stasis
tellraw @s [{text:""},{text:"[암시장] ",color:"dark_purple"},{text:"Stasis",color:"gold"},{text:" — 거래 끝. 들키지 마.",color:"gray"}]
playsound minecraft:entity.wandering_trader.yes master @s ~ ~ ~ 0.8 0.8
function bw:hack/apply
