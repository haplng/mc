execute unless score @s bw.coins matches 300.. run return run function bw:gui/short/coins {need:300}
scoreboard players remove @s bw.coins 300
scoreboard players set @s bw.h_reach 2
tag @s remove bw.off_reach
tellraw @s [{text:""},{text:"[암시장] ",color:"dark_purple"},{text:"Reach (3.5)",color:"gold"},{text:" — 거래 끝. 들키지 마.",color:"gray"}]
playsound minecraft:entity.wandering_trader.yes master @s ~ ~ ~ 0.8 0.8
function bw:hack/apply
