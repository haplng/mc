scoreboard players operation @s bw.lh = #att bw
scoreboard players set @s bw.lht 200
scoreboard players set @s bw.ft 0
scoreboard players set @s bw.calm 0
execute unless score @s bw.st matches 3 run function bw:ai/engage
function bw:hack/displace
