scoreboard players set #dir bw 1
execute positioned 0.0 0.0 0.0 run tp @e[type=minecraft:marker,tag=bw.vec,limit=1] ^ ^0.72 ^1
data modify storage bw:tmp fl set from entity @e[type=minecraft:marker,tag=bw.vec,limit=1] Pos
execute store result storage bw:tmp fl[0] double 0.00055 run data get storage bw:tmp fl[0] 1000
execute store result storage bw:tmp fl[1] double 0.00055 run data get storage bw:tmp fl[1] 1000
execute store result storage bw:tmp fl[2] double 0.00055 run data get storage bw:tmp fl[2] 1000
data modify entity @s Motion set from storage bw:tmp fl
particle minecraft:sweep_attack ~ ~1 ~ 0 0 0 0 1
