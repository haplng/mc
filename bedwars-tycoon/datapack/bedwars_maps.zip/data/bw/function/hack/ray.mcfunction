execute unless block ~ ~ ~ #bw:open run return 0
execute positioned ~-0.95 ~-0.95 ~-0.95 as @e[type=minecraft:mannequin,tag=bw.bot,dx=0,dy=0,dz=0] positioned ~0.9 ~0.9 ~0.9 if entity @s[dx=0,dy=0,dz=0] run tag @s add bw.rayt
execute if entity @e[tag=bw.rayt] run return 1
scoreboard players add #rs bw 30
execute if score #rs bw < @s bw.hreach positioned ^ ^ ^0.3 run function bw:hack/ray
