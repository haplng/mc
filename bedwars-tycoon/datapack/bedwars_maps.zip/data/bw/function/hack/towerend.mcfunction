tag @s remove bw.lev
effect clear @s minecraft:levitation
