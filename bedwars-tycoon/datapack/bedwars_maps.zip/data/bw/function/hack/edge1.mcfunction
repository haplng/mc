execute if block ~0.5 ~-0.5 ~0 #bw:open run return run attribute @s minecraft:movement_speed modifier add bw:eagle -0.7 add_multiplied_total
execute if block ~-0.5 ~-0.5 ~0 #bw:open run return run attribute @s minecraft:movement_speed modifier add bw:eagle -0.7 add_multiplied_total
execute if block ~0 ~-0.5 ~0.5 #bw:open run return run attribute @s minecraft:movement_speed modifier add bw:eagle -0.7 add_multiplied_total
execute if block ~0 ~-0.5 ~-0.5 #bw:open run return run attribute @s minecraft:movement_speed modifier add bw:eagle -0.7 add_multiplied_total
