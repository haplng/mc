scoreboard players set @s bw.ecd 2
execute if entity @e[type=minecraft:marker,tag=bw.safe,distance=..1.2] positioned as @e[type=minecraft:marker,tag=bw.safe,limit=1] run tp @s ~ ~ ~
