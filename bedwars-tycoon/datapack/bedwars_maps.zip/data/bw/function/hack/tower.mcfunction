execute unless predicate bw:jump run return 0
execute if predicate bw:moving run return 0
execute unless items entity @s container.* #bw:scaf run return 0
execute if entity @s[scores={bw.h_tower=1}] run effect give @s minecraft:levitation 1 2 true
execute if entity @s[scores={bw.h_tower=2}] run effect give @s minecraft:levitation 1 5 true
tag @s add bw.lev
execute positioned ~ ~-1.01 ~ if block ~ ~ ~ #bw:open align xyz run function bw:hack/putblock
