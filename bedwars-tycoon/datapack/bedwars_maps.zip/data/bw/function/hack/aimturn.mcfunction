execute if entity @e[tag=bw.aimd] run return 0
rotate @s facing ~ ~ ~
tag @s add bw.aimd
