scoreboard players set @s bw.tpc 12
tag @e[tag=bw.rayt] remove bw.rayt
tag @e[type=minecraft:mannequin,tag=bw.bot,distance=..14,sort=nearest,limit=1] add bw.rayt
particle minecraft:portal ~ ~1 ~ 0.3 0.6 0.3 0.4 30
scoreboard players set #ok bw 0
execute at @e[tag=bw.rayt,limit=1] rotated as @e[tag=bw.rayt,limit=1] rotated ~ 0 positioned ^ ^ ^-1.6 if block ~ ~ ~ #bw:open if block ~ ~1 ~ #bw:open unless block ~ ~-1 ~ #bw:open store success score #ok bw run tp @s ~ ~ ~ facing entity @e[tag=bw.rayt,limit=1] eyes
execute if score #ok bw matches 0 at @e[tag=bw.rayt,limit=1] run tp @s ~ ~ ~
execute at @s run playsound minecraft:entity.enderman.teleport player @a ~ ~ ~ 0.7 1.3
execute at @s run particle minecraft:portal ~ ~1 ~ 0.3 0.6 0.3 0.4 30
function bw:hack/strike
