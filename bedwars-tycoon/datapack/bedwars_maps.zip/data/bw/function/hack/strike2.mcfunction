$damage @e[tag=bw.rayt,limit=1] $(d) minecraft:player_attack by @s
swing @s mainhand
scoreboard players operation #att bw = @s bw.team
tag @a remove bw.hitter
tag @s add bw.hitter
execute as @e[tag=bw.rayt,limit=1] at @s run function bw:hack/struck
tag @e[tag=bw.rayt] remove bw.rayt
