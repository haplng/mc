$execute positioned ~ $(y) ~ positioned ~ ~-0.5 ~ if block ~ ~ ~ #bw:open align xyz run function bw:hack/putblock
