scoreboard players set #ok bw 0
execute if score #ok bw matches 0 if score @s bw.team matches 0 store success score #ok bw run clear @s minecraft:red_wool 1
execute if score #ok bw matches 0 if score @s bw.team matches 1 store success score #ok bw run clear @s minecraft:blue_wool 1
execute if score #ok bw matches 0 if score @s bw.team matches 2 store success score #ok bw run clear @s minecraft:lime_wool 1
execute if score #ok bw matches 0 if score @s bw.team matches 3 store success score #ok bw run clear @s minecraft:yellow_wool 1
execute if score #ok bw matches 0 if score @s bw.team matches 4 store success score #ok bw run clear @s minecraft:cyan_wool 1
execute if score #ok bw matches 0 if score @s bw.team matches 5 store success score #ok bw run clear @s minecraft:white_wool 1
execute if score #ok bw matches 0 if score @s bw.team matches 6 store success score #ok bw run clear @s minecraft:pink_wool 1
execute if score #ok bw matches 0 if score @s bw.team matches 7 store success score #ok bw run clear @s minecraft:gray_wool 1
execute if score #ok bw matches 1 if score @s bw.team matches 0 run return run setblock ~ ~ ~ minecraft:red_wool
execute if score #ok bw matches 1 if score @s bw.team matches 1 run return run setblock ~ ~ ~ minecraft:blue_wool
execute if score #ok bw matches 1 if score @s bw.team matches 2 run return run setblock ~ ~ ~ minecraft:lime_wool
execute if score #ok bw matches 1 if score @s bw.team matches 3 run return run setblock ~ ~ ~ minecraft:yellow_wool
execute if score #ok bw matches 1 if score @s bw.team matches 4 run return run setblock ~ ~ ~ minecraft:cyan_wool
execute if score #ok bw matches 1 if score @s bw.team matches 5 run return run setblock ~ ~ ~ minecraft:white_wool
execute if score #ok bw matches 1 if score @s bw.team matches 6 run return run setblock ~ ~ ~ minecraft:pink_wool
execute if score #ok bw matches 1 if score @s bw.team matches 7 run return run setblock ~ ~ ~ minecraft:gray_wool
execute store success score #ok bw run clear @s minecraft:end_stone 1
execute if score #ok bw matches 1 run return run setblock ~ ~ ~ minecraft:end_stone
execute store success score #ok bw run clear @s minecraft:terracotta 1
execute if score #ok bw matches 1 run return run setblock ~ ~ ~ minecraft:terracotta
execute store success score #ok bw run clear @s minecraft:oak_planks 1
execute if score #ok bw matches 1 run return run setblock ~ ~ ~ minecraft:oak_planks
