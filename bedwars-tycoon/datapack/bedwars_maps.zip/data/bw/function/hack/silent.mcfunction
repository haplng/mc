$item modify entity @s weapon.mainhand {type:"minecraft:set_components",components:{"minecraft:attack_range":{max_reach:$(r),hitbox_margin:0.9}}}
