execute if predicate bw:ground run tp @e[type=minecraft:marker,tag=bw.safe2,limit=1] ~ ~ ~
execute if predicate bw:ground positioned ~ ~-0.5 ~ if block ~ ~ ~ #bw:open align xyz run return run function bw:hack/putblock
execute unless predicate bw:ground if predicate bw:jump unless predicate bw:moving positioned ~ ~-1.01 ~ if block ~ ~ ~ #bw:open align xyz run return run function bw:hack/putblock
execute unless predicate bw:ground if entity @s[scores={bw.h_scaffold=2}] if predicate bw:moving run function bw:hack/keepy
