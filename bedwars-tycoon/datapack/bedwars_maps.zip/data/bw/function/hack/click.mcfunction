scoreboard players set @s bw.acd 2
scoreboard players set #rs bw 0
tag @e[tag=bw.rayt] remove bw.rayt
execute anchored eyes positioned ^ ^ ^0.4 run function bw:hack/ray
execute if entity @e[tag=bw.rayt] run function bw:hack/strike
