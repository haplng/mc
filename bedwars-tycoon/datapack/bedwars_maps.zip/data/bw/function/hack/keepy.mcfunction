execute store result storage bw:tmp ky.y double 0.01 run data get entity @e[type=minecraft:marker,tag=bw.safe2,limit=1] Pos[1] 100
function bw:hack/keepy2 with storage bw:tmp ky
