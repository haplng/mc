scoreboard players add @s bw.h_velocity 0
scoreboard players add @s bw.h_reach 0
scoreboard players add @s bw.h_eagle 0
scoreboard players add @s bw.h_aim 0
scoreboard players add @s bw.h_clicker 0
scoreboard players add @s bw.h_block 0
scoreboard players add @s bw.h_kbd 0
scoreboard players add @s bw.h_antifb 0
scoreboard players add @s bw.h_velocity2 0
scoreboard players add @s bw.h_scaffold 0
scoreboard players add @s bw.h_lag 0
scoreboard players add @s bw.h_stasis 0
scoreboard players add @s bw.h_tower 0
scoreboard players add @s bw.h_nofall 0
scoreboard players add @s bw.h_fbjump 0
scoreboard players add @s bw.h_tpaura 0
attribute @s minecraft:entity_interaction_range modifier remove bw:reach
attribute @s minecraft:entity_interaction_range modifier remove bw:lag
attribute @s minecraft:knockback_resistance modifier remove bw:vel
attribute @s minecraft:fall_damage_multiplier modifier remove bw:nofall
execute if entity @s[scores={bw.h_reach=1},tag=!bw.off_reach] run attribute @s minecraft:entity_interaction_range modifier add bw:reach 0.1 add_value
execute if entity @s[scores={bw.h_reach=2},tag=!bw.off_reach] run attribute @s minecraft:entity_interaction_range modifier add bw:reach 0.5 add_value
execute if entity @s[scores={bw.h_reach=3},tag=!bw.off_reach] run attribute @s minecraft:entity_interaction_range modifier add bw:reach 1.0 add_value
execute if entity @s[scores={bw.h_lag=1},tag=!bw.off_lag] run attribute @s minecraft:entity_interaction_range modifier add bw:lag 0.56 add_value
execute if entity @s[scores={bw.h_lag=2},tag=!bw.off_lag] run attribute @s minecraft:entity_interaction_range modifier add bw:lag 1.12 add_value
execute if entity @s[scores={bw.h_velocity=1},tag=!bw.off_velocity] run attribute @s minecraft:knockback_resistance modifier add bw:vel 0.2 add_value
execute if entity @s[scores={bw.h_velocity=2},tag=!bw.off_velocity] run attribute @s minecraft:knockback_resistance modifier add bw:vel 0.45 add_value
execute if entity @s[scores={bw.h_velocity2=1..},tag=!bw.off_velocity2] run attribute @s minecraft:knockback_resistance modifier remove bw:vel
execute if entity @s[scores={bw.h_velocity2=1..},tag=!bw.off_velocity2] run attribute @s minecraft:knockback_resistance modifier add bw:vel 1.0 add_value
execute if entity @s[scores={bw.h_nofall=1..},tag=!bw.off_nofall] run attribute @s minecraft:fall_damage_multiplier modifier add bw:nofall -1 add_multiplied_total
scoreboard players set #r bw 300
execute if entity @s[scores={bw.h_reach=1},tag=!bw.off_reach] run scoreboard players add #r bw 10
execute if entity @s[scores={bw.h_reach=2},tag=!bw.off_reach] run scoreboard players add #r bw 50
execute if entity @s[scores={bw.h_reach=3},tag=!bw.off_reach] run scoreboard players add #r bw 100
execute if entity @s[scores={bw.h_lag=1},tag=!bw.off_lag] run scoreboard players add #r bw 56
execute if entity @s[scores={bw.h_lag=2},tag=!bw.off_lag] run scoreboard players add #r bw 112
execute store result storage bw:tmp aim.r float 0.01 run scoreboard players get #r bw
execute store result score @s bw.hreach run scoreboard players get #r bw
scoreboard players add @s bw.stc 0
scoreboard players add @s bw.acd 0
scoreboard players add @s bw.tpc 0
scoreboard players add @s bw.ecd 0
