execute unless entity @a[tag=bw.hitter,scores={bw.h_kbd=1..},tag=!bw.off_kbd] run return 0
scoreboard players set #dir bw 0
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 0 0 if block ^ ^-1 ^1.5 #bw:open if block ^ ^-2 ^1.5 #bw:open if block ^ ^-4 ^1.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 45 0 if block ^ ^-1 ^1.5 #bw:open if block ^ ^-2 ^1.5 #bw:open if block ^ ^-4 ^1.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 90 0 if block ^ ^-1 ^1.5 #bw:open if block ^ ^-2 ^1.5 #bw:open if block ^ ^-4 ^1.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 135 0 if block ^ ^-1 ^1.5 #bw:open if block ^ ^-2 ^1.5 #bw:open if block ^ ^-4 ^1.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 180 0 if block ^ ^-1 ^1.5 #bw:open if block ^ ^-2 ^1.5 #bw:open if block ^ ^-4 ^1.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 225 0 if block ^ ^-1 ^1.5 #bw:open if block ^ ^-2 ^1.5 #bw:open if block ^ ^-4 ^1.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 270 0 if block ^ ^-1 ^1.5 #bw:open if block ^ ^-2 ^1.5 #bw:open if block ^ ^-4 ^1.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 315 0 if block ^ ^-1 ^1.5 #bw:open if block ^ ^-2 ^1.5 #bw:open if block ^ ^-4 ^1.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 0 0 if block ^ ^-1 ^2.5 #bw:open if block ^ ^-2 ^2.5 #bw:open if block ^ ^-4 ^2.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 45 0 if block ^ ^-1 ^2.5 #bw:open if block ^ ^-2 ^2.5 #bw:open if block ^ ^-4 ^2.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 90 0 if block ^ ^-1 ^2.5 #bw:open if block ^ ^-2 ^2.5 #bw:open if block ^ ^-4 ^2.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 135 0 if block ^ ^-1 ^2.5 #bw:open if block ^ ^-2 ^2.5 #bw:open if block ^ ^-4 ^2.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 180 0 if block ^ ^-1 ^2.5 #bw:open if block ^ ^-2 ^2.5 #bw:open if block ^ ^-4 ^2.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 225 0 if block ^ ^-1 ^2.5 #bw:open if block ^ ^-2 ^2.5 #bw:open if block ^ ^-4 ^2.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 270 0 if block ^ ^-1 ^2.5 #bw:open if block ^ ^-2 ^2.5 #bw:open if block ^ ^-4 ^2.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 315 0 if block ^ ^-1 ^2.5 #bw:open if block ^ ^-2 ^2.5 #bw:open if block ^ ^-4 ^2.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 0 0 if block ^ ^-1 ^3.5 #bw:open if block ^ ^-2 ^3.5 #bw:open if block ^ ^-4 ^3.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 45 0 if block ^ ^-1 ^3.5 #bw:open if block ^ ^-2 ^3.5 #bw:open if block ^ ^-4 ^3.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 90 0 if block ^ ^-1 ^3.5 #bw:open if block ^ ^-2 ^3.5 #bw:open if block ^ ^-4 ^3.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 135 0 if block ^ ^-1 ^3.5 #bw:open if block ^ ^-2 ^3.5 #bw:open if block ^ ^-4 ^3.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 180 0 if block ^ ^-1 ^3.5 #bw:open if block ^ ^-2 ^3.5 #bw:open if block ^ ^-4 ^3.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 225 0 if block ^ ^-1 ^3.5 #bw:open if block ^ ^-2 ^3.5 #bw:open if block ^ ^-4 ^3.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 270 0 if block ^ ^-1 ^3.5 #bw:open if block ^ ^-2 ^3.5 #bw:open if block ^ ^-4 ^3.5 #bw:open run function bw:hack/fling
execute if entity @a[tag=bw.hitter,scores={bw.h_kbd=2}] if score #dir bw matches 0 rotated 315 0 if block ^ ^-1 ^3.5 #bw:open if block ^ ^-2 ^3.5 #bw:open if block ^ ^-4 ^3.5 #bw:open run function bw:hack/fling
execute if score #dir bw matches 0 store result score #rn bw run random value 0..1
execute if score #dir bw matches 0 if score #rn bw matches 0 facing entity @a[tag=bw.hitter,limit=1] feet rotated ~90 0 run function bw:hack/fling
execute if score #dir bw matches 0 facing entity @a[tag=bw.hitter,limit=1] feet rotated ~-90 0 run function bw:hack/fling
