attribute @s minecraft:movement_speed modifier remove bw:eagle
execute unless predicate bw:ground run return 0
execute unless block ~ ~-0.5 ~ #bw:open run tp @e[type=minecraft:marker,tag=bw.safe,limit=1] ~ ~ ~
execute if block ~ ~-0.5 ~ #bw:open if entity @s[scores={bw.h_eagle=2}] run function bw:hack/eagleback
execute if block ~ ~-0.5 ~ #bw:open if entity @s[scores={bw.h_eagle=1}] if score @s bw.ecd matches 0 run function bw:hack/eagleback
execute if entity @s[scores={bw.h_eagle=1}] unless block ~ ~-0.5 ~ #bw:open run function bw:hack/edge1
execute if entity @s[scores={bw.h_eagle=2}] unless block ~ ~-0.5 ~ #bw:open run function bw:hack/edge2
