tp @s 3483.5 65 34.5 112.4 10
title @s title {"text": "정글 신전", "color": "gold", "bold": true}
title @s subtitle {"text": "207x207 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
