tp @s 3503.5 65 43.5 112.8 10
title @s title {"text": "정글 신전", "color": "gold", "bold": true}
title @s subtitle {"text": "247x247 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
