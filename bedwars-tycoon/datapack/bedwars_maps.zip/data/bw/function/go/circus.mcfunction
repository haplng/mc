tp @s 1473.5 65.0 -31.5 66.8 10
title @s title {"text": "서커스", "color": "gold", "bold": true}
title @s subtitle {"text": "177x177 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
