tp @s 1483.5 65.0 -35.5 67.0 10
title @s title {"text": "서커스", "color": "gold", "bold": true}
title @s subtitle {"text": "197x197 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
