tp @s 3100.5 65 41.5 112.4 10
title @s title {"text": "네더 요새", "color": "gold", "bold": true}
title @s subtitle {"text": "239x239 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
