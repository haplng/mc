tp @s 3079.5 65 33.5 112.8 10
title @s title {"text": "네더 요새", "color": "gold", "bold": true}
title @s subtitle {"text": "197x197 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
