tp @s 678.5 65 32.5 112.5 10
title @s title {"text": "벚꽃 정원", "color": "gold", "bold": true}
title @s subtitle {"text": "189x189 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
