tp @s 657.5 65 24.5 113.1 10
title @s title {"text": "벚꽃 정원", "color": "gold", "bold": true}
title @s subtitle {"text": "147x147 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
