tp @s 1889.5 65 37.5 112.7 10
title @s title {"text": "버섯 숲", "color": "gold", "bold": true}
title @s subtitle {"text": "217x217 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
