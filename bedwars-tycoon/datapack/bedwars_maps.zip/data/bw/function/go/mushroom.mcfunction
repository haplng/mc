tp @s 1868.5 65 28.5 112.6 10
title @s title {"text": "버섯 숲", "color": "gold", "bold": true}
title @s subtitle {"text": "175x175 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
