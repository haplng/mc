tp @s 3499.5 65.0 -37.5 69.3 10
title @s title {"text": "풍차", "color": "gold", "bold": true}
title @s subtitle {"text": "242x243 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
