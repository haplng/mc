tp @s 1893.5 65.0 -31.5 71.4 10
title @s title {"text": "기차", "color": "gold", "bold": true}
title @s subtitle {"text": "207x207 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
