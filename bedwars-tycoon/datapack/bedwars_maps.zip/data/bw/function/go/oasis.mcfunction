tp @s 1081.5 65 34.5 112.9 10
title @s title {"text": "사막 오아시스", "color": "gold", "bold": true}
title @s subtitle {"text": "195x195 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
