tp @s 1061.5 65 25.5 112.5 10
title @s title {"text": "사막 오아시스", "color": "gold", "bold": true}
title @s subtitle {"text": "153x153 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
