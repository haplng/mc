tp @s 3907.5 65 44.5 112.5 10
title @s title {"text": "천공의 성", "color": "gold", "bold": true}
title @s subtitle {"text": "255x255 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
