tp @s 3887.5 65 36.5 112.6 10
title @s title {"text": "천공의 성", "color": "gold", "bold": true}
title @s subtitle {"text": "217x217 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
