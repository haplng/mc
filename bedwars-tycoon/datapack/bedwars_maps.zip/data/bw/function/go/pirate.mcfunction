tp @s 4318.5 65.0 -28.5 76.5 10
title @s title {"text": "해적", "color": "gold", "bold": true}
title @s subtitle {"text": "267x267 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
