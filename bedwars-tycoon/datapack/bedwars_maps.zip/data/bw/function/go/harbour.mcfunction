tp @s 2272.5 65 30.5 112.8 10
title @s title {"text": "등대 항구", "color": "gold", "bold": true}
title @s subtitle {"text": "183x183 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
