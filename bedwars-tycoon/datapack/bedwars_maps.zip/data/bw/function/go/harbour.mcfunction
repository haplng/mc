tp @s 2292.5 65 38.5 112.6 10
title @s title {"text": "등대 항구", "color": "gold", "bold": true}
title @s subtitle {"text": "223x223 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
