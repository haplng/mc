tp @s 0.5 65 9.5 180 0
scoreboard players set @s lobby 0
title @s actionbar {"text": "로비", "color": "gold"}
