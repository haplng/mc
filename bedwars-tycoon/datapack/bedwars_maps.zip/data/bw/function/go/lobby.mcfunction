scoreboard players set @s lobby 0
execute if score #state bw matches 1.. if entity @s[tag=bw.play] run return run function bw:game/giveup
tp @s 0.5 65.0 22.5 180 0
title @s actionbar {"text": "로비", "color": "gold"}
