tp @s 656.5 65.0 -22.5 68.3 10
title @s title {"text": "티타임", "color": "gold", "bold": true}
title @s subtitle {"text": "137x137 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
