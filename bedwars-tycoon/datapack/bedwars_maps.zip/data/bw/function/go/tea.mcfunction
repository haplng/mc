tp @s 675.5 65.0 -30.5 68.0 10
title @s title {"text": "티타임", "color": "gold", "bold": true}
title @s subtitle {"text": "175x175 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
