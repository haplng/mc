tp @s 1083.5 65.0 -26.5 72.4 10
title @s title {"text": "체스", "color": "gold", "bold": true}
title @s subtitle {"text": "187x187 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
