tp @s 1068.5 65.0 -21.5 72.6 10
title @s title {"text": "체스", "color": "gold", "bold": true}
title @s subtitle {"text": "157x157 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
