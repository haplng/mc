tp @s 4291.5 65 38.5 112.8 10
title @s title {"text": "엔드 성채", "color": "gold", "bold": true}
title @s subtitle {"text": "225x225 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
