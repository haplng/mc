tp @s 4311.5 65 46.5 112.6 10
title @s title {"text": "엔드 성채", "color": "gold", "bold": true}
title @s subtitle {"text": "265x265 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
