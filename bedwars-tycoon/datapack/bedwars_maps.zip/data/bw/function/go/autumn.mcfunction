tp @s 2676.5 65 31.5 112.4 10
title @s title {"text": "가을 농장", "color": "gold", "bold": true}
title @s subtitle {"text": "193x193 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
