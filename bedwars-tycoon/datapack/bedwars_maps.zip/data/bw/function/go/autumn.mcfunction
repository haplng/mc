tp @s 2696.5 65 40.5 112.8 10
title @s title {"text": "가을 농장", "color": "gold", "bold": true}
title @s subtitle {"text": "233x233 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
