tp @s 2316.5 65.0 -45.5 68.7 10
title @s title {"text": "태양계", "color": "gold", "bold": true}
title @s subtitle {"text": "267x267 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
