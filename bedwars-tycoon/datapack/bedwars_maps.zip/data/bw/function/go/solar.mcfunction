tp @s 3910.5 65.0 -43.5 68.5 10
title @s title {"text": "태양계", "color": "gold", "bold": true}
title @s subtitle {"text": "255x255 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
