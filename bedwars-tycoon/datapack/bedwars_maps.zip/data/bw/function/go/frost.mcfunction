tp @s 1485.5 65 35.5 112.5 10
title @s title {"text": "얼음 마을", "color": "gold", "bold": true}
title @s subtitle {"text": "211x211 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
