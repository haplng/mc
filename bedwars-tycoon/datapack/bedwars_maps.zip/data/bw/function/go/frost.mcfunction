tp @s 1465.5 65 27.5 112.8 10
title @s title {"text": "얼음 마을", "color": "gold", "bold": true}
title @s subtitle {"text": "169x169 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
