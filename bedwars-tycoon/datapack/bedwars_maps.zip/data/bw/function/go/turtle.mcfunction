tp @s 3103.5 65.0 -37.5 70.1 10
title @s title {"text": "거북", "color": "gold", "bold": true}
title @s subtitle {"text": "233x233 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
