tp @s 2108.5 65.0 -62.5 -55.7 10
title @s title {"text": "축구장", "color": "gold", "bold": true}
title @s subtitle {"text": "211x163 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
