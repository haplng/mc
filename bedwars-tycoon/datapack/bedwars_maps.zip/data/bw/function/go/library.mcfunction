tp @s 1903.5 65.0 -27.5 75.1 10
title @s title {"text": "도서관", "color": "gold", "bold": true}
title @s subtitle {"text": "223x223 · 8팀 · 로비로: /trigger lobby", "color": "gray"}
