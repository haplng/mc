advancement revoke @s only bw:npc/unlock
dialog show @s {type:"minecraft:notice",title:{text:"업그레이드",color:"white",bold:true},pause:false,body:[{type:"minecraft:plain_message",width:300,contents:[{text:""},{text:"게임에서 모은 코인으로\n상점 물건을 하나씩 해금하는 곳이야.\n\n",color:"white"},{text:"코인 시스템이 들어오면 열려!",color:"yellow"}]}],action:{label:{text:"확인"},width:150}}
