advancement revoke @s only bw:npc/shop
scoreboard players set #team bw 5
execute as @e[type=minecraft:villager,tag=bw.npc.shop,distance=..10,sort=nearest,limit=1] run function bw:shop/whose
scoreboard players operation @s bw.team = #team bw
scoreboard players set @s bw.page 1
data modify storage bw:shop a.msg set value {text:"물건을 누르면 바로 구매돼.",color:"gray"}
function bw:shop/refresh
