advancement revoke @s only bw:npc/team
dialog show @s {type:"minecraft:notice",title:{text:"팀 업그레이드",color:"white",bold:true},pause:false,body:[{type:"minecraft:plain_message",width:300,contents:[{text:""},{text:"팀 전체가 강해지는 업그레이드를 파는 곳이야.\n\n",color:"white"},{text:"아직 준비 중이야. 곧 열려!",color:"yellow"}]}],action:{label:{text:"확인"},width:150}}
