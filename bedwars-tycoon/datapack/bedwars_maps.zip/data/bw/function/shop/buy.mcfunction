scoreboard players operation #id bw = @s bw.buy
scoreboard players set @s bw.buy 0
execute unless entity @e[type=minecraft:villager,tag=bw.npc.shop,distance=..10] run return run function bw:shop/far
execute if score #id bw matches 1 run return run function bw:shop/buy/1
execute if score #id bw matches 2 run return run function bw:shop/buy/2
execute if score #id bw matches 3 run return run function bw:shop/buy/3
execute if score #id bw matches 4 run return run function bw:shop/buy/4
execute if score #id bw matches 5 run return run function bw:shop/buy/5
execute if score #id bw matches 6 run return run function bw:shop/buy/6
execute if score #id bw matches 7 run return run function bw:shop/buy/7
execute if score #id bw matches 8 run return run function bw:shop/buy/8
execute if score #id bw matches 9 run return run function bw:shop/buy/9
execute if score #id bw matches 10 run return run function bw:shop/buy/10
execute if score #id bw matches 11 run return run function bw:shop/buy/11
execute if score #id bw matches 12 run return run function bw:shop/buy/12
execute if score #id bw matches 13 run return run function bw:shop/buy/13
execute if score #id bw matches 14 run return run function bw:shop/buy/14
execute if score #id bw matches 15 run return run function bw:shop/buy/15
execute if score #id bw matches 16 run return run function bw:shop/buy/16
execute if score #id bw matches 17 run return run function bw:shop/buy/17
execute if score #id bw matches 18 run return run function bw:shop/buy/18
execute if score #id bw matches 19 run return run function bw:shop/buy/19
execute if score #id bw matches 20 run return run function bw:shop/buy/20
execute if score #id bw matches 21 run return run function bw:shop/buy/21
execute if score #id bw matches 22 run return run function bw:shop/buy/22
execute if score #id bw matches 23 run return run function bw:shop/buy/23
execute if score #id bw matches 24 run return run function bw:shop/buy/24
execute if score #id bw matches 25 run return run function bw:shop/buy/25
execute if score #id bw matches 26 run return run function bw:shop/buy/26
execute if score #id bw matches 27 run return run function bw:shop/buy/27
execute if score #id bw matches 28 run return run function bw:shop/buy/28
execute if score #id bw matches 29 run return run function bw:shop/buy/29
execute if score #id bw matches 30 run return run function bw:shop/buy/30
execute if score #id bw matches 31 run return run function bw:shop/buy/31
execute if score #id bw matches 32 run return run function bw:shop/buy/32
execute if score #id bw matches 33 run return run function bw:shop/buy/33
execute if score #id bw matches 34 run return run function bw:shop/buy/34
execute if score #id bw matches 35 run return run function bw:shop/buy/35
