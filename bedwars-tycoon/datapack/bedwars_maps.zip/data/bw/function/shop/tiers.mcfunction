scoreboard players set #pk bw 0
execute if items entity @s container.* minecraft:wooden_pickaxe run scoreboard players set #pk bw 1
execute if items entity @s weapon.offhand minecraft:wooden_pickaxe run scoreboard players set #pk bw 1
execute if items entity @s container.* minecraft:iron_pickaxe run scoreboard players set #pk bw 2
execute if items entity @s weapon.offhand minecraft:iron_pickaxe run scoreboard players set #pk bw 2
execute if items entity @s container.* minecraft:golden_pickaxe run scoreboard players set #pk bw 3
execute if items entity @s weapon.offhand minecraft:golden_pickaxe run scoreboard players set #pk bw 3
execute if items entity @s container.* minecraft:diamond_pickaxe run scoreboard players set #pk bw 4
execute if items entity @s weapon.offhand minecraft:diamond_pickaxe run scoreboard players set #pk bw 4
scoreboard players set #ax bw 0
execute if items entity @s container.* minecraft:wooden_axe run scoreboard players set #ax bw 1
execute if items entity @s weapon.offhand minecraft:wooden_axe run scoreboard players set #ax bw 1
execute if items entity @s container.* minecraft:stone_axe run scoreboard players set #ax bw 2
execute if items entity @s weapon.offhand minecraft:stone_axe run scoreboard players set #ax bw 2
execute if items entity @s container.* minecraft:iron_axe run scoreboard players set #ax bw 3
execute if items entity @s weapon.offhand minecraft:iron_axe run scoreboard players set #ax bw 3
execute if items entity @s container.* minecraft:diamond_axe run scoreboard players set #ax bw 4
execute if items entity @s weapon.offhand minecraft:diamond_axe run scoreboard players set #ax bw 4
