data modify storage bw:shop a merge value {c12:"red",l12:{text:"철이 부족해!",color:"red"}}
execute if score #iron bw matches 40.. run data modify storage bw:shop a merge value {c12:"green",l12:{text:"클릭해서 구매!",color:"yellow"}}
execute if items entity @s armor.legs #bw:armor1 run data modify storage bw:shop a merge value {c12:"gray",l12:{text:"이미 가지고 있어.",color:"aqua"}}
data modify storage bw:shop a merge value {c13:"red",l13:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 12.. run data modify storage bw:shop a merge value {c13:"green",l13:{text:"클릭해서 구매!",color:"yellow"}}
execute if items entity @s armor.legs #bw:armor2 run data modify storage bw:shop a merge value {c13:"gray",l13:{text:"이미 가지고 있어.",color:"aqua"}}
data modify storage bw:shop a merge value {c14:"red",l14:{text:"에메랄드가 부족해!",color:"red"}}
execute if score #em bw matches 6.. run data modify storage bw:shop a merge value {c14:"green",l14:{text:"클릭해서 구매!",color:"yellow"}}
execute if items entity @s armor.legs #bw:armor3 run data modify storage bw:shop a merge value {c14:"gray",l14:{text:"이미 가지고 있어.",color:"aqua"}}
function bw:shop/show/4 with storage bw:shop a
