data modify storage bw:shop a merge value {c18:"red",l18:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 2.. run data modify storage bw:shop a merge value {c18:"green",l18:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c19:"red",l19:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 12.. run data modify storage bw:shop a merge value {c19:"green",l19:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c20:"red",l20:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 24.. run data modify storage bw:shop a merge value {c20:"green",l20:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c21:"red",l21:{text:"에메랄드가 부족해!",color:"red"}}
execute if score #em bw matches 6.. run data modify storage bw:shop a merge value {c21:"green",l21:{text:"클릭해서 구매!",color:"yellow"}}
function bw:shop/show/6 with storage bw:shop a
