data modify storage bw:shop a merge value {c25:"red",l25:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 3.. run data modify storage bw:shop a merge value {c25:"green",l25:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c26:"red",l26:{text:"철이 부족해!",color:"red"}}
execute if score #iron bw matches 30.. run data modify storage bw:shop a merge value {c26:"green",l26:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c27:"red",l27:{text:"철이 부족해!",color:"red"}}
execute if score #iron bw matches 120.. run data modify storage bw:shop a merge value {c27:"green",l27:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c28:"red",l28:{text:"철이 부족해!",color:"red"}}
execute if score #iron bw matches 40.. run data modify storage bw:shop a merge value {c28:"green",l28:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c29:"red",l29:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 4.. run data modify storage bw:shop a merge value {c29:"green",l29:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c30:"red",l30:{text:"에메랄드가 부족해!",color:"red"}}
execute if score #em bw matches 4.. run data modify storage bw:shop a merge value {c30:"green",l30:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c31:"red",l31:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 3.. run data modify storage bw:shop a merge value {c31:"green",l31:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c32:"red",l32:{text:"에메랄드가 부족해!",color:"red"}}
execute if score #em bw matches 1.. run data modify storage bw:shop a merge value {c32:"green",l32:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c33:"red",l33:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 4.. run data modify storage bw:shop a merge value {c33:"green",l33:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c34:"red",l34:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 3.. run data modify storage bw:shop a merge value {c34:"green",l34:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c35:"red",l35:{text:"철이 부족해!",color:"red"}}
execute if score #iron bw matches 24.. run data modify storage bw:shop a merge value {c35:"green",l35:{text:"클릭해서 구매!",color:"yellow"}}
function bw:shop/show/8 with storage bw:shop a
