data modify storage bw:shop a merge value {c22:"red",l22:{text:"에메랄드가 부족해!",color:"red"}}
execute if score #em bw matches 1.. run data modify storage bw:shop a merge value {c22:"green",l22:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c23:"red",l23:{text:"에메랄드가 부족해!",color:"red"}}
execute if score #em bw matches 1.. run data modify storage bw:shop a merge value {c23:"green",l23:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c24:"red",l24:{text:"에메랄드가 부족해!",color:"red"}}
execute if score #em bw matches 2.. run data modify storage bw:shop a merge value {c24:"green",l24:{text:"클릭해서 구매!",color:"yellow"}}
function bw:shop/show/7 with storage bw:shop a
