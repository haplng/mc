data modify storage bw:shop a merge value {c1:"red",l1:{text:"철이 부족해!",color:"red"}}
execute if score #iron bw matches 4.. run data modify storage bw:shop a merge value {c1:"green",l1:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c8:"red",l8:{text:"철이 부족해!",color:"red"}}
execute if score #iron bw matches 10.. run data modify storage bw:shop a merge value {c8:"green",l8:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c12:"red",l12:{text:"철이 부족해!",color:"red"}}
execute if score #iron bw matches 40.. run data modify storage bw:shop a merge value {c12:"green",l12:{text:"클릭해서 구매!",color:"yellow"}}
execute if items entity @s armor.legs #bw:armor1 run data modify storage bw:shop a merge value {c12:"gray",l12:{text:"이미 가지고 있어.",color:"aqua"}}
execute if score #pk bw matches 0 run data modify storage bw:shop a merge value {n16:"나무 곡괭이",m16:"나무 곡괭이",g16:"효율 I",s16:"wooden_pickaxe",y16:{text:"",extra:[{text:"가격: ",color:"gray"},{text:"10 철",color:"white"},{text:"   (1/4 단계)",color:"dark_gray"}]},c16:"red",l16:{text:"철이 부족해!",color:"red"},x16:{text:"",extra:[{type:"object",atlas:"minecraft:items",sprite:"minecraft:item/iron_ingot",color:"white",shadow_color:0},{text:"10",color:"red"}]}}
execute if score #pk bw matches 0 if score #iron bw matches 10.. run data modify storage bw:shop a merge value {c16:"green",l16:{text:"클릭해서 구매!",color:"yellow"},x16:{text:"",extra:[{type:"object",atlas:"minecraft:items",sprite:"minecraft:item/iron_ingot",color:"white",shadow_color:0},{text:"10",color:"green"}]}}
execute if score #pk bw matches 1 run data modify storage bw:shop a merge value {n16:"철 곡괭이",m16:"철 곡괭이",g16:"효율 II",s16:"iron_pickaxe",y16:{text:"",extra:[{text:"가격: ",color:"gray"},{text:"10 철",color:"white"},{text:"   (2/4 단계)",color:"dark_gray"}]},c16:"red",l16:{text:"철이 부족해!",color:"red"},x16:{text:"",extra:[{type:"object",atlas:"minecraft:items",sprite:"minecraft:item/iron_ingot",color:"white",shadow_color:0},{text:"10",color:"red"}]}}
execute if score #pk bw matches 1 if score #iron bw matches 10.. run data modify storage bw:shop a merge value {c16:"green",l16:{text:"클릭해서 구매!",color:"yellow"},x16:{text:"",extra:[{type:"object",atlas:"minecraft:items",sprite:"minecraft:item/iron_ingot",color:"white",shadow_color:0},{text:"10",color:"green"}]}}
execute if score #pk bw matches 2 run data modify storage bw:shop a merge value {n16:"금 곡괭이",m16:"금 곡괭이",g16:"효율 III, 날카로움 II",s16:"golden_pickaxe",y16:{text:"",extra:[{text:"가격: ",color:"gray"},{text:"3 금",color:"gold"},{text:"   (3/4 단계)",color:"dark_gray"}]},c16:"red",l16:{text:"금이 부족해!",color:"red"},x16:{text:"",extra:[{type:"object",atlas:"minecraft:items",sprite:"minecraft:item/gold_ingot",color:"white",shadow_color:0},{text:"3",color:"red"}]}}
execute if score #pk bw matches 2 if score #gold bw matches 3.. run data modify storage bw:shop a merge value {c16:"green",l16:{text:"클릭해서 구매!",color:"yellow"},x16:{text:"",extra:[{type:"object",atlas:"minecraft:items",sprite:"minecraft:item/gold_ingot",color:"white",shadow_color:0},{text:"3",color:"green"}]}}
execute if score #pk bw matches 3 run data modify storage bw:shop a merge value {n16:"다이아 곡괭이",m16:"다이아몬드 곡괭이",g16:"효율 III",s16:"diamond_pickaxe",y16:{text:"",extra:[{text:"가격: ",color:"gray"},{text:"6 금",color:"gold"},{text:"   (4/4 단계)",color:"dark_gray"}]},c16:"red",l16:{text:"금이 부족해!",color:"red"},x16:{text:"",extra:[{type:"object",atlas:"minecraft:items",sprite:"minecraft:item/gold_ingot",color:"white",shadow_color:0},{text:"6",color:"red"}]}}
execute if score #pk bw matches 3 if score #gold bw matches 6.. run data modify storage bw:shop a merge value {c16:"green",l16:{text:"클릭해서 구매!",color:"yellow"},x16:{text:"",extra:[{type:"object",atlas:"minecraft:items",sprite:"minecraft:item/gold_ingot",color:"white",shadow_color:0},{text:"6",color:"green"}]}}
execute if score #pk bw matches 4 run data modify storage bw:shop a merge value {n16:"다이아 곡괭이",m16:"다이아몬드 곡괭이",g16:"효율 III",s16:"diamond_pickaxe",c16:"gray",x16:{text:"",extra:[{text:"최고",color:"aqua"}]},y16:{text:"",extra:[{text:"더 올릴 단계가 없어.",color:"gray"}]},l16:{text:"이미 최고 단계야!",color:"aqua"}}
data modify storage bw:shop a merge value {c19:"red",l19:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 12.. run data modify storage bw:shop a merge value {c19:"green",l19:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c22:"red",l22:{text:"에메랄드가 부족해!",color:"red"}}
execute if score #em bw matches 1.. run data modify storage bw:shop a merge value {c22:"green",l22:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c29:"red",l29:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 4.. run data modify storage bw:shop a merge value {c29:"green",l29:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c6:"red",l6:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 4.. run data modify storage bw:shop a merge value {c6:"green",l6:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c9:"red",l9:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 7.. run data modify storage bw:shop a merge value {c9:"green",l9:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c13:"red",l13:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 12.. run data modify storage bw:shop a merge value {c13:"green",l13:{text:"클릭해서 구매!",color:"yellow"}}
execute if items entity @s armor.legs #bw:armor2 run data modify storage bw:shop a merge value {c13:"gray",l13:{text:"이미 가지고 있어.",color:"aqua"}}
data modify storage bw:shop a merge value {c15:"red",l15:{text:"철이 부족해!",color:"red"}}
execute if score #iron bw matches 20.. run data modify storage bw:shop a merge value {c15:"green",l15:{text:"클릭해서 구매!",color:"yellow"}}
execute if items entity @s container.* minecraft:shears run data modify storage bw:shop a merge value {c15:"gray",l15:{text:"이미 가지고 있어.",color:"aqua"}}
execute if items entity @s weapon.offhand minecraft:shears run data modify storage bw:shop a merge value {c15:"gray",l15:{text:"이미 가지고 있어.",color:"aqua"}}
data modify storage bw:shop a merge value {c18:"red",l18:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 2.. run data modify storage bw:shop a merge value {c18:"green",l18:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c23:"red",l23:{text:"에메랄드가 부족해!",color:"red"}}
execute if score #em bw matches 1.. run data modify storage bw:shop a merge value {c23:"green",l23:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c31:"red",l31:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 3.. run data modify storage bw:shop a merge value {c31:"green",l31:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c4:"red",l4:{text:"철이 부족해!",color:"red"}}
execute if score #iron bw matches 24.. run data modify storage bw:shop a merge value {c4:"green",l4:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c10:"red",l10:{text:"에메랄드가 부족해!",color:"red"}}
execute if score #em bw matches 4.. run data modify storage bw:shop a merge value {c10:"green",l10:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c14:"red",l14:{text:"에메랄드가 부족해!",color:"red"}}
execute if score #em bw matches 6.. run data modify storage bw:shop a merge value {c14:"green",l14:{text:"클릭해서 구매!",color:"yellow"}}
execute if items entity @s armor.legs #bw:armor3 run data modify storage bw:shop a merge value {c14:"gray",l14:{text:"이미 가지고 있어.",color:"aqua"}}
data modify storage bw:shop a merge value {c25:"red",l25:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 3.. run data modify storage bw:shop a merge value {c25:"green",l25:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c28:"red",l28:{text:"철이 부족해!",color:"red"}}
execute if score #iron bw matches 40.. run data modify storage bw:shop a merge value {c28:"green",l28:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c30:"red",l30:{text:"에메랄드가 부족해!",color:"red"}}
execute if score #em bw matches 4.. run data modify storage bw:shop a merge value {c30:"green",l30:{text:"클릭해서 구매!",color:"yellow"}}
function bw:shop/show/1 with storage bw:shop a
