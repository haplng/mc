data modify storage bw:shop a merge value {c1:"red",l1:{text:"철이 부족해!",color:"red"}}
execute if score #iron bw matches 4.. run data modify storage bw:shop a merge value {c1:"green",l1:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c2:"red",l2:{text:"철이 부족해!",color:"red"}}
execute if score #iron bw matches 12.. run data modify storage bw:shop a merge value {c2:"green",l2:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c3:"red",l3:{text:"철이 부족해!",color:"red"}}
execute if score #iron bw matches 12.. run data modify storage bw:shop a merge value {c3:"green",l3:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c4:"red",l4:{text:"철이 부족해!",color:"red"}}
execute if score #iron bw matches 24.. run data modify storage bw:shop a merge value {c4:"green",l4:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c5:"red",l5:{text:"철이 부족해!",color:"red"}}
execute if score #iron bw matches 4.. run data modify storage bw:shop a merge value {c5:"green",l5:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c6:"red",l6:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 4.. run data modify storage bw:shop a merge value {c6:"green",l6:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c7:"red",l7:{text:"에메랄드가 부족해!",color:"red"}}
execute if score #em bw matches 4.. run data modify storage bw:shop a merge value {c7:"green",l7:{text:"클릭해서 구매!",color:"yellow"}}
function bw:shop/show/2 with storage bw:shop a
