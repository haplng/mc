data modify storage bw:shop a merge value {c8:"red",l8:{text:"철이 부족해!",color:"red"}}
execute if score #iron bw matches 10.. run data modify storage bw:shop a merge value {c8:"green",l8:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c9:"red",l9:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 7.. run data modify storage bw:shop a merge value {c9:"green",l9:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c10:"red",l10:{text:"에메랄드가 부족해!",color:"red"}}
execute if score #em bw matches 4.. run data modify storage bw:shop a merge value {c10:"green",l10:{text:"클릭해서 구매!",color:"yellow"}}
data modify storage bw:shop a merge value {c11:"red",l11:{text:"금이 부족해!",color:"red"}}
execute if score #gold bw matches 5.. run data modify storage bw:shop a merge value {c11:"green",l11:{text:"클릭해서 구매!",color:"yellow"}}
function bw:shop/show/3 with storage bw:shop a
