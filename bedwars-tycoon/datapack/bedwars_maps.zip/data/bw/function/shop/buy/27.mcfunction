execute store result score #have bw run clear @s minecraft:iron_ingot 0
scoreboard players set #need bw 120
scoreboard players operation #need bw -= #have bw
execute if score #need bw matches 1.. run return run function bw:shop/fail/iron
clear @s minecraft:iron_ingot 120
give @s minecraft:iron_golem_spawn_egg[item_name={text:"드림 디펜더"}] 1
function bw:shop/ok {name:"드림 디펜더"}
