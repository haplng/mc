execute store result score #have bw run clear @s minecraft:emerald 0
scoreboard players set #need bw 6
scoreboard players operation #need bw -= #have bw
execute if score #need bw matches 1.. run return run function bw:shop/fail/em
clear @s minecraft:emerald 6
give @s minecraft:bow[enchantments={"minecraft:power":1,"minecraft:punch":1}] 1
function bw:shop/ok {name:"활 (힘 I, 밀치기 I)"}
