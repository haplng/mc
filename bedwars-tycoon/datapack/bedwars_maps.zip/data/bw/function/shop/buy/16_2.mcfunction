execute store result score #have bw run clear @s minecraft:gold_ingot 0
scoreboard players set #need bw 3
scoreboard players operation #need bw -= #have bw
execute if score #need bw matches 1.. run return run function bw:shop/fail/gold
clear @s minecraft:gold_ingot 3
clear @s #minecraft:pickaxes
give @s minecraft:golden_pickaxe[enchantments={"minecraft:efficiency":3,"minecraft:sharpness":2},unbreakable={}] 1
function bw:shop/ok {name:"금 곡괭이 (효율 III, 날카로움 II)"}
