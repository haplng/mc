execute store result score #have bw run clear @s minecraft:gold_ingot 0
scoreboard players set #need bw 5
scoreboard players operation #need bw -= #have bw
execute if score #need bw matches 1.. run return run function bw:shop/fail/gold
clear @s minecraft:gold_ingot 5
give @s minecraft:stick[enchantments={"minecraft:knockback":1},item_name={text:"막대기 (밀치기 I)"}] 1
function bw:shop/ok {name:"막대기 (밀치기 I)"}
