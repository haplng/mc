execute store result score #have bw run clear @s minecraft:iron_ingot 0
scoreboard players set #need bw 24
scoreboard players operation #need bw -= #have bw
execute if score #need bw matches 1.. run return run function bw:shop/fail/iron
clear @s minecraft:iron_ingot 24
give @s minecraft:chest[item_name={text:"소형 팝업 타워"}] 1
function bw:shop/ok {name:"소형 팝업 타워"}
