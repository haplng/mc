execute store result score #have bw run clear @s minecraft:iron_ingot 0
scoreboard players set #need bw 30
scoreboard players operation #need bw -= #have bw
execute if score #need bw matches 1.. run return run function bw:shop/fail/iron
clear @s minecraft:iron_ingot 30
give @s minecraft:snowball[item_name={text:"빈대"}] 1
function bw:shop/ok {name:"빈대"}
