execute store result score #have bw run clear @s minecraft:iron_ingot 0
scoreboard players set #need bw 24
scoreboard players operation #need bw -= #have bw
execute if score #need bw matches 1.. run return run function bw:shop/fail/iron
clear @s minecraft:iron_ingot 24
give @s minecraft:end_stone 12
function bw:shop/ok {name:"엔드 스톤 ×12"}
