execute store result score #have bw run clear @s minecraft:emerald 0
scoreboard players set #need bw 1
scoreboard players operation #need bw -= #have bw
execute if score #need bw matches 1.. run return run function bw:shop/fail/em
clear @s minecraft:emerald 1
give @s minecraft:egg[item_name={text:"다리 알"}] 1
function bw:shop/ok {name:"다리 알"}
