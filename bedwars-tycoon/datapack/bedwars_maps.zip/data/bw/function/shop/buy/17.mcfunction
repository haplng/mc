function bw:shop/tiers
execute if score #ax bw matches 0 run return run function bw:shop/buy/17_0
execute if score #ax bw matches 1 run return run function bw:shop/buy/17_1
execute if score #ax bw matches 2 run return run function bw:shop/buy/17_2
execute if score #ax bw matches 3 run return run function bw:shop/buy/17_3
function bw:shop/no {why:"이미 최고 단계야."}
