function bw:shop/tiers
execute if score #pk bw matches 0 run return run function bw:shop/buy/16_0
execute if score #pk bw matches 1 run return run function bw:shop/buy/16_1
execute if score #pk bw matches 2 run return run function bw:shop/buy/16_2
execute if score #pk bw matches 3 run return run function bw:shop/buy/16_3
function bw:shop/no {why:"이미 최고 단계야."}
