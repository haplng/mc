execute store result score #have bw run clear @s minecraft:emerald 0
scoreboard players set #need bw 4
scoreboard players operation #need bw -= #have bw
execute if score #need bw matches 1.. run return run function bw:shop/fail/em
clear @s minecraft:emerald 4
give @s minecraft:diamond_sword[unbreakable={}] 1
function bw:shop/ok {name:"다이아몬드 검"}
