execute store result score #have bw run clear @s minecraft:emerald 0
scoreboard players set #need bw 2
scoreboard players operation #need bw -= #have bw
execute if score #need bw matches 1.. run return run function bw:shop/fail/em
clear @s minecraft:emerald 2
give @s minecraft:potion[potion_contents={custom_color:8356754,custom_effects:[{id:"minecraft:invisibility",amplifier:0b,duration:600}]},custom_name={text:"투명 물약 (30초)",italic:false}] 1
function bw:shop/ok {name:"투명 물약 (30초)"}
