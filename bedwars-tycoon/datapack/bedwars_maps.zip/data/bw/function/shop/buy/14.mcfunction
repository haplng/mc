execute if items entity @s armor.legs #bw:armor3 run return run function bw:shop/no {why:"이미 같거나 더 좋은 방어구를 입고 있어."}
execute store result score #have bw run clear @s minecraft:emerald 0
scoreboard players set #need bw 6
scoreboard players operation #need bw -= #have bw
execute if score #need bw matches 1.. run return run function bw:shop/fail/em
clear @s minecraft:emerald 6
item replace entity @s armor.legs with minecraft:diamond_leggings[unbreakable={}]
item replace entity @s armor.feet with minecraft:diamond_boots[unbreakable={}]
playsound minecraft:item.armor.equip_generic master @s ~ ~ ~ 1 1
function bw:shop/ok {name:"다이아몬드 갑옷"}
