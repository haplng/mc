execute store result score #have bw run clear @s minecraft:gold_ingot 0
scoreboard players set #need bw 4
scoreboard players operation #need bw -= #have bw
execute if score #need bw matches 1.. run return run function bw:shop/fail/gold
clear @s minecraft:gold_ingot 4
give @s minecraft:milk_bucket[item_name={text:"마법 우유"}] 1
function bw:shop/ok {name:"마법 우유"}
