execute store result score #have bw run clear @s minecraft:iron_ingot 0
scoreboard players set #need bw 10
scoreboard players operation #need bw -= #have bw
execute if score #need bw matches 1.. run return run function bw:shop/fail/iron
clear @s minecraft:iron_ingot 10
clear @s #minecraft:pickaxes
give @s minecraft:wooden_pickaxe[enchantments={"minecraft:efficiency":1},unbreakable={}] 1
function bw:shop/ok {name:"나무 곡괭이 (효율 I)"}
