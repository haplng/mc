execute store result score #have bw run clear @s minecraft:iron_ingot 0
scoreboard players set #need bw 4
scoreboard players operation #need bw -= #have bw
execute if score #need bw matches 1.. run return run function bw:shop/fail/iron
clear @s minecraft:iron_ingot 4
function bw:shop/dye
function bw:shop/give/1 with storage bw:shop d
function bw:shop/ok {name:"양털 ×16"}
