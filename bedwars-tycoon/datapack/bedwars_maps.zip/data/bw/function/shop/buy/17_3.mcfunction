execute store result score #have bw run clear @s minecraft:gold_ingot 0
scoreboard players set #need bw 6
scoreboard players operation #need bw -= #have bw
execute if score #need bw matches 1.. run return run function bw:shop/fail/gold
clear @s minecraft:gold_ingot 6
clear @s #minecraft:axes
give @s minecraft:diamond_axe[enchantments={"minecraft:efficiency":3},unbreakable={}] 1
function bw:shop/ok {name:"다이아몬드 도끼 (효율 III)"}
