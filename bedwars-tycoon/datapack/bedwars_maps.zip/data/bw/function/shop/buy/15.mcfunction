execute if items entity @s container.* minecraft:shears run return run function bw:shop/no {why:"이미 가지고 있어."}
execute if items entity @s weapon.offhand minecraft:shears run return run function bw:shop/no {why:"이미 가지고 있어."}
execute store result score #have bw run clear @s minecraft:iron_ingot 0
scoreboard players set #need bw 20
scoreboard players operation #need bw -= #have bw
execute if score #need bw matches 1.. run return run function bw:shop/fail/iron
clear @s minecraft:iron_ingot 20
give @s minecraft:shears[unbreakable={}] 1
function bw:shop/ok {name:"가위"}
