execute store result score #have bw run clear @s minecraft:gold_ingot 0
scoreboard players set #need bw 12
scoreboard players operation #need bw -= #have bw
execute if score #need bw matches 1.. run return run function bw:shop/fail/gold
clear @s minecraft:gold_ingot 12
give @s minecraft:bow 1
function bw:shop/ok {name:"활"}
