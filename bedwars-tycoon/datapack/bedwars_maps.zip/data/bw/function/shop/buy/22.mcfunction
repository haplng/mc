execute store result score #have bw run clear @s minecraft:emerald 0
scoreboard players set #need bw 1
scoreboard players operation #need bw -= #have bw
execute if score #need bw matches 1.. run return run function bw:shop/fail/em
clear @s minecraft:emerald 1
give @s minecraft:potion[potion_contents={custom_color:8171462,custom_effects:[{id:"minecraft:speed",amplifier:1b,duration:900}]},custom_name={text:"신속 II 물약 (45초)",italic:false}] 1
function bw:shop/ok {name:"신속 II 물약 (45초)"}
