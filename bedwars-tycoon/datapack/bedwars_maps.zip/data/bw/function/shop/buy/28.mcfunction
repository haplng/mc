execute store result score #have bw run clear @s minecraft:iron_ingot 0
scoreboard players set #need bw 40
scoreboard players operation #need bw -= #have bw
execute if score #need bw matches 1.. run return run function bw:shop/fail/iron
clear @s minecraft:iron_ingot 40
give @s minecraft:fire_charge[item_name={text:"화염구"}] 1
function bw:shop/ok {name:"화염구"}
