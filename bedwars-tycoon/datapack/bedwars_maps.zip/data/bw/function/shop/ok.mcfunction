$data modify storage bw:shop a.msg set value {text:"✔ $(name) 구매!",color:"green"}
$tellraw @s [{text:"구매 완료! ",color:"green"},{text:"$(name)",color:"gold"}]
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.8 2
function bw:shop/refresh
