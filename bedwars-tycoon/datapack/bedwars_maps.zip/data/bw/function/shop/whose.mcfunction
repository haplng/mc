execute if entity @s[tag=bw.t.red] run scoreboard players set #team bw 0
execute if entity @s[tag=bw.t.blue] run scoreboard players set #team bw 1
execute if entity @s[tag=bw.t.lime] run scoreboard players set #team bw 2
execute if entity @s[tag=bw.t.yellow] run scoreboard players set #team bw 3
execute if entity @s[tag=bw.t.cyan] run scoreboard players set #team bw 4
execute if entity @s[tag=bw.t.white] run scoreboard players set #team bw 5
execute if entity @s[tag=bw.t.pink] run scoreboard players set #team bw 6
execute if entity @s[tag=bw.t.gray] run scoreboard players set #team bw 7
