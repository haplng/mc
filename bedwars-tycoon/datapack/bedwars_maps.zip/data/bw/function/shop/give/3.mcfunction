$give @s minecraft:$(dye)_stained_glass[item_name={text:"폭발 방지 유리"}] 4
