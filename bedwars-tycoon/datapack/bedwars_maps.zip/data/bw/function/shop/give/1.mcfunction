$give @s minecraft:$(dye)_wool 16
