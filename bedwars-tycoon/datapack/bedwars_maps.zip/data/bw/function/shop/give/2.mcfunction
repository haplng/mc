$give @s minecraft:$(dye)_terracotta 16
