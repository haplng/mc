give @s minecraft:iron_ingot 64
give @s minecraft:gold_ingot 32
give @s minecraft:emerald 16
tellraw @s {text:"시험용 자원을 줬어: 철 64, 금 32, 에메랄드 16",color:"yellow"}
