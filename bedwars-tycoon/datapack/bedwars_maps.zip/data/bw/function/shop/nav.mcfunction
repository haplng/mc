scoreboard players operation #p bw = @s bw.shop
scoreboard players set @s bw.shop 0
execute if score #p bw matches 99 run return run dialog clear @s
execute unless score #p bw matches 1..8 run return fail
execute unless entity @e[type=minecraft:villager,tag=bw.npc.shop,distance=..10] run return run function bw:shop/far
scoreboard players operation @s bw.page = #p bw
data modify storage bw:shop a.msg set value {text:"물건을 누르면 바로 구매돼.",color:"gray"}
function bw:shop/refresh
