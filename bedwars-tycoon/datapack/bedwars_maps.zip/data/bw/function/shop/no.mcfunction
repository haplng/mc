$data modify storage bw:shop a.msg set value {text:"✘ $(why)",color:"red"}
$tellraw @s {text:"$(why)",color:"red"}
playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.6 0.5
function bw:shop/refresh
