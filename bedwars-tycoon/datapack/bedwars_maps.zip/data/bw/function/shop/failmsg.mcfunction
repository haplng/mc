$data modify storage bw:shop a.msg set value {text:"✘ $(subj) 부족해! $(n)개 더 필요해.",color:"red"}
$tellraw @s {text:"$(subj) 부족해! $(n)개 더 필요해!",color:"red"}
playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.6 0.5
function bw:shop/refresh
