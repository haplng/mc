dialog clear @s
tellraw @s {text:"상점 주인 가까이에서만 살 수 있어.",color:"red"}
