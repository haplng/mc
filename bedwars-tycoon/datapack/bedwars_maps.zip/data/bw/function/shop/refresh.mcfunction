execute store result score #iron bw run clear @s minecraft:iron_ingot 0
execute store result score #gold bw run clear @s minecraft:gold_ingot 0
execute store result score #em bw run clear @s minecraft:emerald 0
execute store result storage bw:shop a.iron int 1 run scoreboard players get #iron bw
execute store result storage bw:shop a.gold int 1 run scoreboard players get #gold bw
execute store result storage bw:shop a.em int 1 run scoreboard players get #em bw
function bw:shop/tiers
execute if score @s bw.page matches 1 run function bw:shop/page/1
execute if score @s bw.page matches 2 run function bw:shop/page/2
execute if score @s bw.page matches 3 run function bw:shop/page/3
execute if score @s bw.page matches 4 run function bw:shop/page/4
execute if score @s bw.page matches 5 run function bw:shop/page/5
execute if score @s bw.page matches 6 run function bw:shop/page/6
execute if score @s bw.page matches 7 run function bw:shop/page/7
execute if score @s bw.page matches 8 run function bw:shop/page/8
