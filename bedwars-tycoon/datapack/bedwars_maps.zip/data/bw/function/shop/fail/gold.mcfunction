execute store result storage bw:shop t.n int 1 run scoreboard players get #need bw
data modify storage bw:shop t.subj set value "금이"
function bw:shop/failmsg with storage bw:shop t
