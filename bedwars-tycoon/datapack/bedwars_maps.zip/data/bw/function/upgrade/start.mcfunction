scoreboard players set #ver bw 3
scoreboard players set #wipe bw 1
scoreboard players set #first bw 1
scoreboard players set #installed bw 1
execute as @a run function bw:go/lobby
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "예전 맵을 지우고 새 맵 10개로 바꾸는 중이야. 2~3분쯤 걸려, 끝날 때까지 로비에 있어.", "color": "yellow"}]
function bw:step/lobby/load
