execute as @e[type=minecraft:marker,tag=bw.fbm] unless predicate bw:riding at @s run function bw:fb/boom
execute as @e[type=minecraft:marker,tag=bw.tntm] unless predicate bw:riding at @s run function bw:fb/tntboom
scoreboard players add @e[type=minecraft:fireball,tag=bw.fb] bw.t 1
kill @e[type=minecraft:fireball,tag=bw.fb,scores={bw.t=160..}]
execute as @a[tag=bw.fighter,scores={bw.use=1..}] at @s run function bw:fb/use
execute as @a[tag=bw.fighter,scores={bw.tnt=1..}] at @s run function bw:fb/tnt
execute as @e[type=minecraft:snowball,tag=!bw.seen] run function bw:fb/egg0
execute as @e[type=minecraft:snowball,tag=bw.egg] at @s run function bw:fb/egg
scoreboard players set @a[scores={bw.use=1..}] bw.use 0
scoreboard players set @a[scores={bw.tnt=1..}] bw.tnt 0
