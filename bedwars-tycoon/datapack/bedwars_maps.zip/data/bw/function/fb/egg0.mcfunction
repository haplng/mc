tag @s add bw.seen
execute if data entity @s Item.components."minecraft:custom_data"{bw:"egg"} run tag @s add bw.egg
execute if entity @s[tag=bw.egg] at @s run scoreboard players operation @s bw.team = @a[tag=bw.fighter,sort=nearest,limit=1] bw.team
