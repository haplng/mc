execute positioned 0.0 0.0 0.0 run tp @e[type=minecraft:marker,tag=bw.vec,limit=1] ^ ^ ^1
summon minecraft:fireball ~ ~ ~ {Tags:["bw","bw.round","bw.fb","bw.fbnew"],ExplosionPower:0b,acceleration_power:0.0526d,Passengers:[{id:"minecraft:marker",Tags:["bw","bw.round","bw.fbm","bw.fbnew"]}]}
data modify entity @e[type=minecraft:fireball,tag=bw.fbnew,limit=1] Motion set from entity @e[type=minecraft:marker,tag=bw.vec,limit=1] Pos
data modify entity @e[type=minecraft:fireball,tag=bw.fbnew,limit=1] Owner set from entity @s UUID
scoreboard players operation @e[tag=bw.fbnew] bw.team = @s bw.team
tag @e[tag=bw.fbnew] remove bw.fbnew
playsound minecraft:entity.blaze.shoot player @a ~ ~ ~ 1 1
