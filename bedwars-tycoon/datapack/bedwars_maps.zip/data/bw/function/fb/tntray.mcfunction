execute if block ~ ~ ~ minecraft:tnt run return run function bw:fb/ignite
scoreboard players add #rs bw 1
execute if score #rs bw matches ..28 positioned ^ ^ ^0.2 run function bw:fb/tntray
