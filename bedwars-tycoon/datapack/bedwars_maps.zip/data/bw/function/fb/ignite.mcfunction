scoreboard players set #hit bw 1
setblock ~ ~ ~ minecraft:air
execute align xyz positioned ~0.5 ~ ~0.5 run function bw:fb/prime
