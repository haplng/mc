scoreboard players set @s bw.use 0
execute unless items entity @s weapon.mainhand *[minecraft:custom_data~{bw:"fireball"}] unless items entity @s weapon.offhand *[minecraft:custom_data~{bw:"fireball"}] run return 0
execute store result score #pre bw run function bw:fb/pre
execute if score #pre bw matches 1 run return 0
function bw:fb/throw
