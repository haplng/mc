scoreboard players set @s bw.tnt 0
scoreboard players set #rs bw 0
scoreboard players set #hit bw 0
execute anchored eyes positioned ^ ^ ^0.2 run function bw:fb/tntray
execute if score #hit bw matches 0 store result score #n bw run fill ~-5 ~-5 ~-5 ~5 ~5 ~5 minecraft:air replace minecraft:tnt
execute if score #hit bw matches 0 if score #n bw matches 1.. anchored eyes positioned ^ ^ ^3 run function bw:fb/prime
