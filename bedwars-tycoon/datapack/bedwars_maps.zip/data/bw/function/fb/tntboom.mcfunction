summon minecraft:armor_stand ~ ~ ~ {Marker:1b,Invisible:1b,NoGravity:1b,Tags:["bw","bw.round","bw.boom"],equipment:{head:{id:"minecraft:leather_helmet",count:1,components:{"minecraft:enchantments":{"bw:blast_tnt":1}}}}}
scoreboard players operation #att bw = @s bw.team
execute as @e[tag=bw.fighter,distance=..5] unless score @s bw.team = #att bw run scoreboard players operation @s bw.lh = #att bw
execute as @e[tag=bw.fighter,distance=..5] unless score @s bw.team = #att bw run scoreboard players set @s bw.lht 200
execute as @e[tag=bw.fighter,distance=..2.5] run damage @s 9 minecraft:explosion
execute as @e[tag=bw.fighter,distance=2.5..4.5] run damage @s 5 minecraft:explosion
execute as @e[tag=bw.fighter,distance=4.5..6.5] run damage @s 2 minecraft:explosion
kill @s
