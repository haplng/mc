scoreboard players add @s bw.t 1
execute if score @s bw.t matches ..2 run return 0
execute if score @s bw.t matches 45.. run return run kill @s
execute if score @s bw.team matches 0 run fill ~-1 ~-2 ~-1 ~ ~-2 ~ minecraft:red_wool keep
execute if score @s bw.team matches 1 run fill ~-1 ~-2 ~-1 ~ ~-2 ~ minecraft:blue_wool keep
execute if score @s bw.team matches 2 run fill ~-1 ~-2 ~-1 ~ ~-2 ~ minecraft:lime_wool keep
execute if score @s bw.team matches 3 run fill ~-1 ~-2 ~-1 ~ ~-2 ~ minecraft:yellow_wool keep
execute if score @s bw.team matches 4 run fill ~-1 ~-2 ~-1 ~ ~-2 ~ minecraft:cyan_wool keep
execute if score @s bw.team matches 5 run fill ~-1 ~-2 ~-1 ~ ~-2 ~ minecraft:white_wool keep
execute if score @s bw.team matches 6 run fill ~-1 ~-2 ~-1 ~ ~-2 ~ minecraft:pink_wool keep
execute if score @s bw.team matches 7 run fill ~-1 ~-2 ~-1 ~ ~-2 ~ minecraft:gray_wool keep
playsound minecraft:block.wool.place block @a ~ ~ ~ 0.5 1.4
