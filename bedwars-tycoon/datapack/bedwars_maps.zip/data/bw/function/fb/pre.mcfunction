execute if entity @s[scores={bw.h_fbjump=1..},tag=!bw.off_fbjump,x_rotation=45..90] run return run function bw:hack/fbjump
return 0
