clear @s *[minecraft:custom_data~{bw:"fireball"}] 1
execute anchored eyes positioned ^ ^ ^1.3 run function bw:fb/launch
