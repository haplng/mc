summon minecraft:tnt ~ ~ ~ {fuse:52s,explosion_power:0f,Tags:["bw","bw.round","bw.tntnew"],Passengers:[{id:"minecraft:marker",Tags:["bw","bw.round","bw.tntm","bw.tntnew"]}]}
scoreboard players operation @e[tag=bw.tntnew] bw.team = @s bw.team
tag @e[tag=bw.tntnew] remove bw.tntnew
playsound minecraft:entity.tnt.primed block @a ~ ~ ~ 1 1
