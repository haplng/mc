execute unless score #sudden bw matches 1 run clone ~-6 ~-6 ~266394 ~6 ~6 ~266406 ~-6 ~-6 ~-6 filtered #bw:blastable force
execute as @e[type=minecraft:item,distance=..9,tag=!bw.res] store result score @s bw.t run data get entity @s Age
kill @e[type=minecraft:item,distance=..9,tag=!bw.res,scores={bw.t=..3}]
