scoreboard players enable @a lobby
execute as @a[scores={lobby=1..}] run function bw:go/lobby
execute unless score #installed bw matches 1.. run effect give @a minecraft:slow_falling 2 0 true
execute if score #wipe bw matches 1 as @a unless entity @s[x=-110,y=-64,z=-110,dx=220,dy=400,dz=230] run function bw:go/lobby
execute if score #installed bw matches 6.. as @a[x=-32,y=65,z=-26,dx=4,dy=1,dz=2,gamemode=!spectator] run function bw:go/tea
execute if score #installed bw matches 6.. as @a[x=-17,y=65,z=-26,dx=4,dy=1,dz=2,gamemode=!spectator] run function bw:go/chess
execute if score #installed bw matches 6.. as @a[x=-2,y=65,z=-26,dx=4,dy=1,dz=2,gamemode=!spectator] run function bw:go/circus
execute if score #installed bw matches 6.. as @a[x=13,y=65,z=-26,dx=4,dy=1,dz=2,gamemode=!spectator] run function bw:go/library
execute if score #installed bw matches 6.. as @a[x=28,y=65,z=-26,dx=4,dy=1,dz=2,gamemode=!spectator] run function bw:go/solar
scoreboard players add #npc bw 1
execute if score #npc bw matches 100.. if score #installed bw matches 6.. unless score #wipe bw matches 1 run function bw:npc/ensure
scoreboard players enable @a bw.buy
scoreboard players enable @a bw.shop
scoreboard players set @a[scores={bw.buy=..-1}] bw.buy 0
scoreboard players set @a[scores={bw.shop=..-1}] bw.shop 0
execute as @a[scores={bw.buy=1..}] at @s run function bw:shop/buy
execute as @a[scores={bw.shop=1..}] at @s run function bw:shop/nav
