scoreboard players enable @a lobby
execute as @a[scores={lobby=1..}] run function bw:go/lobby
execute unless score #installed bw matches 1.. run effect give @a minecraft:slow_falling 2 0 true
execute if score #wipe bw matches 1 as @a unless entity @s[x=-110,y=-64,z=-110,dx=220,dy=400,dz=230] run function bw:go/lobby
execute if score #state bw matches 0 if score #installed bw matches 6.. as @a[x=-32,y=65,z=-26,dx=4,dy=1,dz=2,gamemode=!spectator,limit=1] run function bw:game/pick/tea
execute if score #state bw matches 0 if score #installed bw matches 6.. as @a[x=-17,y=65,z=-26,dx=4,dy=1,dz=2,gamemode=!spectator,limit=1] run function bw:game/pick/chess
execute if score #state bw matches 0 if score #installed bw matches 6.. as @a[x=-2,y=65,z=-26,dx=4,dy=1,dz=2,gamemode=!spectator,limit=1] run function bw:game/pick/circus
execute if score #state bw matches 0 if score #installed bw matches 6.. as @a[x=13,y=65,z=-26,dx=4,dy=1,dz=2,gamemode=!spectator,limit=1] run function bw:game/pick/library
execute if score #state bw matches 0 if score #installed bw matches 6.. as @a[x=28,y=65,z=-26,dx=4,dy=1,dz=2,gamemode=!spectator,limit=1] run function bw:game/pick/solar
scoreboard players add #npc bw 1
execute if score #npc bw matches 100.. if score #installed bw matches 6.. unless score #wipe bw matches 1 unless score #state bw matches 1..2 run function bw:npc/ensure
execute if score #npc bw matches 50 run function bw:core/helpers
execute if score #state bw matches 3 run function bw:game/tick
tag @a[tag=bw.fighter,tag=!bw.play] remove bw.fighter
execute if score #state bw matches 3 run tag @a[tag=bw.play,gamemode=survival] add bw.fighter
tag @a[tag=bw.fighter,gamemode=!survival] remove bw.fighter
scoreboard players remove @a[scores={bw.gcd=1..}] bw.gcd 1
scoreboard players add #lt bw 1
execute if score #state bw matches 0 if score #lt bw matches 20.. run function bw:lobby/second
execute as @a[tag=bw.fighter] at @s run function bw:hack/tick
tag @a[tag=bw.aimd] remove bw.aimd
execute as @a[gamemode=!spectator] at @s if entity @e[type=minecraft:marker,tag=bw.gui,distance=..8,limit=1] run function bw:gui/near
execute if score #lt bw matches 5 as @e[type=minecraft:marker,tag=bw.gui,tag=!bw.gui.a,tag=!bw.gui.b] at @s run function bw:gui/init
