scoreboard players enable @a lobby
execute as @a[scores={lobby=1..}] run function bw:go/lobby
execute unless score #installed bw matches 1.. run effect give @a minecraft:slow_falling 2 0 true
execute if score #wipe bw matches 1 as @a unless entity @s[x=-110,y=-64,z=-110,dx=220,dy=400,dz=230] run function bw:go/lobby
execute if score #installed bw matches 11.. as @a[x=-27,y=65,z=-11,dx=4,dy=1,dz=4,gamemode=!spectator] run function bw:go/tea
execute if score #installed bw matches 11.. as @a[x=-28,y=65,z=0,dx=2,dy=1,dz=4,gamemode=!spectator] run function bw:go/chess
execute if score #installed bw matches 11.. as @a[x=-26,y=65,z=11,dx=4,dy=1,dz=4,gamemode=!spectator] run function bw:go/circus
execute if score #installed bw matches 11.. as @a[x=-18,y=65,z=20,dx=4,dy=1,dz=4,gamemode=!spectator] run function bw:go/train
execute if score #installed bw matches 11.. as @a[x=-8,y=65,z=25,dx=4,dy=1,dz=2,gamemode=!spectator] run function bw:go/stadium
execute if score #installed bw matches 11.. as @a[x=4,y=65,z=25,dx=4,dy=1,dz=2,gamemode=!spectator] run function bw:go/library
execute if score #installed bw matches 11.. as @a[x=14,y=65,z=20,dx=4,dy=1,dz=4,gamemode=!spectator] run function bw:go/turtle
execute if score #installed bw matches 11.. as @a[x=22,y=65,z=11,dx=4,dy=1,dz=4,gamemode=!spectator] run function bw:go/windmill
execute if score #installed bw matches 11.. as @a[x=26,y=65,z=0,dx=2,dy=1,dz=4,gamemode=!spectator] run function bw:go/solar
execute if score #installed bw matches 11.. as @a[x=23,y=65,z=-11,dx=4,dy=1,dz=4,gamemode=!spectator] run function bw:go/pirate
