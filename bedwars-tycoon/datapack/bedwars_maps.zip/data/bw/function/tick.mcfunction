scoreboard players enable @a lobby
execute as @a[scores={lobby=1..}] run function bw:go/lobby
execute unless score #installed bw matches 1.. run effect give @a minecraft:slow_falling 2 0 true
execute as @a[x=-27,y=65,z=-11,dx=4,dy=1,dz=4,gamemode=!spectator] run function bw:go/sakura
execute as @a[x=-28,y=65,z=0,dx=2,dy=1,dz=4,gamemode=!spectator] run function bw:go/oasis
execute as @a[x=-26,y=65,z=11,dx=4,dy=1,dz=4,gamemode=!spectator] run function bw:go/frost
execute as @a[x=-18,y=65,z=20,dx=4,dy=1,dz=4,gamemode=!spectator] run function bw:go/mushroom
execute as @a[x=-8,y=65,z=25,dx=4,dy=1,dz=2,gamemode=!spectator] run function bw:go/harbour
execute as @a[x=4,y=65,z=25,dx=4,dy=1,dz=2,gamemode=!spectator] run function bw:go/autumn
execute as @a[x=14,y=65,z=20,dx=4,dy=1,dz=4,gamemode=!spectator] run function bw:go/nether
execute as @a[x=22,y=65,z=11,dx=4,dy=1,dz=4,gamemode=!spectator] run function bw:go/jungle
execute as @a[x=26,y=65,z=0,dx=2,dy=1,dz=4,gamemode=!spectator] run function bw:go/castle
execute as @a[x=23,y=65,z=-11,dx=4,dy=1,dz=4,gamemode=!spectator] run function bw:go/end
