forceload add 505 -95 600 95
forceload add 601 -95 695 95
execute unless loaded 505 64 -95 run return run schedule function bw:step/tea/try 20t
execute unless loaded 695 64 -95 run return run schedule function bw:step/tea/try 20t
execute unless loaded 505 64 95 run return run schedule function bw:step/tea/try 20t
execute unless loaded 695 64 95 run return run schedule function bw:step/tea/try 20t
execute unless loaded 600 64 0 run return run schedule function bw:step/tea/try 20t
kill @e[type=!player,tag=bw,x=505,y=29,z=-95,dx=190,dy=53,dz=190]
execute if score #wipe bw matches 1 run function bw:step/tea/wipe
place template bw:tea 513 51 -87
schedule function bw:step/tea/finish 10t
