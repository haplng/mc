forceload add 505 -95 600 95
forceload add 601 -95 695 95
schedule function bw:step/tea/try 40t
