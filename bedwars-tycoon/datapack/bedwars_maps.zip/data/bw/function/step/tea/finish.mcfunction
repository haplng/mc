kill @e[type=item,x=505,y=29,z=-95,dx=190,dy=53,dz=190]
kill @e[type=falling_block,x=505,y=29,z=-95,dx=190,dy=53,dz=190]
forceload remove 505 -95 600 95
forceload remove 601 -95 695 95
scoreboard players set #installed bw 2
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "티타임 설치 완료 (2/11)", "color": "gray"}]
schedule function bw:step/chess/load 10t
