forceload add 1676 -124 1800 124
forceload add 1801 -124 1924 124
schedule function bw:step/library/try 40t
