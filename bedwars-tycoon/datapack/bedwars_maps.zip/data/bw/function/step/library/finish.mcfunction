kill @e[type=item,x=1676,y=35,z=-124,dx=248,dy=48,dz=248]
kill @e[type=falling_block,x=1676,y=35,z=-124,dx=248,dy=48,dz=248]
forceload remove 1676 -124 1800 124
forceload remove 1801 -124 1924 124
scoreboard players set #installed bw 5
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "도서관 설치 완료 (5/6)", "color": "gray"}]
schedule function bw:step/solar/load 10t
