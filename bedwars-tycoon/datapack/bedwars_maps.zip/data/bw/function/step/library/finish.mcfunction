kill @e[type=item,x=2483,y=34,z=-117,dx=234,dy=51,dz=234]
kill @e[type=falling_block,x=2483,y=34,z=-117,dx=234,dy=51,dz=234]
forceload remove 2483 -117 2600 117
forceload remove 2601 -117 2717 117
scoreboard players set #installed bw 7
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "도서관 설치 완료 (7/11)", "color": "gray"}]
schedule function bw:step/turtle/load 10t
