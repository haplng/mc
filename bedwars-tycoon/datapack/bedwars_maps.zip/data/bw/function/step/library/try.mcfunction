forceload add 2483 -117 2600 117
forceload add 2601 -117 2717 117
execute unless loaded 2483 64 -117 run return run schedule function bw:step/library/try 20t
execute unless loaded 2717 64 -117 run return run schedule function bw:step/library/try 20t
execute unless loaded 2483 64 117 run return run schedule function bw:step/library/try 20t
execute unless loaded 2717 64 117 run return run schedule function bw:step/library/try 20t
execute unless loaded 2600 64 0 run return run schedule function bw:step/library/try 20t
kill @e[type=!player,tag=bw,x=2483,y=34,z=-117,dx=234,dy=51,dz=234]
execute if score #wipe bw matches 1 run function bw:step/library/wipe
place template bw:library 2489 47 -111
schedule function bw:step/library/finish 10t
