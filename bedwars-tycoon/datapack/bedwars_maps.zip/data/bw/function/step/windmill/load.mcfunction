forceload add 3276 -124 3400 124
forceload add 3401 -124 3524 124
schedule function bw:step/windmill/try 40t
