kill @e[type=item,x=3276,y=30,z=-124,dx=248,dy=66,dz=248]
kill @e[type=falling_block,x=3276,y=30,z=-124,dx=248,dy=66,dz=248]
forceload remove 3276 -124 3400 124
forceload remove 3401 -124 3524 124
scoreboard players set #installed bw 9
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "풍차 설치 완료 (9/11)", "color": "gray"}]
schedule function bw:step/solar/load 10t
