forceload add 3276 -124 3400 124
forceload add 3401 -124 3524 124
execute unless loaded 3276 64 -124 run return run schedule function bw:step/windmill/try 20t
execute unless loaded 3524 64 -124 run return run schedule function bw:step/windmill/try 20t
execute unless loaded 3276 64 124 run return run schedule function bw:step/windmill/try 20t
execute unless loaded 3524 64 124 run return run schedule function bw:step/windmill/try 20t
execute unless loaded 3400 64 0 run return run schedule function bw:step/windmill/try 20t
kill @e[type=!player,tag=bw,x=3276,y=30,z=-124,dx=248,dy=66,dz=248]
execute if score #wipe bw matches 1 run function bw:step/windmill/wipe
place template bw:windmill 3280 38 -121
schedule function bw:step/windmill/finish 10t
