forceload add 2880 -120 3000 120
forceload add 3001 -120 3120 120
execute unless loaded 2880 64 -120 run return run schedule function bw:step/turtle/try 20t
execute unless loaded 3120 64 -120 run return run schedule function bw:step/turtle/try 20t
execute unless loaded 2880 64 120 run return run schedule function bw:step/turtle/try 20t
execute unless loaded 3120 64 120 run return run schedule function bw:step/turtle/try 20t
execute unless loaded 3000 64 0 run return run schedule function bw:step/turtle/try 20t
kill @e[type=!player,tag=bw,x=2880,y=27,z=-120,dx=240,dy=54,dz=240]
execute if score #wipe bw matches 1 run function bw:step/turtle/wipe
place template bw:turtle 2884 39 -116
schedule function bw:step/turtle/finish 10t
