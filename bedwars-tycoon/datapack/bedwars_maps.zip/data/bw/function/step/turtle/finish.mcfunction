kill @e[type=item,x=2880,y=27,z=-120,dx=240,dy=54,dz=240]
kill @e[type=falling_block,x=2880,y=27,z=-120,dx=240,dy=54,dz=240]
forceload remove 2880 -120 3000 120
forceload remove 3001 -120 3120 120
scoreboard players set #installed bw 8
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "거북 설치 완료 (8/11)", "color": "gray"}]
schedule function bw:step/windmill/load 10t
