forceload add 902 -98 1000 98
forceload add 1001 -98 1098 98
execute unless loaded 902 64 -98 run return run schedule function bw:step/chess/try 20t
execute unless loaded 1098 64 -98 run return run schedule function bw:step/chess/try 20t
execute unless loaded 902 64 98 run return run schedule function bw:step/chess/try 20t
execute unless loaded 1098 64 98 run return run schedule function bw:step/chess/try 20t
execute unless loaded 1000 64 0 run return run schedule function bw:step/chess/try 20t
kill @e[type=!player,tag=bw,x=902,y=26,z=-98,dx=196,dy=59,dz=196]
execute if score #wipe bw matches 1 run function bw:step/chess/wipe
place template bw:chess 907 50 -93
schedule function bw:step/chess/finish 10t
