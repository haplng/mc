forceload add 902 -98 1000 98
forceload add 1001 -98 1098 98
schedule function bw:step/chess/try 40t
