forceload add 896 -104 1000 104
forceload add 1001 -104 1104 104
schedule function bw:step/chess/try 40t
