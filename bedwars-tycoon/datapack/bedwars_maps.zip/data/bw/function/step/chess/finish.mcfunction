kill @e[type=item,x=902,y=26,z=-98,dx=196,dy=59,dz=196]
kill @e[type=falling_block,x=902,y=26,z=-98,dx=196,dy=59,dz=196]
forceload remove 902 -98 1000 98
forceload remove 1001 -98 1098 98
scoreboard players set #installed bw 3
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "체스 설치 완료 (3/11)", "color": "gray"}]
schedule function bw:step/circus/load 10t
