kill @e[type=item,x=896,y=26,z=-104,dx=208,dy=59,dz=208]
kill @e[type=falling_block,x=896,y=26,z=-104,dx=208,dy=59,dz=208]
forceload remove 896 -104 1000 104
forceload remove 1001 -104 1104 104
scoreboard players set #installed bw 3
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "체스 설치 완료 (3/6)", "color": "gray"}]
schedule function bw:step/circus/load 10t
