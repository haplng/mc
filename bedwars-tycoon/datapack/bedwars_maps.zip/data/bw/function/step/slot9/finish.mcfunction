kill @e[type=item,x=3276,y=30,z=-124,dx=248,dy=66,dz=248]
kill @e[type=falling_block,x=3276,y=30,z=-124,dx=248,dy=66,dz=248]
forceload remove 3276 -124 3400 124
forceload remove 3401 -124 3524 124
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "안 쓰는 예전 맵 자리 비움 (3/5)", "color": "gray"}]
schedule function bw:step/slot10/load 10t
