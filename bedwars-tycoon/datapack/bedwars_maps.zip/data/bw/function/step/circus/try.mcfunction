forceload add 1294 -106 1400 106
forceload add 1401 -106 1506 106
execute unless loaded 1294 64 -106 run return run schedule function bw:step/circus/try 20t
execute unless loaded 1506 64 -106 run return run schedule function bw:step/circus/try 20t
execute unless loaded 1294 64 106 run return run schedule function bw:step/circus/try 20t
execute unless loaded 1506 64 106 run return run schedule function bw:step/circus/try 20t
execute unless loaded 1400 64 0 run return run schedule function bw:step/circus/try 20t
kill @e[type=!player,tag=bw,x=1294,y=31,z=-106,dx=212,dy=55,dz=212]
execute if score #wipe bw matches 1 run function bw:step/circus/wipe
place template bw:circus 1302 51 -98
schedule function bw:step/circus/finish 10t
