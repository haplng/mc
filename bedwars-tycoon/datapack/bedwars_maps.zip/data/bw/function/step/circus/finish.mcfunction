kill @e[type=item,x=1294,y=31,z=-106,dx=212,dy=55,dz=212]
kill @e[type=falling_block,x=1294,y=31,z=-106,dx=212,dy=55,dz=212]
forceload remove 1294 -106 1400 106
forceload remove 1401 -106 1506 106
scoreboard players set #installed bw 4
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "서커스 설치 완료 (4/11)", "color": "gray"}]
schedule function bw:step/train/load 10t
