kill @e[type=item,x=1286,y=31,z=-114,dx=228,dy=55,dz=228]
kill @e[type=falling_block,x=1286,y=31,z=-114,dx=228,dy=55,dz=228]
forceload remove 1286 -114 1400 114
forceload remove 1401 -114 1514 114
scoreboard players set #installed bw 4
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "서커스 설치 완료 (4/6)", "color": "gray"}]
schedule function bw:step/library/load 10t
