forceload add 1294 -106 1400 106
forceload add 1401 -106 1506 106
schedule function bw:step/circus/try 40t
