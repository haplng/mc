forceload add 1286 -114 1400 114
forceload add 1401 -114 1514 114
schedule function bw:step/circus/try 40t
