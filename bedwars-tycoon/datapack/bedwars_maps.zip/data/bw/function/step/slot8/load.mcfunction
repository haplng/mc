forceload add 2880 -120 3000 120
forceload add 3001 -120 3120 120
schedule function bw:step/slot8/try 40t
