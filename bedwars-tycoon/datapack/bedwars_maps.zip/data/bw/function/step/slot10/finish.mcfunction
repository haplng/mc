kill @e[type=item,x=3672,y=25,z=-128,dx=256,dy=65,dz=256]
kill @e[type=falling_block,x=3672,y=25,z=-128,dx=256,dy=65,dz=256]
forceload remove 3672 -128 3800 128
forceload remove 3801 -128 3928 128
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "안 쓰는 예전 맵 자리 비움 (4/5)", "color": "gray"}]
schedule function bw:step/slot11/load 10t
