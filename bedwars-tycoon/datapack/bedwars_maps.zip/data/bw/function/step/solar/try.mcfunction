forceload add 3672 -128 3800 128
forceload add 3801 -128 3928 128
execute unless loaded 3672 64 -128 run return run schedule function bw:step/solar/try 20t
execute unless loaded 3928 64 -128 run return run schedule function bw:step/solar/try 20t
execute unless loaded 3672 64 128 run return run schedule function bw:step/solar/try 20t
execute unless loaded 3928 64 128 run return run schedule function bw:step/solar/try 20t
execute unless loaded 3800 64 0 run return run schedule function bw:step/solar/try 20t
kill @e[type=!player,tag=bw,x=3672,y=25,z=-128,dx=256,dy=65,dz=256]
execute if score #wipe bw matches 1 run function bw:step/solar/wipe
place template bw:solar 3673 35 -127
schedule function bw:step/solar/finish 10t
