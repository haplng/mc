kill @e[type=item,x=2066,y=32,z=-134,dx=268,dy=60,dz=268]
kill @e[type=falling_block,x=2066,y=32,z=-134,dx=268,dy=60,dz=268]
forceload remove 2066 -134 2200 134
forceload remove 2201 -134 2334 134
scoreboard players set #installed bw 6
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "태양계 설치 완료 (6/6)", "color": "gray"}]
function bw:install/done
