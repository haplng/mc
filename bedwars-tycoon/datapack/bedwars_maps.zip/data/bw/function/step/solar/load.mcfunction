forceload add 2066 -134 2200 134
forceload add 2201 -134 2334 134
schedule function bw:step/solar/try 40t
