forceload add 3672 -128 3800 128
forceload add 3801 -128 3928 128
schedule function bw:step/solar/try 40t
