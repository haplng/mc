forceload add 4066 -134 4200 134
forceload add 4201 -134 4334 134
schedule function bw:step/slot11/try 40t
