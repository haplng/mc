kill @e[type=item,x=2088,y=32,z=-112,dx=224,dy=60,dz=224]
kill @e[type=falling_block,x=2088,y=32,z=-112,dx=224,dy=60,dz=224]
forceload remove 2088 -112 2200 112
forceload remove 2201 -112 2312 112
scoreboard players set #installed bw 6
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "축구장 설치 완료 (6/11)", "color": "gray"}]
schedule function bw:step/library/load 10t
