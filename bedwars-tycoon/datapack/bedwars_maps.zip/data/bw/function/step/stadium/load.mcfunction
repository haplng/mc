forceload add 2088 -112 2200 112
forceload add 2201 -112 2312 112
schedule function bw:step/stadium/try 40t
