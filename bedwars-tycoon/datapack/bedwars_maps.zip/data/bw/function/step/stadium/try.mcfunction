forceload add 2088 -112 2200 112
forceload add 2201 -112 2312 112
execute unless loaded 2088 64 -112 run return run schedule function bw:step/stadium/try 20t
execute unless loaded 2312 64 -112 run return run schedule function bw:step/stadium/try 20t
execute unless loaded 2088 64 112 run return run schedule function bw:step/stadium/try 20t
execute unless loaded 2312 64 112 run return run schedule function bw:step/stadium/try 20t
execute unless loaded 2200 64 0 run return run schedule function bw:step/stadium/try 20t
kill @e[type=!player,tag=bw,x=2088,y=32,z=-112,dx=224,dy=60,dz=224]
execute if score #wipe bw matches 1 run function bw:step/stadium/wipe
place template bw:stadium 2095 43 -81
schedule function bw:step/stadium/finish 10t
