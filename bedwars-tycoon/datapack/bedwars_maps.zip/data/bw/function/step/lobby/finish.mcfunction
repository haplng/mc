kill @e[type=item,x=-89,y=10,z=-65,dx=179,dy=104,dz=165]
kill @e[type=falling_block,x=-89,y=10,z=-65,dx=179,dy=104,dz=165]
forceload remove -89 -65 0 100
forceload remove 1 -65 90 100
scoreboard players set #installed bw 1
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "로비 설치 완료 (1/6)", "color": "gray"}]
execute if score #wipe bw matches 1 run schedule function bw:step/slot7/load 10t
execute unless score #wipe bw matches 1 run schedule function bw:step/tea/load 10t
