kill @e[type=item,x=-89,y=10,z=-59,dx=179,dy=86,dz=159]
kill @e[type=falling_block,x=-89,y=10,z=-59,dx=179,dy=86,dz=159]
forceload remove -89 -59 0 100
forceload remove 1 -59 90 100
scoreboard players set #installed bw 1
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "로비 설치 완료 (1/11)", "color": "gray"}]
schedule function bw:step/tea/load 10t
