forceload add -89 -59 0 100
forceload add 1 -59 90 100
execute unless loaded -89 64 -59 run return run schedule function bw:step/lobby/try 20t
execute unless loaded 90 64 -59 run return run schedule function bw:step/lobby/try 20t
execute unless loaded -89 64 100 run return run schedule function bw:step/lobby/try 20t
execute unless loaded 90 64 100 run return run schedule function bw:step/lobby/try 20t
execute unless loaded 0 64 20 run return run schedule function bw:step/lobby/try 20t
kill @e[type=!player,tag=bw,x=-89,y=10,z=-59,dx=179,dy=86,dz=159]
execute if score #wipe bw matches 1 run function bw:step/lobby/wipe
place template bw:lobby -88 11 -58
execute if score #first bw matches 1 as @a run function bw:go/lobby
effect clear @a minecraft:slow_falling
schedule function bw:step/lobby/finish 10t
