forceload add -89 -65 0 100
forceload add 1 -65 90 100
execute unless loaded -89 64 -65 run return run schedule function bw:step/lobby/try 20t
execute unless loaded 90 64 -65 run return run schedule function bw:step/lobby/try 20t
execute unless loaded -89 64 100 run return run schedule function bw:step/lobby/try 20t
execute unless loaded 90 64 100 run return run schedule function bw:step/lobby/try 20t
execute unless loaded 0 64 17 run return run schedule function bw:step/lobby/try 20t
kill @e[type=!player,tag=bw,x=-89,y=10,z=-65,dx=179,dy=104,dz=165]
execute if score #wipe bw matches 1 run function bw:step/lobby/wipe
place template bw:lobby -80 21 -64
summon minecraft:villager -24.5 65 22.5 {NoAI:1b,Invulnerable:1b,Silent:1b,PersistenceRequired:1b,CanPickUpLoot:0b,CustomNameVisible:1b,CustomName:{text:"업그레이드",color:"gold",bold:1b},VillagerData:{type:"minecraft:plains",profession:"minecraft:cleric",level:5},Offers:{Recipes:[]},Rotation:[-90.0f,0f],Tags:["bw","bw.npc","bw.npc.unlock"]}
execute if score #first bw matches 1 as @a run function bw:go/lobby
effect clear @a minecraft:slow_falling
schedule function bw:step/lobby/finish 10t
