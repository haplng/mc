forceload add -89 -59 0 100
forceload add 1 -59 90 100
schedule function bw:step/lobby/try 40t
