forceload add -89 -65 0 100
forceload add 1 -65 90 100
schedule function bw:step/lobby/try 40t
