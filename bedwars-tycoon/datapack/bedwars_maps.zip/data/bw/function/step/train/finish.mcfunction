kill @e[type=item,x=1691,y=35,z=-109,dx=218,dy=46,dz=218]
kill @e[type=falling_block,x=1691,y=35,z=-109,dx=218,dy=46,dz=218]
forceload remove 1691 -109 1800 109
forceload remove 1801 -109 1909 109
scoreboard players set #installed bw 5
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "기차 설치 완료 (5/11)", "color": "gray"}]
schedule function bw:step/stadium/load 10t
