forceload add 1691 -109 1800 109
forceload add 1801 -109 1909 109
execute unless loaded 1691 64 -109 run return run schedule function bw:step/train/try 20t
execute unless loaded 1909 64 -109 run return run schedule function bw:step/train/try 20t
execute unless loaded 1691 64 109 run return run schedule function bw:step/train/try 20t
execute unless loaded 1909 64 109 run return run schedule function bw:step/train/try 20t
execute unless loaded 1800 64 0 run return run schedule function bw:step/train/try 20t
kill @e[type=!player,tag=bw,x=1691,y=35,z=-109,dx=218,dy=46,dz=218]
execute if score #wipe bw matches 1 run function bw:step/train/wipe
place template bw:train 1697 54 -103
schedule function bw:step/train/finish 10t
