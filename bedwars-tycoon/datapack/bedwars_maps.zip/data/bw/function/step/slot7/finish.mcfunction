kill @e[type=item,x=2483,y=34,z=-117,dx=234,dy=51,dz=234]
kill @e[type=falling_block,x=2483,y=34,z=-117,dx=234,dy=51,dz=234]
forceload remove 2483 -117 2600 117
forceload remove 2601 -117 2717 117
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "안 쓰는 예전 맵 자리 비움 (1/5)", "color": "gray"}]
schedule function bw:step/slot8/load 10t
