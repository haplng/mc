forceload add 4066 -134 4200 134
forceload add 4201 -134 4334 134
execute unless loaded 4066 64 -134 run return run schedule function bw:step/pirate/try 20t
execute unless loaded 4334 64 -134 run return run schedule function bw:step/pirate/try 20t
execute unless loaded 4066 64 134 run return run schedule function bw:step/pirate/try 20t
execute unless loaded 4334 64 134 run return run schedule function bw:step/pirate/try 20t
execute unless loaded 4200 64 0 run return run schedule function bw:step/pirate/try 20t
kill @e[type=!player,tag=bw,x=4066,y=28,z=-134,dx=268,dy=65,dz=268]
execute if score #wipe bw matches 1 run function bw:step/pirate/wipe
place template bw:pirate 4067 35 -133
schedule function bw:step/pirate/finish 10t
