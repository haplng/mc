kill @e[type=item,x=4066,y=28,z=-134,dx=268,dy=65,dz=268]
kill @e[type=falling_block,x=4066,y=28,z=-134,dx=268,dy=65,dz=268]
forceload remove 4066 -134 4200 134
forceload remove 4201 -134 4334 134
scoreboard players set #installed bw 11
tellraw @a [{"text": "[배드워즈] ", "color": "gold"}, {"text": "해적 설치 완료 (11/11)", "color": "gray"}]
function bw:install/done
