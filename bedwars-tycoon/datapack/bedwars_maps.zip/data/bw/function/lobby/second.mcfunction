scoreboard players set #lt bw 0
effect give @a minecraft:night_vision infinite 0 true
effect give @a[gamemode=!creative,gamemode=!spectator] minecraft:saturation infinite 0 true
scoreboard players add @a bw.coins 0
scoreboard players add @a bw.stage 0
scoreboard players add @a bw.wins 0
execute as @a[tag=!bw.init] run function bw:lobby/init
execute as @a[tag=bw.play] run function bw:game/leave
scoreboard players set #l7 bw.lob 7
scoreboard players display name #l7 bw.lob [{text:""},{text:" "}]
scoreboard players display numberformat #l7 bw.lob blank
scoreboard players set #l6 bw.lob 6
scoreboard players display name #l6 bw.lob [{text:""},{text:"코인: ",color:"white"},{score:{name:"@a[limit=1,sort=arbitrary]",objective:"bw.coins"},color:"gold"}]
scoreboard players display numberformat #l6 bw.lob blank
scoreboard players set #l5 bw.lob 5
scoreboard players display name #l5 bw.lob [{text:""},{text:"목표: ",color:"white"},{score:{name:"#goal",objective:"bw"},color:"yellow"}]
scoreboard players display numberformat #l5 bw.lob blank
scoreboard players set #l4 bw.lob 4
scoreboard players display name #l4 bw.lob [{text:""},{text:"  "}]
scoreboard players display numberformat #l4 bw.lob blank
scoreboard players set #l3 bw.lob 3
scoreboard players display name #l3 bw.lob [{text:""},{text:"단계: ",color:"white"},{score:{name:"@a[limit=1,sort=arbitrary]",objective:"bw.stage"},color:"aqua"}]
scoreboard players display numberformat #l3 bw.lob blank
scoreboard players set #l2 bw.lob 2
scoreboard players display name #l2 bw.lob [{text:""},{text:"승리: ",color:"white"},{score:{name:"@a[limit=1,sort=arbitrary]",objective:"bw.wins"},color:"green"}]
scoreboard players display numberformat #l2 bw.lob blank
scoreboard players set #l1 bw.lob 1
scoreboard players display name #l1 bw.lob [{text:""},{text:"   "}]
scoreboard players display numberformat #l1 bw.lob blank
scoreboard objectives setdisplay sidebar bw.lob
execute as @a[tag=!bw.ended] if score @s bw.coins >= #goal bw at @s run function bw:lobby/ending
