execute if score @s bw.gcd matches 1.. run return 0
scoreboard players set @s bw.gcd 60
$title @s actionbar [{text:"$(name) 맵은 잠겨 있어 · ",color:"red"},{text:"$(price) 코인",color:"gold"}]
$tellraw @s [{text:"[배드워즈 타이쿤] ",color:"gold"},{text:"$(name)",color:"aqua"},{text:" 맵은 아직 잠겨 있어. 업그레이드 가게 상자 맨 아랫줄에서 ",color:"white"},{text:"$(price) 코인",color:"gold"},{text:"으로 해금할 수 있어.",color:"white"}]
playsound minecraft:block.chest.locked master @s ~ ~ ~ 0.8 1
