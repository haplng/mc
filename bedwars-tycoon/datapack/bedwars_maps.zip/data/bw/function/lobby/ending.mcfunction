tag @s add bw.ended
title @s times 10 140 30
title @s subtitle [{text:""},{text:"코인 ",color:"gray"},{score:{name:"@s",objective:"bw.coins"},color:"gold"},{text:"개를 모았어!",color:"gray"}]
title @s title {text:"엔딩!",color:"gold",bold:true}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
summon minecraft:firework_rocket ~2 ~1 ~ {LifeTime:22,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"large_ball",colors:[I;16766720,16711680],fade_colors:[I;16777215],has_twinkle:true}]}}}}
summon minecraft:firework_rocket ~-2 ~1 ~1 {LifeTime:28,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"star",colors:[I;65535,65280],fade_colors:[I;16777215],has_twinkle:true}]}}}}
summon minecraft:firework_rocket ~ ~1 ~-2 {LifeTime:34,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"burst",colors:[I;16711935,255],fade_colors:[I;16777215],has_twinkle:true}]}}}}
tellraw @a [{text:""},{text:"\n★ ",color:"gold"},{selector:"@s"},{text:"이(가) 목표 코인을 다 모았어. 배드워즈 타이쿤 클리어!\n",color:"yellow"},{text:"   승리 ",color:"gray"},{score:{name:"@s",objective:"bw.wins"},color:"green"},{text:"번 · ",color:"gray"},{score:{name:"@s",objective:"bw.stage"},color:"aqua"},{text:"단계. 계속 플레이해도 돼.\n",color:"gray"}]
