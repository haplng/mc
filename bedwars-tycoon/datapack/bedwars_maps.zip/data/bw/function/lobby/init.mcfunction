tag @s add bw.init
tag @s add bw.m.tea
tag @s add bw.u.wool
tag @s add bw.u.stone_sword
tag @s add bw.u.shears
tag @s add bw.u.pick
tellraw @s [{text:""},{text:"[배드워즈 타이쿤] ",color:"gold"},{text:"성문으로 들어가면 게임이 시작돼. 이기면 코인을 받고, 스폰 서쪽 업그레이드 가게의 상자에서 코인으로 상점 물건과 맵을 해금해. ",color:"white"},{score:{name:"#goal",objective:"bw"},color:"yellow"},{text:" 코인을 모으면 엔딩!",color:"yellow"}]
function bw:hack/apply
