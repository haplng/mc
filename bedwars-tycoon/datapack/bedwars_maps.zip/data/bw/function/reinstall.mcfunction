function bw:upgrade/start
