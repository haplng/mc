execute store result score #n jv run data get storage jb:wk hl[-1].n
data remove storage jb:wk hl[-1]
scoreboard players set #txt jv 2
function jb:hist/calc
data modify storage jb:wk hx set value {bn:{text:"꽝",color:"dark_gray"}}
data modify storage jb:wk hx.ns set from storage jb:wk r.ns
execute store result storage jb:wk hx.n int 1 run scoreboard players get #n jv
execute store result storage jb:wk hx.i int 1 run scoreboard players get #bid jv
execute if score #bid jv matches 1.. run function jb:hist/bn with storage jb:wk hx
function jb:hist/tiphead
data modify storage jb:wk hx.bl set from storage jb:wk bl
function jb:hist/ent with storage jb:wk hx
scoreboard players add #hi jv 1
function jb:hist/take
