$data modify storage jb:wk hx.bn set from storage jb:hn h$(i).n
