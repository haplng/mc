execute store result storage jb:wk th.k int 1 run scoreboard players get #nh jv
scoreboard players operation #fn jv = #pay jv
function jb:sys/comma
data modify storage jb:wk th.c set from storage jb:wk cm.o
data modify storage jb:wk th.ns set from storage jb:wk r.ns
function jb:hist/tiphead2 with storage jb:wk th
