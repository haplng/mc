scoreboard players operation #hpg jv = #m jv
scoreboard players remove #hpg jv 3000
function jb:hist/page
function jb:snd/play {s:"minecraft:item.book.page_turn",b:60,p:1}
