execute if score #hi jv matches ..19 if data storage jb:wk hl[-1] run function jb:hist/take2
