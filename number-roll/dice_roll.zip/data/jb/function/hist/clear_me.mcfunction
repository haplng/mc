execute store result storage jb:wk hq.pid int 1 run scoreboard players get @s jb.pid
function jb:hist/clear2 with storage jb:wk hq
