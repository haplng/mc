scoreboard players operation #sq jv = @s jb.srch
scoreboard players set @s jb.srch -1
execute if score #sq jv matches 1000000000.. run return run function jb:snd/play {s:"minecraft:block.note_block.bass",b:70,p:0.7}
scoreboard players operation #n jv = #sq jv
scoreboard players set #txt jv 1
function jb:hist/calc
function jb:vis/build
data modify storage jb:wk sd set value {q:"$(q)"}
data modify storage jb:wk sd.v set from storage jb:wk vis
data modify storage jb:wk sd.ns set from storage jb:wk r.ns
execute store result storage jb:wk sd.n int 1 run scoreboard players get #sq jv
execute store result storage jb:wk sd.k int 1 run scoreboard players get #nh jv
scoreboard players operation #fn jv = #pay jv
function jb:sys/comma
data modify storage jb:wk sd.c set from storage jb:wk cm.o
execute store result storage jb:wk sd.pid int 1 run scoreboard players get @s jb.pid
execute if score #nh jv matches 0 run data modify storage jb:wk bl append value {"text": "\n(없음)", "color": "dark_gray"}
execute unless score @s jb.unl matches 10.. run data modify storage jb:wk bl append value {"text": "\n\n🔒 전설·신화 족보는 코인 상점에서 해금하면 보여요", "color": "dark_gray"}
data modify storage jb:wk bl prepend value {"text": "걸린 족보", "color": "gray"}
data modify storage jb:wk sd.dl set from storage jb:wk bl
data modify storage jb:wk sd.rec set value {"text": "", "color": "gray"}
function jb:hist/find with storage jb:wk sd
function jb:hist/detail with storage jb:wk sd
function jb:snd/play {s:"minecraft:ui.button.click",b:60,p:1.2}
