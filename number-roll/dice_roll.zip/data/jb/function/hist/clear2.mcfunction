$data remove storage jb:hist h.p$(pid)
$data remove storage jb:fd f.p$(pid)
$data remove storage jb:ms m.p$(pid)
