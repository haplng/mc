data remove storage jb:wk hl[-1]
scoreboard players remove #hs jv 1
function jb:hist/skip
