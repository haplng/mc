scoreboard players set #hpg jv 0
function jb:hist/page
function jb:snd/play {s:"minecraft:item.book.page_turn",b:60,p:1}
