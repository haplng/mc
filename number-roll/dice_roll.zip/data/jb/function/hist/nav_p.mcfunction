$data modify storage jb:wk hd.acts append value {"label": {"text": "◀ 최근", "color": "green"}, "width": 200, "action": {"type": "minecraft:run_command", "command": "/trigger jb.menu set $(pv)"}}
