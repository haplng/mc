execute if score #hs jv matches 1.. if data storage jb:wk hl[-1] run function jb:hist/skip2
