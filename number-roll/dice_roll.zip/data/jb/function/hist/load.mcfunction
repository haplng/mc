$execute if data storage jb:hist h.p$(pid) run data modify storage jb:wk hl set from storage jb:hist h.p$(pid)
