function jb:num/d9
function jb:roll/pre
function jb:hand/eval
scoreboard players set #cm jv 2
data modify storage jb:wk bl set value []
data modify storage jb:wk rvl set value []
execute if score #txt jv matches 1 run function jb:roll/txt_pre
function jb:roll/commit
function jb:num/ns
