data remove storage jb:wk hm
$data modify storage jb:wk hm set from storage jb:hist h.p$(pid)[{n:$(n)}]
execute if data storage jb:wk hm.n run data modify storage jb:wk sd.rec set value {"text": "   ✔ 굴려 본 숫자", "color": "green"}
