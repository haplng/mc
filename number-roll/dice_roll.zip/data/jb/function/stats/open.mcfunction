data modify storage jb:wk st set value {}
scoreboard players operation #s jv = @s jb.ptk
scoreboard players operation #s jv /= #c20 jv
scoreboard players operation #h jv = #s jv
scoreboard players operation #h jv /= #c3600 jv
scoreboard players operation #s jv %= #c3600 jv
scoreboard players operation #s jv /= #c60 jv
execute store result storage jb:wk st.h int 1 run scoreboard players get #h jv
execute store result storage jb:wk st.m int 1 run scoreboard players get #s jv
scoreboard players operation #fn jv = @s jb.rolls
function jb:sys/comma
data modify storage jb:wk st.r set from storage jb:wk cm.o
execute store result storage jb:wk st.f int 1 run scoreboard players get @s jb.found
execute store result storage jb:wk st.sx int 1 run scoreboard players get @s jb.stot
execute store result storage jb:wk st.s5 int 1 run scoreboard players get @s jb.s5n
scoreboard players operation #fn jv = @s jb.rr
function jb:sys/comma
data modify storage jb:wk st.rr set from storage jb:wk cm.o
execute store result storage jb:wk st.md int 1 run scoreboard players get @s jb.mdone
execute store result storage jb:wk st.jo int 1 run scoreboard players get @s jb.jown
execute store result storage jb:wk st.mn int 1 run scoreboard players get @s jb.mxn
scoreboard players set #fh jv 0
scoreboard players operation #fl jv = @s jb.mxr
execute if score #fl jv matches 1000000000.. run scoreboard players set #fh jv 1
execute if score #fl jv matches 1000000000.. run scoreboard players remove #fl jv 1000000000
execute if score @s jb.mxr matches 2000000000.. run scoreboard players set #fh jv 2
execute if score @s jb.mxr matches 2000000000.. run scoreboard players set #fl jv 0
function jb:sys/big
data modify storage jb:wk st.mr set from storage jb:wk cm.o
data modify storage jb:wk st.mx set value ""
execute if score @s jb.mxr matches 2000000000.. run data modify storage jb:wk st.mx set value " 이상"
scoreboard players operation #fh jv = @s jb.rch
scoreboard players operation #fl jv = @s jb.rc
function jb:sys/big
data modify storage jb:wk st.rc set from storage jb:wk cm.o
scoreboard players operation #fh jv = @s jb.tch
scoreboard players operation #fl jv = @s jb.tcl
function jb:sys/big
data modify storage jb:wk st.tc set from storage jb:wk cm.o
data modify storage jb:wk st.b set value {text:"아직 없음",color:"gray"}
data modify storage jb:wk st.bn set value ""
execute if score @s jb.topid matches 1.. run function jb:stats/top
function jb:stats/show with storage jb:wk st
function jb:snd/play {s:"minecraft:item.book.page_turn",b:60,p:1}
