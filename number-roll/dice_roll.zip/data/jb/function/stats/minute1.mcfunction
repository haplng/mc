scoreboard players operation @s jb.rc = @s jb.wc
scoreboard players operation @s jb.rch = @s jb.wch
scoreboard players operation @s jb.rr = @s jb.wr
scoreboard players set @s jb.wc 0
scoreboard players set @s jb.wch 0
scoreboard players set @s jb.wr 0
execute if score @s jb.pid matches 1.. run function jb:ms/refresh
