scoreboard players operation @s jb.wc += #cgl jv
execute if score @s jb.wc matches 1000000000.. run scoreboard players add @s jb.wch 1
execute if score @s jb.wc matches 1000000000.. run scoreboard players remove @s jb.wc 1000000000
scoreboard players operation @s jb.wch += #cgh jv
scoreboard players operation @s jb.wr += #sen jv
scoreboard players operation @s jb.tcl += #cgl jv
execute if score @s jb.tcl matches 1000000000.. run scoreboard players add @s jb.tch 1
execute if score @s jb.tcl matches 1000000000.. run scoreboard players remove @s jb.tcl 1000000000
scoreboard players operation @s jb.tch += #cgh jv
