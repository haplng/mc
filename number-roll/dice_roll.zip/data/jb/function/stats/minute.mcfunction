scoreboard players set #stt jv 0
execute as @a run function jb:stats/minute1
