$data modify storage jb:wk st.b set from storage jb:hn h$(i).n
