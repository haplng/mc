execute store result storage jb:wk bi.i int 1 run scoreboard players get @s jb.topid
function jb:stats/top2 with storage jb:wk bi
scoreboard players operation #n jv = @s jb.topn
function jb:num/d9
function jb:num/ns
data modify storage jb:wk st.bn set from storage jb:wk r.ns
