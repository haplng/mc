$execute at @s run playsound $(s) master @s ~ ~ ~ $(v) $(p)
