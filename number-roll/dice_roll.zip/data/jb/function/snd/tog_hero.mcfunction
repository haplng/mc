scoreboard players add @s jb.mhero 1
execute if score @s jb.mhero matches 2.. run scoreboard players set @s jb.mhero 0
function jb:snd/play {s:"minecraft:block.note_block.chime",b:60,p:1.6}
function jb:menu/sound
