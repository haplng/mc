scoreboard players operation #va jv = @s jb.vset
scoreboard players operation #va jv %= #c10 jv
scoreboard players operation @s jb.vol = @s jb.vset
scoreboard players operation @s jb.vol /= #c10 jv
scoreboard players set @s jb.vset -1
execute if score @s jb.vol matches 101.. run scoreboard players set @s jb.vol 100
execute if score @s jb.vol matches 0 run scoreboard players set @s jb.muted 1
execute if score #va jv matches 1 run return run function jb:snd/tog_hero
execute if score #va jv matches 2 run return run function jb:snd/tog_fw
execute if score #va jv matches 3 run return run function jb:snd/tog_chat
execute if score #va jv matches 4 run return run function jb:menu/main
execute if score #va jv matches 5 run return run dialog clear @s
function jb:snd/play {s:"minecraft:block.note_block.chime",b:60,p:1.6}
function jb:menu/sound
