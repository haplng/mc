scoreboard players add @s jb.achat 1
execute if score @s jb.achat matches 5.. run scoreboard players set @s jb.achat 0
function jb:snd/play {s:"minecraft:block.note_block.chime",b:60,p:1.6}
function jb:menu/sound
