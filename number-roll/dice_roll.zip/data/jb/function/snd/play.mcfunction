execute unless score @s jb.vol matches 0..100 run scoreboard players set @s jb.vol 100
$scoreboard players set #sv jv $(b)
scoreboard players operation #sv jv *= @s jb.vol
execute store result storage jb:wk sv.v float 0.0001 run scoreboard players get #sv jv
$data modify storage jb:wk sv.s set value "$(s)"
$data modify storage jb:wk sv.p set value $(p)f
execute if score @s jb.vol matches 1.. run function jb:snd/play2 with storage jb:wk sv
