execute store result storage jb:wk nd.d1 int 1 run scoreboard players get #d1 jv
execute store result storage jb:wk nd.d2 int 1 run scoreboard players get #d2 jv
execute store result storage jb:wk nd.d3 int 1 run scoreboard players get #d3 jv
execute store result storage jb:wk nd.d4 int 1 run scoreboard players get #d4 jv
execute store result storage jb:wk nd.d5 int 1 run scoreboard players get #d5 jv
execute store result storage jb:wk nd.d6 int 1 run scoreboard players get #d6 jv
execute store result storage jb:wk nd.d7 int 1 run scoreboard players get #d7 jv
execute store result storage jb:wk nd.d8 int 1 run scoreboard players get #d8 jv
execute store result storage jb:wk nd.d9 int 1 run scoreboard players get #d9 jv
function jb:num/ns2 with storage jb:wk nd
