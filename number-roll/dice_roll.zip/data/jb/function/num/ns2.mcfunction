$data modify storage jb:wk r.ns set value "$(d1)$(d2)$(d3)$(d4)$(d5)$(d6)$(d7)$(d8)$(d9)"
