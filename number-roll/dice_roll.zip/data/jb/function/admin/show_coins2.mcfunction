$tellraw @s [{"text": "[숫자 굴리기] ", "color": "yellow"}, {"text": "코인: ", "color": "white"}, {"text": "$(o)⛃", "color": "gold", "bold": true}]
