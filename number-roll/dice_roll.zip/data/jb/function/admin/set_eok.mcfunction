$scoreboard players set #cgh jv $(n)
execute if score #cgh jv matches ..-1 run scoreboard players set #cgh jv 0
scoreboard players operation #cgl jv = #cgh jv
scoreboard players operation #cgl jv %= #c10 jv
scoreboard players operation #cgl jv *= #c100000000 jv
scoreboard players operation #cgh jv /= #c10 jv
scoreboard players set @s jb.coins 0
scoreboard players set @s jb.cb 0
function jb:sys/addc2
function jb:admin/show_coins
