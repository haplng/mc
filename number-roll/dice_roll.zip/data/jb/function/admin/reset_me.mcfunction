function jb:hist/clear_me
function jb:player/bb_rm_me
advancement revoke @s from jb:root
scoreboard players reset @s jb.pid
tellraw @s {text:"[숫자 굴리기] 내 기록을 초기화했어요.",color:"yellow"}
