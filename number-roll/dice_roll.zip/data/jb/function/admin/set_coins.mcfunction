$scoreboard players set #cg jv $(n)
execute if score #cg jv matches ..-1 run scoreboard players set #cg jv 0
scoreboard players set @s jb.coins 0
scoreboard players set @s jb.cb 0
function jb:sys/addc
function jb:admin/show_coins
