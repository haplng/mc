scoreboard players operation #fh jv = @s jb.cb
scoreboard players operation #fl jv = @s jb.coins
function jb:sys/big
function jb:admin/show_coins2 with storage jb:wk cm
