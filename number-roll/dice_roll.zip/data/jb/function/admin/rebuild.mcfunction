function jb:world/prepare
