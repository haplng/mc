scoreboard players set @s jb.u1 10
scoreboard players set @s jb.u2 10
scoreboard players set @s jb.u3 7
scoreboard players set @s jb.u4 10
scoreboard players set @s jb.e1 5
scoreboard players set @s jb.e2 5
scoreboard players set @s jb.e4 5
scoreboard players set @s jb.e5 3
scoreboard players set @s jb.unl 10
scoreboard players set @s jb.jslot 4
scoreboard players set @s jb.autoon 1
function jb:ms/init
function jb:ms/side
function jb:player/items
scoreboard players set #bdt jv 99
tellraw @s {text:"[숫자 굴리기] 업그레이드·강화·해금을 최대로 만들었어요.",color:"yellow"}
