scoreboard players set #cg jv 100000
function jb:sys/addc
function jb:admin/show_coins
