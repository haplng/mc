data modify storage jb:wk bn set value [""]
execute store result storage jb:wk bc.c int 1 run scoreboard players get @s jb.ft0
function jb:world/bdh0 with storage jb:wk bc
scoreboard players set #ft jv 0
execute if score @s jb.h1 matches 1.. run function jb:world/bd/1
execute if score @s jb.h2 matches 1.. run function jb:world/bd/2
execute if score @s jb.h3 matches 1.. run function jb:world/bd/3
execute if score @s jb.h4 matches 1.. run function jb:world/bd/4
execute if score @s jb.h5 matches 1.. run function jb:world/bd/5
execute if score @s jb.h6 matches 1.. run function jb:world/bd/6
execute if score @s jb.h7 matches 1.. run function jb:world/bd/7
execute if score @s jb.h8 matches 1.. run function jb:world/bd/8
execute if score @s jb.h9 matches 1.. run function jb:world/bd/9
execute if score @s jb.h10 matches 1.. run function jb:world/bd/10
execute if score @s jb.h11 matches 1.. run function jb:world/bd/11
execute if score @s jb.h12 matches 1.. run function jb:world/bd/12
execute if score @s jb.h13 matches 1.. run function jb:world/bd/13
execute if score @s jb.h14 matches 1.. run function jb:world/bd/14
execute if score @s jb.h15 matches 1.. run function jb:world/bd/15
execute if score @s jb.h16 matches 1.. run function jb:world/bd/16
execute if score @s jb.h17 matches 1.. run function jb:world/bd/17
execute if score @s jb.h18 matches 1.. run function jb:world/bd/18
execute if score @s jb.h19 matches 1.. run function jb:world/bd/19
execute if score @s jb.h20 matches 1.. run function jb:world/bd/20
execute if score @s jb.h21 matches 1.. run function jb:world/bd/21
execute if score @s jb.h22 matches 1.. run function jb:world/bd/22
execute if score @s jb.h23 matches 1.. run function jb:world/bd/23
execute if score @s jb.h24 matches 1.. run function jb:world/bd/24
execute if score @s jb.h25 matches 1.. run function jb:world/bd/25
execute if score @s jb.h26 matches 1.. run function jb:world/bd/26
execute if score @s jb.h27 matches 1.. run function jb:world/bd/27
execute if score @s jb.h28 matches 1.. run function jb:world/bd/28
execute if score @s jb.h29 matches 1.. run function jb:world/bd/29
execute if score @s jb.h30 matches 1.. run function jb:world/bd/30
execute if score @s jb.h31 matches 1.. run function jb:world/bd/31
execute if score @s jb.h32 matches 1.. run function jb:world/bd/32
execute if score @s jb.h33 matches 1.. run function jb:world/bd/33
execute if score @s jb.h34 matches 1.. run function jb:world/bd/34
execute if score @s jb.h35 matches 1.. run function jb:world/bd/35
execute if score @s jb.h36 matches 1.. run function jb:world/bd/36
execute if score @s jb.h37 matches 1.. run function jb:world/bd/37
execute if score @s jb.h38 matches 1.. run function jb:world/bd/38
execute if score @s jb.h39 matches 1.. run function jb:world/bd/39
execute if score @s jb.h40 matches 1.. run function jb:world/bd/40
execute if score @s jb.h41 matches 1.. run function jb:world/bd/41
execute if score #ft jv matches 0 run data modify storage jb:wk bn set value [{text:"아직 없음",color:"dark_gray"}]
data modify storage jb:wk bnc set value {text:""}
data modify storage jb:wk bnc.extra set from storage jb:wk bn
data modify entity @e[type=text_display,tag=jb.bdn0,limit=1] text set from storage jb:wk bnc
