data modify storage jb:wk bn set value [""]
execute store result storage jb:wk bc.c int 1 run scoreboard players get @s jb.ft5
function jb:world/bdh5 with storage jb:wk bc
scoreboard players set #ft jv 0
execute if score @s jb.h342 matches 1.. run function jb:world/bd/342
execute if score @s jb.h343 matches 1.. run function jb:world/bd/343
execute if score @s jb.h344 matches 1.. run function jb:world/bd/344
execute if score @s jb.h345 matches 1.. run function jb:world/bd/345
execute if score @s jb.h346 matches 1.. run function jb:world/bd/346
execute if score @s jb.h347 matches 1.. run function jb:world/bd/347
execute if score @s jb.h348 matches 1.. run function jb:world/bd/348
execute if score @s jb.h349 matches 1.. run function jb:world/bd/349
execute if score @s jb.h350 matches 1.. run function jb:world/bd/350
execute if score @s jb.h351 matches 1.. run function jb:world/bd/351
execute if score @s jb.h352 matches 1.. run function jb:world/bd/352
execute if score @s jb.h353 matches 1.. run function jb:world/bd/353
execute if score @s jb.h354 matches 1.. run function jb:world/bd/354
execute if score @s jb.h355 matches 1.. run function jb:world/bd/355
execute if score @s jb.h356 matches 1.. run function jb:world/bd/356
execute if score @s jb.h357 matches 1.. run function jb:world/bd/357
execute if score @s jb.h358 matches 1.. run function jb:world/bd/358
execute if score @s jb.h359 matches 1.. run function jb:world/bd/359
execute if score @s jb.h360 matches 1.. run function jb:world/bd/360
execute if score @s jb.h361 matches 1.. run function jb:world/bd/361
execute if score @s jb.h362 matches 1.. run function jb:world/bd/362
execute if score @s jb.h363 matches 1.. run function jb:world/bd/363
execute if score @s jb.h364 matches 1.. run function jb:world/bd/364
execute if score @s jb.h365 matches 1.. run function jb:world/bd/365
execute if score @s jb.h366 matches 1.. run function jb:world/bd/366
execute if score @s jb.h367 matches 1.. run function jb:world/bd/367
execute if score @s jb.h368 matches 1.. run function jb:world/bd/368
execute if score @s jb.h369 matches 1.. run function jb:world/bd/369
execute if score @s jb.h370 matches 1.. run function jb:world/bd/370
execute if score @s jb.h371 matches 1.. run function jb:world/bd/371
execute if score @s jb.h372 matches 1.. run function jb:world/bd/372
execute if score @s jb.h373 matches 1.. run function jb:world/bd/373
execute if score @s jb.h374 matches 1.. run function jb:world/bd/374
execute if score @s jb.h375 matches 1.. run function jb:world/bd/375
execute if score @s jb.h376 matches 1.. run function jb:world/bd/376
execute if score @s jb.h377 matches 1.. run function jb:world/bd/377
execute if score @s jb.h378 matches 1.. run function jb:world/bd/378
execute if score @s jb.h379 matches 1.. run function jb:world/bd/379
execute if score @s jb.h380 matches 1.. run function jb:world/bd/380
execute if score @s jb.h381 matches 1.. run function jb:world/bd/381
execute if score @s jb.h382 matches 1.. run function jb:world/bd/382
execute if score @s jb.h383 matches 1.. run function jb:world/bd/383
execute if score @s jb.h384 matches 1.. run function jb:world/bd/384
execute if score @s jb.h385 matches 1.. run function jb:world/bd/385
execute if score @s jb.h386 matches 1.. run function jb:world/bd/386
execute if score @s jb.h387 matches 1.. run function jb:world/bd/387
execute if score @s jb.h388 matches 1.. run function jb:world/bd/388
execute if score @s jb.h389 matches 1.. run function jb:world/bd/389
execute if score @s jb.h390 matches 1.. run function jb:world/bd/390
execute if score @s jb.h391 matches 1.. run function jb:world/bd/391
execute if score @s jb.h392 matches 1.. run function jb:world/bd/392
execute if score @s jb.h393 matches 1.. run function jb:world/bd/393
execute if score @s jb.h394 matches 1.. run function jb:world/bd/394
execute if score @s jb.h395 matches 1.. run function jb:world/bd/395
execute if score @s jb.h396 matches 1.. run function jb:world/bd/396
execute if score @s jb.h397 matches 1.. run function jb:world/bd/397
execute if score @s jb.h398 matches 1.. run function jb:world/bd/398
execute if score @s jb.h399 matches 1.. run function jb:world/bd/399
execute if score @s jb.h400 matches 1.. run function jb:world/bd/400
execute if score #ft jv matches 0 run data modify storage jb:wk bn set value [{text:"아직 없음",color:"dark_gray"}]
execute unless score @s jb.unl matches 10.. run data modify storage jb:wk bn set value [{text:"🔒 코인 상점에서 해금",color:"dark_gray"}]
data modify storage jb:wk bnc set value {text:""}
data modify storage jb:wk bnc.extra set from storage jb:wk bn
data modify entity @e[type=text_display,tag=jb.bdn5,limit=1] text set from storage jb:wk bnc
