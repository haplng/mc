scoreboard players set #bdt jv 0
execute store result storage jb:wk bh.f int 1 run scoreboard players get @s jb.found
function jb:world/board_h with storage jb:wk bh
function jb:world/bt0
function jb:world/bt1
function jb:world/bt2
function jb:world/bt3
function jb:world/bt4
function jb:world/bt5
