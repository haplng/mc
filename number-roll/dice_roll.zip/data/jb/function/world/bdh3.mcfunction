$data modify entity @e[type=text_display,tag=jb.bdh3,limit=1] text set value [{"text": "영웅  ", "color": "light_purple", "bold": true}, {"text": "$(c)/61", "color": "white", "bold": false}]
