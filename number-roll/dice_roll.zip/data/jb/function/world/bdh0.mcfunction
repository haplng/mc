$data modify entity @e[type=text_display,tag=jb.bdh0,limit=1] text set value [{"text": "흔함  ", "color": "white", "bold": true}, {"text": "$(c)/41", "color": "white", "bold": false}]
