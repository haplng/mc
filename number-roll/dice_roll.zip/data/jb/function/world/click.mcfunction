execute if data entity @s interaction if entity @s[tag=jb.b_roll] on target run function jb:roll/click
data remove entity @s interaction
data remove entity @s attack
