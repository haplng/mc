execute if score #ft jv matches 1.. run data modify storage jb:wk bn append value {"text": " · ", "color": "dark_gray"}
data modify storage jb:wk bn append value {"text": "이 맵이 태어난 해", "color": "aqua"}
scoreboard players add #ft jv 1
