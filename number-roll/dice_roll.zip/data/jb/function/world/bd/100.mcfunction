execute if score #ft jv matches 1.. run data modify storage jb:wk bn append value {"text": " · ", "color": "dark_gray"}
data modify storage jb:wk bn append value {"text": "세 살 버릇 여든까지", "color": "green"}
scoreboard players add #ft jv 1
