execute if score #ft jv matches 1.. run data modify storage jb:wk bn append value {"text": " · ", "color": "dark_gray"}
data modify storage jb:wk bn append value {"text": "도시라솔파미레", "color": "red"}
scoreboard players add #ft jv 1
