execute if score #ft jv matches 1.. run data modify storage jb:wk bn append value {"text": " · ", "color": "dark_gray"}
data modify storage jb:wk bn append value {"text": "에베레스트", "color": "gold"}
scoreboard players add #ft jv 1
