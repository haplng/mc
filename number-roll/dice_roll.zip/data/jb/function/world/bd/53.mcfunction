execute if score #ft jv matches 1.. run data modify storage jb:wk bn append value {"text": " · ", "color": "dark_gray"}
data modify storage jb:wk bn append value {"text": "삼십육계 줄행랑", "color": "green"}
scoreboard players add #ft jv 1
