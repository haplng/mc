execute if score #ft jv matches 1.. run data modify storage jb:wk bn append value {"text": " · ", "color": "dark_gray"}
data modify storage jb:wk bn append value {"text": "칠팔 오십육", "color": "white"}
scoreboard players add #ft jv 1
