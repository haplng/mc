execute if score #ft jv matches 1.. run data modify storage jb:wk bn append value {"text": " · ", "color": "dark_gray"}
data modify storage jb:wk bn append value {"text": "국민 비밀번호", "color": "aqua"}
scoreboard players add #ft jv 1
