execute if score #ft jv matches 1.. run data modify storage jb:wk bn append value {"text": " · ", "color": "dark_gray"}
data modify storage jb:wk bn append value {"text": "수원 왕갈비", "color": "green"}
scoreboard players add #ft jv 1
