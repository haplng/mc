execute if score #ft jv matches 1.. run data modify storage jb:wk bn append value {"text": " · ", "color": "dark_gray"}
data modify storage jb:wk bn append value {"text": "광주 상추튀김", "color": "green"}
scoreboard players add #ft jv 1
