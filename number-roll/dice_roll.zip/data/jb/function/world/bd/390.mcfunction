execute if score #ft jv matches 1.. run data modify storage jb:wk bn append value {"text": " · ", "color": "dark_gray"}
data modify storage jb:wk bn append value {"text": "마인크래프트 탄생", "color": "red"}
scoreboard players add #ft jv 1
