execute if score #ft jv matches 1.. run data modify storage jb:wk bn append value {"text": " · ", "color": "dark_gray"}
data modify storage jb:wk bn append value {"text": "화성 갈 거니까", "color": "red"}
scoreboard players add #ft jv 1
