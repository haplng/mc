execute if score #ft jv matches 1.. run data modify storage jb:wk bn append value {"text": " · ", "color": "dark_gray"}
data modify storage jb:wk bn append value {"text": "출석 체크", "color": "aqua"}
scoreboard players add #ft jv 1
