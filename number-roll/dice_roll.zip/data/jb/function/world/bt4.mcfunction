data modify storage jb:wk bn set value [""]
execute store result storage jb:wk bc.c int 1 run scoreboard players get @s jb.ft4
function jb:world/bdh4 with storage jb:wk bc
scoreboard players set #ft jv 0
execute if score @s jb.h292 matches 1.. run function jb:world/bd/292
execute if score @s jb.h293 matches 1.. run function jb:world/bd/293
execute if score @s jb.h294 matches 1.. run function jb:world/bd/294
execute if score @s jb.h295 matches 1.. run function jb:world/bd/295
execute if score @s jb.h296 matches 1.. run function jb:world/bd/296
execute if score @s jb.h297 matches 1.. run function jb:world/bd/297
execute if score @s jb.h298 matches 1.. run function jb:world/bd/298
execute if score @s jb.h299 matches 1.. run function jb:world/bd/299
execute if score @s jb.h300 matches 1.. run function jb:world/bd/300
execute if score @s jb.h301 matches 1.. run function jb:world/bd/301
execute if score @s jb.h302 matches 1.. run function jb:world/bd/302
execute if score @s jb.h303 matches 1.. run function jb:world/bd/303
execute if score @s jb.h304 matches 1.. run function jb:world/bd/304
execute if score @s jb.h305 matches 1.. run function jb:world/bd/305
execute if score @s jb.h306 matches 1.. run function jb:world/bd/306
execute if score @s jb.h307 matches 1.. run function jb:world/bd/307
execute if score @s jb.h308 matches 1.. run function jb:world/bd/308
execute if score @s jb.h309 matches 1.. run function jb:world/bd/309
execute if score @s jb.h310 matches 1.. run function jb:world/bd/310
execute if score @s jb.h311 matches 1.. run function jb:world/bd/311
execute if score @s jb.h312 matches 1.. run function jb:world/bd/312
execute if score @s jb.h313 matches 1.. run function jb:world/bd/313
execute if score @s jb.h314 matches 1.. run function jb:world/bd/314
execute if score @s jb.h315 matches 1.. run function jb:world/bd/315
execute if score @s jb.h316 matches 1.. run function jb:world/bd/316
execute if score @s jb.h317 matches 1.. run function jb:world/bd/317
execute if score @s jb.h318 matches 1.. run function jb:world/bd/318
execute if score @s jb.h319 matches 1.. run function jb:world/bd/319
execute if score @s jb.h320 matches 1.. run function jb:world/bd/320
execute if score @s jb.h321 matches 1.. run function jb:world/bd/321
execute if score @s jb.h322 matches 1.. run function jb:world/bd/322
execute if score @s jb.h323 matches 1.. run function jb:world/bd/323
execute if score @s jb.h324 matches 1.. run function jb:world/bd/324
execute if score @s jb.h325 matches 1.. run function jb:world/bd/325
execute if score @s jb.h326 matches 1.. run function jb:world/bd/326
execute if score @s jb.h327 matches 1.. run function jb:world/bd/327
execute if score @s jb.h328 matches 1.. run function jb:world/bd/328
execute if score @s jb.h329 matches 1.. run function jb:world/bd/329
execute if score @s jb.h330 matches 1.. run function jb:world/bd/330
execute if score @s jb.h331 matches 1.. run function jb:world/bd/331
execute if score @s jb.h332 matches 1.. run function jb:world/bd/332
execute if score @s jb.h333 matches 1.. run function jb:world/bd/333
execute if score @s jb.h334 matches 1.. run function jb:world/bd/334
execute if score @s jb.h335 matches 1.. run function jb:world/bd/335
execute if score @s jb.h336 matches 1.. run function jb:world/bd/336
execute if score @s jb.h337 matches 1.. run function jb:world/bd/337
execute if score @s jb.h338 matches 1.. run function jb:world/bd/338
execute if score @s jb.h339 matches 1.. run function jb:world/bd/339
execute if score @s jb.h340 matches 1.. run function jb:world/bd/340
execute if score @s jb.h341 matches 1.. run function jb:world/bd/341
execute if score #ft jv matches 0 run data modify storage jb:wk bn set value [{text:"아직 없음",color:"dark_gray"}]
execute unless score @s jb.unl matches 6.. run data modify storage jb:wk bn set value [{text:"🔒 코인 상점에서 해금",color:"dark_gray"}]
data modify storage jb:wk bnc set value {text:""}
data modify storage jb:wk bnc.extra set from storage jb:wk bn
data modify entity @e[type=text_display,tag=jb.bdn4,limit=1] text set from storage jb:wk bnc
