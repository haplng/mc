forceload add -32 -32 32 32
tp @s 0.5 160 4.5 180 0
effect give @s minecraft:slow_falling 10 0 true
schedule function jb:world/build 40t
