$data modify entity @e[type=text_display,tag=jb.bdh4,limit=1] text set value [{"text": "전설  ", "color": "gold", "bold": true}, {"text": "$(c)/50", "color": "white", "bold": false}]
