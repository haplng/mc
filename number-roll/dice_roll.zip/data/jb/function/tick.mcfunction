execute as @a[scores={jb.pid=1..}] unless score @s jb.dv matches 3 run function jb:player/wipe
execute as @a unless score @s jb.pid matches 1.. run function jb:player/init
execute as @a[scores={jb.use=1..}] run function jb:player/use
execute as @e[type=interaction,tag=jb.btn] run function jb:world/click
execute as @a[scores={jb.menu=1..}] run function jb:menu/trigger
scoreboard players enable @a jb.menu
execute as @a unless score @s jb.srch = @s jb.srch run scoreboard players set @s jb.srch -1
execute as @a[scores={jb.srch=0..}] run function jb:hist/search
scoreboard players enable @a jb.srch
execute as @a unless score @s jb.vset = @s jb.vset run scoreboard players set @s jb.vset -1
execute as @a[scores={jb.vset=0..}] run function jb:snd/vset
scoreboard players enable @a jb.vset
execute as @e[type=item,nbt=!{PickupDelay:32767s}] at @s run function jb:player/dropped
scoreboard players remove @a[scores={jb.alert=1..}] jb.alert 1
scoreboard players remove @a[scores={jb.hold=1..}] jb.hold 1
execute as @a[scores={jb.hold=1..,jb.state=3}] run function jb:roll/start
execute as @a[scores={jb.hold=1..,jb.state=0}] run function jb:roll/start
execute as @a[scores={jb.state=1..}] run function jb:roll/tick
execute as @a[scores={jb.autoon=1,jb.u2=1..}] run function jb:roll/autotick
scoreboard players add #hud jv 1
execute if score #hud jv matches 4.. as @a[scores={jb.pid=1..}] run function jb:player/hud
execute if score #hud jv matches 4.. run scoreboard players set #hud jv 0
scoreboard players add #pulse jv 1
execute if score #pulse jv matches 40.. as @a run function jb:player/pulse
execute if score #pulse jv matches 40.. run scoreboard players set #pulse jv 0
execute as @a[y=-100,dy=240] if score #built jv matches 1 run function jb:player/fell
execute if score #built jv matches 1 unless score #bver jv matches 14 run function jb:world/build
scoreboard players add #prt jv 1
execute if score #prt jv matches 10.. run function jb:world/slow
scoreboard players add #rbt jv 1
execute if score #rbd jv matches 1.. if score #rbt jv matches 10.. run function jb:rb/draw
execute as @a[scores={jb.fwt=1..}] run function jb:fx/tick
scoreboard players remove @a[scores={jb.asc=1..}] jb.asc 1
scoreboard players add #advt jv 1
execute if score #advt jv matches 20.. run function jb:adv/tick
scoreboard players add @a[scores={jb.rolls=1..}] jb.ptk 1
scoreboard players add #stt jv 1
execute if score #stt jv matches 1200.. run function jb:stats/minute
