$scoreboard players display name jb_m1 jb.side [{"text": "쉬움  ", "color": "green"}, {"text": "$(s)", "color": "white", "bold": true}, {"text": "   +$(r)⛃", "color": "gold"}]
