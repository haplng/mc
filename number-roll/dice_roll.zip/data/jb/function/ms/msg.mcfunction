$data modify storage jb:wk mdn.s set from storage jb:ms m.p$(pid).s$(i)
function jb:ms/msg2 with storage jb:wk mdn
