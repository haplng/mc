scoreboard players operation #fh jv = @s jb.mcb1
scoreboard players operation #fl jv = @s jb.mc1
function jb:sys/short
data modify storage jb:wk sd.r set from storage jb:wk sh.o
data modify storage jb:wk sd.i set value 1
function jb:ms/side_s with storage jb:wk sd
scoreboard players set jb_m1 jb.side 3
function jb:ms/side1b with storage jb:wk sd
