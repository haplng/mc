execute if score #d1 jv = @s jb.m2a if score #d2 jv = @s jb.m2b if score #d3 jv = @s jb.m2c if score #d4 jv = @s jb.m2d run return run function jb:ms/done2
execute if score #d2 jv = @s jb.m2a if score #d3 jv = @s jb.m2b if score #d4 jv = @s jb.m2c if score #d5 jv = @s jb.m2d run return run function jb:ms/done2
execute if score #d3 jv = @s jb.m2a if score #d4 jv = @s jb.m2b if score #d5 jv = @s jb.m2c if score #d6 jv = @s jb.m2d run return run function jb:ms/done2
execute if score #d4 jv = @s jb.m2a if score #d5 jv = @s jb.m2b if score #d6 jv = @s jb.m2c if score #d7 jv = @s jb.m2d run return run function jb:ms/done2
execute if score #d5 jv = @s jb.m2a if score #d6 jv = @s jb.m2b if score #d7 jv = @s jb.m2c if score #d8 jv = @s jb.m2d run return run function jb:ms/done2
execute if score #d6 jv = @s jb.m2a if score #d7 jv = @s jb.m2b if score #d8 jv = @s jb.m2c if score #d9 jv = @s jb.m2d run return run function jb:ms/done2
