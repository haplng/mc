execute store result storage jb:wk sd.pid int 1 run scoreboard players get @s jb.pid
execute unless score @s jb.ml1 matches 1.. run scoreboard players reset jb_m1 jb.side
execute if score @s jb.ml1 matches 1.. run function jb:ms/side1
execute unless score @s jb.ml2 matches 1.. run scoreboard players reset jb_m2 jb.side
execute if score @s jb.ml2 matches 1.. run function jb:ms/side2
execute unless score @s jb.ml3 matches 1.. run scoreboard players reset jb_m3 jb.side
execute if score @s jb.ml3 matches 1.. run function jb:ms/side3
