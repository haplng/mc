scoreboard players operation #q jv = @s jb.rch
scoreboard players operation #q jv < #c2000 jv
scoreboard players operation #q jv *= #c1000000 jv
scoreboard players operation #t jv = @s jb.rc
scoreboard players operation #t jv /= #c1000 jv
scoreboard players operation #q jv += #t jv
scoreboard players operation #q jv /= @s jb.rr
scoreboard players operation #q jv < #c700000 jv
scoreboard players operation #q jv *= #mk jv
scoreboard players operation #qh jv = #q jv
scoreboard players operation #qh jv /= #c1000000 jv
scoreboard players operation #ql jv = #q jv
scoreboard players operation #ql jv %= #c1000000 jv
scoreboard players operation #ql jv *= #c1000 jv
function jb:ms/rel_max
