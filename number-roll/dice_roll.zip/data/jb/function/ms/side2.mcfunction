scoreboard players operation #fh jv = @s jb.mcb2
scoreboard players operation #fl jv = @s jb.mc2
function jb:sys/short
data modify storage jb:wk sd.r set from storage jb:wk sh.o
data modify storage jb:wk sd.i set value 2
function jb:ms/side_s with storage jb:wk sd
scoreboard players set jb_m2 jb.side 2
function jb:ms/side2b with storage jb:wk sd
