function jb:ms/rw2
scoreboard players operation #cgh jv = @s jb.mcb2
scoreboard players operation #cgl jv = @s jb.mc2
scoreboard players set #fh jv 0
scoreboard players set #fl jv 0
function jb:ms/pay
execute if score @s jb.j8 matches 2 run function jb:ms/pay
execute if score @s jb.j8 matches 2 run function jb:ms/pay
scoreboard players add @s jb.mdone 1
function jb:sys/big
data modify storage jb:wk mdn.c set from storage jb:wk cm.o
execute store result storage jb:wk mdn.pid int 1 run scoreboard players get @s jb.pid
data modify storage jb:wk mdn.i set value 2
function jb:ms/msg with storage jb:wk mdn
function jb:snd/play {s:"minecraft:entity.player.levelup",b:80,p:1.0}
function jb:ms/new2
function jb:ms/side
