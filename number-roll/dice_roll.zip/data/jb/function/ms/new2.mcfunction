scoreboard players set @s jb.ml2 0
execute unless score @s jb.unl matches 5.. run return 0
scoreboard players set @s jb.ml2 4
execute store result score #mv jv run random value 0..9999
scoreboard players operation #t jv = #mv jv
scoreboard players operation @s jb.m2d = #t jv
scoreboard players operation @s jb.m2d %= #c10 jv
scoreboard players operation #t jv /= #c10 jv
scoreboard players operation @s jb.m2c = #t jv
scoreboard players operation @s jb.m2c %= #c10 jv
scoreboard players operation #t jv /= #c10 jv
scoreboard players operation @s jb.m2b = #t jv
scoreboard players operation @s jb.m2b %= #c10 jv
scoreboard players operation #t jv /= #c10 jv
scoreboard players operation @s jb.m2a = #t jv
scoreboard players operation @s jb.m2a %= #c10 jv
scoreboard players operation #t jv /= #c10 jv
function jb:ms/rw2
scoreboard players add #mv jv 10000
execute store result storage jb:wk mss.v int 1 run scoreboard players get #mv jv
execute store result storage jb:wk mss.pid int 1 run scoreboard players get @s jb.pid
data modify storage jb:wk mss.i set value 2
function jb:ms/str with storage jb:wk mss
