$scoreboard players display name jb_m3 jb.side [{"text": "어려움  ", "color": "red"}, {"text": "$(s)", "color": "white", "bold": true}, {"text": "   +$(r)⛃", "color": "gold"}]
