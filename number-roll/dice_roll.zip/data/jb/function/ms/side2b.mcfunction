$scoreboard players display name jb_m2 jb.side [{"text": "보통  ", "color": "yellow"}, {"text": "$(s)", "color": "white", "bold": true}, {"text": "   +$(r)⛃", "color": "gold"}]
