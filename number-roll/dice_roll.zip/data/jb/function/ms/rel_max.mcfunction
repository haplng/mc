execute if score #qh jv > #mrh jv run return run function jb:ms/rel_set
execute if score #qh jv = #mrh jv if score #ql jv > #mrl jv run function jb:ms/rel_set
