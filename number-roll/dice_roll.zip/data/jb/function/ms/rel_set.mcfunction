scoreboard players operation #mrh jv = #qh jv
scoreboard players operation #mrl jv = #ql jv
