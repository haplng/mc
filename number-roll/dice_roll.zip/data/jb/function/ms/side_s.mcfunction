$data modify storage jb:wk sd.s set from storage jb:ms m.p$(pid).s$(i)
