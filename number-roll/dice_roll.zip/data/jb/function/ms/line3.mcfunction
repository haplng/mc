scoreboard players operation #fh jv = @s jb.mcb3
scoreboard players operation #fl jv = @s jb.mc3
function jb:sys/short
data modify storage jb:wk sd.r set from storage jb:wk sh.o
data modify storage jb:wk sd.i set value 3
function jb:ms/side_s with storage jb:wk sd
function jb:ms/line3b with storage jb:wk sd
