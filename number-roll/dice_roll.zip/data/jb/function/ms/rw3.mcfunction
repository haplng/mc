scoreboard players set #mrh jv 0
scoreboard players set #mrl jv 4000000
scoreboard players operation #t jv = #mrl jv
scoreboard players operation #t jv *= @s jb.u4
scoreboard players operation #t jv /= #c2 jv
scoreboard players operation #mrl jv += #t jv
scoreboard players set #mk jv 3000
function jb:ms/rel
scoreboard players operation @s jb.mc3 = #mrl jv
scoreboard players operation @s jb.mcb3 = #mrh jv
