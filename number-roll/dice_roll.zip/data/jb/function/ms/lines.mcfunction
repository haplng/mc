execute store result storage jb:wk sd.pid int 1 run scoreboard players get @s jb.pid
execute if score @s jb.ml1 matches 1.. run function jb:ms/line1
execute if score @s jb.ml2 matches 1.. run function jb:ms/line2
execute if score @s jb.ml3 matches 1.. run function jb:ms/line3
