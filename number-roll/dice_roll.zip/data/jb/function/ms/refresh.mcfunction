execute if score @s jb.ml1 matches 1.. run function jb:ms/rw1
execute if score @s jb.ml2 matches 1.. run function jb:ms/rw2
execute if score @s jb.ml3 matches 1.. run function jb:ms/rw3
execute if score @s jb.ml1 matches 1.. run function jb:ms/side
