scoreboard players set #mrh jv 0
scoreboard players set #mrl jv 30000
scoreboard players operation #t jv = #mrl jv
scoreboard players operation #t jv *= @s jb.u4
scoreboard players operation #t jv /= #c2 jv
scoreboard players operation #mrl jv += #t jv
scoreboard players set #mk jv 30
function jb:ms/rel
scoreboard players operation @s jb.mc1 = #mrl jv
scoreboard players operation @s jb.mcb1 = #mrh jv
