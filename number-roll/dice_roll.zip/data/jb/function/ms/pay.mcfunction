function jb:sys/addc2
scoreboard players operation #fl jv += #cgl jv
execute if score #fl jv matches 1000000000.. run scoreboard players add #fh jv 1
execute if score #fl jv matches 1000000000.. run scoreboard players remove #fl jv 1000000000
scoreboard players operation #fh jv += #cgh jv
