$data modify storage jb:wk mss.t set value "$(v)"
data modify storage jb:wk mss.s set string storage jb:wk mss.t 1
$data modify storage jb:ms m.p$(pid).s$(i) set from storage jb:wk mss.s
