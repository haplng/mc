execute if score @s jb.ml1 matches 1.. run function jb:ms/c1
execute if score @s jb.ml2 matches 1.. run function jb:ms/c2
execute if score @s jb.ml3 matches 1.. run function jb:ms/c3
