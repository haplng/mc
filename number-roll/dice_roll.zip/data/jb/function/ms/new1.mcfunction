scoreboard players set @s jb.ml1 0
execute unless score @s jb.unl matches 1.. run return 0
scoreboard players set @s jb.ml1 3
execute store result score #mv jv run random value 0..999
scoreboard players operation #t jv = #mv jv
scoreboard players operation @s jb.m1c = #t jv
scoreboard players operation @s jb.m1c %= #c10 jv
scoreboard players operation #t jv /= #c10 jv
scoreboard players operation @s jb.m1b = #t jv
scoreboard players operation @s jb.m1b %= #c10 jv
scoreboard players operation #t jv /= #c10 jv
scoreboard players operation @s jb.m1a = #t jv
scoreboard players operation @s jb.m1a %= #c10 jv
scoreboard players operation #t jv /= #c10 jv
function jb:ms/rw1
scoreboard players add #mv jv 1000
execute store result storage jb:wk mss.v int 1 run scoreboard players get #mv jv
execute store result storage jb:wk mss.pid int 1 run scoreboard players get @s jb.pid
data modify storage jb:wk mss.i set value 1
function jb:ms/str with storage jb:wk mss
