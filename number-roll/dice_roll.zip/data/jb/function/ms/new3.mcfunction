scoreboard players set @s jb.ml3 0
execute unless score @s jb.unl matches 8.. run return 0
scoreboard players set @s jb.ml3 5
execute store result score #mv jv run random value 0..99999
scoreboard players operation #t jv = #mv jv
scoreboard players operation @s jb.m3e = #t jv
scoreboard players operation @s jb.m3e %= #c10 jv
scoreboard players operation #t jv /= #c10 jv
scoreboard players operation @s jb.m3d = #t jv
scoreboard players operation @s jb.m3d %= #c10 jv
scoreboard players operation #t jv /= #c10 jv
scoreboard players operation @s jb.m3c = #t jv
scoreboard players operation @s jb.m3c %= #c10 jv
scoreboard players operation #t jv /= #c10 jv
scoreboard players operation @s jb.m3b = #t jv
scoreboard players operation @s jb.m3b %= #c10 jv
scoreboard players operation #t jv /= #c10 jv
scoreboard players operation @s jb.m3a = #t jv
scoreboard players operation @s jb.m3a %= #c10 jv
scoreboard players operation #t jv /= #c10 jv
function jb:ms/rw3
scoreboard players add #mv jv 100000
execute store result storage jb:wk mss.v int 1 run scoreboard players get #mv jv
execute store result storage jb:wk mss.pid int 1 run scoreboard players get @s jb.pid
data modify storage jb:wk mss.i set value 3
function jb:ms/str with storage jb:wk mss
