execute unless score @s jb.rr matches 1.. run return 0
execute if score @s jb.rch matches 1.. run return run function jb:ms/rel_k
scoreboard players operation #q jv = @s jb.rc
scoreboard players operation #q jv /= @s jb.rr
execute if score #q jv matches 700001.. run return run function jb:ms/rel_k
scoreboard players operation #q jv *= #mk jv
scoreboard players operation #qh jv = #q jv
scoreboard players operation #qh jv /= #c1000000000 jv
scoreboard players operation #ql jv = #q jv
scoreboard players operation #ql jv %= #c1000000000 jv
function jb:ms/rel_max
