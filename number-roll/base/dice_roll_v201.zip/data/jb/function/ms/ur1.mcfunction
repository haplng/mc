scoreboard players operation #fn jv = @s jb.mc1
function jb:sys/comma
function jb:ms/ur1b with storage jb:wk cm
scoreboard players operation #fn jv = @s jb.mx1
function jb:sys/comma
function jb:ms/ur1c with storage jb:wk cm
