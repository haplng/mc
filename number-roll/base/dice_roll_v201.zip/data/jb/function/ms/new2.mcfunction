scoreboard players set @s jb.ml2 0
scoreboard players set @s jb.mc2 0
scoreboard players set @s jb.mx2 0
scoreboard players set @s jb.m2 -1
execute if score @s jb.lv matches 10..13 run scoreboard players set @s jb.ml2 4
execute if score @s jb.lv matches 14..99 run scoreboard players set @s jb.ml2 5
execute if score @s jb.ml2 matches 0 run return run function jb:ms/lock2
execute if score @s jb.ml2 matches 2 store result score @s jb.m2 run random value 0..99
execute if score @s jb.ml2 matches 2 run scoreboard players set @s jb.mc2 2500
execute if score @s jb.ml2 matches 2 run scoreboard players set @s jb.mx2 150
execute if score @s jb.ml2 matches 2 run scoreboard players set #p10 jv 100
execute if score @s jb.ml2 matches 3 store result score @s jb.m2 run random value 0..999
execute if score @s jb.ml2 matches 3 run scoreboard players set @s jb.mc2 30000
execute if score @s jb.ml2 matches 3 run scoreboard players set @s jb.mx2 1500
execute if score @s jb.ml2 matches 3 run scoreboard players set #p10 jv 1000
execute if score @s jb.ml2 matches 4 store result score @s jb.m2 run random value 0..9999
execute if score @s jb.ml2 matches 4 run scoreboard players set @s jb.mc2 330000
execute if score @s jb.ml2 matches 4 run scoreboard players set @s jb.mx2 12000
execute if score @s jb.ml2 matches 4 run scoreboard players set #p10 jv 10000
execute if score @s jb.ml2 matches 5 store result score @s jb.m2 run random value 0..99999
execute if score @s jb.ml2 matches 5 run scoreboard players set @s jb.mc2 4000000
execute if score @s jb.ml2 matches 5 run scoreboard players set @s jb.mx2 100000
execute if score @s jb.ml2 matches 5 run scoreboard players set #p10 jv 100000
execute if score @s jb.ml2 matches 6 store result score @s jb.m2 run random value 0..999999
execute if score @s jb.ml2 matches 6 run scoreboard players set @s jb.mc2 50000000
execute if score @s jb.ml2 matches 6 run scoreboard players set @s jb.mx2 500000
execute if score @s jb.ml2 matches 6 run scoreboard players set #p10 jv 1000000
scoreboard players operation #t jv = @s jb.mc2
scoreboard players operation #t jv *= @s jb.u4
scoreboard players operation #t jv /= #c2 jv
scoreboard players operation @s jb.mc2 += #t jv
scoreboard players operation #p10 jv += @s jb.m2
execute store result storage jb:wk mss.v int 1 run scoreboard players get #p10 jv
execute store result storage jb:wk mss.pid int 1 run scoreboard players get @s jb.pid
data modify storage jb:wk mss.i set value 2
function jb:ms/str with storage jb:wk mss
