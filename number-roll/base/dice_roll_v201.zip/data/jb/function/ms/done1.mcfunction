scoreboard players operation #cg jv = @s jb.mc1
function jb:sys/addc
scoreboard players add @s jb.mdone 1
execute if score #man jv matches 1 run scoreboard players operation @s jb.px += @s jb.mx1
execute unless score #man jv matches 1 run scoreboard players operation @s jb.gxp += @s jb.mx1
scoreboard players operation #fn jv = @s jb.mc1
function jb:sys/comma
data modify storage jb:wk mdn.c set from storage jb:wk cm.o
scoreboard players operation #fn jv = @s jb.mx1
function jb:sys/comma
data modify storage jb:wk mdn.x set from storage jb:wk cm.o
execute store result storage jb:wk mdn.pid int 1 run scoreboard players get @s jb.pid
data modify storage jb:wk mdn.i set value 1
function jb:ms/msg with storage jb:wk mdn
function jb:snd/play {s:"minecraft:entity.player.levelup",b:80,p:1.0}
function jb:ms/new1
function jb:ms/side
