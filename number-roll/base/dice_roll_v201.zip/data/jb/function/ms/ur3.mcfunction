scoreboard players operation #fn jv = @s jb.mc3
function jb:sys/comma
function jb:ms/ur3b with storage jb:wk cm
scoreboard players operation #fn jv = @s jb.mx3
function jb:sys/comma
function jb:ms/ur3c with storage jb:wk cm
