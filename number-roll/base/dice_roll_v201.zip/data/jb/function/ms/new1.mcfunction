scoreboard players set @s jb.ml1 0
scoreboard players set @s jb.mc1 0
scoreboard players set @s jb.mx1 0
scoreboard players set @s jb.m1 -1
execute if score @s jb.lv matches 3..6 run scoreboard players set @s jb.ml1 2
execute if score @s jb.lv matches 7..13 run scoreboard players set @s jb.ml1 3
execute if score @s jb.lv matches 14..99 run scoreboard players set @s jb.ml1 4
execute if score @s jb.ml1 matches 0 run return run function jb:ms/lock1
execute if score @s jb.ml1 matches 2 store result score @s jb.m1 run random value 0..99
execute if score @s jb.ml1 matches 2 run scoreboard players set @s jb.mc1 2500
execute if score @s jb.ml1 matches 2 run scoreboard players set @s jb.mx1 150
execute if score @s jb.ml1 matches 2 run scoreboard players set #p10 jv 100
execute if score @s jb.ml1 matches 3 store result score @s jb.m1 run random value 0..999
execute if score @s jb.ml1 matches 3 run scoreboard players set @s jb.mc1 30000
execute if score @s jb.ml1 matches 3 run scoreboard players set @s jb.mx1 1500
execute if score @s jb.ml1 matches 3 run scoreboard players set #p10 jv 1000
execute if score @s jb.ml1 matches 4 store result score @s jb.m1 run random value 0..9999
execute if score @s jb.ml1 matches 4 run scoreboard players set @s jb.mc1 330000
execute if score @s jb.ml1 matches 4 run scoreboard players set @s jb.mx1 12000
execute if score @s jb.ml1 matches 4 run scoreboard players set #p10 jv 10000
execute if score @s jb.ml1 matches 5 store result score @s jb.m1 run random value 0..99999
execute if score @s jb.ml1 matches 5 run scoreboard players set @s jb.mc1 4000000
execute if score @s jb.ml1 matches 5 run scoreboard players set @s jb.mx1 100000
execute if score @s jb.ml1 matches 5 run scoreboard players set #p10 jv 100000
execute if score @s jb.ml1 matches 6 store result score @s jb.m1 run random value 0..999999
execute if score @s jb.ml1 matches 6 run scoreboard players set @s jb.mc1 50000000
execute if score @s jb.ml1 matches 6 run scoreboard players set @s jb.mx1 500000
execute if score @s jb.ml1 matches 6 run scoreboard players set #p10 jv 1000000
scoreboard players operation #t jv = @s jb.mc1
scoreboard players operation #t jv *= @s jb.u4
scoreboard players operation #t jv /= #c2 jv
scoreboard players operation @s jb.mc1 += #t jv
scoreboard players operation #p10 jv += @s jb.m1
execute store result storage jb:wk mss.v int 1 run scoreboard players get #p10 jv
execute store result storage jb:wk mss.pid int 1 run scoreboard players get @s jb.pid
data modify storage jb:wk mss.i set value 1
function jb:ms/str with storage jb:wk mss
