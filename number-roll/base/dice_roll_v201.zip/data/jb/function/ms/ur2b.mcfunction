$data modify storage jb:wk mh.r2 set value "   +$(o)⛃"
