$data modify storage jb:wk mh.r1 set value "   +$(o)⛃"
