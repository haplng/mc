$data modify storage jb:ms m.p$(pid).s1 set value "🔒 Lv.3"
