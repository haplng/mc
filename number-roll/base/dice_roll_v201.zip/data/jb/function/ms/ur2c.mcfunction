$data modify storage jb:wk mh.y2 set value "  +$(o)XP"
