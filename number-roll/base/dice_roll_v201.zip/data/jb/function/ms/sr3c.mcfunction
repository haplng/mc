$data modify storage jb:wk sd2.x3 set value "  +$(o)XP"
