$data modify storage jb:wk mh.m1 set from storage jb:ms m.p$(pid).s1
$data modify storage jb:wk mh.m2 set from storage jb:ms m.p$(pid).s2
$data modify storage jb:wk mh.m3 set from storage jb:ms m.p$(pid).s3
