execute if score #mw6_1 jv = @s jb.m2 run return run function jb:ms/done2
execute if score #mw6_2 jv = @s jb.m2 run return run function jb:ms/done2
execute if score #mw6_3 jv = @s jb.m2 run return run function jb:ms/done2
execute if score #mw6_4 jv = @s jb.m2 run return run function jb:ms/done2
