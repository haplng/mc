scoreboard players operation #fn jv = @s jb.mc2
function jb:sys/comma
function jb:ms/sr2b with storage jb:wk cm
scoreboard players operation #fn jv = @s jb.mx2
function jb:sys/comma
function jb:ms/sr2c with storage jb:wk cm
