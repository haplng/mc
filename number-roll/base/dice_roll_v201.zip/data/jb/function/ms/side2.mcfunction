execute if score @s jb.ml1 matches 2.. run scoreboard players set jb_m1 jb.side 3
execute unless score @s jb.ml1 matches 2.. run scoreboard players reset jb_m1 jb.side
$execute if score @s jb.ml1 matches 2.. run scoreboard players display name jb_m1 jb.side [{"text": "쉬움  ", "color": "green"}, {"text": "$(m1)", "color": "white", "bold": true}, {"text": "$(r1)", "color": "gold", "bold": true}, {"text": "$(x1)", "color": "aqua"}]
execute if score @s jb.ml2 matches 2.. run scoreboard players set jb_m2 jb.side 2
execute unless score @s jb.ml2 matches 2.. run scoreboard players reset jb_m2 jb.side
$execute if score @s jb.ml2 matches 2.. run scoreboard players display name jb_m2 jb.side [{"text": "보통  ", "color": "yellow"}, {"text": "$(m2)", "color": "white", "bold": true}, {"text": "$(r2)", "color": "gold", "bold": true}, {"text": "$(x2)", "color": "aqua"}]
execute if score @s jb.ml3 matches 2.. run scoreboard players set jb_m3 jb.side 1
execute unless score @s jb.ml3 matches 2.. run scoreboard players reset jb_m3 jb.side
$execute if score @s jb.ml3 matches 2.. run scoreboard players display name jb_m3 jb.side [{"text": "어려움  ", "color": "red"}, {"text": "$(m3)", "color": "white", "bold": true}, {"text": "$(r3)", "color": "gold", "bold": true}, {"text": "$(x3)", "color": "aqua"}]
