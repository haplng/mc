scoreboard players operation #mw2_1 jv = #d1 jv
scoreboard players operation #mw2_1 jv *= #c10 jv
scoreboard players operation #mw2_1 jv += #d2 jv
scoreboard players operation #mw2_2 jv = #d2 jv
scoreboard players operation #mw2_2 jv *= #c10 jv
scoreboard players operation #mw2_2 jv += #d3 jv
scoreboard players operation #mw2_3 jv = #d3 jv
scoreboard players operation #mw2_3 jv *= #c10 jv
scoreboard players operation #mw2_3 jv += #d4 jv
scoreboard players operation #mw2_4 jv = #d4 jv
scoreboard players operation #mw2_4 jv *= #c10 jv
scoreboard players operation #mw2_4 jv += #d5 jv
scoreboard players operation #mw2_5 jv = #d5 jv
scoreboard players operation #mw2_5 jv *= #c10 jv
scoreboard players operation #mw2_5 jv += #d6 jv
scoreboard players operation #mw2_6 jv = #d6 jv
scoreboard players operation #mw2_6 jv *= #c10 jv
scoreboard players operation #mw2_6 jv += #d7 jv
scoreboard players operation #mw2_7 jv = #d7 jv
scoreboard players operation #mw2_7 jv *= #c10 jv
scoreboard players operation #mw2_7 jv += #d8 jv
scoreboard players operation #mw2_8 jv = #d8 jv
scoreboard players operation #mw2_8 jv *= #c10 jv
scoreboard players operation #mw2_8 jv += #d9 jv
scoreboard players operation #mw3_1 jv = #mw2_1 jv
scoreboard players operation #mw3_1 jv *= #c10 jv
scoreboard players operation #mw3_1 jv += #d3 jv
scoreboard players operation #mw3_2 jv = #mw2_2 jv
scoreboard players operation #mw3_2 jv *= #c10 jv
scoreboard players operation #mw3_2 jv += #d4 jv
scoreboard players operation #mw3_3 jv = #mw2_3 jv
scoreboard players operation #mw3_3 jv *= #c10 jv
scoreboard players operation #mw3_3 jv += #d5 jv
scoreboard players operation #mw3_4 jv = #mw2_4 jv
scoreboard players operation #mw3_4 jv *= #c10 jv
scoreboard players operation #mw3_4 jv += #d6 jv
scoreboard players operation #mw3_5 jv = #mw2_5 jv
scoreboard players operation #mw3_5 jv *= #c10 jv
scoreboard players operation #mw3_5 jv += #d7 jv
scoreboard players operation #mw3_6 jv = #mw2_6 jv
scoreboard players operation #mw3_6 jv *= #c10 jv
scoreboard players operation #mw3_6 jv += #d8 jv
scoreboard players operation #mw3_7 jv = #mw2_7 jv
scoreboard players operation #mw3_7 jv *= #c10 jv
scoreboard players operation #mw3_7 jv += #d9 jv
scoreboard players operation #mw4_1 jv = #mw3_1 jv
scoreboard players operation #mw4_1 jv *= #c10 jv
scoreboard players operation #mw4_1 jv += #d4 jv
scoreboard players operation #mw4_2 jv = #mw3_2 jv
scoreboard players operation #mw4_2 jv *= #c10 jv
scoreboard players operation #mw4_2 jv += #d5 jv
scoreboard players operation #mw4_3 jv = #mw3_3 jv
scoreboard players operation #mw4_3 jv *= #c10 jv
scoreboard players operation #mw4_3 jv += #d6 jv
scoreboard players operation #mw4_4 jv = #mw3_4 jv
scoreboard players operation #mw4_4 jv *= #c10 jv
scoreboard players operation #mw4_4 jv += #d7 jv
scoreboard players operation #mw4_5 jv = #mw3_5 jv
scoreboard players operation #mw4_5 jv *= #c10 jv
scoreboard players operation #mw4_5 jv += #d8 jv
scoreboard players operation #mw4_6 jv = #mw3_6 jv
scoreboard players operation #mw4_6 jv *= #c10 jv
scoreboard players operation #mw4_6 jv += #d9 jv
scoreboard players operation #mw5_1 jv = #mw4_1 jv
scoreboard players operation #mw5_1 jv *= #c10 jv
scoreboard players operation #mw5_1 jv += #d5 jv
scoreboard players operation #mw5_2 jv = #mw4_2 jv
scoreboard players operation #mw5_2 jv *= #c10 jv
scoreboard players operation #mw5_2 jv += #d6 jv
scoreboard players operation #mw5_3 jv = #mw4_3 jv
scoreboard players operation #mw5_3 jv *= #c10 jv
scoreboard players operation #mw5_3 jv += #d7 jv
scoreboard players operation #mw5_4 jv = #mw4_4 jv
scoreboard players operation #mw5_4 jv *= #c10 jv
scoreboard players operation #mw5_4 jv += #d8 jv
scoreboard players operation #mw5_5 jv = #mw4_5 jv
scoreboard players operation #mw5_5 jv *= #c10 jv
scoreboard players operation #mw5_5 jv += #d9 jv
scoreboard players operation #mw6_1 jv = #mw5_1 jv
scoreboard players operation #mw6_1 jv *= #c10 jv
scoreboard players operation #mw6_1 jv += #d6 jv
scoreboard players operation #mw6_2 jv = #mw5_2 jv
scoreboard players operation #mw6_2 jv *= #c10 jv
scoreboard players operation #mw6_2 jv += #d7 jv
scoreboard players operation #mw6_3 jv = #mw5_3 jv
scoreboard players operation #mw6_3 jv *= #c10 jv
scoreboard players operation #mw6_3 jv += #d8 jv
scoreboard players operation #mw6_4 jv = #mw5_4 jv
scoreboard players operation #mw6_4 jv *= #c10 jv
scoreboard players operation #mw6_4 jv += #d9 jv
execute if score @s jb.ml1 matches 2 run function jb:ms/c1_2
execute if score @s jb.ml1 matches 3 run function jb:ms/c1_3
execute if score @s jb.ml1 matches 4 run function jb:ms/c1_4
execute if score @s jb.ml1 matches 5 run function jb:ms/c1_5
execute if score @s jb.ml1 matches 6 run function jb:ms/c1_6
execute if score @s jb.ml2 matches 2 run function jb:ms/c2_2
execute if score @s jb.ml2 matches 3 run function jb:ms/c2_3
execute if score @s jb.ml2 matches 4 run function jb:ms/c2_4
execute if score @s jb.ml2 matches 5 run function jb:ms/c2_5
execute if score @s jb.ml2 matches 6 run function jb:ms/c2_6
execute if score @s jb.ml3 matches 2 run function jb:ms/c3_2
execute if score @s jb.ml3 matches 3 run function jb:ms/c3_3
execute if score @s jb.ml3 matches 4 run function jb:ms/c3_4
execute if score @s jb.ml3 matches 5 run function jb:ms/c3_5
execute if score @s jb.ml3 matches 6 run function jb:ms/c3_6
