scoreboard players set @s jb.ml3 0
scoreboard players set @s jb.mc3 0
scoreboard players set @s jb.mx3 0
scoreboard players set @s jb.m3 -1
execute if score @s jb.lv matches 15..99 run scoreboard players set @s jb.ml3 6
execute if score @s jb.ml3 matches 0 run return run function jb:ms/lock3
execute if score @s jb.ml3 matches 2 store result score @s jb.m3 run random value 0..99
execute if score @s jb.ml3 matches 2 run scoreboard players set @s jb.mc3 2500
execute if score @s jb.ml3 matches 2 run scoreboard players set @s jb.mx3 150
execute if score @s jb.ml3 matches 2 run scoreboard players set #p10 jv 100
execute if score @s jb.ml3 matches 3 store result score @s jb.m3 run random value 0..999
execute if score @s jb.ml3 matches 3 run scoreboard players set @s jb.mc3 30000
execute if score @s jb.ml3 matches 3 run scoreboard players set @s jb.mx3 1500
execute if score @s jb.ml3 matches 3 run scoreboard players set #p10 jv 1000
execute if score @s jb.ml3 matches 4 store result score @s jb.m3 run random value 0..9999
execute if score @s jb.ml3 matches 4 run scoreboard players set @s jb.mc3 330000
execute if score @s jb.ml3 matches 4 run scoreboard players set @s jb.mx3 12000
execute if score @s jb.ml3 matches 4 run scoreboard players set #p10 jv 10000
execute if score @s jb.ml3 matches 5 store result score @s jb.m3 run random value 0..99999
execute if score @s jb.ml3 matches 5 run scoreboard players set @s jb.mc3 4000000
execute if score @s jb.ml3 matches 5 run scoreboard players set @s jb.mx3 100000
execute if score @s jb.ml3 matches 5 run scoreboard players set #p10 jv 100000
execute if score @s jb.ml3 matches 6 store result score @s jb.m3 run random value 0..999999
execute if score @s jb.ml3 matches 6 run scoreboard players set @s jb.mc3 50000000
execute if score @s jb.ml3 matches 6 run scoreboard players set @s jb.mx3 500000
execute if score @s jb.ml3 matches 6 run scoreboard players set #p10 jv 1000000
scoreboard players operation #t jv = @s jb.mc3
scoreboard players operation #t jv *= @s jb.u4
scoreboard players operation #t jv /= #c2 jv
scoreboard players operation @s jb.mc3 += #t jv
scoreboard players operation #p10 jv += @s jb.m3
execute store result storage jb:wk mss.v int 1 run scoreboard players get #p10 jv
execute store result storage jb:wk mss.pid int 1 run scoreboard players get @s jb.pid
data modify storage jb:wk mss.i set value 3
function jb:ms/str with storage jb:wk mss
