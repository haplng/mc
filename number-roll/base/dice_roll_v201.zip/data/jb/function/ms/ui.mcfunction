execute store result storage jb:wk mdn.pid int 1 run scoreboard players get @s jb.pid
function jb:ms/ui2 with storage jb:wk mdn
scoreboard players operation #rr jv = @s jb.mc1
scoreboard players operation #rr jv += @s jb.mc2
scoreboard players operation #rr jv += @s jb.mc3
scoreboard players operation #rr jv /= #c10 jv
data modify storage jb:wk mh.r1 set value ""
data modify storage jb:wk mh.y1 set value ""
execute if score @s jb.ml1 matches 2.. run function jb:ms/ur1
data modify storage jb:wk mh.r2 set value ""
data modify storage jb:wk mh.y2 set value ""
execute if score @s jb.ml2 matches 2.. run function jb:ms/ur2
data modify storage jb:wk mh.r3 set value ""
data modify storage jb:wk mh.y3 set value ""
execute if score @s jb.ml3 matches 2.. run function jb:ms/ur3
scoreboard players operation #fn jv = #rr jv
function jb:sys/comma
data modify storage jb:wk mh.rr set from storage jb:wk cm.o
