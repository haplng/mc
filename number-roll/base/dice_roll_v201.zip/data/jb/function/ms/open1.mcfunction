function jb:ms/new1
function jb:ms/side
tellraw @s [{"text": "📋 새 미션 열림! ", "color": "gold", "bold": true}, {"text": "쉬움", "color": "green", "bold": true}, {"text": " 미션 (오른쪽 사이드바)", "color": "white"}]
