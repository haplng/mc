$data modify storage jb:ms m.p$(pid).s2 set value "🔒 Lv.10"
