$data modify storage jb:wk sd2.x1 set value "  +$(o)XP"
