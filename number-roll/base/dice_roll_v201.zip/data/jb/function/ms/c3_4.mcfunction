execute if score #mw4_1 jv = @s jb.m3 run return run function jb:ms/done3
execute if score #mw4_2 jv = @s jb.m3 run return run function jb:ms/done3
execute if score #mw4_3 jv = @s jb.m3 run return run function jb:ms/done3
execute if score #mw4_4 jv = @s jb.m3 run return run function jb:ms/done3
execute if score #mw4_5 jv = @s jb.m3 run return run function jb:ms/done3
execute if score #mw4_6 jv = @s jb.m3 run return run function jb:ms/done3
