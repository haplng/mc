execute if score #mw2_1 jv = @s jb.m1 run return run function jb:ms/done1
execute if score #mw2_2 jv = @s jb.m1 run return run function jb:ms/done1
execute if score #mw2_3 jv = @s jb.m1 run return run function jb:ms/done1
execute if score #mw2_4 jv = @s jb.m1 run return run function jb:ms/done1
execute if score #mw2_5 jv = @s jb.m1 run return run function jb:ms/done1
execute if score #mw2_6 jv = @s jb.m1 run return run function jb:ms/done1
execute if score #mw2_7 jv = @s jb.m1 run return run function jb:ms/done1
execute if score #mw2_8 jv = @s jb.m1 run return run function jb:ms/done1
