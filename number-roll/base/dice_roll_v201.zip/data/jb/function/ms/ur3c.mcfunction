$data modify storage jb:wk mh.y3 set value "  +$(o)XP"
