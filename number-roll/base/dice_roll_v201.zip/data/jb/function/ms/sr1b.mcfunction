$data modify storage jb:wk sd2.r1 set value "   +$(o)⛃"
