$data modify storage jb:wk mh.r3 set value "   +$(o)⛃"
