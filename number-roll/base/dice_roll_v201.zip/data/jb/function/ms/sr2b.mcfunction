$data modify storage jb:wk sd2.r2 set value "   +$(o)⛃"
