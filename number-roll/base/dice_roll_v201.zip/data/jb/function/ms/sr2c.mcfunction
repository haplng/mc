$data modify storage jb:wk sd2.x2 set value "  +$(o)XP"
