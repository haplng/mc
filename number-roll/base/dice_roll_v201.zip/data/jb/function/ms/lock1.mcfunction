execute store result storage jb:wk mss.pid int 1 run scoreboard players get @s jb.pid
function jb:ms/lock1b with storage jb:wk mss
