execute if score #mw5_1 jv = @s jb.m1 run return run function jb:ms/done1
execute if score #mw5_2 jv = @s jb.m1 run return run function jb:ms/done1
execute if score #mw5_3 jv = @s jb.m1 run return run function jb:ms/done1
execute if score #mw5_4 jv = @s jb.m1 run return run function jb:ms/done1
execute if score #mw5_5 jv = @s jb.m1 run return run function jb:ms/done1
