execute if score #mw3_1 jv = @s jb.m3 run return run function jb:ms/done3
execute if score #mw3_2 jv = @s jb.m3 run return run function jb:ms/done3
execute if score #mw3_3 jv = @s jb.m3 run return run function jb:ms/done3
execute if score #mw3_4 jv = @s jb.m3 run return run function jb:ms/done3
execute if score #mw3_5 jv = @s jb.m3 run return run function jb:ms/done3
execute if score #mw3_6 jv = @s jb.m3 run return run function jb:ms/done3
execute if score #mw3_7 jv = @s jb.m3 run return run function jb:ms/done3
