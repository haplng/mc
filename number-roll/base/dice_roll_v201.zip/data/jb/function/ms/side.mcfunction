execute store result storage jb:wk sd2.pid int 1 run scoreboard players get @s jb.pid
function jb:ms/side1 with storage jb:wk sd2
data modify storage jb:wk sd2.r1 set value ""
data modify storage jb:wk sd2.x1 set value ""
execute if score @s jb.ml1 matches 2.. run function jb:ms/sr1
data modify storage jb:wk sd2.r2 set value ""
data modify storage jb:wk sd2.x2 set value ""
execute if score @s jb.ml2 matches 2.. run function jb:ms/sr2
data modify storage jb:wk sd2.r3 set value ""
data modify storage jb:wk sd2.x3 set value ""
execute if score @s jb.ml3 matches 2.. run function jb:ms/sr3
function jb:ms/side2 with storage jb:wk sd2
