scoreboard players operation #rr jv = @s jb.mc1
scoreboard players operation #rr jv += @s jb.mc2
scoreboard players operation #rr jv += @s jb.mc3
scoreboard players operation #rr jv /= #c10 jv
execute if score @s jb.coins < #rr jv run return run function jb:ms/poor
scoreboard players operation @s jb.coins -= #rr jv
function jb:ms/init
function jb:snd/play {s:"minecraft:block.note_block.chime",b:60,p:1.3}
function jb:menu/main
