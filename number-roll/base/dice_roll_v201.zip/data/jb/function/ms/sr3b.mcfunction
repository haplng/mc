$data modify storage jb:wk sd2.r3 set value "   +$(o)⛃"
