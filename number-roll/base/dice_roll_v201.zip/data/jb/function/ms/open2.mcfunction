function jb:ms/new2
function jb:ms/side
tellraw @s [{"text": "📋 새 미션 열림! ", "color": "gold", "bold": true}, {"text": "보통", "color": "yellow", "bold": true}, {"text": " 미션 (오른쪽 사이드바)", "color": "white"}]
