$data modify storage jb:wk sd2.m1 set from storage jb:ms m.p$(pid).s1
$data modify storage jb:wk sd2.m2 set from storage jb:ms m.p$(pid).s2
$data modify storage jb:wk sd2.m3 set from storage jb:ms m.p$(pid).s3
