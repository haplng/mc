$data modify storage jb:wk mh.y1 set value "  +$(o)XP"
