function jb:snd/play {s:"minecraft:block.note_block.bass",b:70,p:0.7}
function jb:menu/main
