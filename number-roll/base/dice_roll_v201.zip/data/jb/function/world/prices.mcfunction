scoreboard players set #prt jv 0
kill @e[tag=jb.ent,tag=!jb.v13]
kill @e[tag=dice.ent]
scoreboard players add #bdt jv 1
execute if score #bdt jv matches 4.. positioned -13 152 0 as @p run function jb:world/board_chk
