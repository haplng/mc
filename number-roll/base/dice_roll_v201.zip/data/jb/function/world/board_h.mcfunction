$data modify entity @e[type=text_display,tag=jb.dex_h,limit=1] text set value [{"text": "모은 족보 $(f) / 350", "color": "yellow", "bold": true}]
