$data modify entity @e[type=text_display,tag=jb.bdh2,limit=1] text set value [{"text": "희귀  ", "color": "aqua", "bold": true}, {"text": "$(c)/63", "color": "white", "bold": false}]
