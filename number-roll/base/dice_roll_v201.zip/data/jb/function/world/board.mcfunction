scoreboard players set #bdt jv 0
execute store result storage jb:wk bh.f int 1 run scoreboard players get @s jb.found
function jb:world/board_h with storage jb:wk bh
scoreboard players set #ft jv 0
data modify storage jb:wk bn set value [""]
execute if score @s jb.h1 matches 1.. run function jb:world/bd/1
execute if score @s jb.h89 matches 1.. run function jb:world/bd/89
execute if score @s jb.h90 matches 1.. run function jb:world/bd/90
execute if score @s jb.h7 matches 1.. run function jb:world/bd/7
execute if score @s jb.h153 matches 1.. run function jb:world/bd/153
execute if score @s jb.h62 matches 1.. run function jb:world/bd/62
execute if score @s jb.h64 matches 1.. run function jb:world/bd/64
execute if score @s jb.h40 matches 1.. run function jb:world/bd/40
execute if score @s jb.h66 matches 1.. run function jb:world/bd/66
execute if score @s jb.h149 matches 1.. run function jb:world/bd/149
execute if score @s jb.h150 matches 1.. run function jb:world/bd/150
execute if score @s jb.h151 matches 1.. run function jb:world/bd/151
execute if score @s jb.h152 matches 1.. run function jb:world/bd/152
execute if score @s jb.h73 matches 1.. run function jb:world/bd/73
execute if score @s jb.h2 matches 1.. run function jb:world/bd/2
execute if score @s jb.h69 matches 1.. run function jb:world/bd/69
execute if score @s jb.h30 matches 1.. run function jb:world/bd/30
execute if score @s jb.h21 matches 1.. run function jb:world/bd/21
execute if score @s jb.h11 matches 1.. run function jb:world/bd/11
execute if score @s jb.h16 matches 1.. run function jb:world/bd/16
execute if score @s jb.h80 matches 1.. run function jb:world/bd/80
execute if score @s jb.h45 matches 1.. run function jb:world/bd/45
execute if score @s jb.h22 matches 1.. run function jb:world/bd/22
execute if score @s jb.h166 matches 1.. run function jb:world/bd/166
execute if score @s jb.h97 matches 1.. run function jb:world/bd/97
execute if score @s jb.h164 matches 1.. run function jb:world/bd/164
execute if score @s jb.h96 matches 1.. run function jb:world/bd/96
execute if score @s jb.h76 matches 1.. run function jb:world/bd/76
execute if score @s jb.h161 matches 1.. run function jb:world/bd/161
execute if score @s jb.h147 matches 1.. run function jb:world/bd/147
execute if score @s jb.h132 matches 1.. run function jb:world/bd/132
execute if score @s jb.h133 matches 1.. run function jb:world/bd/133
execute if score @s jb.h165 matches 1.. run function jb:world/bd/165
execute if score @s jb.h163 matches 1.. run function jb:world/bd/163
execute if score #ft jv matches 0 run data modify storage jb:wk bn set value [{text:"아직 없음",color:"dark_gray"}]
execute store result storage jb:wk bc.c int 1 run scoreboard players get #ft jv
function jb:world/bdh0 with storage jb:wk bc
data modify storage jb:wk bnc set value {text:""}
data modify storage jb:wk bnc.extra set from storage jb:wk bn
data modify entity @e[type=text_display,tag=jb.bdn0,limit=1] text set from storage jb:wk bnc
scoreboard players set #ft jv 0
data modify storage jb:wk bn set value [""]
execute if score @s jb.h48 matches 1.. run function jb:world/bd/48
execute if score @s jb.h95 matches 1.. run function jb:world/bd/95
execute if score @s jb.h98 matches 1.. run function jb:world/bd/98
execute if score @s jb.h160 matches 1.. run function jb:world/bd/160
execute if score @s jb.h140 matches 1.. run function jb:world/bd/140
execute if score @s jb.h167 matches 1.. run function jb:world/bd/167
execute if score @s jb.h180 matches 1.. run function jb:world/bd/180
execute if score @s jb.h8 matches 1.. run function jb:world/bd/8
execute if score @s jb.h63 matches 1.. run function jb:world/bd/63
execute if score @s jb.h65 matches 1.. run function jb:world/bd/65
execute if score @s jb.h71 matches 1.. run function jb:world/bd/71
execute if score @s jb.h100 matches 1.. run function jb:world/bd/100
execute if score @s jb.h29 matches 1.. run function jb:world/bd/29
execute if score @s jb.h10 matches 1.. run function jb:world/bd/10
execute if score @s jb.h102 matches 1.. run function jb:world/bd/102
execute if score @s jb.h106 matches 1.. run function jb:world/bd/106
execute if score @s jb.h135 matches 1.. run function jb:world/bd/135
execute if score @s jb.h154 matches 1.. run function jb:world/bd/154
execute if score @s jb.h157 matches 1.. run function jb:world/bd/157
execute if score @s jb.h158 matches 1.. run function jb:world/bd/158
execute if score @s jb.h159 matches 1.. run function jb:world/bd/159
execute if score @s jb.h162 matches 1.. run function jb:world/bd/162
execute if score @s jb.h155 matches 1.. run function jb:world/bd/155
execute if score @s jb.h168 matches 1.. run function jb:world/bd/168
execute if score @s jb.h170 matches 1.. run function jb:world/bd/170
execute if score @s jb.h172 matches 1.. run function jb:world/bd/172
execute if score @s jb.h41 matches 1.. run function jb:world/bd/41
execute if score @s jb.h134 matches 1.. run function jb:world/bd/134
execute if score @s jb.h49 matches 1.. run function jb:world/bd/49
execute if score @s jb.h141 matches 1.. run function jb:world/bd/141
execute if score @s jb.h50 matches 1.. run function jb:world/bd/50
execute if score @s jb.h51 matches 1.. run function jb:world/bd/51
execute if score @s jb.h52 matches 1.. run function jb:world/bd/52
execute if score @s jb.h56 matches 1.. run function jb:world/bd/56
execute if score @s jb.h57 matches 1.. run function jb:world/bd/57
execute if score @s jb.h58 matches 1.. run function jb:world/bd/58
execute if score @s jb.h198 matches 1.. run function jb:world/bd/198
execute if score @s jb.h199 matches 1.. run function jb:world/bd/199
execute if score @s jb.h200 matches 1.. run function jb:world/bd/200
execute if score @s jb.h53 matches 1.. run function jb:world/bd/53
execute if score @s jb.h194 matches 1.. run function jb:world/bd/194
execute if score @s jb.h36 matches 1.. run function jb:world/bd/36
execute if score @s jb.h3 matches 1.. run function jb:world/bd/3
execute if score @s jb.h67 matches 1.. run function jb:world/bd/67
execute if score @s jb.h61 matches 1.. run function jb:world/bd/61
execute if score @s jb.h86 matches 1.. run function jb:world/bd/86
execute if score @s jb.h23 matches 1.. run function jb:world/bd/23
execute if score @s jb.h33 matches 1.. run function jb:world/bd/33
execute if score @s jb.h72 matches 1.. run function jb:world/bd/72
execute if score @s jb.h12 matches 1.. run function jb:world/bd/12
execute if score @s jb.h17 matches 1.. run function jb:world/bd/17
execute if score @s jb.h182 matches 1.. run function jb:world/bd/182
execute if score #ft jv matches 0 run data modify storage jb:wk bn set value [{text:"아직 없음",color:"dark_gray"}]
execute store result storage jb:wk bc.c int 1 run scoreboard players get #ft jv
function jb:world/bdh1 with storage jb:wk bc
data modify storage jb:wk bnc set value {text:""}
data modify storage jb:wk bnc.extra set from storage jb:wk bn
data modify entity @e[type=text_display,tag=jb.bdn1,limit=1] text set from storage jb:wk bnc
scoreboard players set #ft jv 0
data modify storage jb:wk bn set value [""]
execute if score @s jb.h81 matches 1.. run function jb:world/bd/81
execute if score @s jb.h24 matches 1.. run function jb:world/bd/24
execute if score @s jb.h176 matches 1.. run function jb:world/bd/176
execute if score @s jb.h75 matches 1.. run function jb:world/bd/75
execute if score @s jb.h59 matches 1.. run function jb:world/bd/59
execute if score @s jb.h60 matches 1.. run function jb:world/bd/60
execute if score @s jb.h37 matches 1.. run function jb:world/bd/37
execute if score @s jb.h130 matches 1.. run function jb:world/bd/130
execute if score @s jb.h131 matches 1.. run function jb:world/bd/131
execute if score @s jb.h144 matches 1.. run function jb:world/bd/144
execute if score @s jb.h93 matches 1.. run function jb:world/bd/93
execute if score @s jb.h94 matches 1.. run function jb:world/bd/94
execute if score @s jb.h178 matches 1.. run function jb:world/bd/178
execute if score @s jb.h179 matches 1.. run function jb:world/bd/179
execute if score @s jb.h70 matches 1.. run function jb:world/bd/70
execute if score @s jb.h99 matches 1.. run function jb:world/bd/99
execute if score @s jb.h156 matches 1.. run function jb:world/bd/156
execute if score @s jb.h28 matches 1.. run function jb:world/bd/28
execute if score @s jb.h39 matches 1.. run function jb:world/bd/39
execute if score @s jb.h169 matches 1.. run function jb:world/bd/169
execute if score @s jb.h171 matches 1.. run function jb:world/bd/171
execute if score @s jb.h173 matches 1.. run function jb:world/bd/173
execute if score @s jb.h142 matches 1.. run function jb:world/bd/142
execute if score @s jb.h103 matches 1.. run function jb:world/bd/103
execute if score @s jb.h107 matches 1.. run function jb:world/bd/107
execute if score @s jb.h42 matches 1.. run function jb:world/bd/42
execute if score @s jb.h54 matches 1.. run function jb:world/bd/54
execute if score @s jb.h113 matches 1.. run function jb:world/bd/113
execute if score @s jb.h114 matches 1.. run function jb:world/bd/114
execute if score @s jb.h116 matches 1.. run function jb:world/bd/116
execute if score @s jb.h117 matches 1.. run function jb:world/bd/117
execute if score @s jb.h118 matches 1.. run function jb:world/bd/118
execute if score @s jb.h120 matches 1.. run function jb:world/bd/120
execute if score @s jb.h121 matches 1.. run function jb:world/bd/121
execute if score @s jb.h123 matches 1.. run function jb:world/bd/123
execute if score @s jb.h124 matches 1.. run function jb:world/bd/124
execute if score @s jb.h125 matches 1.. run function jb:world/bd/125
execute if score @s jb.h128 matches 1.. run function jb:world/bd/128
execute if score @s jb.h129 matches 1.. run function jb:world/bd/129
execute if score @s jb.h185 matches 1.. run function jb:world/bd/185
execute if score @s jb.h186 matches 1.. run function jb:world/bd/186
execute if score @s jb.h187 matches 1.. run function jb:world/bd/187
execute if score @s jb.h188 matches 1.. run function jb:world/bd/188
execute if score @s jb.h189 matches 1.. run function jb:world/bd/189
execute if score @s jb.h190 matches 1.. run function jb:world/bd/190
execute if score @s jb.h191 matches 1.. run function jb:world/bd/191
execute if score @s jb.h192 matches 1.. run function jb:world/bd/192
execute if score @s jb.h193 matches 1.. run function jb:world/bd/193
execute if score @s jb.h195 matches 1.. run function jb:world/bd/195
execute if score @s jb.h197 matches 1.. run function jb:world/bd/197
execute if score @s jb.h126 matches 1.. run function jb:world/bd/126
execute if score @s jb.h55 matches 1.. run function jb:world/bd/55
execute if score @s jb.h112 matches 1.. run function jb:world/bd/112
execute if score @s jb.h115 matches 1.. run function jb:world/bd/115
execute if score @s jb.h119 matches 1.. run function jb:world/bd/119
execute if score @s jb.h122 matches 1.. run function jb:world/bd/122
execute if score @s jb.h127 matches 1.. run function jb:world/bd/127
execute if score @s jb.h4 matches 1.. run function jb:world/bd/4
execute if score @s jb.h27 matches 1.. run function jb:world/bd/27
execute if score @s jb.h87 matches 1.. run function jb:world/bd/87
execute if score @s jb.h88 matches 1.. run function jb:world/bd/88
execute if score @s jb.h143 matches 1.. run function jb:world/bd/143
execute if score @s jb.h9 matches 1.. run function jb:world/bd/9
execute if score #ft jv matches 0 run data modify storage jb:wk bn set value [{text:"아직 없음",color:"dark_gray"}]
execute store result storage jb:wk bc.c int 1 run scoreboard players get #ft jv
function jb:world/bdh2 with storage jb:wk bc
data modify storage jb:wk bnc set value {text:""}
data modify storage jb:wk bnc.extra set from storage jb:wk bn
data modify entity @e[type=text_display,tag=jb.bdn2,limit=1] text set from storage jb:wk bnc
scoreboard players set #ft jv 0
data modify storage jb:wk bn set value [""]
execute if score @s jb.h31 matches 1.. run function jb:world/bd/31
execute if score @s jb.h207 matches 1.. run function jb:world/bd/207
execute if score @s jb.h208 matches 1.. run function jb:world/bd/208
execute if score @s jb.h85 matches 1.. run function jb:world/bd/85
execute if score @s jb.h136 matches 1.. run function jb:world/bd/136
execute if score @s jb.h137 matches 1.. run function jb:world/bd/137
execute if score @s jb.h139 matches 1.. run function jb:world/bd/139
execute if score @s jb.h13 matches 1.. run function jb:world/bd/13
execute if score @s jb.h18 matches 1.. run function jb:world/bd/18
execute if score @s jb.h181 matches 1.. run function jb:world/bd/181
execute if score @s jb.h209 matches 1.. run function jb:world/bd/209
execute if score @s jb.h202 matches 1.. run function jb:world/bd/202
execute if score @s jb.h203 matches 1.. run function jb:world/bd/203
execute if score @s jb.h46 matches 1.. run function jb:world/bd/46
execute if score @s jb.h47 matches 1.. run function jb:world/bd/47
execute if score @s jb.h218 matches 1.. run function jb:world/bd/218
execute if score @s jb.h68 matches 1.. run function jb:world/bd/68
execute if score @s jb.h25 matches 1.. run function jb:world/bd/25
execute if score @s jb.h213 matches 1.. run function jb:world/bd/213
execute if score @s jb.h35 matches 1.. run function jb:world/bd/35
execute if score @s jb.h82 matches 1.. run function jb:world/bd/82
execute if score @s jb.h217 matches 1.. run function jb:world/bd/217
execute if score @s jb.h210 matches 1.. run function jb:world/bd/210
execute if score @s jb.h148 matches 1.. run function jb:world/bd/148
execute if score @s jb.h184 matches 1.. run function jb:world/bd/184
execute if score @s jb.h216 matches 1.. run function jb:world/bd/216
execute if score @s jb.h26 matches 1.. run function jb:world/bd/26
execute if score @s jb.h38 matches 1.. run function jb:world/bd/38
execute if score @s jb.h174 matches 1.. run function jb:world/bd/174
execute if score @s jb.h205 matches 1.. run function jb:world/bd/205
execute if score @s jb.h206 matches 1.. run function jb:world/bd/206
execute if score @s jb.h215 matches 1.. run function jb:world/bd/215
execute if score @s jb.h83 matches 1.. run function jb:world/bd/83
execute if score @s jb.h214 matches 1.. run function jb:world/bd/214
execute if score @s jb.h204 matches 1.. run function jb:world/bd/204
execute if score @s jb.h101 matches 1.. run function jb:world/bd/101
execute if score @s jb.h221 matches 1.. run function jb:world/bd/221
execute if score @s jb.h84 matches 1.. run function jb:world/bd/84
execute if score @s jb.h196 matches 1.. run function jb:world/bd/196
execute if score @s jb.h222 matches 1.. run function jb:world/bd/222
execute if score @s jb.h223 matches 1.. run function jb:world/bd/223
execute if score @s jb.h110 matches 1.. run function jb:world/bd/110
execute if score @s jb.h111 matches 1.. run function jb:world/bd/111
execute if score @s jb.h219 matches 1.. run function jb:world/bd/219
execute if score @s jb.h211 matches 1.. run function jb:world/bd/211
execute if score @s jb.h212 matches 1.. run function jb:world/bd/212
execute if score @s jb.h220 matches 1.. run function jb:world/bd/220
execute if score @s jb.h104 matches 1.. run function jb:world/bd/104
execute if score @s jb.h108 matches 1.. run function jb:world/bd/108
execute if score @s jb.h5 matches 1.. run function jb:world/bd/5
execute if score @s jb.h201 matches 1.. run function jb:world/bd/201
execute if score #ft jv matches 0 run data modify storage jb:wk bn set value [{text:"아직 없음",color:"dark_gray"}]
execute store result storage jb:wk bc.c int 1 run scoreboard players get #ft jv
function jb:world/bdh3 with storage jb:wk bc
data modify storage jb:wk bnc set value {text:""}
data modify storage jb:wk bnc.extra set from storage jb:wk bn
data modify entity @e[type=text_display,tag=jb.bdn3,limit=1] text set from storage jb:wk bnc
scoreboard players set #ft jv 0
data modify storage jb:wk bn set value [""]
execute if score @s jb.h258 matches 1.. run function jb:world/bd/258
execute if score @s jb.h237 matches 1.. run function jb:world/bd/237
execute if score @s jb.h257 matches 1.. run function jb:world/bd/257
execute if score @s jb.h227 matches 1.. run function jb:world/bd/227
execute if score @s jb.h238 matches 1.. run function jb:world/bd/238
execute if score @s jb.h43 matches 1.. run function jb:world/bd/43
execute if score @s jb.h229 matches 1.. run function jb:world/bd/229
execute if score @s jb.h250 matches 1.. run function jb:world/bd/250
execute if score @s jb.h74 matches 1.. run function jb:world/bd/74
execute if score @s jb.h79 matches 1.. run function jb:world/bd/79
execute if score @s jb.h91 matches 1.. run function jb:world/bd/91
execute if score @s jb.h92 matches 1.. run function jb:world/bd/92
execute if score @s jb.h177 matches 1.. run function jb:world/bd/177
execute if score @s jb.h138 matches 1.. run function jb:world/bd/138
execute if score @s jb.h230 matches 1.. run function jb:world/bd/230
execute if score @s jb.h232 matches 1.. run function jb:world/bd/232
execute if score @s jb.h231 matches 1.. run function jb:world/bd/231
execute if score @s jb.h226 matches 1.. run function jb:world/bd/226
execute if score @s jb.h14 matches 1.. run function jb:world/bd/14
execute if score @s jb.h19 matches 1.. run function jb:world/bd/19
execute if score @s jb.h259 matches 1.. run function jb:world/bd/259
execute if score @s jb.h228 matches 1.. run function jb:world/bd/228
execute if score @s jb.h251 matches 1.. run function jb:world/bd/251
execute if score @s jb.h256 matches 1.. run function jb:world/bd/256
execute if score @s jb.h175 matches 1.. run function jb:world/bd/175
execute if score @s jb.h233 matches 1.. run function jb:world/bd/233
execute if score @s jb.h234 matches 1.. run function jb:world/bd/234
execute if score @s jb.h252 matches 1.. run function jb:world/bd/252
execute if score @s jb.h236 matches 1.. run function jb:world/bd/236
execute if score @s jb.h225 matches 1.. run function jb:world/bd/225
execute if score @s jb.h255 matches 1.. run function jb:world/bd/255
execute if score @s jb.h239 matches 1.. run function jb:world/bd/239
execute if score @s jb.h240 matches 1.. run function jb:world/bd/240
execute if score @s jb.h235 matches 1.. run function jb:world/bd/235
execute if score @s jb.h253 matches 1.. run function jb:world/bd/253
execute if score @s jb.h254 matches 1.. run function jb:world/bd/254
execute if score @s jb.h241 matches 1.. run function jb:world/bd/241
execute if score @s jb.h242 matches 1.. run function jb:world/bd/242
execute if score @s jb.h243 matches 1.. run function jb:world/bd/243
execute if score @s jb.h244 matches 1.. run function jb:world/bd/244
execute if score @s jb.h245 matches 1.. run function jb:world/bd/245
execute if score @s jb.h246 matches 1.. run function jb:world/bd/246
execute if score @s jb.h247 matches 1.. run function jb:world/bd/247
execute if score @s jb.h248 matches 1.. run function jb:world/bd/248
execute if score @s jb.h249 matches 1.. run function jb:world/bd/249
execute if score @s jb.h261 matches 1.. run function jb:world/bd/261
execute if score @s jb.h262 matches 1.. run function jb:world/bd/262
execute if score @s jb.h263 matches 1.. run function jb:world/bd/263
execute if score @s jb.h260 matches 1.. run function jb:world/bd/260
execute if score @s jb.h224 matches 1.. run function jb:world/bd/224
execute if score #ft jv matches 0 run data modify storage jb:wk bn set value [{text:"아직 없음",color:"dark_gray"}]
execute store result storage jb:wk bc.c int 1 run scoreboard players get #ft jv
function jb:world/bdh4 with storage jb:wk bc
execute unless score @s jb.lv matches 10.. run data modify storage jb:wk bn set value [{text:"🔒 Lv.10",color:"dark_gray"}]
data modify storage jb:wk bnc set value {text:""}
data modify storage jb:wk bnc.extra set from storage jb:wk bn
data modify entity @e[type=text_display,tag=jb.bdn4,limit=1] text set from storage jb:wk bnc
scoreboard players set #ft jv 0
data modify storage jb:wk bn set value [""]
execute if score @s jb.h307 matches 1.. run function jb:world/bd/307
execute if score @s jb.h310 matches 1.. run function jb:world/bd/310
execute if score @s jb.h311 matches 1.. run function jb:world/bd/311
execute if score @s jb.h309 matches 1.. run function jb:world/bd/309
execute if score @s jb.h288 matches 1.. run function jb:world/bd/288
execute if score @s jb.h6 matches 1.. run function jb:world/bd/6
execute if score @s jb.h145 matches 1.. run function jb:world/bd/145
execute if score @s jb.h312 matches 1.. run function jb:world/bd/312
execute if score @s jb.h301 matches 1.. run function jb:world/bd/301
execute if score @s jb.h266 matches 1.. run function jb:world/bd/266
execute if score @s jb.h267 matches 1.. run function jb:world/bd/267
execute if score @s jb.h303 matches 1.. run function jb:world/bd/303
execute if score @s jb.h271 matches 1.. run function jb:world/bd/271
execute if score @s jb.h272 matches 1.. run function jb:world/bd/272
execute if score @s jb.h287 matches 1.. run function jb:world/bd/287
execute if score @s jb.h32 matches 1.. run function jb:world/bd/32
execute if score @s jb.h183 matches 1.. run function jb:world/bd/183
execute if score @s jb.h294 matches 1.. run function jb:world/bd/294
execute if score @s jb.h296 matches 1.. run function jb:world/bd/296
execute if score @s jb.h268 matches 1.. run function jb:world/bd/268
execute if score @s jb.h15 matches 1.. run function jb:world/bd/15
execute if score @s jb.h20 matches 1.. run function jb:world/bd/20
execute if score @s jb.h276 matches 1.. run function jb:world/bd/276
execute if score @s jb.h277 matches 1.. run function jb:world/bd/277
execute if score @s jb.h284 matches 1.. run function jb:world/bd/284
execute if score @s jb.h295 matches 1.. run function jb:world/bd/295
execute if score @s jb.h300 matches 1.. run function jb:world/bd/300
execute if score @s jb.h281 matches 1.. run function jb:world/bd/281
execute if score @s jb.h282 matches 1.. run function jb:world/bd/282
execute if score @s jb.h34 matches 1.. run function jb:world/bd/34
execute if score @s jb.h273 matches 1.. run function jb:world/bd/273
execute if score @s jb.h278 matches 1.. run function jb:world/bd/278
execute if score @s jb.h105 matches 1.. run function jb:world/bd/105
execute if score @s jb.h109 matches 1.. run function jb:world/bd/109
execute if score @s jb.h44 matches 1.. run function jb:world/bd/44
execute if score @s jb.h146 matches 1.. run function jb:world/bd/146
execute if score @s jb.h308 matches 1.. run function jb:world/bd/308
execute if score @s jb.h291 matches 1.. run function jb:world/bd/291
execute if score @s jb.h78 matches 1.. run function jb:world/bd/78
execute if score @s jb.h285 matches 1.. run function jb:world/bd/285
execute if score @s jb.h286 matches 1.. run function jb:world/bd/286
execute if score @s jb.h289 matches 1.. run function jb:world/bd/289
execute if score @s jb.h290 matches 1.. run function jb:world/bd/290
execute if score @s jb.h298 matches 1.. run function jb:world/bd/298
execute if score @s jb.h299 matches 1.. run function jb:world/bd/299
execute if score @s jb.h274 matches 1.. run function jb:world/bd/274
execute if score @s jb.h77 matches 1.. run function jb:world/bd/77
execute if score @s jb.h275 matches 1.. run function jb:world/bd/275
execute if score @s jb.h305 matches 1.. run function jb:world/bd/305
execute if score @s jb.h306 matches 1.. run function jb:world/bd/306
execute if score @s jb.h283 matches 1.. run function jb:world/bd/283
execute if score @s jb.h292 matches 1.. run function jb:world/bd/292
execute if score @s jb.h280 matches 1.. run function jb:world/bd/280
execute if score @s jb.h313 matches 1.. run function jb:world/bd/313
execute if score @s jb.h314 matches 1.. run function jb:world/bd/314
execute if score @s jb.h315 matches 1.. run function jb:world/bd/315
execute if score @s jb.h316 matches 1.. run function jb:world/bd/316
execute if score @s jb.h317 matches 1.. run function jb:world/bd/317
execute if score @s jb.h318 matches 1.. run function jb:world/bd/318
execute if score @s jb.h319 matches 1.. run function jb:world/bd/319
execute if score @s jb.h320 matches 1.. run function jb:world/bd/320
execute if score @s jb.h321 matches 1.. run function jb:world/bd/321
execute if score @s jb.h322 matches 1.. run function jb:world/bd/322
execute if score @s jb.h323 matches 1.. run function jb:world/bd/323
execute if score @s jb.h324 matches 1.. run function jb:world/bd/324
execute if score @s jb.h325 matches 1.. run function jb:world/bd/325
execute if score @s jb.h326 matches 1.. run function jb:world/bd/326
execute if score @s jb.h327 matches 1.. run function jb:world/bd/327
execute if score @s jb.h328 matches 1.. run function jb:world/bd/328
execute if score @s jb.h329 matches 1.. run function jb:world/bd/329
execute if score @s jb.h330 matches 1.. run function jb:world/bd/330
execute if score @s jb.h331 matches 1.. run function jb:world/bd/331
execute if score @s jb.h332 matches 1.. run function jb:world/bd/332
execute if score @s jb.h333 matches 1.. run function jb:world/bd/333
execute if score @s jb.h334 matches 1.. run function jb:world/bd/334
execute if score @s jb.h335 matches 1.. run function jb:world/bd/335
execute if score @s jb.h336 matches 1.. run function jb:world/bd/336
execute if score @s jb.h337 matches 1.. run function jb:world/bd/337
execute if score @s jb.h338 matches 1.. run function jb:world/bd/338
execute if score @s jb.h339 matches 1.. run function jb:world/bd/339
execute if score @s jb.h340 matches 1.. run function jb:world/bd/340
execute if score @s jb.h341 matches 1.. run function jb:world/bd/341
execute if score @s jb.h342 matches 1.. run function jb:world/bd/342
execute if score @s jb.h343 matches 1.. run function jb:world/bd/343
execute if score @s jb.h344 matches 1.. run function jb:world/bd/344
execute if score @s jb.h345 matches 1.. run function jb:world/bd/345
execute if score @s jb.h346 matches 1.. run function jb:world/bd/346
execute if score @s jb.h347 matches 1.. run function jb:world/bd/347
execute if score @s jb.h348 matches 1.. run function jb:world/bd/348
execute if score @s jb.h349 matches 1.. run function jb:world/bd/349
execute if score @s jb.h350 matches 1.. run function jb:world/bd/350
execute if score @s jb.h269 matches 1.. run function jb:world/bd/269
execute if score @s jb.h270 matches 1.. run function jb:world/bd/270
execute if score @s jb.h264 matches 1.. run function jb:world/bd/264
execute if score @s jb.h293 matches 1.. run function jb:world/bd/293
execute if score @s jb.h297 matches 1.. run function jb:world/bd/297
execute if score @s jb.h304 matches 1.. run function jb:world/bd/304
execute if score @s jb.h302 matches 1.. run function jb:world/bd/302
execute if score @s jb.h265 matches 1.. run function jb:world/bd/265
execute if score @s jb.h279 matches 1.. run function jb:world/bd/279
execute if score #ft jv matches 0 run data modify storage jb:wk bn set value [{text:"아직 없음",color:"dark_gray"}]
execute store result storage jb:wk bc.c int 1 run scoreboard players get #ft jv
function jb:world/bdh5 with storage jb:wk bc
execute unless score @s jb.lv matches 20.. run data modify storage jb:wk bn set value [{text:"🔒 Lv.20",color:"dark_gray"}]
data modify storage jb:wk bnc set value {text:""}
data modify storage jb:wk bnc.extra set from storage jb:wk bn
data modify entity @e[type=text_display,tag=jb.bdn5,limit=1] text set from storage jb:wk bnc
