$data modify entity @e[type=text_display,tag=jb.bdh5,limit=1] text set value [{"text": "신화  ", "color": "red", "bold": true}, {"text": "$(c)/100", "color": "white", "bold": false}]
