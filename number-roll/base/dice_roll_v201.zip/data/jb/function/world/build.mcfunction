kill @e[tag=dice.ent]
kill @e[tag=jb.ent]
kill @e[tag=nr.entity]
fill -20 148 -20 20 164 20 air
fill -16 150 -16 16 150 16 smooth_quartz
fill -16 149 -16 16 149 16 polished_blackstone_bricks
fill -16 150 -16 16 150 -16 polished_blackstone_bricks
fill -16 150 16 16 150 16 polished_blackstone_bricks
fill -16 150 -16 -16 150 16 polished_blackstone_bricks
fill 16 150 -16 16 150 16 polished_blackstone_bricks
fill -16 151 -16 16 151 -16 polished_blackstone_wall
fill -16 151 16 16 151 16 polished_blackstone_wall
fill -16 151 -16 -16 151 16 polished_blackstone_wall
fill 16 151 -16 16 151 16 polished_blackstone_wall
fill -16 152 -16 16 158 -16 barrier
fill -16 152 16 16 158 16 barrier
fill -16 152 -16 -16 158 16 barrier
fill 16 152 -16 16 158 16 barrier
setblock -12 150 -12 sea_lantern
setblock -12 150 -6 sea_lantern
setblock -12 150 0 sea_lantern
setblock -12 150 6 sea_lantern
setblock -12 150 12 sea_lantern
setblock -6 150 -12 sea_lantern
setblock -6 150 -6 sea_lantern
setblock -6 150 0 sea_lantern
setblock -6 150 6 sea_lantern
setblock -6 150 12 sea_lantern
setblock 0 150 -12 sea_lantern
setblock 0 150 -6 sea_lantern
setblock 0 150 0 sea_lantern
setblock 0 150 6 sea_lantern
setblock 0 150 12 sea_lantern
setblock 6 150 -12 sea_lantern
setblock 6 150 -6 sea_lantern
setblock 6 150 0 sea_lantern
setblock 6 150 6 sea_lantern
setblock 6 150 12 sea_lantern
setblock 12 150 -12 sea_lantern
setblock 12 150 -6 sea_lantern
setblock 12 150 0 sea_lantern
setblock 12 150 6 sea_lantern
setblock 12 150 12 sea_lantern
fill 0 150 -10 0 150 10 yellow_glazed_terracotta
setblock 0 150 0 sea_lantern
fill -8 151 -15 8 159 -15 gold_block
fill -7 152 -15 7 158 -15 black_concrete
fill -8 151 -14 8 151 -13 polished_blackstone_bricks
fill -7 152 -14 7 152 -14 gold_block
setblock 0 151 -11 polished_blackstone_bricks
setblock 0 152 -11 red_concrete
summon text_display 0.5 156.6 -13.95 {text:[{"text": "⚀ 숫자 굴리기 ⚀", "color": "gold", "bold": true}],billboard:"fixed",Rotation:[0f,0f],alignment:"center",background:0,shadow:1b,line_width:400,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[3.2f,3.2f,3.2f]},Tags:["jb.ent","jb.v13"]}
summon text_display 0.5 155.3 -13.95 {text:[{"text": "숫자 속 ", "color": "white"}, {"text": "족보", "color": "yellow", "bold": true}, {"text": "를 찾아라!", "color": "white"}],billboard:"fixed",Rotation:[0f,0f],alignment:"center",background:0,shadow:1b,line_width:400,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.6f,1.6f,1.6f]},Tags:["jb.ent","jb.v13"]}
summon interaction 0.5 151.85 -10.5 {width:1.2f,height:1.3f,response:1b,Tags:["jb.ent","jb.v13","jb.btn","jb.b_roll"]}
summon text_display 0.5 153.4 -10.5 {text:[{"text": "▶ 우클릭 ◀", "color": "red", "bold": true}],billboard:"fixed",Rotation:[0f,0f],alignment:"center",background:0,shadow:1b,line_width:400,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.3f,1.3f,1.3f]},Tags:["jb.ent","jb.v13"]}
fill -15 151 -14 -15 159 14 gold_block
fill -15 151 -13 -15 158 13 black_concrete
summon text_display -13.95 157.25 0.5 {text:[{"text": "📖 족보 도감 📖", "color": "gold", "bold": true}],billboard:"fixed",Rotation:[-90f,0f],alignment:"center",background:0,shadow:1b,line_width:400,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.6f,1.6f,1.6f]},Tags:["jb.ent","jb.v13"]}
summon text_display -13.95 156.7 0.5 {text:[{"text": "...", "color": "white"}],billboard:"fixed",Rotation:[-90f,0f],alignment:"center",background:0,shadow:1b,line_width:400,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},Tags:["jb.ent","jb.v13","jb.dex_h"]}
summon text_display -13.95 155.9 12.08 {text:[{"text": "흔함", "color": "white", "bold": true}],billboard:"fixed",Rotation:[-90f,0f],alignment:"center",background:0,shadow:1b,line_width:400,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.9f,0.9f,0.9f]},Tags:["jb.ent","jb.v13","jb.bdh0"]}
summon text_display -13.95 151.15 12.08 {text:[{"text": " "}],billboard:"fixed",Rotation:[-90f,0f],alignment:"center",background:0,shadow:1b,line_width:139,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.7f,0.7f,0.7f]},Tags:["jb.ent","jb.v13","jb.bdn0"]}
summon text_display -13.95 155.9 8.89 {text:[{"text": "보통", "color": "green", "bold": true}],billboard:"fixed",Rotation:[-90f,0f],alignment:"center",background:0,shadow:1b,line_width:400,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.9f,0.9f,0.9f]},Tags:["jb.ent","jb.v13","jb.bdh1"]}
summon text_display -13.95 151.15 8.89 {text:[{"text": " "}],billboard:"fixed",Rotation:[-90f,0f],alignment:"center",background:0,shadow:1b,line_width:179,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.7f,0.7f,0.7f]},Tags:["jb.ent","jb.v13","jb.bdn1"]}
summon text_display -13.95 155.9 4.95 {text:[{"text": "희귀", "color": "aqua", "bold": true}],billboard:"fixed",Rotation:[-90f,0f],alignment:"center",background:0,shadow:1b,line_width:400,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.9f,0.9f,0.9f]},Tags:["jb.ent","jb.v13","jb.bdh2"]}
summon text_display -13.95 151.15 4.95 {text:[{"text": " "}],billboard:"fixed",Rotation:[-90f,0f],alignment:"center",background:0,shadow:1b,line_width:224,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.7f,0.7f,0.7f]},Tags:["jb.ent","jb.v13","jb.bdn2"]}
summon text_display -13.95 155.9 1.02 {text:[{"text": "영웅", "color": "light_purple", "bold": true}],billboard:"fixed",Rotation:[-90f,0f],alignment:"center",background:0,shadow:1b,line_width:400,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.9f,0.9f,0.9f]},Tags:["jb.ent","jb.v13","jb.bdh3"]}
summon text_display -13.95 151.15 1.02 {text:[{"text": " "}],billboard:"fixed",Rotation:[-90f,0f],alignment:"center",background:0,shadow:1b,line_width:178,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.7f,0.7f,0.7f]},Tags:["jb.ent","jb.v13","jb.bdn3"]}
summon text_display -13.95 155.9 -2.68 {text:[{"text": "전설", "color": "gold", "bold": true}],billboard:"fixed",Rotation:[-90f,0f],alignment:"center",background:0,shadow:1b,line_width:400,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.9f,0.9f,0.9f]},Tags:["jb.ent","jb.v13","jb.bdh4"]}
summon text_display -13.95 151.15 -2.68 {text:[{"text": " "}],billboard:"fixed",Rotation:[-90f,0f],alignment:"center",background:0,shadow:1b,line_width:197,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.7f,0.7f,0.7f]},Tags:["jb.ent","jb.v13","jb.bdn4"]}
summon text_display -13.95 155.9 -8.55 {text:[{"text": "신화", "color": "red", "bold": true}],billboard:"fixed",Rotation:[-90f,0f],alignment:"center",background:0,shadow:1b,line_width:400,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.9f,0.9f,0.9f]},Tags:["jb.ent","jb.v13","jb.bdh5"]}
summon text_display -13.95 151.15 -8.55 {text:[{"text": " "}],billboard:"fixed",Rotation:[-90f,0f],alignment:"center",background:0,shadow:1b,line_width:428,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.7f,0.7f,0.7f]},Tags:["jb.ent","jb.v13","jb.bdn5"]}
fill 14 151 -14 14 159 14 gold_block
fill 14 151 -13 14 158 13 black_concrete
summon text_display 13.95 157.25 0.5 {text:[{"text": "⚀ 최근 숫자 ⚀", "color": "gold", "bold": true}],billboard:"fixed",Rotation:[90f,0f],alignment:"center",background:0,shadow:1b,line_width:400,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.6f,1.6f,1.6f]},Tags:["jb.ent","jb.v13"]}
summon text_display 13.95 151.15 -11.65 {text:[{"text": " "}],billboard:"fixed",Rotation:[90f,0f],alignment:"center",background:0,shadow:1b,line_width:200,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.88f,0.88f,0.88f]},Tags:["jb.ent","jb.v13","jb.rb0"]}
summon text_display 13.95 151.15 -10.03 {text:[{"text": " "}],billboard:"fixed",Rotation:[90f,0f],alignment:"center",background:0,shadow:1b,line_width:200,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.88f,0.88f,0.88f]},Tags:["jb.ent","jb.v13","jb.rb1"]}
summon text_display 13.95 151.15 -8.41 {text:[{"text": " "}],billboard:"fixed",Rotation:[90f,0f],alignment:"center",background:0,shadow:1b,line_width:200,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.88f,0.88f,0.88f]},Tags:["jb.ent","jb.v13","jb.rb2"]}
summon text_display 13.95 151.15 -6.79 {text:[{"text": " "}],billboard:"fixed",Rotation:[90f,0f],alignment:"center",background:0,shadow:1b,line_width:200,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.88f,0.88f,0.88f]},Tags:["jb.ent","jb.v13","jb.rb3"]}
summon text_display 13.95 151.15 -5.17 {text:[{"text": " "}],billboard:"fixed",Rotation:[90f,0f],alignment:"center",background:0,shadow:1b,line_width:200,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.88f,0.88f,0.88f]},Tags:["jb.ent","jb.v13","jb.rb4"]}
summon text_display 13.95 151.15 -3.55 {text:[{"text": " "}],billboard:"fixed",Rotation:[90f,0f],alignment:"center",background:0,shadow:1b,line_width:200,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.88f,0.88f,0.88f]},Tags:["jb.ent","jb.v13","jb.rb5"]}
summon text_display 13.95 151.15 -1.93 {text:[{"text": " "}],billboard:"fixed",Rotation:[90f,0f],alignment:"center",background:0,shadow:1b,line_width:200,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.88f,0.88f,0.88f]},Tags:["jb.ent","jb.v13","jb.rb6"]}
summon text_display 13.95 151.15 -0.31 {text:[{"text": " "}],billboard:"fixed",Rotation:[90f,0f],alignment:"center",background:0,shadow:1b,line_width:200,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.88f,0.88f,0.88f]},Tags:["jb.ent","jb.v13","jb.rb7"]}
summon text_display 13.95 151.15 1.31 {text:[{"text": " "}],billboard:"fixed",Rotation:[90f,0f],alignment:"center",background:0,shadow:1b,line_width:200,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.88f,0.88f,0.88f]},Tags:["jb.ent","jb.v13","jb.rb8"]}
summon text_display 13.95 151.15 2.93 {text:[{"text": " "}],billboard:"fixed",Rotation:[90f,0f],alignment:"center",background:0,shadow:1b,line_width:200,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.88f,0.88f,0.88f]},Tags:["jb.ent","jb.v13","jb.rb9"]}
summon text_display 13.95 151.15 4.55 {text:[{"text": " "}],billboard:"fixed",Rotation:[90f,0f],alignment:"center",background:0,shadow:1b,line_width:200,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.88f,0.88f,0.88f]},Tags:["jb.ent","jb.v13","jb.rb10"]}
summon text_display 13.95 151.15 6.17 {text:[{"text": " "}],billboard:"fixed",Rotation:[90f,0f],alignment:"center",background:0,shadow:1b,line_width:200,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.88f,0.88f,0.88f]},Tags:["jb.ent","jb.v13","jb.rb11"]}
summon text_display 13.95 151.15 7.79 {text:[{"text": " "}],billboard:"fixed",Rotation:[90f,0f],alignment:"center",background:0,shadow:1b,line_width:200,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.88f,0.88f,0.88f]},Tags:["jb.ent","jb.v13","jb.rb12"]}
summon text_display 13.95 151.15 9.41 {text:[{"text": " "}],billboard:"fixed",Rotation:[90f,0f],alignment:"center",background:0,shadow:1b,line_width:200,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.88f,0.88f,0.88f]},Tags:["jb.ent","jb.v13","jb.rb13"]}
summon text_display 13.95 151.15 11.03 {text:[{"text": " "}],billboard:"fixed",Rotation:[90f,0f],alignment:"center",background:0,shadow:1b,line_width:200,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.88f,0.88f,0.88f]},Tags:["jb.ent","jb.v13","jb.rb14"]}
summon text_display 13.95 151.15 12.65 {text:[{"text": " "}],billboard:"fixed",Rotation:[90f,0f],alignment:"center",background:0,shadow:1b,line_width:200,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.88f,0.88f,0.88f]},Tags:["jb.ent","jb.v13","jb.rb15"]}
function jb:rb/init
summon text_display 0.5 152.6 15.9 {text:[{"text": "⚀ 하는 법 ⚀\n", "color": "gold", "bold": true}, {"text": "빨간 블록 우클릭 → 숫자 9자리\n", "color": "white"}, {"text": "족보가 있으면 ", "color": "white"}, {"text": "딩!", "color": "yellow", "bold": true}, {"text": " 전부 코인\n", "color": "white"}, {"text": "예) 4", "color": "gray"}, {"text": "77", "color": "#F2F2F2", "bold": true}, {"text": "1", "color": "gray"}, {"text": "555", "color": "#F2F2F2", "bold": true}, {"text": "09 → ", "color": "gray"}, {"text": "쌍둥이", "color": "white", "bold": true}, {"text": " + ", "color": "gray"}, {"text": "삼총사", "color": "white", "bold": true}, {"text": " + ", "color": "gray"}, {"text": "더블 데이트", "color": "white", "bold": true}, {"text": "\n\n레벨업 → ", "color": "white"}, {"text": "⭐ 강화 포인트", "color": "aqua", "bold": true}, {"text": " + ", "color": "white"}, {"text": "⛃ 선물\n", "color": "gold", "bold": true}, {"text": "Lv.10 🔓 전설", "color": "gold", "bold": true}, {"text": "     ", "color": "white"}, {"text": "Lv.20 🔓 신화", "color": "red", "bold": true}, {"text": "\n\n📖 목표: 족보 350개 모으기", "color": "yellow"}],billboard:"fixed",Rotation:[180f,0f],alignment:"center",background:0,shadow:1b,line_width:400,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.0f,1.0f,1.0f]},Tags:["jb.ent","jb.v13"]}
setworldspawn 0 151 11
time set noon
weather clear
scoreboard players set #built jv 1
scoreboard players set #bver jv 13
forceload remove -32 -32 32 32
forceload add -16 -16 16 16
tp @a[scores={jb.rolls=1..}] 0.5 151 4.5 180 0
tp @a[scores={jb.rolls=..0}] 0.5 151 11.5 0 -10
effect clear @a minecraft:slow_falling
execute as @a run function jb:player/items
execute as @a[scores={jb.pid=1..}] run function jb:ms/init
scoreboard players set #bdt jv 99
