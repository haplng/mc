$data modify entity @e[type=text_display,tag=jb.bdh1,limit=1] text set value [{"text": "보통  ", "color": "green", "bold": true}, {"text": "$(c)/52", "color": "white", "bold": false}]
