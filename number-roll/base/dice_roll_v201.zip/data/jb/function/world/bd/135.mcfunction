execute if score #ft jv matches 1.. run data modify storage jb:wk bn append value {"text": " · ", "color": "dark_gray"}
data modify storage jb:wk bn append value {"text": "주사위 놀이", "color": "green"}
scoreboard players add #ft jv 1
