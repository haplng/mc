execute if score #ft jv matches 1.. run data modify storage jb:wk bn append value {"text": " · ", "color": "dark_gray"}
data modify storage jb:wk bn append value {"text": "원주율 그랜드마스터", "color": "gold"}
scoreboard players add #ft jv 1
