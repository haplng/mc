execute if score #ft jv matches 1.. run data modify storage jb:wk bn append value {"text": " · ", "color": "dark_gray"}
data modify storage jb:wk bn append value {"text": "2의 16제곱", "color": "light_purple"}
scoreboard players add #ft jv 1
