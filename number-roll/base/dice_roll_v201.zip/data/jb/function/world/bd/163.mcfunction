execute if score #ft jv matches 1.. run data modify storage jb:wk bn append value {"text": " · ", "color": "dark_gray"}
data modify storage jb:wk bn append value {"text": "구구단을 외자", "color": "white"}
scoreboard players add #ft jv 1
