execute if score #ft jv matches 1.. run data modify storage jb:wk bn append value {"text": " · ", "color": "dark_gray"}
data modify storage jb:wk bn append value {"text": "하위 0.001%", "color": "gold"}
scoreboard players add #ft jv 1
