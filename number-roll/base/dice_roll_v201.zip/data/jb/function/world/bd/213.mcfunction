execute if score #ft jv matches 1.. run data modify storage jb:wk bn append value {"text": " · ", "color": "dark_gray"}
data modify storage jb:wk bn append value {"text": "피보나치 마스터", "color": "light_purple"}
scoreboard players add #ft jv 1
