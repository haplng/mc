execute if score @s jb.state matches 1..2 run return 0
scoreboard players operation #bdk jv = @s jb.found
scoreboard players operation #bdk jv *= #c100 jv
scoreboard players operation #bdk jv += @s jb.lv
scoreboard players operation #bdk jv *= #c1000 jv
scoreboard players operation #bdk jv += @s jb.pid
execute if score #bdk jv = #bdlast jv if score #bdt jv matches ..98 run return run scoreboard players set #bdt jv 0
scoreboard players operation #bdlast jv = #bdk jv
function jb:world/board
