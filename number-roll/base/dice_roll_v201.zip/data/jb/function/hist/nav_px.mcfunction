$data modify storage jb:wk hd.acts append value {"label": {"text": "◀ 최근", "color": "dark_gray"}, "width": 200, "action": {"type": "minecraft:run_command", "command": "/trigger jb.menu set $(cv)"}}
