execute store result storage jb:wk hq.pid int 1 run scoreboard players get @s jb.pid
data modify storage jb:wk hl set value []
function jb:hist/load with storage jb:wk hq
execute store result score #hn jv run data get storage jb:wk hl
scoreboard players operation #hpt jv = #hn jv
scoreboard players add #hpt jv 19
scoreboard players operation #hpt jv /= #c20 jv
execute if score #hpt jv matches ..0 run scoreboard players set #hpt jv 1
scoreboard players operation #hmx jv = #hpt jv
scoreboard players remove #hmx jv 1
scoreboard players operation #hp jv < #hmx jv
execute if score #hp jv matches ..-1 run scoreboard players set #hp jv 0
scoreboard players operation #hs jv = #hp jv
scoreboard players operation #hs jv *= #c20 jv
function jb:hist/skip
data modify storage jb:wk hd set value {acts:[]}
scoreboard players set #hi jv 0
function jb:hist/take
scoreboard players operation #t jv = #hp jv
scoreboard players add #t jv 2999
execute store result storage jb:wk hd.pv int 1 run scoreboard players get #t jv
scoreboard players add #t jv 2
execute store result storage jb:wk hd.nv int 1 run scoreboard players get #t jv
scoreboard players remove #t jv 1
execute store result storage jb:wk hd.cv int 1 run scoreboard players get #t jv
execute if score #hp jv matches 1.. run function jb:hist/nav_p with storage jb:wk hd
execute if score #hp jv matches 0 run function jb:hist/nav_px with storage jb:wk hd
execute if data storage jb:wk hl[-1] run function jb:hist/nav_n with storage jb:wk hd
execute unless data storage jb:wk hl[-1] run function jb:hist/nav_nx with storage jb:wk hd
data modify storage jb:wk hd.acts append value {"label": {"text": "🔍 검색", "color": "yellow", "bold": true}, "width": 200, "action": {"type": "minecraft:dynamic/run_command", "template": "trigger jb.srch set $(q)"}}
data modify storage jb:wk hd.acts append value {"label": {"text": "← 메뉴", "color": "gray"}, "width": 200, "action": {"type": "minecraft:run_command", "command": "/trigger jb.menu set 1"}}
execute store result storage jb:wk hd.hn int 1 run scoreboard players get #hn jv
scoreboard players operation #t jv = #hp jv
scoreboard players add #t jv 1
execute store result storage jb:wk hd.pg int 1 run scoreboard players get #t jv
execute store result storage jb:wk hd.pt int 1 run scoreboard players get #hpt jv
execute if score #hn jv matches 0 run return run function jb:hist/show0 with storage jb:wk hd
function jb:hist/show with storage jb:wk hd
