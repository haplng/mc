data modify storage jb:wk sd.rec set value {"text": "   ✔ 굴려 본 숫자", "color": "green"}
