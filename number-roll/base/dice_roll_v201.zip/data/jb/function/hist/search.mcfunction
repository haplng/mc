scoreboard players operation #sq jv = @s jb.srch
scoreboard players set @s jb.srch -1
execute if score #sq jv matches 1000000000.. run return run function jb:snd/play {s:"minecraft:block.note_block.bass",b:70,p:0.7}
scoreboard players operation #n jv = #sq jv
function jb:num/d9
scoreboard players set #K jv 9
scoreboard players set #dry jv 1
data modify storage jb:wk dl set value [{"text": "걸린 족보", "color": "gray"}]
function jb:hand/core
function jb:hand/sum
execute if score #nh jv matches 0 run data modify storage jb:wk dl append value {"text": "\n(없음)", "color": "dark_gray"}
execute unless score @s jb.lv matches 20.. run data modify storage jb:wk dl append value {"text": "\n\n🔒 전설 Lv.10 · 신화 Lv.20에 열림", "color": "dark_gray"}
scoreboard players set #dry jv 0
data modify storage jb:wk r set value {}
function jb:num/ns
function jb:vis/build
data modify storage jb:wk sd set value {q:"$(q)"}
data modify storage jb:wk sd.v set from storage jb:wk vis
data modify storage jb:wk sd.ns set from storage jb:wk r.ns
execute store result storage jb:wk sd.n int 1 run scoreboard players get #sq jv
execute store result storage jb:wk sd.k int 1 run scoreboard players get #nh jv
scoreboard players operation #fn jv = #pay jv
function jb:sys/comma
data modify storage jb:wk sd.c set from storage jb:wk cm.o
execute store result storage jb:wk sd.pid int 1 run scoreboard players get @s jb.pid
data modify storage jb:wk sd.dl set from storage jb:wk dl
data modify storage jb:wk sd.rec set value {"text": "", "color": "gray"}
function jb:hist/find with storage jb:wk sd
function jb:hist/detail with storage jb:wk sd
function jb:snd/play {s:"minecraft:ui.button.click",b:60,p:1.2}
