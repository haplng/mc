function jb:hist/ent with storage jb:wk hl[-1]
data remove storage jb:wk hl[-1]
scoreboard players add #hi jv 1
function jb:hist/take
