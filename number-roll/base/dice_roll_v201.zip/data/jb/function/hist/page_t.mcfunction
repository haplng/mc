scoreboard players operation #hp jv = #m jv
scoreboard players remove #hp jv 3000
function jb:hist/page
function jb:snd/play {s:"minecraft:item.book.page_turn",b:60,p:1}
