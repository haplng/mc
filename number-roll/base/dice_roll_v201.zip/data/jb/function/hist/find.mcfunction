data remove storage jb:wk hm
$data modify storage jb:wk hm set from storage jb:hist h.p$(pid)[{n:$(n)}]
execute if data storage jb:wk hm.n run function jb:hist/found with storage jb:wk hm
