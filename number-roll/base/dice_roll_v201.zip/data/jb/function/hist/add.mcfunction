data remove storage jb:wk r.vis
$data modify storage jb:hist h.p$(pid) append from storage jb:wk r
$execute store result score #hs jv run data get storage jb:hist h.p$(pid)
$execute if score #hs jv matches 1001.. run data remove storage jb:hist h.p$(pid)[0]
data modify storage jb:wk r.vis set from storage jb:wk vis
