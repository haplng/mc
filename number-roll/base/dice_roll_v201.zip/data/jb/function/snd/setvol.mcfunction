scoreboard players operation @s jb.vol = #m jv
scoreboard players remove @s jb.vol 2000
function jb:snd/play {s:"minecraft:block.note_block.chime",b:60,p:1.6}
function jb:menu/sound
