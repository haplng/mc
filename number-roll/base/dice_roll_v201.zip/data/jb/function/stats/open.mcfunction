function jb:player/mig
data modify storage jb:wk st set value {}
scoreboard players operation #s jv = @s jb.ptk
scoreboard players operation #s jv /= #c20 jv
scoreboard players operation #h jv = #s jv
scoreboard players operation #h jv /= #c3600 jv
scoreboard players operation #s jv %= #c3600 jv
scoreboard players operation #s jv /= #c60 jv
execute store result storage jb:wk st.h int 1 run scoreboard players get #h jv
execute store result storage jb:wk st.m int 1 run scoreboard players get #s jv
execute store result storage jb:wk st.r int 1 run scoreboard players get @s jb.rolls
execute store result storage jb:wk st.l int 1 run scoreboard players get @s jb.lv
execute store result storage jb:wk st.f int 1 run scoreboard players get @s jb.found
execute store result storage jb:wk st.rr int 1 run scoreboard players get @s jb.rr
execute store result storage jb:wk st.md int 1 run scoreboard players get @s jb.mdone
scoreboard players operation #fh jv = @s jb.rch
scoreboard players operation #fl jv = @s jb.rc
function jb:sys/fmt
data modify storage jb:wk st.rc set from storage jb:wk f.out
scoreboard players operation #fh jv = @s jb.tch
scoreboard players operation #fl jv = @s jb.tcl
function jb:sys/fmt
data modify storage jb:wk st.tc set from storage jb:wk f.out
data modify storage jb:wk st.b set value {text:"아직 없음",color:"gray"}
data modify storage jb:wk st.bn set value ""
execute if score @s jb.topid matches 1.. run function jb:stats/top
function jb:stats/show with storage jb:wk st
function jb:snd/play {s:"minecraft:item.book.page_turn",b:60,p:1}
