execute store result storage jb:wk bi.i int 1 run scoreboard players get @s jb.topid
function jb:hand/bn with storage jb:wk bi
data modify storage jb:wk st.b set from storage jb:wk r.bn
scoreboard players operation #n jv = @s jb.topn
function jb:num/d9
function jb:num/ns
data modify storage jb:wk st.bn set from storage jb:wk r.ns
