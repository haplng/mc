scoreboard players set @s jb.u1 10
scoreboard players set @s jb.u2 10
scoreboard players set @s jb.u3 7
scoreboard players set @s jb.u4 10
scoreboard players set @s jb.e1 5
scoreboard players set @s jb.e2 5
scoreboard players set @s jb.e3 5
scoreboard players set @s jb.e4 5
scoreboard players set @s jb.e5 3
scoreboard players set @s jb.ept 0
scoreboard players set @s jb.autoon 1
scoreboard players set @s jb.lv 21
scoreboard players set @s jb.xp 0
function jb:lv/bar
scoreboard players set #bdt jv 99
tellraw @s {text:"[숫자 굴리기] 업그레이드와 레벨을 최대로 만들었어요.",color:"yellow"}
