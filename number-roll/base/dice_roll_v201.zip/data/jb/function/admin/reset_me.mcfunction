function jb:hist/clear_me
scoreboard players reset @s jb.pid
xp set @s 0 levels
xp set @s 0 points
tellraw @s {text:"[숫자 굴리기] 내 기록을 초기화했어요.",color:"yellow"}
