$scoreboard players set #ac jv $(n)
execute if score #ac jv matches 1500000001.. run scoreboard players set #ac jv 1500000000
execute if score #ac jv matches ..-1 run scoreboard players set #ac jv 0
scoreboard players operation @s jb.coins = #ac jv
tellraw @s [{"text": "[숫자 굴리기] ", "color": "yellow"}, {"text": "코인: ", "color": "white"}, {"score": {"name": "@s", "objective": "jb.coins"}, "color": "gold", "bold": true}, {"text": "⛃", "color": "gold"}]
