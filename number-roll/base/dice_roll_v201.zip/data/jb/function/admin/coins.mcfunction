scoreboard players add @s jb.coins 100000
tellraw @s [{"text": "[숫자 굴리기] ", "color": "yellow"}, {"text": "코인: ", "color": "white"}, {"score": {"name": "@s", "objective": "jb.coins"}, "color": "gold", "bold": true}, {"text": "⛃", "color": "gold"}]
