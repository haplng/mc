execute as @a[scores={jb.pid=1..}] run function jb:player/bb_rm_me
advancement revoke @a from jb:root
scoreboard players reset * jb.pid
scoreboard players reset * jb.dv
data remove storage jb:hist h
data remove storage jb:fd f
data remove storage jb:ms m
scoreboard players reset * jb.side
function jb:rb/init
function jb:rb/draw
xp set @a 0 levels
xp set @a 0 points
title @a clear
clear @a carrot_on_a_stick
scoreboard players set #bdt jv 99
tellraw @a {text:"[숫자 굴리기] 모든 기록을 초기화했어요. 처음부터 시작!",color:"yellow"}
