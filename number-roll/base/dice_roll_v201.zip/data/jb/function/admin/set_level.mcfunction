$scoreboard players set @s jb.lv $(n)
execute if score @s jb.lv matches 22.. run scoreboard players set @s jb.lv 21
execute if score @s jb.lv matches ..-1 run scoreboard players set @s jb.lv 0
scoreboard players set @s jb.xp 0
function jb:lv/bar
scoreboard players set #bdt jv 99
tellraw @s [{text:"[숫자 굴리기] Lv.",color:"yellow"},{score:{name:"@s",objective:"jb.lv"},color:"gold"}]
