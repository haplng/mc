execute if score #bt jv matches 1.. run advancement grant @s only jb:t1
execute if score #bt jv matches 2.. run advancement grant @s only jb:t2
execute if score #bt jv matches 3.. run advancement grant @s only jb:t3
execute if score #bt jv matches 4.. run advancement grant @s only jb:t4
execute if score #bt jv matches 5.. run advancement grant @s only jb:t5
execute if score #nh jv matches 10.. run advancement grant @s only jb:o10
execute if score #nh jv matches 15.. run advancement grant @s only jb:o15
execute if score #nh jv matches 20.. run advancement grant @s only jb:o20
execute if score #rt jv matches 10000.. run advancement grant @s only jb:oc10k
execute if score #rt jv matches 100000.. run advancement grant @s only jb:oc100k
execute if score #rt jv matches 1000000.. run advancement grant @s only jb:oc1m
execute if score #rt jv matches 10000000.. run advancement grant @s only jb:oc10m
execute if score #hl jv matches 2.. run advancement grant @s only jb:double_leg
execute if score #nh jv matches 0 run scoreboard players add @s jb.zs 1
execute if score #nh jv matches 1.. run scoreboard players set @s jb.zs 0
execute if score #nh jv matches 0 run advancement grant @s only jb:nolucky
execute if score @s jb.zs matches 3.. run advancement grant @s only jb:unlucky3
execute if score #qs jv matches 21 run advancement grant @s only jb:bj
execute if score #n jv matches 499000000..501000000 run advancement grant @s only jb:mid
execute if score #n jv matches 499999000..500001000 run advancement grant @s only jb:center
execute if score #n0 jv matches 0 if score #nd jv matches 9 run advancement grant @s only jb:pandig
execute unless entity @s[advancements={jb:n42=true}] run function jb:adv/p/n42
execute unless entity @s[advancements={jb:n1337=true}] run function jb:adv/p/n1337
execute unless entity @s[advancements={jb:n9001=true}] run function jb:adv/p/n9001
execute unless entity @s[advancements={jb:n5508=true}] run function jb:adv/p/n5508
execute unless entity @s[advancements={jb:n25565=true}] run function jb:adv/p/n25565
execute unless entity @s[advancements={jb:n127001=true}] run function jb:adv/p/n127001
execute unless entity @s[advancements={jb:n376006=true}] run function jb:adv/p/n376006
