scoreboard players set #advt jv 0
execute as @a[scores={jb.pid=1..}] run function jb:adv/chk
