execute if score #d1 jv matches 5 if score #d2 jv matches 5 if score #d3 jv matches 0 if score #d4 jv matches 8 run return run advancement grant @s only jb:n5508
execute if score #d2 jv matches 5 if score #d3 jv matches 5 if score #d4 jv matches 0 if score #d5 jv matches 8 run return run advancement grant @s only jb:n5508
execute if score #d3 jv matches 5 if score #d4 jv matches 5 if score #d5 jv matches 0 if score #d6 jv matches 8 run return run advancement grant @s only jb:n5508
execute if score #d4 jv matches 5 if score #d5 jv matches 5 if score #d6 jv matches 0 if score #d7 jv matches 8 run return run advancement grant @s only jb:n5508
execute if score #d5 jv matches 5 if score #d6 jv matches 5 if score #d7 jv matches 0 if score #d8 jv matches 8 run return run advancement grant @s only jb:n5508
execute if score #d6 jv matches 5 if score #d7 jv matches 5 if score #d8 jv matches 0 if score #d9 jv matches 8 run return run advancement grant @s only jb:n5508
