scoreboard players set #cg jv 20000000
function jb:sys/addc
tellraw @s [{"text": "🏆 도전과제 ", "color": "gold", "bold": true}, {"text": "원주율의 신", "color": "light_purple", "bold": true}, {"text": "  +20,000,000⛃", "color": "gold"}]
function jb:snd/play {s:"minecraft:ui.toast.challenge_complete",b:50,p:1.3}
