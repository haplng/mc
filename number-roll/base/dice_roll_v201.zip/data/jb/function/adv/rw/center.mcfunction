scoreboard players set #cg jv 10000000
function jb:sys/addc
tellraw @s [{"text": "🏆 도전과제 ", "color": "gold", "bold": true}, {"text": "정중앙 저격", "color": "light_purple", "bold": true}, {"text": "  +10,000,000⛃", "color": "gold"}]
function jb:snd/play {s:"minecraft:ui.toast.challenge_complete",b:50,p:1.3}
