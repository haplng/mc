scoreboard players set #cg jv 1000000
function jb:sys/addc
tellraw @s [{"text": "🏆 도전과제 ", "color": "gold", "bold": true}, {"text": "천만장자", "color": "aqua", "bold": true}, {"text": "  +1,000,000⛃", "color": "gold"}]
function jb:snd/play {s:"minecraft:entity.player.levelup",b:50,p:1.5}
