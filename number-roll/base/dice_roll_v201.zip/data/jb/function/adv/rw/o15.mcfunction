scoreboard players set #cg jv 300000
function jb:sys/addc
tellraw @s [{"text": "🏆 도전과제 ", "color": "gold", "bold": true}, {"text": "대풍년", "color": "aqua", "bold": true}, {"text": "  +300,000⛃", "color": "gold"}]
function jb:snd/play {s:"minecraft:entity.player.levelup",b:50,p:1.5}
