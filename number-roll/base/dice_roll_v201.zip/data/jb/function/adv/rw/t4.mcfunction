scoreboard players set #cg jv 2000000
function jb:sys/addc
tellraw @s [{"text": "🏆 도전과제 ", "color": "gold", "bold": true}, {"text": "전설의 시작", "color": "aqua", "bold": true}, {"text": "  +2,000,000⛃", "color": "gold"}]
function jb:snd/play {s:"minecraft:entity.player.levelup",b:50,p:1.5}
