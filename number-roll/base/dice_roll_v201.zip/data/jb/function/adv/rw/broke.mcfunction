scoreboard players set #cg jv 10000
function jb:sys/addc
tellraw @s [{"text": "🏆 도전과제 ", "color": "gold", "bold": true}, {"text": "빈털터리", "color": "green", "bold": true}, {"text": "  +10,000⛃", "color": "gold"}]
function jb:snd/play {s:"minecraft:entity.player.levelup",b:50,p:1.5}
