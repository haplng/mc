scoreboard players set #runs ek 5
scoreboard players set #wins ek 5
function ek:lobby/enter
