function ek:setup/room
function ek:lobby/enter
