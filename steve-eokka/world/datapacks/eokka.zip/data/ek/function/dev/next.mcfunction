execute if score #state ek matches 1 if score #stage ek matches ..6 run function ek:game/stage_clear
