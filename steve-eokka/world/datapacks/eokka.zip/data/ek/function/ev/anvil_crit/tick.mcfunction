execute if score #it ek matches 2 run function ek:ev/anvil_crit/t2
execute if score #it ek matches 16 run function ek:say/r65
execute if score #it ek matches 50 run function ek:ev/end_death
