execute if score #it ek matches 12 run function ek:ev/pick_crit/t12
execute if score #it ek matches 14 run data modify storage ek:s status set value "곡괭이 다시 만드는 중"
execute if score #it ek matches 20 run function ek:ev/pick_crit/t20
execute if score #it ek matches 30 run function ek:ev/pick_crit/t30
execute if score #it ek matches 40 run function ek:ev/pick_crit/t40
execute if score #it ek matches 50 run function ek:ev/pick_crit/t50
execute if score #it ek matches 60 run function ek:ev/pick_crit/t60
execute if score #it ek matches 70 run function ek:ev/pick_crit/t70
execute if score #it ek matches 80 run function ek:ev/pick_crit/t80
execute if score #it ek matches 84 run execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"곡괭이 다시 제작",c:"aqua",s:"3"}
execute if score #it ek matches 90 run function ek:ev/end_resume
