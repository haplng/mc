scoreboard players set #intr ek 14
scoreboard players set #it ek 0
data modify storage ek:s status set value "마른하늘에 날벼락"
weather thunder
