data merge entity @e[tag=ek.creep,limit=1] {ignited:1b}
execute as @a at @s run playsound minecraft:entity.creeper.primed master @s ~ ~ ~ 1 1
