execute at @e[tag=ek.aim,limit=1] run function ek:fx/boom
execute as @e[tag=ek.fb] run function ek:fx/vanish
function ek:steve/hurt
scoreboard players set #dmg ek 7
function ek:game/dmg
