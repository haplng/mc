function ek:say/r60
scoreboard players set #dmg ek 9
function ek:game/dmg
