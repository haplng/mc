execute if score #it ek matches 24 run function ek:ev/ghast_crit/t24
execute if score #it ek matches 38 run function ek:ev/ghast_crit/t38
execute if score #it ek matches 42 run function ek:ev/ghast_crit/t42
execute if score #it ek matches 50 run function ek:ev/ghast_crit/t50
execute if score #it ek matches 58 run function ek:ev/ghast_crit/t58
execute if score #it ek matches 66 run function ek:ev/ghast_crit/t66
execute if score #it ek matches 74 run function ek:ev/ghast_crit/t74
execute if score #it ek matches 84 run function ek:say/r40
execute if score #it ek matches 92 run execute as @e[tag=ek.ghast] run function ek:fx/vanish
execute if score #it ek matches 25..36 run execute as @e[tag=ek.fb] at @s facing entity @e[tag=ek.aim,limit=1] feet run tp @s ^ ^ ^1.3
execute if score #it ek matches 39..72 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ ~40 ~
execute if score #it ek matches 112 run function ek:ev/end_major
