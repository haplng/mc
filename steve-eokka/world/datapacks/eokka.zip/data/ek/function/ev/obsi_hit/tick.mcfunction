execute if score #it ek matches 10 run function ek:ev/obsi_hit/t10
execute if score #it ek matches 30 run function ek:ev/obsi_hit/t30
execute if score #it ek matches 82 run function ek:ev/obsi_hit/t82
execute if score #it ek matches 31..80 run time add 480
execute if score #it ek matches 88 run function ek:ev/end_back
