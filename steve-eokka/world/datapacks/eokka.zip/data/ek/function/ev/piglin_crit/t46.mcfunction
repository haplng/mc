tellraw @a {"text":"Steve이(가) 피글린에게 살해당했습니다","color":"white"}
scoreboard players add #deaths ek 1
scoreboard players add #dc_piglin ek 1
kill @e[tag=ek.steve]
kill @e[tag=ek.bub]
scoreboard players set #steve ek 0
scoreboard players set #bubt ek 0
execute as @a at @s run playsound minecraft:entity.player.death master @s ~ ~ ~ 0.8 1
scoreboard players set #dmg ek 13
function ek:game/dmg
