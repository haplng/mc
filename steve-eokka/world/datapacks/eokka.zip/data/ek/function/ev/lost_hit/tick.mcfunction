execute if score #it ek matches 40 run function ek:ev/lost_hit/t40
execute if score #it ek matches 4..80 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ^ ^ ^0.12 ~9 ~
execute if score #it ek matches 85 run function ek:ev/end_resume
