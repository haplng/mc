execute if score #it ek matches 2 run function ek:ev/anvil_hit/t2
execute if score #it ek matches 8 run function ek:say/r66
execute if score #it ek matches 30 run function ek:ev/end_resume
