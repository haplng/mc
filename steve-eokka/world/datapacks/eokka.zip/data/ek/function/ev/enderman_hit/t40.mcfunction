execute as @a at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 1
execute at @e[tag=ek.angry,limit=1] run particle minecraft:portal ~ ~1.5 ~ 0.3 0.8 0.3 0.5 40 force
