function ek:say/r47
scoreboard players set #dmg ek 7
function ek:game/dmg
