execute if score #it ek matches 2 run function ek:ev/bed_crit/t2
execute if score #it ek matches 14 run function ek:say/r57
execute if score #it ek matches 50 run function ek:ev/end_death
