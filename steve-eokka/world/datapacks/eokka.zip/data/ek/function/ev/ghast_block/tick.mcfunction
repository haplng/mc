execute if score #it ek matches 24 run function ek:ev/ghast_block/t24
execute if score #it ek matches 37 run function ek:ev/ghast_block/t37
execute if score #it ek matches 52 run function ek:ev/ghast_block/t52
execute if score #it ek matches 58 run function ek:ev/ghast_block/t58
execute if score #it ek matches 25..36 run execute as @e[tag=ek.fb] at @s facing entity @e[tag=ek.aim,limit=1] feet run tp @s ^ ^ ^1.3
execute if score #it ek matches 38..50 run execute as @e[tag=ek.fb] at @s facing entity @e[tag=ek.ghast,limit=1] eyes run tp @s ^ ^ ^1.3
execute if score #it ek matches 80 run function ek:ev/end_cont
