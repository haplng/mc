execute if score #it ek matches 6 run function ek:ev/lost_block/t6
execute if score #it ek matches 30 run function ek:ev/end_cont
