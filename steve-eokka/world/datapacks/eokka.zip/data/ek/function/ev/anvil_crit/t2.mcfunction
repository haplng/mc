tellraw @a {"text":"Steve이(가) 떨어지는 모루에 깔렸습니다","color":"white"}
scoreboard players add #deaths ek 1
scoreboard players add #dc_anvil ek 1
kill @e[tag=ek.steve]
kill @e[tag=ek.bub]
scoreboard players set #steve ek 0
scoreboard players set #bubt ek 0
execute as @a at @s run playsound minecraft:entity.player.death master @s ~ ~ ~ 0.8 1
scoreboard players set #dmg ek 14
function ek:game/dmg
