scoreboard players set #intr ek 55
scoreboard players set #it ek 0
data modify storage ek:s status set value "엔더의 눈이 모자람"
