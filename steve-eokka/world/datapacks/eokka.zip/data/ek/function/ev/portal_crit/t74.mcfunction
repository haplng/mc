execute positioned -8.0 62 10.5 run function ek:fx/boom
execute as @e[tag=ek.fb] run function ek:fx/vanish
fill -9 62 10 -8 64 10 minecraft:nether_portal[axis=x]
execute as @a at @s run playsound minecraft:block.portal.trigger master @s ~ ~ ~ 0.5 1
