execute at @e[tag=ek.evt,limit=1] run fill ~ ~ ~ ~ ~4 ~ minecraft:air replace minecraft:gravel destroy
scoreboard players set #dmg ek 6
function ek:game/dmg
scoreboard players set #snap ek 1
