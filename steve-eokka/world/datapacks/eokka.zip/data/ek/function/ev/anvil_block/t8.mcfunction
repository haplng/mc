function ek:say/r67
scoreboard players set #dmg ek 3
execute if score #sweet ek matches 1 run scoreboard players set #dmg ek 7
function ek:game/dmg
