execute if score #it ek matches 8 run function ek:ev/barter_block/t8
execute if score #it ek matches 30 run function ek:ev/end_cont
