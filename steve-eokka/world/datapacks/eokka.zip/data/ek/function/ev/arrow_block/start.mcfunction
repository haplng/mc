scoreboard players set #intr ek 9
scoreboard players set #it ek 0
data modify storage ek:s status set value "어디선가 화살이"
execute at @e[tag=ek.aim,limit=1] positioned ~0 ~ ~0 run summon minecraft:skeleton ~ ~ ~ {Tags:["ek.mob","ek.skel"],NoAI:1b,PersistenceRequired:1b,Invulnerable:1b,Silent:1b,equipment:{mainhand:{id:"minecraft:bow",count:1},head:{id:"minecraft:stone_button",count:1}}}
execute as @e[tag=ek.skel] at @s run tp @s ~ ~ ~ facing entity @e[tag=ek.steve,limit=1] eyes
execute as @a at @s run playsound minecraft:entity.skeleton.ambient master @s ~ ~ ~ 1 1
