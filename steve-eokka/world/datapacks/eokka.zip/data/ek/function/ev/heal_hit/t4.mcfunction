scoreboard players add #dhp ek 25
execute if score #dhp ek matches 101.. run scoreboard players set #dhp ek 100
