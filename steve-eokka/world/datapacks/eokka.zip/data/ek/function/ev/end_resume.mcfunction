function ek:ev/cleanup
scoreboard players set #intr ek 0
function ek:cards/learn_check
execute if score #mental ek matches 1.. run function ek:beat/restart
