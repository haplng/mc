kill @e[tag=ek.zom]
execute as @a at @s run playsound minecraft:entity.zombie.death master @s ~ ~ ~ 1 1
