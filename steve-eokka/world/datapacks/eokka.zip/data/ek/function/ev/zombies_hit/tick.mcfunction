execute if score #it ek matches 30 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing entity @e[tag=ek.zom,limit=1] feet
execute if score #it ek matches 40 run function ek:ev/zombies_hit/t40
execute if score #it ek matches 44 run function ek:ev/zombies_hit/t44
execute if score #it ek matches 50 run function ek:ev/zombies_hit/t50
execute if score #it ek matches 56 run function ek:ev/zombies_hit/t56
execute if score #it ek matches 62 run function ek:ev/zombies_hit/t62
execute if score #it ek matches 66 run function ek:ev/zombies_hit/t66
execute if score #it ek matches 72 run function ek:steve/say {t:"좀비 정도야 뭐"}
execute if score #it ek matches 1..50 run function ek:fx/chase
execute if score #it ek matches 85 run function ek:ev/end_resume
