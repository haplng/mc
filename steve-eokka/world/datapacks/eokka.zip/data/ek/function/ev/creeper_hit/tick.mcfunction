execute if score #it ek matches 22 run function ek:ev/creeper_hit/t22
execute if score #it ek matches 30 run function ek:ev/creeper_hit/t30
execute if score #it ek matches 56 run function ek:ev/creeper_hit/t56
execute if score #it ek matches 62 run function ek:say/r5
execute if score #it ek matches 1..28 run function ek:fx/chase
execute if score #it ek matches 85 run function ek:ev/end_resume
