scoreboard players set #intr ek 60
scoreboard players set #it ek 0
data modify storage ek:s status set value "엔더맨이랑 눈이 마주쳤다"
execute at @e[tag=ek.cur,limit=1] run tag @e[tag=ek.end,limit=1,sort=nearest] add ek.angry
execute unless entity @e[tag=ek.angry] run tag @e[tag=ek.end,limit=1,sort=random] add ek.angry
execute as @a at @s run playsound minecraft:entity.enderman.stare master @s ~ ~ ~ 0.9 1
