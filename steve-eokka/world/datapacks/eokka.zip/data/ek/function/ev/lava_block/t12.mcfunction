execute as @a at @s run playsound minecraft:item.bucket.empty master @s ~ ~ ~ 1 1
execute as @e[tag=ek.steve,limit=1] at @s run setblock ^ ^ ^1 minecraft:obsidian keep
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"물양동이",c:"aqua",s:"3"}
