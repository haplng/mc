scoreboard players set #intr ek 33
scoreboard players set #it ek 0
scoreboard players set #flint ek 0
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"여분 부싯돌",c:"aqua",s:"3"}
