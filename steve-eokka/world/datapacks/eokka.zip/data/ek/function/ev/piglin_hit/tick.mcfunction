execute if score #it ek matches 30 run function ek:ev/piglin_hit/t30
execute if score #it ek matches 36 run function ek:steve/say {t:"왜 갑자기 화를 내"}
execute if score #it ek matches 1..34 run function ek:fx/chase
execute if score #it ek matches 55 run function ek:ev/end_resume
