scoreboard players set #intr ek 52
scoreboard players set #it ek 0
data modify storage ek:s status set value "엔더의 눈이 깨졌다"
scoreboard players remove #eyes ek 3
execute as @a at @s run playsound minecraft:entity.ender_eye.death master @s ~ ~ ~ 1 1
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"엔더의 눈이 깨졌다 (-3)",c:"red",s:"3"}
execute as @e[tag=ek.eyefx] run function ek:fx/vanish
