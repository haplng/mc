execute as @a at @s run playsound minecraft:entity.ghast.shoot master @s ~ ~ ~ 1 1
summon item_display 5.5 68 0.5 {Tags:["ek.mob","ek.fb"],billboard:"center",teleport_duration:1,item:{id:"minecraft:fire_charge",count:1},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2.5f,2.5f,2.5f]}}
