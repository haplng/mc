data modify entity @e[tag=ek.steve,limit=1] pose set value "sleeping"
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"Zzz",c:"gray",s:"3"}
