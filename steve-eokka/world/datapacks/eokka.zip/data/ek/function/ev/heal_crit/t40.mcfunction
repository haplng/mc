item replace entity @e[tag=ek.steve,limit=1] weapon.mainhand with minecraft:bow
swing @e[tag=ek.steve,limit=1] mainhand
execute as @a at @s run playsound minecraft:entity.arrow.shoot master @s ~ ~ ~ 1 1
