scoreboard players set #intr ek 17
scoreboard players set #it ek 0
data modify storage ek:s status set value "머리 위에서 자갈이"
execute at @e[tag=ek.steve,limit=1] run summon marker ~ ~ ~ {Tags:["ek.evt"]}
scoreboard players set #snap ek 0
execute at @e[tag=ek.steve,limit=1] run summon minecraft:falling_block ~ ~5 ~ {BlockState:"minecraft:gravel",Time:1,DropItem:0b}
execute at @e[tag=ek.steve,limit=1] run summon minecraft:falling_block ~ ~7 ~ {BlockState:"minecraft:gravel",Time:1,DropItem:0b}
execute as @a at @s run playsound minecraft:block.gravel.break master @s ~ ~ ~ 0.5 1
