scoreboard players set #intr ek 39
scoreboard players set #it ek 0
scoreboard players set #rmiss ek 0
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"약탈 검",c:"aqua",s:"3"}
