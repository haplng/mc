title @a times 5 40 10
title @a subtitle {"text":"장비를 처음부터 다시 맞추는 중","color":"gray"}
title @a title {"text":" "}
