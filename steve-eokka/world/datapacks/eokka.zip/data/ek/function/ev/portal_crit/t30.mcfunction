data modify storage ek:s status set value "가스트를 유인해서 포탈 다시 켜는 중"
summon minecraft:ghast -8.5 68 2.5 {Tags:["ek.mob","ek.ghast"],NoAI:1b,PersistenceRequired:1b,Invulnerable:1b,Silent:1b,Rotation:[0f,20f]}
execute as @a at @s run playsound minecraft:entity.ghast.warn master @s ~ ~ ~ 0.9 1
