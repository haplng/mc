swing @e[tag=ek.steve,limit=1] mainhand
execute as @a at @s run playsound minecraft:entity.player.attack.sweep master @s ~ ~ ~ 0.6 1
kill @e[tag=ek.creep]
execute as @a at @s run playsound minecraft:entity.creeper.death master @s ~ ~ ~ 1 1
scoreboard players set #dmg ek 3
execute if score #sweet ek matches 1 run scoreboard players set #dmg ek 6
function ek:game/dmg
