execute if score #it ek matches 18 run function ek:steve/say {t:"좀비 소리?"}
execute if score #it ek matches 36 run function ek:steve/hurt
execute if score #it ek matches 46 run function ek:steve/hurt
execute if score #it ek matches 56 run function ek:steve/hurt
execute if score #it ek matches 66 run function ek:steve/hurt
execute if score #it ek matches 72 run function ek:ev/zombies_crit/t72
execute if score #it ek matches 80 run execute as @e[tag=ek.zom] run function ek:fx/vanish
execute if score #it ek matches 84 run function ek:say/r22
execute if score #it ek matches 1..70 run function ek:fx/chase
execute if score #it ek matches 105 run function ek:ev/end_death
