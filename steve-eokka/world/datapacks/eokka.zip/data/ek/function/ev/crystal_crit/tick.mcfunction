execute if score #it ek matches 12 run function ek:ev/crystal_crit/t12
execute if score #it ek matches 24 run function ek:say/r62
execute if score #it ek matches 60 run function ek:ev/end_death
