function ek:say/r56
scoreboard players set #dmg ek 3
execute if score #sweet ek matches 1 run scoreboard players set #dmg ek 9
function ek:game/dmg
