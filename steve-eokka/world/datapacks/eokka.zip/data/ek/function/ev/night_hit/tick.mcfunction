execute if score #it ek matches 8 run function ek:say/r9
execute if score #it ek matches 22 run function ek:ev/night_hit/t22
execute if score #it ek matches 52 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing entity @e[tag=ek.zom,limit=1] feet
execute if score #it ek matches 58 run function ek:ev/night_hit/t58
execute if score #it ek matches 60 run function ek:ev/night_hit/t60
execute if score #it ek matches 66 run function ek:ev/night_hit/t66
execute if score #it ek matches 72 run function ek:ev/night_hit/t72
execute if score #it ek matches 74 run function ek:ev/night_hit/t74
execute if score #it ek matches 84 run function ek:ev/night_hit/t84
execute if score #it ek matches 1..20 run time add 400
execute if score #it ek matches 23..60 run function ek:fx/chase
execute if score #it ek matches 92 run function ek:ev/end_resume
