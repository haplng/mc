execute as @a at @s run playsound minecraft:item.bucket.empty master @s ~ ~ ~ 1 1
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"물양동이 착지",c:"aqua",s:"3"}
execute at @e[tag=ek.steve,limit=1] run particle minecraft:splash ~ ~0.2 ~ 0.4 0.1 0.4 0.1 40 force
