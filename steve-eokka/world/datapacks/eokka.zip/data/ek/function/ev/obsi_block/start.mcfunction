scoreboard players set #intr ek 42
scoreboard players set #it ek 0
data modify storage ek:s status set value "흑요석이 모자람"
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"흑요석 여분",c:"aqua",s:"3"}
