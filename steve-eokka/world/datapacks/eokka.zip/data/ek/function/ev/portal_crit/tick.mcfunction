execute if score #it ek matches 14 run function ek:ev/portal_crit/t14
execute if score #it ek matches 30 run function ek:ev/portal_crit/t30
execute if score #it ek matches 60 run function ek:ev/portal_crit/t60
execute if score #it ek matches 74 run function ek:ev/portal_crit/t74
execute if score #it ek matches 84 run function ek:ev/portal_crit/t84
execute if score #it ek matches 61..72 run execute as @e[tag=ek.fb] at @s facing -8.0 63 10.5 run tp @s ^ ^ ^0.6
execute if score #it ek matches 95 run function ek:ev/end_resume
