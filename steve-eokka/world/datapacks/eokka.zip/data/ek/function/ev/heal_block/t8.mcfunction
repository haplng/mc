function ek:say/r61
scoreboard players set #dmg ek 2
execute if score #sweet ek matches 1 run scoreboard players set #dmg ek 4
function ek:game/dmg
