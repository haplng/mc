execute if score #it ek matches 40 run execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"?",c:"yellow",s:"3"}
execute if score #it ek matches 80 run execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"?",c:"yellow",s:"3"}
execute if score #it ek matches 90 run function ek:ev/lost_crit/t90
execute if score #it ek matches 120 run execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"?",c:"yellow",s:"3"}
execute if score #it ek matches 160 run execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"?",c:"yellow",s:"3"}
execute if score #it ek matches 4..160 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ^ ^ ^0.12 ~9 ~
execute if score #it ek matches 165 run function ek:ev/end_resume
