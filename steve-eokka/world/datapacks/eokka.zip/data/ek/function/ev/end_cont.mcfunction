function ek:ev/cleanup
scoreboard players set #intr ek 0
data modify storage ek:s status set from storage ek:s bstatus
function ek:cards/learn_check
