function ek:say/r34
scoreboard players set #dmg ek 8
function ek:game/dmg
