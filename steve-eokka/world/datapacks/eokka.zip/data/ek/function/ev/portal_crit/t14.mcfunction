function ek:say/r43
scoreboard players set #dmg ek 11
function ek:game/dmg
