execute as @e[tag=ek.ghast] run function ek:fx/vanish
function ek:steve/say {t:"가스트로 포탈 켜기 성공. 하..."}
