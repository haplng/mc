execute if score #it ek matches 8 run function ek:say/r7
execute if score #it ek matches 24 run function ek:ev/night_crit/t24
execute if score #it ek matches 44 run function ek:steve/say {t:"일단 땅 파고 숨는다"}
execute if score #it ek matches 50 run execute at @e[tag=ek.steve,limit=1] run setblock ~ ~-1 ~ minecraft:air destroy
execute if score #it ek matches 55 run execute at @e[tag=ek.steve,limit=1] run setblock ~ ~-1 ~ minecraft:air destroy
execute if score #it ek matches 60 run execute at @e[tag=ek.steve,limit=1] run setblock ~ ~-1 ~ minecraft:air destroy
execute if score #it ek matches 66 run function ek:ev/night_crit/t66
execute if score #it ek matches 90 run execute as @a at @s run playsound minecraft:entity.zombie.ambient master @s ~ ~ ~ 0.6 0.8
execute if score #it ek matches 100 run function ek:ev/night_crit/t100
execute if score #it ek matches 120 run execute as @a at @s run playsound minecraft:entity.zombie.ambient master @s ~ ~ ~ 0.6 0.8
execute if score #it ek matches 150 run execute as @a at @s run playsound minecraft:entity.zombie.ambient master @s ~ ~ ~ 0.6 0.8
execute if score #it ek matches 160 run function ek:ev/night_crit/t160
execute if score #it ek matches 170 run execute at @e[tag=ek.steve,limit=1] run setblock ~ ~2 ~ minecraft:air
execute if score #it ek matches 174 run function ek:ev/night_crit/t174
execute if score #it ek matches 178 run function ek:ev/night_crit/t178
execute if score #it ek matches 182 run function ek:ev/night_crit/t182
execute if score #it ek matches 186 run function ek:steve/say {t:"아침이다. 하루 날렸네"}
execute if score #it ek matches 1..20 run time add 400
execute if score #it ek matches 25..158 run function ek:fx/chase
execute if score #it ek matches 195 run function ek:ev/end_resume
