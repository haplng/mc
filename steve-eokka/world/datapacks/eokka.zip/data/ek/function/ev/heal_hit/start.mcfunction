scoreboard players set #intr ek 69
scoreboard players set #it ek 0
data modify storage ek:s status set value "숨은 수정"
summon minecraft:end_crystal 9.5 72 -9.5 {Tags:["ek.mob","ek.hc"],ShowBottom:0b,Invulnerable:1b}
execute as @a at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 1 1.2
execute positioned 0.5 76 -1.5 run function ek:fx/popup {t:"숨은 수정이 드래곤을 회복시킨다",c:"light_purple",s:"2.5"}
