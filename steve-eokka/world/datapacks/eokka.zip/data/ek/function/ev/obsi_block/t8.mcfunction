function ek:say/r39
scoreboard players set #dmg ek 2
execute if score #sweet ek matches 1 run scoreboard players set #dmg ek 5
function ek:game/dmg
