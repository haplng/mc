scoreboard players set #dmg ek 5
function ek:game/dmg
function ek:steve/say {t:"잠깐 헷갈렸네"}
