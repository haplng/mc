execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing entity @e[tag=ek.creep,limit=1] feet
function ek:say/r6
