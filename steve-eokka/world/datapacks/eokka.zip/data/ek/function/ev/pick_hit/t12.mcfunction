function ek:steve/say {t:"...안 쓰고 있었는데 왜 부서져"}
scoreboard players set #dmg ek 4
function ek:game/dmg
