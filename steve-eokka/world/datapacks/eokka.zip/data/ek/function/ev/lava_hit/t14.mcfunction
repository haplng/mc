execute at @e[tag=ek.steve,limit=1] run setblock ~ ~ ~ minecraft:lava
data merge entity @e[tag=ek.steve,limit=1] {HasVisualFire:1b}
execute as @a at @s run playsound minecraft:entity.player.hurt_on_fire master @s ~ ~ ~ 1 1
