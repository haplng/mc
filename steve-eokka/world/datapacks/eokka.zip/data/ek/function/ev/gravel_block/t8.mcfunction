function ek:say/r21
scoreboard players set #dmg ek 3
execute if score #sweet ek matches 1 run scoreboard players set #dmg ek 5
function ek:game/dmg
