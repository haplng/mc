execute if score #it ek matches 14 run function ek:ev/gravel_crit/t14
execute if score #it ek matches 20 run function ek:steve/hurt
execute if score #it ek matches 30 run function ek:steve/hurt
execute if score #it ek matches 40 run function ek:steve/hurt
execute if score #it ek matches 50 run function ek:steve/hurt
execute if score #it ek matches 58 run function ek:ev/gravel_crit/t58
execute if score #it ek matches 64 run execute at @e[tag=ek.evt,limit=1] run fill ~ ~ ~ ~ ~4 ~ minecraft:air replace minecraft:gravel
execute if score #it ek matches 72 run function ek:say/r20
execute if score #it ek matches 95 run function ek:ev/end_death
