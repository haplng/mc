function ek:say/r49
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"엔더의 눈 부족",c:"red",s:"3"}
