execute if score #it ek matches 6 run function ek:ev/floor_crit/t6
execute if score #it ek matches 10 run function ek:ev/floor_crit/t10
execute if score #it ek matches 18 run function ek:ev/floor_crit/t18
execute if score #it ek matches 26 run function ek:ev/floor_crit/t26
execute if score #it ek matches 34 run function ek:ev/floor_crit/t34
execute if score #it ek matches 42 run function ek:ev/floor_crit/t42
execute if score #it ek matches 56 run function ek:say/r29
execute if score #it ek matches 7..40 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ ~40 ~
execute if score #it ek matches 85 run function ek:ev/end_major
