execute if score #it ek matches 14 run function ek:ev/lava_crit/t14
execute if score #it ek matches 18 run function ek:ev/lava_crit/t18
execute if score #it ek matches 26 run function ek:ev/lava_crit/t26
execute if score #it ek matches 30 run function ek:steve/say {t:"아아아 다이아"}
execute if score #it ek matches 34 run function ek:ev/lava_crit/t34
execute if score #it ek matches 42 run function ek:ev/lava_crit/t42
execute if score #it ek matches 50 run function ek:ev/lava_crit/t50
execute if score #it ek matches 56 run function ek:ev/lava_crit/t56
execute if score #it ek matches 60 run execute at @e[tag=ek.evt,limit=1] run setblock ~ ~ ~ minecraft:air
execute if score #it ek matches 72 run function ek:say/r26
execute if score #it ek matches 15..54 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ ~40 ~
execute if score #it ek matches 100 run function ek:ev/end_major
