execute at @e[tag=ek.steve,limit=1] run setblock ~ ~ ~ minecraft:cobblestone
execute as @a at @s run playsound minecraft:block.stone.place master @s ~ ~ ~ 1 1
