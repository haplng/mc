execute at @e[tag=ek.creep,limit=1] run function ek:fx/boom
execute as @e[tag=ek.creep] run function ek:fx/vanish
function ek:steve/hurt
scoreboard players set #dmg ek 7
function ek:game/dmg
