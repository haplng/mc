scoreboard players set #intr ek 29
scoreboard players set #it ek 0
data modify storage ek:s status set value "발밑이 꺼졌다"
execute as @a at @s run playsound minecraft:block.stone.break master @s ~ ~ ~ 1 1
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"발밑이 꺼졌다",c:"red",s:"3"}
execute at @e[tag=ek.steve,limit=1] run setblock ~ ~-1 ~ minecraft:air destroy
