execute if score #it ek matches 14 run function ek:ev/portal_hit/t14
execute if score #it ek matches 40 run function ek:ev/end_resume
