function ek:steve/hurt
scoreboard players set #dmg ek 5
function ek:game/dmg
