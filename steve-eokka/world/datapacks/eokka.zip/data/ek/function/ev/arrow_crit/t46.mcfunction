tellraw @a {"text":"Steve이(가) 스켈레톤에게서 도망치려다 떨어졌습니다","color":"white"}
scoreboard players add #deaths ek 1
scoreboard players add #dc_fall ek 1
kill @e[tag=ek.steve]
kill @e[tag=ek.bub]
scoreboard players set #steve ek 0
scoreboard players set #bubt ek 0
execute as @a at @s run playsound minecraft:entity.player.death master @s ~ ~ ~ 0.8 1
scoreboard players set #dmg ek 12
function ek:game/dmg
