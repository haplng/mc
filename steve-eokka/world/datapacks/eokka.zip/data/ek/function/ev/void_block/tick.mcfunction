execute if score #it ek matches 30 run function ek:ev/void_block/t30
execute if score #it ek matches 46 run function ek:ev/void_block/t46
execute if score #it ek matches 57 run function ek:ev/void_block/t57
execute if score #it ek matches 60 run function ek:ev/void_block/t60
execute if score #it ek matches 1..28 run execute as @e[tag=ek.dragon,limit=1] at @s facing entity @e[tag=ek.dtgt,limit=1] feet unless entity @e[tag=ek.dtgt,distance=..1] run tp @s ^ ^ ^0.9 ~180 0
execute if score #it ek matches 31..45 run execute as @e[tag=ek.dragon,limit=1] at @s run tp @s ~ ~0.4 ~-0.9 0 0
execute if score #it ek matches 31..46 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~0.25 ~
execute if score #it ek matches 75 run function ek:ev/end_cont
