execute if score #it ek matches 8 run function ek:ev/gravel_block/t8
execute if score #it ek matches 35 run function ek:ev/end_cont
