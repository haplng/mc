scoreboard players set #snap ek 1
scoreboard players set #dmode ek 0
