execute at @e[tag=ek.steve,limit=1] rotated ~ 0 positioned ^ ^ ^1.6 run tp @e[tag=ek.angry,limit=1] ~ ~ ~
execute as @e[tag=ek.angry,limit=1] at @s run tp @s ~ ~ ~ facing entity @e[tag=ek.steve,limit=1] feet
execute as @a at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 1
execute at @e[tag=ek.angry,limit=1] run particle minecraft:portal ~ ~1.5 ~ 0.3 0.8 0.3 0.5 40 force
