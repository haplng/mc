scoreboard players set #intr ek 76
scoreboard players set #it ek 0
data modify storage ek:s status set value "모루가 떨어졌다"
execute at @e[tag=ek.aim,limit=1] run summon item_display ~ ~0.6 ~ {Tags:["ek.mob","ek.anvfx"],billboard:"center",teleport_duration:1,item:{id:"minecraft:anvil",count:1},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.8f,1.8f,1.8f]}}
execute as @a at @s run playsound minecraft:block.anvil.land master @s ~ ~ ~ 0.9 0.8
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"위를 보고 피했다",c:"aqua",s:"3"}
