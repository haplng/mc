execute at @e[tag=ek.steve,limit=1] run setblock ~ ~2 ~ minecraft:dirt
execute as @a at @s run playsound minecraft:block.gravel.break master @s ~ ~ ~ 1 1
