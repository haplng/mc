function ek:ev/cleanup
scoreboard players set #intr ek 0
scoreboard players add #day ek 1
function ek:game/stage_setup
scoreboard players set #redo ek 1
tellraw @a {"text":"(아이템을 전부 잃어서 이번 단계를 처음부터 다시 한다)","color":"gray"}
execute if score #mental ek matches 1.. run function ek:say/r70
function ek:cards/learn_check
execute if score #mental ek matches 1.. run function ek:beat/start
