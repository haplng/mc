execute if score #it ek matches 12 run function ek:ev/creeper_block/t12
execute if score #it ek matches 24 run function ek:ev/creeper_block/t24
execute if score #it ek matches 34 run function ek:ev/creeper_block/t34
execute if score #it ek matches 1..18 run function ek:fx/chase
execute if score #it ek matches 60 run function ek:ev/end_cont
