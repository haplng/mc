execute if score #it ek matches 4 run function ek:ev/heal_crit/t4
execute if score #it ek matches 14 run function ek:ev/heal_crit/t14
execute if score #it ek matches 40 run function ek:ev/heal_crit/t40
execute if score #it ek matches 48 run function ek:ev/heal_crit/t48
execute if score #it ek matches 60 run function ek:ev/end_resume
