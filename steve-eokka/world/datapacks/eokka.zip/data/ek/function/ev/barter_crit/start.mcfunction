scoreboard players set #intr ek 34
scoreboard players set #it ek 0
scoreboard players add #bmiss ek 3
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"교환 꽝 확률 폭등",c:"red",s:"3"}
execute as @a at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.5
