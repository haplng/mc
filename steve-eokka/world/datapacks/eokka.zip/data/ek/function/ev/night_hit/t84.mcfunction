time set 6000
function ek:steve/say {t:"금방 아침이네"}
