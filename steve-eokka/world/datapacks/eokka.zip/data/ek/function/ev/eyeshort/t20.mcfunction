scoreboard players set #dmg ek 12
function ek:game/dmg
