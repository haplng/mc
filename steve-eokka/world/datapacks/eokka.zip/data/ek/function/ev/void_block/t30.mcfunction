execute as @a at @s run playsound minecraft:entity.ender_dragon.flap master @s ~ ~ ~ 1 0.8
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"날갯짓!",c:"light_purple",s:"3"}
scoreboard players set #snap ek 0
data modify entity @e[tag=ek.steve,limit=1] pose set value "standing"
