execute if score #it ek matches 10 run function ek:ev/barter_crit/t10
execute if score #it ek matches 30 run function ek:ev/end_resume
