function ek:say/r8
scoreboard players set #dmg ek 11
function ek:game/dmg
