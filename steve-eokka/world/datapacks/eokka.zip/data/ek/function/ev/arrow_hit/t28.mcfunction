execute as @e[tag=ek.arrowfx] run function ek:fx/vanish
execute as @a at @s run playsound minecraft:entity.arrow.hit_player master @s ~ ~ ~ 1 1
function ek:steve/hurt
scoreboard players set #dmg ek 6
function ek:game/dmg
