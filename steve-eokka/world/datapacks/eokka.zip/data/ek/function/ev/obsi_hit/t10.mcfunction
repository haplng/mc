function ek:steve/say {t:"세어보니 9개네. 하나 더 캐고 온다"}
scoreboard players set #dmg ek 5
function ek:game/dmg
