scoreboard players set #intr ek 36
scoreboard players set #it ek 0
scoreboard players set #bmiss ek 0
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"금 블록 통째로",c:"aqua",s:"3"}
