execute if score #it ek matches 10 run function ek:ev/rods_hit/t10
execute if score #it ek matches 30 run function ek:ev/end_resume
