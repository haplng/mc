scoreboard players set #intr ek 19
scoreboard players set #it ek 0
data modify storage ek:s status set value "어둠 속 좀비 떼"
execute at @e[tag=ek.aim,limit=1] positioned ~0 ~ ~0 run summon minecraft:zombie ~ ~ ~ {Tags:["ek.mob","ek.zom","ek.chase","ek.fast"],NoAI:1b,PersistenceRequired:1b,Invulnerable:1b,Silent:1b,equipment:{head:{id:"minecraft:stone_button",count:1}}}
execute at @e[tag=ek.aim,limit=1] positioned ~1.5 ~ ~0.5 run summon minecraft:zombie ~ ~ ~ {Tags:["ek.mob","ek.zom","ek.chase","ek.fast"],NoAI:1b,PersistenceRequired:1b,Invulnerable:1b,Silent:1b,equipment:{head:{id:"minecraft:stone_button",count:1}}}
execute at @e[tag=ek.aim,limit=1] positioned ~-1.5 ~ ~-0.5 run summon minecraft:zombie ~ ~ ~ {Tags:["ek.mob","ek.zom","ek.chase","ek.fast"],NoAI:1b,PersistenceRequired:1b,Invulnerable:1b,Silent:1b,equipment:{head:{id:"minecraft:stone_button",count:1}}}
execute as @a at @s run playsound minecraft:entity.zombie.ambient master @s ~ ~ ~ 1 1
