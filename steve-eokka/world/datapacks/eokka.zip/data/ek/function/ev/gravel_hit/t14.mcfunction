execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"자갈에 묻혔다",c:"red",s:"3"}
function ek:steve/say {t:"아 자갈"}
