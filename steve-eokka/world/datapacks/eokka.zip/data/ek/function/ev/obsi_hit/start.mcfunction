scoreboard players set #intr ek 41
scoreboard players set #it ek 0
data modify storage ek:s status set value "흑요석이 모자람"
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"흑요석이 9개뿐?!",c:"red",s:"3"}
execute as @a at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.5
