execute at @e[tag=ek.steve,limit=1] run setblock ~ ~ ~ minecraft:lava
data merge entity @e[tag=ek.steve,limit=1] {HasVisualFire:1b}
execute as @a at @s run playsound minecraft:entity.player.hurt_on_fire master @s ~ ~ ~ 1 1
execute as @a at @s run playsound minecraft:block.lava.extinguish master @s ~ ~ ~ 1 0.8
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"캔 게 전부 타고 있다",c:"red",s:"3"}
