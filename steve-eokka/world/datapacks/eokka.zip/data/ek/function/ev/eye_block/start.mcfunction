scoreboard players set #intr ek 54
scoreboard players set #it ek 0
data modify storage ek:s status set value "엔더의 눈이 깨졌다"
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"눈 여분",c:"aqua",s:"3"}
