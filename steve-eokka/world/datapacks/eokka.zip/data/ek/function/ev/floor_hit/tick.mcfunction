execute if score #it ek matches 10 run function ek:ev/floor_hit/t10
execute if score #it ek matches 24 run function ek:ev/floor_hit/t24
execute if score #it ek matches 40 run function ek:ev/end_resume
