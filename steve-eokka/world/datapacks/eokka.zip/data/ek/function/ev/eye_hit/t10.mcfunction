function ek:steve/say {t:"눈 하나 깨졌네. 아슬아슬한데"}
scoreboard players set #dmg ek 4
function ek:game/dmg
