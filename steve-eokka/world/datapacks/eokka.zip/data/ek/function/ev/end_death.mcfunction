function ek:ev/cleanup
scoreboard players set #intr ek 0
execute if score #stage ek matches 1 run function ek:s1/spawn
execute if score #stage ek matches 2 run function ek:s2/spawn
execute if score #stage ek matches 3 run function ek:s3/spawn
execute if score #stage ek matches 4 run function ek:s4/spawn
execute if score #stage ek matches 5 run function ek:s5/spawn
execute if score #stage ek matches 6 run function ek:s6/spawn
execute if score #stage ek matches 7 run function ek:s7/spawn
execute if score #mental ek matches 1.. run function ek:say/r69
function ek:cards/learn_check
execute if score #mental ek matches 1.. run function ek:beat/restart
