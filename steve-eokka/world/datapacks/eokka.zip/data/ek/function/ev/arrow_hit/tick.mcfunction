execute if score #it ek matches 14 run function ek:ev/arrow_hit/t14
execute if score #it ek matches 28 run function ek:ev/arrow_hit/t28
execute if score #it ek matches 34 run function ek:say/r12
execute if score #it ek matches 46 run execute as @e[tag=ek.skel] run function ek:fx/vanish
execute if score #it ek matches 15..27 run execute as @e[tag=ek.arrowfx] at @s facing entity @e[tag=ek.steve,limit=1] eyes run tp @s ^ ^ ^2.2
execute if score #it ek matches 60 run function ek:ev/end_resume
