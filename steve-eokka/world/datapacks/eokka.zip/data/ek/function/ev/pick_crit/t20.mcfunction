swing @e[tag=ek.steve,limit=1] mainhand
execute as @a at @s run playsound minecraft:block.wood.hit master @s ~ ~ ~ 0.5 1.4
