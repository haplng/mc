scoreboard players set #intr ek 18
scoreboard players set #it ek 0
data modify storage ek:s status set value "머리 위에서 자갈이"
execute as @a at @s run playsound minecraft:block.gravel.break master @s ~ ~ ~ 0.5 1
execute at @e[tag=ek.steve,limit=1] run particle minecraft:block{block_state:"minecraft:gravel"} ~ ~2.5 ~ 0.3 0.3 0.3 0 15 force
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"자갈을 피했다",c:"aqua",s:"3"}
