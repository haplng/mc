scoreboard players set #intr ek 30
scoreboard players set #it ek 0
data modify storage ek:s status set value "발밑이 꺼졌다"
data modify entity @e[tag=ek.steve,limit=1] pose set value "crouching"
execute as @a at @s run playsound minecraft:block.stone.place master @s ~ ~ ~ 1 1
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"블록 클러치",c:"aqua",s:"3"}
