function ek:say/r36
scoreboard players set #dmg ek 8
function ek:game/dmg
