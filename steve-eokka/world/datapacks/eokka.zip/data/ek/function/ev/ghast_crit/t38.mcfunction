execute at @e[tag=ek.steve,limit=1] run function ek:fx/boom
execute as @e[tag=ek.fb] run function ek:fx/vanish
execute as @e[tag=ek.steve,limit=1] at @s run tp @s -4.0 ~ ~
execute as @e[tag=ek.steve,limit=1] at @s unless block ~ ~-1 ~ minecraft:lava run tp @s -4.0 61 0.5
data merge entity @e[tag=ek.steve,limit=1] {HasVisualFire:1b}
execute as @a at @s run playsound minecraft:entity.player.hurt_on_fire master @s ~ ~ ~ 1 1
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"용암에 빠졌다",c:"red",s:"3"}
