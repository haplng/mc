execute if score #it ek matches 24 run function ek:steve/hurt
execute if score #it ek matches 32 run function ek:steve/hurt
execute if score #it ek matches 40 run function ek:steve/hurt
execute if score #it ek matches 46 run function ek:ev/piglin_crit/t46
execute if score #it ek matches 56 run function ek:say/r45
execute if score #it ek matches 1..44 run function ek:fx/chase
execute if score #it ek matches 85 run function ek:ev/end_death
