scoreboard players set #intr ek 5
scoreboard players set #it ek 0
data modify storage ek:s status set value "갑자기 밤이 됐다"
