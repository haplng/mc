scoreboard players set #intr ek 28
scoreboard players set #it ek 0
data modify storage ek:s status set value "발밑이 꺼졌다"
execute as @a at @s run playsound minecraft:block.stone.break master @s ~ ~ ~ 1 1
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"발밑이 꺼졌다",c:"red",s:"3"}
execute if score #stage ek matches 6 run tp @e[tag=ek.steve,limit=1] 0.5 60 -8.5
execute unless score #stage ek matches 6 run execute at @e[tag=ek.steve,limit=1] run fill ~ ~-1 ~ ~ ~-2 ~ minecraft:lava
