function ek:steve/say {t:"왠지 오늘 진주 안 나올 것 같은 느낌"}
scoreboard players set #dmg ek 3
function ek:game/dmg
