scoreboard players set #intr ek 32
scoreboard players set #it ek 0
scoreboard players add #flint ek 2
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"불길한 예감...",c:"gray",s:"3"}
execute as @a at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.6 0.7
