scoreboard players set #intr ek 15
scoreboard players set #it ek 0
data modify storage ek:s status set value "마른하늘에 날벼락"
weather thunder
execute as @e[tag=ek.steve,limit=1] at @s run setblock ^ ^ ^3 minecraft:lightning_rod keep
