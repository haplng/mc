execute at @e[tag=ek.zom] run particle minecraft:flame ~ ~1 ~ 0.2 0.5 0.2 0.02 20 force
execute as @e[tag=ek.zom] run function ek:fx/vanish
time set 6000
scoreboard players add #day ek 1
