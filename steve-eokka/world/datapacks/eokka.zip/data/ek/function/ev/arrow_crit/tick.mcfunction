execute if score #it ek matches 14 run function ek:ev/arrow_crit/t14
execute if score #it ek matches 28 run function ek:ev/arrow_crit/t28
execute if score #it ek matches 46 run function ek:ev/arrow_crit/t46
execute if score #it ek matches 60 run function ek:say/r11
execute if score #it ek matches 70 run execute as @e[tag=ek.skel] run function ek:fx/vanish
execute if score #it ek matches 15..27 run execute as @e[tag=ek.arrowfx] at @s facing entity @e[tag=ek.steve,limit=1] eyes run tp @s ^ ^ ^2.2
execute if score #it ek matches 29..44 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~-0.25 ~ ~0.3
execute if score #it ek matches 95 run function ek:ev/end_death
