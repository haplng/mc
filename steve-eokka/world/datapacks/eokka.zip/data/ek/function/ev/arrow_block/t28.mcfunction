execute as @e[tag=ek.arrowfx] run function ek:fx/vanish
execute as @a at @s run playsound minecraft:item.shield.block master @s ~ ~ ~ 1 1
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"방패 막기",c:"aqua",s:"3"}
