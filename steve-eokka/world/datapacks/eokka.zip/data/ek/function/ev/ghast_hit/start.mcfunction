scoreboard players set #intr ek 44
scoreboard players set #it ek 0
data modify storage ek:s status set value "가스트가 나타났다"
summon minecraft:ghast 7.5 67 0.5 {Tags:["ek.mob","ek.ghast"],NoAI:1b,PersistenceRequired:1b,Invulnerable:1b,Silent:1b}
execute as @e[tag=ek.ghast] at @s run tp @s ~ ~ ~ facing entity @e[tag=ek.steve,limit=1] eyes
execute as @a at @s run playsound minecraft:entity.ghast.warn master @s ~ ~ ~ 0.9 1
