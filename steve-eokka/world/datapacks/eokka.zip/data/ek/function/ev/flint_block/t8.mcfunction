function ek:say/r33
scoreboard players set #dmg ek 1
execute if score #sweet ek matches 1 run scoreboard players set #dmg ek 4
function ek:game/dmg
