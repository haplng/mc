execute if score #it ek matches 4 run function ek:ev/crystal_hit/t4
execute if score #it ek matches 40 run function ek:ev/end_resume
