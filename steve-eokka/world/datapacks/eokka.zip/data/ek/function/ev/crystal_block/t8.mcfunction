function ek:say/r64
scoreboard players set #dmg ek 3
execute if score #sweet ek matches 1 run scoreboard players set #dmg ek 6
function ek:game/dmg
