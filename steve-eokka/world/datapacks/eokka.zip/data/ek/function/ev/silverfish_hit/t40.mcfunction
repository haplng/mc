swing @e[tag=ek.steve,limit=1] mainhand
execute as @a at @s run playsound minecraft:entity.player.attack.sweep master @s ~ ~ ~ 0.6 1
kill @e[tag=ek.sf,limit=1]
