execute if score #it ek matches 12 run function ek:ev/lava_block/t12
execute if score #it ek matches 18 run function ek:ev/lava_block/t18
execute if score #it ek matches 40 run function ek:ev/end_cont
