scoreboard players set #intr ek 73
scoreboard players set #it ek 0
data modify storage ek:s status set value "수정이 혼자 터졌다"
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"안전거리 확보",c:"aqua",s:"3"}
