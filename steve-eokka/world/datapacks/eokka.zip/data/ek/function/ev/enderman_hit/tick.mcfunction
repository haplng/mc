execute if score #it ek matches 10 run execute as @a at @s run playsound minecraft:entity.enderman.scream master @s ~ ~ ~ 0.8 1
execute if score #it ek matches 16 run function ek:ev/enderman_hit/t16
execute if score #it ek matches 22 run function ek:ev/enderman_hit/t22
execute if score #it ek matches 26 run function ek:ev/enderman_hit/t26
execute if score #it ek matches 32 run function ek:ev/enderman_hit/t32
execute if score #it ek matches 38 run function ek:ev/enderman_hit/t38
execute if score #it ek matches 40 run function ek:ev/enderman_hit/t40
execute if score #it ek matches 44 run function ek:steve/say {t:"엔더맨은 왜 건드려 가지고"}
execute if score #it ek matches 60 run function ek:ev/end_resume
