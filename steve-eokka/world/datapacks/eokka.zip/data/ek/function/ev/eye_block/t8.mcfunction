function ek:say/r48
scoreboard players set #dmg ek 2
execute if score #sweet ek matches 1 run scoreboard players set #dmg ek 3
function ek:game/dmg
