execute as @e[tag=ek.arrowfx] run function ek:fx/vanish
execute as @a at @s run playsound minecraft:entity.arrow.hit_player master @s ~ ~ ~ 1 1
function ek:steve/hurt
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"명중",c:"red",s:"3"}
