scoreboard players set #intr ek 51
scoreboard players set #it ek 0
data modify storage ek:s status set value "피글린이 화났다"
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"금 장화 착용",c:"aqua",s:"3"}
