execute if score #it ek matches 14 run function ek:ev/lava_hit/t14
execute if score #it ek matches 36 run function ek:ev/lava_hit/t36
execute if score #it ek matches 42 run function ek:say/r27
execute if score #it ek matches 15..34 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ ~40 ~
execute if score #it ek matches 60 run function ek:ev/end_resume
