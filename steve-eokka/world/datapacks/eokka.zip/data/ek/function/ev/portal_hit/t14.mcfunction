function ek:steve/say {t:"뒤에서 뭔 소리 났는데? 포탈인가"}
scoreboard players set #dmg ek 5
function ek:game/dmg
