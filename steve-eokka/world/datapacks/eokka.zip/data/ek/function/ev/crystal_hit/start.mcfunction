scoreboard players set #intr ek 72
scoreboard players set #it ek 0
data modify storage ek:s status set value "수정이 혼자 터졌다"
execute at @e[tag=ek.cr,limit=1,sort=random] run function ek:fx/boom
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"수정 유폭",c:"red",s:"3"}
