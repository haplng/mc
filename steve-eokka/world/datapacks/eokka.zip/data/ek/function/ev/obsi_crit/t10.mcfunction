function ek:say/r38
scoreboard players set #dmg ek 10
function ek:game/dmg
