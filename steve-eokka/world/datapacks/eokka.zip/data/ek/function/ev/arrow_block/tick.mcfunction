execute if score #it ek matches 14 run function ek:ev/arrow_block/t14
execute if score #it ek matches 28 run function ek:ev/arrow_block/t28
execute if score #it ek matches 32 run function ek:ev/arrow_block/t32
execute if score #it ek matches 44 run execute as @e[tag=ek.skel] run function ek:fx/vanish
execute if score #it ek matches 15..27 run execute as @e[tag=ek.arrowfx] at @s facing entity @e[tag=ek.steve,limit=1] eyes run tp @s ^ ^ ^2.2
execute if score #it ek matches 55 run function ek:ev/end_cont
