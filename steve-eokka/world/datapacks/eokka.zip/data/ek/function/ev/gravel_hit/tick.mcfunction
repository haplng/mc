execute if score #it ek matches 14 run function ek:ev/gravel_hit/t14
execute if score #it ek matches 22 run function ek:steve/hurt
execute if score #it ek matches 26 run swing @e[tag=ek.steve,limit=1] mainhand
execute if score #it ek matches 32 run swing @e[tag=ek.steve,limit=1] mainhand
execute if score #it ek matches 38 run swing @e[tag=ek.steve,limit=1] mainhand
execute if score #it ek matches 40 run function ek:ev/gravel_hit/t40
execute if score #it ek matches 46 run function ek:steve/say {t:"자갈은 위에서부터 캐야지..."}
execute if score #it ek matches 60 run function ek:ev/end_resume
