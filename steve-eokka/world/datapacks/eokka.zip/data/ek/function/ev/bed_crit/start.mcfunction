scoreboard players set #intr ek 65
scoreboard players set #it ek 0
data modify storage ek:s status set value "침대가 먼저 터졌다"
execute at @e[tag=ek.steve,limit=1] run function ek:fx/boom
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"침대가 먼저 터졌다",c:"red",s:"3"}
setblock 2 65 0 minecraft:air
setblock 1 65 0 minecraft:air
