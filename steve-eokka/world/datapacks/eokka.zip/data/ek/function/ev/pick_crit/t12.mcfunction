function ek:say/r14
scoreboard players set #dmg ek 8
execute if score #f_obs ek matches 1 run scoreboard players add #dmg ek 4
function ek:game/dmg
