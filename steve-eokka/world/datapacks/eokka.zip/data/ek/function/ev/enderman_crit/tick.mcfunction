execute if score #it ek matches 10 run execute as @a at @s run playsound minecraft:entity.enderman.scream master @s ~ ~ ~ 0.8 1
execute if score #it ek matches 16 run function ek:ev/enderman_crit/t16
execute if score #it ek matches 22 run function ek:steve/hurt
execute if score #it ek matches 32 run function ek:steve/hurt
execute if score #it ek matches 42 run function ek:steve/hurt
execute if score #it ek matches 44 run function ek:ev/enderman_crit/t44
execute if score #it ek matches 54 run function ek:say/r52
execute if score #it ek matches 85 run function ek:ev/end_death
