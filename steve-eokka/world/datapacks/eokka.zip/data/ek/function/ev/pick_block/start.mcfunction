scoreboard players set #intr ek 12
scoreboard players set #it ek 0
data modify storage ek:s status set value "곡괭이가 부서졌다"
execute as @a at @s run playsound minecraft:entity.item.break master @s ~ ~ ~ 1 1
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"여분 곡괭이로 교체",c:"aqua",s:"3"}
