scoreboard players set #intr ek 21
scoreboard players set #it ek 0
data modify storage ek:s status set value "어둠 속 좀비 떼"
execute at @e[tag=ek.steve,limit=1] run setblock ~ ~ ~ minecraft:torch keep
execute as @a at @s run playsound minecraft:block.wood.place master @s ~ ~ ~ 1 1
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"횃불 도배",c:"aqua",s:"3"}
