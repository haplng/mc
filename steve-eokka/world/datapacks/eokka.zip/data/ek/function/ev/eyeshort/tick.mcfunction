execute if score #it ek matches 5 run function ek:ev/eyeshort/t5
execute if score #it ek matches 20 run function ek:ev/eyeshort/t20
execute if score #it ek matches 50 run function ek:ev/eyeshort/t50
execute if score #it ek matches 102 run function ek:ev/eyeshort/t102
execute if score #it ek matches 104 run scoreboard players set #eyes ek 12
execute if score #it ek matches 51..100 run time add 480
execute if score #it ek matches 108 run function ek:ev/end_back
