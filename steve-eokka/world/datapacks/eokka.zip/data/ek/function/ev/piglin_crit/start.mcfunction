scoreboard players set #intr ek 49
scoreboard players set #it ek 0
data modify storage ek:s status set value "피글린이 화났다"
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"금 갑옷이 사라졌다",c:"red",s:"3"}
execute as @a at @s run playsound minecraft:entity.piglin.angry master @s ~ ~ ~ 0.9 1
tag @e[tag=ek.pig] add ek.chase
