execute as @a at @s run playsound minecraft:entity.arrow.shoot master @s ~ ~ ~ 1 1
execute at @e[tag=ek.skel,limit=1] run summon item_display ~ ~1.5 ~ {Tags:["ek.mob","ek.arrowfx"],billboard:"center",teleport_duration:1,item:{id:"minecraft:arrow",count:1},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.5f,1.5f,1.5f]}}
