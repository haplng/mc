time set 6000
data modify entity @e[tag=ek.steve,limit=1] pose set value "standing"
scoreboard players set #dmg ek 3
execute if score #sweet ek matches 1 run scoreboard players set #dmg ek 5
function ek:game/dmg
