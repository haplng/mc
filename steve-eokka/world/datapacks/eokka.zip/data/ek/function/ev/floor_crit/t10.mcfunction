execute at @e[tag=ek.steve,limit=1] run particle minecraft:lava ~ ~1 ~ 0.3 0.3 0.3 0 6 force
execute at @e[tag=ek.steve,limit=1] run particle minecraft:large_smoke ~ ~1.5 ~ 0.2 0.2 0.2 0.02 5 force
