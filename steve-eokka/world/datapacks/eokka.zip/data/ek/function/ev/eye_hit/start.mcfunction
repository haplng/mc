scoreboard players set #intr ek 53
scoreboard players set #it ek 0
data modify storage ek:s status set value "엔더의 눈이 깨졌다"
scoreboard players remove #eyes ek 1
execute as @a at @s run playsound minecraft:entity.ender_eye.death master @s ~ ~ ~ 1 1
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"주머니 속 눈에 금이 갔다 (-1)",c:"red",s:"3"}
