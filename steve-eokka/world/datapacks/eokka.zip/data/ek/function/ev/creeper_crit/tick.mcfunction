execute if score #it ek matches 40 run function ek:ev/creeper_crit/t40
execute if score #it ek matches 66 run function ek:ev/creeper_crit/t66
execute if score #it ek matches 82 run function ek:say/r4
execute if score #it ek matches 1..38 run function ek:fx/chase
execute if score #it ek matches 110 run function ek:ev/end_death
