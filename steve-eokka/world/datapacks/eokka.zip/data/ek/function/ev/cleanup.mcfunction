execute as @e[tag=ek.mob] run function ek:fx/vanish
kill @e[tag=ek.evt]
kill @e[tag=ek.aim]
scoreboard players set #snap ek 1
scoreboard players set #aimx ek 100
weather clear
time set 6000
function ek:steve/reset_pose
execute if score #stage ek matches 5 run function ek:s5/evclean
execute if score #stage ek matches 7 run function ek:s7/evclean
