function ek:say/r44
fill -9 62 10 -8 64 10 minecraft:nether_portal[axis=x]
execute as @a at @s run playsound minecraft:item.flintandsteel.use master @s ~ ~ ~ 1 1
scoreboard players set #dmg ek 2
execute if score #sweet ek matches 1 run scoreboard players set #dmg ek 5
function ek:game/dmg
