time set 6000
scoreboard players add #day ek 2
