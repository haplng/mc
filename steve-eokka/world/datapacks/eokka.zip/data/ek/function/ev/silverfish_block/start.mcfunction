scoreboard players set #intr ek 58
scoreboard players set #it ek 0
data modify storage ek:s status set value "좀벌레 떼"
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"좀벌레 차단",c:"aqua",s:"3"}
