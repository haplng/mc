execute if score #it ek matches 12 run function ek:ev/portal_block/t12
execute if score #it ek matches 35 run function ek:ev/end_cont
