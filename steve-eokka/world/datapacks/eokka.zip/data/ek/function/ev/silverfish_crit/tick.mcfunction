execute if score #it ek matches 12 run function ek:steve/say {t:"좀벌레?!"}
execute if score #it ek matches 20 run function ek:steve/hurt
execute if score #it ek matches 30 run function ek:steve/hurt
execute if score #it ek matches 40 run function ek:steve/hurt
execute if score #it ek matches 50 run function ek:steve/hurt
execute if score #it ek matches 56 run function ek:ev/silverfish_crit/t56
execute if score #it ek matches 64 run execute as @e[tag=ek.sf] run function ek:fx/vanish
execute if score #it ek matches 70 run function ek:say/r50
execute if score #it ek matches 1..60 run function ek:fx/chase
execute if score #it ek matches 95 run function ek:ev/end_death
