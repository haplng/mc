swing @e[tag=ek.steve,limit=1] mainhand
execute as @a at @s run playsound minecraft:entity.player.attack.strong master @s ~ ~ ~ 1 1
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"쳐냈다",c:"aqua",s:"3"}
