scoreboard players set #intr ek 62
scoreboard players set #it ek 0
data modify storage ek:s status set value "드래곤의 날갯짓"
scoreboard players set #dmode ek 3
execute as @a at @s run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.9 1
execute at @e[tag=ek.steve,limit=1] run tp @e[tag=ek.dtgt,limit=1] ~ ~9 ~
