function ek:steve/hurt
scoreboard players set #dmg ek 6
function ek:game/dmg
function ek:say/r17
