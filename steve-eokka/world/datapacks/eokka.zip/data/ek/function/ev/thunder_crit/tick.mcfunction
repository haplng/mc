execute if score #it ek matches 20 run execute at @e[tag=ek.steve,limit=1] run summon minecraft:lightning_bolt ~ ~ ~
execute if score #it ek matches 22 run function ek:ev/thunder_crit/t22
execute if score #it ek matches 30 run fill -14 58 -14 14 86 14 minecraft:air replace minecraft:fire
execute if score #it ek matches 40 run function ek:say/r16
execute if score #it ek matches 70 run weather clear
execute if score #it ek matches 95 run function ek:ev/end_death
