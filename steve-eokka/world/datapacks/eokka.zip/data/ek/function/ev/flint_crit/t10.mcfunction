function ek:say/r32
scoreboard players set #dmg ek 8
function ek:game/dmg
