scoreboard players set #intr ek 10
scoreboard players set #it ek 0
data modify storage ek:s status set value "곡괭이가 부서졌다"
execute as @a at @s run playsound minecraft:entity.item.break master @s ~ ~ ~ 1 1
item replace entity @e[tag=ek.steve,limit=1] weapon.mainhand with minecraft:air
execute at @e[tag=ek.steve,limit=1] run particle minecraft:poof ~ ~1.2 ~ 0.2 0.2 0.2 0.02 10 force
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"곡괭이가 부서졌다",c:"red",s:"3"}
