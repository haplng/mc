execute if score #it ek matches 12 run function ek:ev/pick_hit/t12
execute if score #it ek matches 45 run function ek:ev/end_resume
