execute if score #it ek matches 30 run function ek:ev/void_crit/t30
execute if score #it ek matches 46 run scoreboard players set #dmode ek 0
execute if score #it ek matches 67 run function ek:ev/void_crit/t67
execute if score #it ek matches 78 run function ek:say/r54
execute if score #it ek matches 90 run function ek:ev/void_crit/t90
execute if score #it ek matches 142 run function ek:ev/void_crit/t142
execute if score #it ek matches 1..28 run execute as @e[tag=ek.dragon,limit=1] at @s facing entity @e[tag=ek.dtgt,limit=1] feet unless entity @e[tag=ek.dtgt,distance=..1] run tp @s ^ ^ ^0.9 ~180 0
execute if score #it ek matches 31..45 run execute as @e[tag=ek.dragon,limit=1] at @s run tp @s ~ ~0.4 ~-0.9 0 0
execute if score #it ek matches 31..46 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~0.25 ~0.55
execute if score #it ek matches 47..66 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~-1.1 ~0.25
execute if score #it ek matches 91..140 run time add 480
execute if score #it ek matches 146 run function ek:ev/end_major
