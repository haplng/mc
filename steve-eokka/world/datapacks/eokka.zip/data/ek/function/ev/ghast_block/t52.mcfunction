execute at @e[tag=ek.ghast,limit=1] run function ek:fx/boom
execute as @e[tag=ek.fb] run function ek:fx/vanish
kill @e[tag=ek.ghast]
execute as @a at @s run playsound minecraft:entity.ghast.death master @s ~ ~ ~ 0.8 1
tellraw @a {"text":"","extra":[{"text":"Steve이(가) 발전 과제 ","color":"white"},{"text":"[발신자에게 반송]","color":"green"},{"text":"을 달성했습니다!","color":"white"}]}
