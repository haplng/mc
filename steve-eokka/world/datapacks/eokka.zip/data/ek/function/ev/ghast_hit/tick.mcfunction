execute if score #it ek matches 24 run function ek:ev/ghast_hit/t24
execute if score #it ek matches 38 run function ek:ev/ghast_hit/t38
execute if score #it ek matches 44 run function ek:say/r41
execute if score #it ek matches 60 run execute as @e[tag=ek.ghast] run function ek:fx/vanish
execute if score #it ek matches 25..36 run execute as @e[tag=ek.fb] at @s facing entity @e[tag=ek.aim,limit=1] feet run tp @s ^ ^ ^1.3
execute if score #it ek matches 75 run function ek:ev/end_resume
