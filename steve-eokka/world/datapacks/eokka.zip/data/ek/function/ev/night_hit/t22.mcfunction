execute as @e[tag=ek.steve,limit=1] at @s rotated ~ 0 positioned ^ ^ ^-6 run summon minecraft:zombie ~ ~ ~ {Tags:["ek.mob","ek.zom","ek.chase"],NoAI:1b,PersistenceRequired:1b,Invulnerable:1b,Silent:1b,equipment:{head:{id:"minecraft:stone_button",count:1}}}
execute as @a at @s run playsound minecraft:entity.zombie.ambient master @s ~ ~ ~ 1 1
