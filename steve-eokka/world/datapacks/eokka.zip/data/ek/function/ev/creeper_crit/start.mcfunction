scoreboard players set #intr ek 1
scoreboard players set #it ek 0
data modify storage ek:s status set value "등 뒤에 크리퍼"
execute at @e[tag=ek.aim,limit=1] positioned ~0 ~ ~0 run summon minecraft:creeper ~ ~ ~ {Tags:["ek.mob","ek.creep","ek.chase","ek.fast"],NoAI:1b,PersistenceRequired:1b,Invulnerable:1b,Silent:1b,ExplosionRadius:0b,Fuse:30s}
