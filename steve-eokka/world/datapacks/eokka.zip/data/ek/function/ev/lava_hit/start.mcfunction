scoreboard players set #intr ek 26
scoreboard players set #it ek 0
data modify storage ek:s status set value "용암이 터져 나왔다"
execute at @e[tag=ek.steve,limit=1] run summon marker ~ ~ ~ {Tags:["ek.evt"]}
execute as @a at @s run playsound minecraft:block.lava.pop master @s ~ ~ ~ 1 0.8
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"...용암 소리?",c:"gold",s:"3"}
