scoreboard players set #intr ek 71
scoreboard players set #it ek 0
data modify storage ek:s status set value "수정이 눈앞에서 터졌다"
execute at @e[tag=ek.steve,limit=1] run function ek:fx/boom
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"수정이 눈앞에서 터졌다",c:"red",s:"3"}
fill -3 65 4 -3 80 4 minecraft:air replace minecraft:cobblestone
