function ek:say/r42
scoreboard players set #dmg ek 3
execute if score #sweet ek matches 1 run scoreboard players set #dmg ek 7
function ek:game/dmg
