scoreboard players set #intr ek 56
scoreboard players set #it ek 0
data modify storage ek:s status set value "좀벌레 떼"
execute at @e[tag=ek.aim,limit=1] positioned ~0 ~ ~0 run summon minecraft:silverfish ~ ~ ~ {Tags:["ek.mob","ek.sf","ek.chase","ek.fast"],NoAI:1b,PersistenceRequired:1b,Invulnerable:1b,Silent:1b,attributes:[{id:"minecraft:scale",base:2.2d}]}
execute at @e[tag=ek.aim,limit=1] positioned ~1.2 ~ ~0.6 run summon minecraft:silverfish ~ ~ ~ {Tags:["ek.mob","ek.sf","ek.chase","ek.fast"],NoAI:1b,PersistenceRequired:1b,Invulnerable:1b,Silent:1b,attributes:[{id:"minecraft:scale",base:2.2d}]}
execute at @e[tag=ek.aim,limit=1] positioned ~-1.2 ~ ~0.6 run summon minecraft:silverfish ~ ~ ~ {Tags:["ek.mob","ek.sf","ek.chase","ek.fast"],NoAI:1b,PersistenceRequired:1b,Invulnerable:1b,Silent:1b,attributes:[{id:"minecraft:scale",base:2.2d}]}
execute at @e[tag=ek.aim,limit=1] positioned ~0.6 ~ ~-1.2 run summon minecraft:silverfish ~ ~ ~ {Tags:["ek.mob","ek.sf","ek.chase","ek.fast"],NoAI:1b,PersistenceRequired:1b,Invulnerable:1b,Silent:1b,attributes:[{id:"minecraft:scale",base:2.2d}]}
execute at @e[tag=ek.aim,limit=1] positioned ~-0.6 ~ ~-1.2 run summon minecraft:silverfish ~ ~ ~ {Tags:["ek.mob","ek.sf","ek.chase","ek.fast"],NoAI:1b,PersistenceRequired:1b,Invulnerable:1b,Silent:1b,attributes:[{id:"minecraft:scale",base:2.2d}]}
execute as @a at @s run playsound minecraft:entity.silverfish.ambient master @s ~ ~ ~ 1 1
