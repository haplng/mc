execute if score #it ek matches 20 run execute as @e[tag=ek.steve,limit=1] at @s run summon minecraft:lightning_bolt ^ ^ ^3
execute if score #it ek matches 24 run function ek:ev/thunder_block/t24
execute if score #it ek matches 30 run fill -14 58 -14 14 86 14 minecraft:air replace minecraft:fire
execute if score #it ek matches 55 run weather clear
execute if score #it ek matches 65 run function ek:ev/end_cont
