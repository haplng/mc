execute if score #it ek matches 10 run function ek:ev/obsi_crit/t10
execute if score #it ek matches 40 run function ek:steve/say {t:"...다시 캐러 간다"}
execute if score #it ek matches 60 run function ek:ev/obsi_crit/t60
execute if score #it ek matches 112 run function ek:ev/obsi_crit/t112
execute if score #it ek matches 61..110 run time add 480
execute if score #it ek matches 118 run function ek:ev/end_back
