execute if score #it ek matches 4 run function ek:ev/heal_hit/t4
execute if score #it ek matches 14 run function ek:ev/heal_hit/t14
execute if score #it ek matches 40 run function ek:ev/heal_hit/t40
execute if score #it ek matches 48 run function ek:ev/heal_hit/t48
execute if score #it ek matches 60 run function ek:ev/end_resume
