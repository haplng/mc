execute at @e[tag=ek.evt,limit=1] run setblock ~ ~ ~ minecraft:air
data merge entity @e[tag=ek.steve,limit=1] {HasVisualFire:0b}
function ek:steve/hurt
scoreboard players set #dmg ek 7
function ek:game/dmg
