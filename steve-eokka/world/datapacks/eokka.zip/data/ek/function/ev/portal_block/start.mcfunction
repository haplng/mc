scoreboard players set #intr ek 48
scoreboard players set #it ek 0
data modify storage ek:s status set value "포탈이 꺼졌다"
fill -9 62 10 -8 64 10 minecraft:air
execute as @a at @s run playsound minecraft:block.glass.break master @s ~ ~ ~ 1 0.6
execute positioned -8 66 10.5 run function ek:fx/popup {t:"포탈 꺼짐",c:"red",s:"3"}
