execute if score #it ek matches 10 run function ek:ev/floor_block/t10
execute if score #it ek matches 20 run data modify entity @e[tag=ek.steve,limit=1] pose set value "standing"
execute if score #it ek matches 35 run function ek:ev/end_cont
