function ek:steve/hurt
scoreboard players set #dmg ek 7
function ek:game/dmg
function ek:say/r55
