scoreboard players set #intr ek 31
scoreboard players set #it ek 0
scoreboard players add #flint ek 4
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"부싯돌 확률 급락",c:"red",s:"3"}
execute as @a at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.5
