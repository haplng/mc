execute if score #it ek matches 8 run function ek:say/r10
execute if score #it ek matches 24 run function ek:ev/night_block/t24
execute if score #it ek matches 64 run function ek:ev/night_block/t64
execute if score #it ek matches 1..20 run time add 400
execute if score #it ek matches 75 run function ek:ev/end_cont
