function ek:steve/say {t:"나가는 길이 어디야"}
scoreboard players set #dmg ek 8
function ek:game/dmg
