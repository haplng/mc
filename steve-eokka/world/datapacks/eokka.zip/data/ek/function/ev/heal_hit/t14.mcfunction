function ek:steve/say {t:"수정이 하나 더 있었네"}
scoreboard players set #dmg ek 5
function ek:game/dmg
