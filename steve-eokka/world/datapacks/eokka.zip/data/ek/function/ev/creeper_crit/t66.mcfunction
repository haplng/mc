execute at @e[tag=ek.creep,limit=1] run function ek:fx/boom
execute as @e[tag=ek.creep] run function ek:fx/vanish
tellraw @a {"text":"Steve이(가) 크리퍼에게 폭파당했습니다","color":"white"}
scoreboard players add #deaths ek 1
scoreboard players add #dc_creeper ek 1
kill @e[tag=ek.steve]
kill @e[tag=ek.bub]
scoreboard players set #steve ek 0
scoreboard players set #bubt ek 0
execute as @a at @s run playsound minecraft:entity.player.death master @s ~ ~ ~ 0.8 1
scoreboard players set #dmg ek 13
function ek:game/dmg
