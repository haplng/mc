scoreboard players set #intr ek 23
scoreboard players set #it ek 0
data modify storage ek:s status set value "길을 잃음"
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"?",c:"yellow",s:"3"}
