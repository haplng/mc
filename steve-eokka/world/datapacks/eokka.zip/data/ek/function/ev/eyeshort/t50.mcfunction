execute at @e[tag=ek.steve,limit=1] run particle minecraft:poof ~ ~1 ~ 0.3 0.6 0.3 0.05 30 force
execute as @e[tag=ek.steve,limit=1] run function ek:fx/vanish
scoreboard players set #steve ek 0
kill @e[tag=ek.bub]
scoreboard players set #bubt ek 0
title @a times 5 40 10
title @a subtitle {"text":"3일 뒤","color":"gray"}
title @a title {"text":" "}
