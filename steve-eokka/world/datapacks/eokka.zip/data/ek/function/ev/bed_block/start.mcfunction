scoreboard players set #intr ek 67
scoreboard players set #it ek 0
data modify storage ek:s status set value "침대가 먼저 터졌다"
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"블록 방패",c:"aqua",s:"3"}
