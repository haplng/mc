execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing entity @e[tag=ek.creep,limit=1] feet
function ek:steve/say {t:"어 크리퍼?"}
