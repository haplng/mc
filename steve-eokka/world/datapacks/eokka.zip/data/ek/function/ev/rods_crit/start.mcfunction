scoreboard players set #intr ek 37
scoreboard players set #it ek 0
scoreboard players add #rmiss ek 3
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"막대 드롭 급락",c:"red",s:"3"}
execute as @a at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.5
