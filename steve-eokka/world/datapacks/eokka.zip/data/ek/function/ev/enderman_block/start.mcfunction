scoreboard players set #intr ek 61
scoreboard players set #it ek 0
data modify storage ek:s status set value "엔더맨이랑 눈이 마주쳤다"
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"호박 착용",c:"aqua",s:"3"}
