execute at @e[tag=ek.hc] run function ek:fx/boom
kill @e[tag=ek.hc]
