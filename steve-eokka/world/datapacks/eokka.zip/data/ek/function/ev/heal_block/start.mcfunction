scoreboard players set #intr ek 70
scoreboard players set #it ek 0
data modify storage ek:s status set value "숨은 수정"
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"수정 개수 확인 완료",c:"aqua",s:"3"}
