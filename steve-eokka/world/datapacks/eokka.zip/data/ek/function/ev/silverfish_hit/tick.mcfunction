execute if score #it ek matches 24 run function ek:ev/silverfish_hit/t24
execute if score #it ek matches 28 run function ek:ev/silverfish_hit/t28
execute if score #it ek matches 34 run function ek:ev/silverfish_hit/t34
execute if score #it ek matches 40 run function ek:ev/silverfish_hit/t40
execute if score #it ek matches 46 run function ek:ev/silverfish_hit/t46
execute if score #it ek matches 48 run kill @e[tag=ek.sf]
execute if score #it ek matches 54 run function ek:steve/say {t:"벌레 주제에"}
execute if score #it ek matches 1..40 run function ek:fx/chase
execute if score #it ek matches 70 run function ek:ev/end_resume
