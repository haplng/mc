scoreboard players set #ho_iron ek 1
scoreboard players set #heal ek 6
function ek:game/heal
