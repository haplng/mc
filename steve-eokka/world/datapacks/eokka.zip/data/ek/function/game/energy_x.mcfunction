scoreboard players add #ex ek 1
execute if score #ex ek matches 2.. run scoreboard players add #et ek 1
execute if score #ex ek matches 2.. run scoreboard players set #ex ek 0
