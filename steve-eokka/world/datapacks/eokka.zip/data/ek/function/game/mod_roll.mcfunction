scoreboard players set #mod ek 0
scoreboard players set #ex ek 0
execute if score #stage ek matches 2.. store result score #mod ek run random value 0..5
execute if score #mod ek matches 1 run tellraw @a {"text":"","extra":[{"text":"  오늘의 변수: ","color":"gray"},{"text":"기력이 넘치는 날","color":"yellow","bold":true},{"text":"  기력이 1.5배 빨리 찬다","color":"gray"}]}
execute if score #mod ek matches 2 run tellraw @a {"text":"","extra":[{"text":"  오늘의 변수: ","color":"gray"},{"text":"스티브 컨디션 최상","color":"red","bold":true},{"text":"  스티브가 서둘러 걷는다","color":"gray"}]}
execute if score #mod ek matches 3 run tellraw @a {"text":"","extra":[{"text":"  오늘의 변수: ","color":"gray"},{"text":"재수 없는 날","color":"gold","bold":true},{"text":"  모든 억까 피해 +20%","color":"gray"}]}
execute if score #mod ek matches 4 run tellraw @a {"text":"","extra":[{"text":"  오늘의 변수: ","color":"gray"},{"text":"행운 상자 풍년","color":"yellow","bold":true},{"text":"  행운 상자가 훨씬 자주 떨어진다","color":"gray"}]}
execute if score #mod ek matches 5 run tellraw @a {"text":"","extra":[{"text":"  오늘의 변수: ","color":"gray"},{"text":"스티브가 산만한 날","color":"aqua","bold":true},{"text":"  스티브가 딴짓을 훨씬 자주 한다","color":"gray"}]}
execute if score #mod ek matches 1 run title @a subtitle {"text":"","extra":[{"score":{"name":"#day","objective":"ek"},"color":"white"},{"text":"일차 · ","color":"white"},{"text":"기력이 넘치는 날","color":"yellow"}]}
execute if score #mod ek matches 2 run title @a subtitle {"text":"","extra":[{"score":{"name":"#day","objective":"ek"},"color":"white"},{"text":"일차 · ","color":"white"},{"text":"스티브 컨디션 최상","color":"red"}]}
execute if score #mod ek matches 3 run title @a subtitle {"text":"","extra":[{"score":{"name":"#day","objective":"ek"},"color":"white"},{"text":"일차 · ","color":"white"},{"text":"재수 없는 날","color":"gold"}]}
execute if score #mod ek matches 4 run title @a subtitle {"text":"","extra":[{"score":{"name":"#day","objective":"ek"},"color":"white"},{"text":"일차 · ","color":"white"},{"text":"행운 상자 풍년","color":"yellow"}]}
execute if score #mod ek matches 5 run title @a subtitle {"text":"","extra":[{"score":{"name":"#day","objective":"ek"},"color":"white"},{"text":"일차 · ","color":"white"},{"text":"스티브가 산만한 날","color":"aqua"}]}
