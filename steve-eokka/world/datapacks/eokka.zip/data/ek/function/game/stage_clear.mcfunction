scoreboard players add #stage ek 1
scoreboard players add #day ek 1
scoreboard players set #heal ek 8
function ek:game/heal
function ek:cards/relax
function ek:game/stage_begin
