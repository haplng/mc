scoreboard players set #ho_dia ek 1
scoreboard players set #heal ek 8
function ek:game/heal
