scoreboard players set #diff ek 0
scoreboard players set #mmax ek 240
scoreboard players set #recint ek 150
scoreboard players set #learn ek 3
scoreboard players set #eint ek 10
scoreboard players set #dscale ek 110
function ek:game/begin
