execute store result bossbar ek:energy value run scoreboard players get #energy ek
bossbar set ek:energy name ["",{"text":"억까 기력 ","color":"yellow"},{"score":{"name":"#energy","objective":"ek"},"color":"white"}]
