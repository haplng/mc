execute as @e[tag=ek.steve] run function ek:fx/vanish
execute as @e[tag=ek.mob] run function ek:fx/vanish
execute as @e[tag=ek.stg] run function ek:fx/vanish
kill @e[tag=ek.bub]
kill @e[tag=ek.tmp]
kill @e[tag=ek.tgt]
kill @e[tag=ek.evt]
function ek:drop/cancel
function ek:box/clear
scoreboard players set #idle ek 0
scoreboard players set #wild ek 0
