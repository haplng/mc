execute if score #combo_t ek matches 1.. run scoreboard players add #combo ek 1
execute unless score #combo_t ek matches 1.. run scoreboard players set #combo ek 1
scoreboard players set #combo_t ek 140
scoreboard players operation #mul ek = #combo ek
scoreboard players remove #mul ek 1
scoreboard players operation #mul ek *= #c20 ek
scoreboard players add #mul ek 100
execute if score #mul ek matches 161.. run scoreboard players set #mul ek 160
scoreboard players operation #dmg ek *= #mul ek
scoreboard players operation #dmg ek *= #dscale ek
scoreboard players operation #dmg ek /= #c10000 ek
scoreboard players operation #dmg ek *= #aimx ek
scoreboard players operation #dmg ek /= #c100 ek
scoreboard players set #aimx ek 100
execute if score #mod ek matches 3 run scoreboard players operation #dmg ek *= #c6 ek
execute if score #mod ek matches 3 run scoreboard players operation #dmg ek /= #c5 ek
execute if score #dmg ek matches ..0 run scoreboard players set #dmg ek 1
scoreboard players operation #mental ek -= #dmg ek
execute if score #mental ek matches ..-1 run scoreboard players set #mental ek 0
scoreboard players operation #total ek += #dmg ek
execute if score #combo ek > #maxcombo ek run scoreboard players operation #maxcombo ek = #combo ek
execute store result storage ek:s tmp.n int 1 run scoreboard players get #dmg ek
execute store result storage ek:s tmp.c int 1 run scoreboard players get #combo ek
function ek:fx/dmg_popup with storage ek:s tmp
execute if score #combo ek matches 2.. run function ek:fx/combo_popup with storage ek:s tmp
execute if score #combo ek matches ..1 run data modify storage ek:s ab.combo set value ""
execute as @a at @s run playsound minecraft:entity.player.attack.strong master @s ~ ~ ~ 0.8 0.7
function ek:game/bars
