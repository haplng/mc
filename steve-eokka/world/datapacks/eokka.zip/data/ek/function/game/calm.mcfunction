execute if score #combo_t ek matches 1 run data modify storage ek:s ab.combo set value ""
execute if score #combo_t ek matches 1.. run scoreboard players remove #combo_t ek 1
scoreboard players add #rec ek 1
execute if score #rec ek >= #recint ek run function ek:game/rec1
