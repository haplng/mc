scoreboard players set #maxbeat ek 0
scoreboard players set #redo ek 0
function ek:game/stage_setup
function ek:cards/deal
execute if score #stage ek matches 1 run data modify storage ek:s stage set value "1단계: 나무와 돌"
execute if score #stage ek matches 2 run data modify storage ek:s stage set value "2단계: 철 캐기"
execute if score #stage ek matches 3 run data modify storage ek:s stage set value "3단계: 다이아"
execute if score #stage ek matches 4 run data modify storage ek:s stage set value "4단계: 네더 포탈"
execute if score #stage ek matches 5 run data modify storage ek:s stage set value "5단계: 네더"
execute if score #stage ek matches 6 run data modify storage ek:s stage set value "6단계: 요새"
execute if score #stage ek matches 7 run data modify storage ek:s stage set value "7단계: 엔드"
title @a times 5 40 10
title @a subtitle {"text":"","extra":[{"score":{"name":"#day","objective":"ek"},"color":"white"},{"text":"일차","color":"white"}]}
title @a title {"nbt":"stage","storage":"ek:s","color":"yellow"}
execute as @a at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.7 1.4
particle minecraft:poof 0.5 64 0.5 9 3 9 0.02 300 force
function ek:game/mod_roll
function ek:beat/start
