scoreboard players set #et ek 0
execute if score #energy ek matches ..99 run scoreboard players add #energy ek 1
function ek:game/energy_bar
