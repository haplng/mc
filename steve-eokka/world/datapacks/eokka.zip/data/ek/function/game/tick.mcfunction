execute as @a[limit=1] at @s run function ek:aim/tick
function ek:game/energy
execute if score #drop ek matches 1 run function ek:drop/tick
function ek:box/tick
execute if score #gu ek matches 1.. run scoreboard players remove #gu ek 1
execute if score #stage ek matches 7 run function ek:s7/tick
execute if score #intr ek matches 1.. run function ek:ev/tick
execute if score #intr ek matches 0 if score #steve ek matches 1 run function ek:beat/tick
execute if score #state ek matches 1 if score #intr ek matches 0 if score #steve ek matches 1 unless entity @e[tag=ek.steve] run function ek:steve/lost
execute if score #snap ek matches 1 as @e[tag=ek.steve,limit=1] at @s run function ek:steve/snap
execute if score #bubt ek matches 1.. run function ek:steve/bubble_tick
execute if score #intr ek matches 0 run function ek:game/calm
function ek:ui/tick
execute if score #state ek matches 1 if score #intr ek matches 0 if score #mental ek matches ..0 run function ek:game/win
