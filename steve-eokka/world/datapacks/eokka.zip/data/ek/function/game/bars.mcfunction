execute store result bossbar ek:mental value run scoreboard players get #mental ek
bossbar set ek:mental name ["",{"text":"스티브 멘탈 ","color":"white"},{"score":{"name":"#mental","objective":"ek"},"color":"white"},{"text":"/","color":"gray"},{"score":{"name":"#mmax","objective":"ek"},"color":"gray"}]
scoreboard players operation #pct ek = #mental ek
scoreboard players operation #pct ek *= #c100 ek
scoreboard players operation #pct ek /= #mmax ek
execute if score #pct ek matches 60.. run bossbar set ek:mental color green
execute if score #pct ek matches 30..59 run bossbar set ek:mental color yellow
execute if score #pct ek matches ..29 run bossbar set ek:mental color red
execute store result bossbar ek:prog value run scoreboard players get #prog ek
bossbar set ek:prog name ["",{"score":{"name":"#day","objective":"ek"},"color":"white"},{"text":"일차 · ","color":"white"},{"nbt":"stage","storage":"ek:s","color":"aqua"},{"text":" · 진행 ","color":"gray"},{"score":{"name":"#prog","objective":"ek"},"color":"white"},{"text":"%","color":"gray"}]
