function ek:game/cleanup
fill -14 58 -14 14 86 14 minecraft:air
execute if score #stage ek matches 1 run function ek:s1/build
execute if score #stage ek matches 2 run function ek:s2/build
execute if score #stage ek matches 3 run function ek:s3/build
execute if score #stage ek matches 4 run function ek:s4/build
execute if score #stage ek matches 5 run function ek:s5/build
execute if score #stage ek matches 6 run function ek:s6/build
execute if score #stage ek matches 7 run function ek:s7/build
execute if score #stage ek matches 1 run function ek:s1/init
execute if score #stage ek matches 2 run function ek:s2/init
execute if score #stage ek matches 3 run function ek:s3/init
execute if score #stage ek matches 4 run function ek:s4/init
execute if score #stage ek matches 5 run function ek:s5/init
execute if score #stage ek matches 6 run function ek:s6/init
execute if score #stage ek matches 7 run function ek:s7/init
summon marker 0 60 0 {Tags:["ek.tgt"]}
scoreboard players set #beat ek 0
scoreboard players set #intr ek 0
scoreboard players set #snap ek 1
scoreboard players set #phase ek 0
time set 6000
weather clear
execute if score #stage ek matches 1 run function ek:s1/spawn
execute if score #stage ek matches 2 run function ek:s2/spawn
execute if score #stage ek matches 3 run function ek:s3/spawn
execute if score #stage ek matches 4 run function ek:s4/spawn
execute if score #stage ek matches 5 run function ek:s5/spawn
execute if score #stage ek matches 6 run function ek:s6/spawn
execute if score #stage ek matches 7 run function ek:s7/spawn
