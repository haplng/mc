scoreboard players operation #mental ek += #heal ek
execute if score #mental ek > #mmax ek run scoreboard players operation #mental ek = #mmax ek
execute store result storage ek:s tmp.n int 1 run scoreboard players get #heal ek
function ek:fx/heal_popup with storage ek:s tmp
function ek:game/bars
