scoreboard players set #ho_diapick ek 1
scoreboard players set #heal ek 4
function ek:game/heal
