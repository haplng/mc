scoreboard players set #diff ek 1
scoreboard players set #mmax ek 320
scoreboard players set #recint ek 120
scoreboard players set #learn ek 2
scoreboard players set #eint ek 12
scoreboard players set #dscale ek 100
function ek:game/begin
