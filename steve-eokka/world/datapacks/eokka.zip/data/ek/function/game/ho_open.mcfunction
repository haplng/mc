scoreboard players set #ho_open ek 1
scoreboard players set #heal ek 6
function ek:game/heal
