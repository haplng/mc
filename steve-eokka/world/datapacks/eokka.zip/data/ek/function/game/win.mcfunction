scoreboard players set #state ek 3
scoreboard players set #res ek 1
scoreboard players set #rt ek 0
scoreboard players add #wins ek 1
scoreboard players add #runs ek 1
function ek:lobby/hidebars
clear @a
kill @e[tag=ek.bub]
function ek:drop/cancel
function ek:box/clear
