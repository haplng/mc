scoreboard players add #et ek 1
execute if score #mod ek matches 1 run function ek:game/energy_x
execute if score #et ek >= #eint ek run function ek:game/energy1
