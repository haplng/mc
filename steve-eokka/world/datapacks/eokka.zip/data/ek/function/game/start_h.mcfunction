scoreboard players set #diff ek 2
scoreboard players set #mmax ek 400
scoreboard players set #recint ek 100
scoreboard players set #learn ek 1
scoreboard players set #eint ek 12
scoreboard players set #dscale ek 90
function ek:game/begin
