execute if score #gu ek matches 1.. run return run function ek:lobby/enter
scoreboard players set #gu ek 60
title @a actionbar {"text":"한 번 더 우클릭하면 포기하고 로비로 돌아가.","color":"red"}
scoreboard players set #abt ek 60
