scoreboard players set #rec ek 0
execute if score #mental ek < #mmax ek run scoreboard players add #mental ek 1
function ek:game/bars
