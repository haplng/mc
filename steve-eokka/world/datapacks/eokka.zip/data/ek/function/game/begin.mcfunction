kill @e[tag=ek.ui]
scoreboard players set #state ek 1
scoreboard players set #stage ek 1
scoreboard players set #day ek 1
scoreboard players set #deaths ek 0
scoreboard players set #ncards ek 0
scoreboard players set #total ek 0
scoreboard players set #combo ek 0
scoreboard players set #combo_t ek 0
scoreboard players set #maxcombo ek 0
scoreboard players set #tilt ek 0
scoreboard players set #rec ek 0
scoreboard players set #et ek 0
scoreboard players set #intr ek 0
scoreboard players set #abt ek 0
scoreboard players set #gu ek 0
scoreboard players set #bubt ek 0
scoreboard players set #drop ek 0
scoreboard players set #dropt ek 0
scoreboard players set #dcard ek 0
scoreboard players set #dcost ek 0
scoreboard players set #idle ek 0
scoreboard players set #idlek ek 0
scoreboard players set #wild ek 0
scoreboard players set #lucky ek 0
scoreboard players set #box ek 0
scoreboard players set #boxlife ek 0
scoreboard players set #npt ek 0
scoreboard players set #cur ek 0
scoreboard players set #lock ek 0
scoreboard players set #near ek 0
scoreboard players set #moving ek 0
scoreboard players set #tier ek 0
scoreboard players set #nthrow ek 0
scoreboard players set #nhit ek 0
scoreboard players set #pace ek 0
scoreboard players set #aimed ek 0
scoreboard players set #am ek 0
scoreboard players set #amprev ek 0
scoreboard players set #idlecd ek 0
scoreboard players set #boxt ek 0
scoreboard players set #boxhint ek 0
scoreboard players set #mod ek 0
scoreboard players set #ex ek 0
scoreboard players set #halt ek 0
scoreboard players set #dash ek 0
scoreboard players set #ddodge ek 0
scoreboard players set #noticed ek 0
scoreboard players set #aimx ek 100
scoreboard players set #idlecd ek 200
scoreboard players set #boxt ek 400
data modify storage ek:s ab set value {star:"",combo:""}
scoreboard players set #u_creeper ek 0
scoreboard players set #u_night ek 0
scoreboard players set #u_arrow ek 0
scoreboard players set #u_pick ek 0
scoreboard players set #u_thunder ek 0
scoreboard players set #u_gravel ek 0
scoreboard players set #u_zombies ek 0
scoreboard players set #u_lost ek 0
scoreboard players set #u_lava ek 0
scoreboard players set #u_floor ek 0
scoreboard players set #u_flint ek 0
scoreboard players set #u_barter ek 0
scoreboard players set #u_rods ek 0
scoreboard players set #u_obsi ek 0
scoreboard players set #u_ghast ek 0
scoreboard players set #u_portal ek 0
scoreboard players set #u_piglin ek 0
scoreboard players set #u_eye ek 0
scoreboard players set #u_silverfish ek 0
scoreboard players set #u_enderman ek 0
scoreboard players set #u_void ek 0
scoreboard players set #u_bed ek 0
scoreboard players set #u_heal ek 0
scoreboard players set #u_crystal ek 0
scoreboard players set #u_anvil ek 0
scoreboard players set #l_creeper ek 0
scoreboard players set #l_night ek 0
scoreboard players set #l_arrow ek 0
scoreboard players set #l_pick ek 0
scoreboard players set #l_thunder ek 0
scoreboard players set #l_gravel ek 0
scoreboard players set #l_zombies ek 0
scoreboard players set #l_lost ek 0
scoreboard players set #l_lava ek 0
scoreboard players set #l_floor ek 0
scoreboard players set #l_flint ek 0
scoreboard players set #l_barter ek 0
scoreboard players set #l_rods ek 0
scoreboard players set #l_obsi ek 0
scoreboard players set #l_ghast ek 0
scoreboard players set #l_portal ek 0
scoreboard players set #l_piglin ek 0
scoreboard players set #l_eye ek 0
scoreboard players set #l_silverfish ek 0
scoreboard players set #l_enderman ek 0
scoreboard players set #l_void ek 0
scoreboard players set #l_bed ek 0
scoreboard players set #l_heal ek 0
scoreboard players set #l_crystal ek 0
scoreboard players set #l_anvil ek 0
scoreboard players set #dc_creeper ek 0
scoreboard players set #dc_fall ek 0
scoreboard players set #dc_lightning ek 0
scoreboard players set #dc_suffocate ek 0
scoreboard players set #dc_zombie ek 0
scoreboard players set #dc_lava ek 0
scoreboard players set #dc_piglin ek 0
scoreboard players set #dc_silverfish ek 0
scoreboard players set #dc_enderman ek 0
scoreboard players set #dc_void ek 0
scoreboard players set #dc_bed ek 0
scoreboard players set #dc_anvil ek 0
scoreboard players set #dc_unknown ek 0
scoreboard players set #ho_iron ek 0
scoreboard players set #ho_dia ek 0
scoreboard players set #ho_diapick ek 0
scoreboard players set #ho_lit ek 0
scoreboard players set #ho_room ek 0
scoreboard players set #ho_open ek 0
scoreboard players operation #mental ek = #mmax ek
scoreboard players set #energy ek 60
scoreboard players set #armor ek 0
execute store result bossbar ek:mental max run scoreboard players get #mmax ek
bossbar set ek:prog players @a
bossbar set ek:mental players @a
bossbar set ek:energy players @a
title @a times 5 50 15
title @a subtitle {"text":"드래곤이 잡히기 전에 스티브를 접게 만들어라","color":"white"}
title @a title {"text":"억까 시작","color":"gold","bold":true}
tellraw @a {"text":"  카드를 들고 우클릭하면 억까가 들어가. ◎ 카드는 바라보는 곳에 떨어지니까 스티브를 잘 겨냥해.","color":"gray"}
tellraw @a {"text":"  화면 아래에 ★가 뜰 때 쓰면 훨씬 세게 들어가.","color":"gray"}
function ek:game/energy_bar
function ek:game/stage_begin
