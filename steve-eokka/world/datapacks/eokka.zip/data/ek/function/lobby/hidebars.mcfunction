bossbar set ek:prog players
bossbar set ek:mental players
bossbar set ek:energy players
