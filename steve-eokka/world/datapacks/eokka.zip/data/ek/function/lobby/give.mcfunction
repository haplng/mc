clear @s
function ek:lobby/put
