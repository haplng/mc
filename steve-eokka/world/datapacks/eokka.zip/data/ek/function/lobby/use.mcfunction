execute if score #sl ek matches 0 run return run function ek:game/start_n
execute if score #sl ek matches 1 run return run function ek:game/start_e
execute if score #sl ek matches 2 if score #wins ek matches 1.. run return run function ek:game/start_h
execute if score #sl ek matches 2 run return run tellraw @s {"text":"고인물 스티브는 한 번 이기면 열려.","color":"gray"}
execute if score #sl ek matches 4 run function ek:lobby/howto
