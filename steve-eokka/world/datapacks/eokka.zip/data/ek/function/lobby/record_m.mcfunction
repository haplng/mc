$data modify entity @e[tag=ek.rec,limit=1] text set value {text:"",extra:[{text:"1번 칸 들고 우클릭: 시작\n",color:"yellow"},{text:"승리 $(wins)회 · 플레이 $(runs)회 · 최고 등급: $(best)",color:"gray"}]}
