execute store result storage ek:s r.wins int 1 run scoreboard players get #wins ek
execute store result storage ek:s r.runs int 1 run scoreboard players get #runs ek
execute if score #best ek matches 0 run data modify storage ek:s r.best set value "성자"
execute if score #best ek matches 1 run data modify storage ek:s r.best set value "천사"
execute if score #best ek matches 2 run data modify storage ek:s r.best set value "평범한 불운"
execute if score #best ek matches 3 run data modify storage ek:s r.best set value "장난꾸러기 운명"
execute if score #best ek matches 4 run data modify storage ek:s r.best set value "억까꾼"
execute if score #best ek matches 5 run data modify storage ek:s r.best set value "악질"
execute if score #best ek matches 6 run data modify storage ek:s r.best set value "악마"
execute if score #runs ek matches 1.. run function ek:lobby/record_m with storage ek:s r
