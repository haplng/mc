scoreboard players set #state ek 0
scoreboard players set #intr ek 0
function ek:game/cleanup
kill @e[tag=ek.ui]
fill -14 58 -14 14 86 14 minecraft:air
function ek:s1/build
time set 6000
weather clear
scoreboard players set #armor ek 0
scoreboard players set #redo ek 0
function ek:s1/spawn
summon text_display 0.5 79.5 0.5 {Tags:["ek.ui"],billboard:"center",line_width:400,background:0,shadow:1b,view_range:4f,brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[8f,8f,8f]},text:{"text":"스티브 억까 시뮬레이터","color":"gold","bold":true}}
summon text_display 0.5 75.5 0.5 {Tags:["ek.ui"],billboard:"center",line_width:400,background:0,shadow:1b,view_range:4f,brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[3f,3f,3f]},text:{"text":"드래곤 잡으러 가는 스티브를 억까해서 접게 만들어라","color":"white"}}
summon text_display 0.5 73 0.5 {Tags:["ek.ui","ek.rec"],billboard:"center",line_width:400,background:0,shadow:1b,view_range:4f,brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[3f,3f,3f]},text:{"text":"1번 칸 들고 우클릭: 시작","color":"yellow"}}
function ek:lobby/record
function ek:lobby/hidebars
execute as @a run function ek:lobby/give
