execute unless score #built ek matches 1 run tp @a 0.5 57 26.5
execute unless score #built ek matches 1 run return 0
execute unless score #ver ek matches 2 if entity @a run function ek:setup/upgrade
execute as @a[tag=!ek.in] run function ek:player/init
execute as @a[tag=!ek.v2] run function ek:player/init2
scoreboard players remove @a[scores={ek.cd=1..}] ek.cd 1
execute as @a[scores={ek.use=1..}] run function ek:player/use
execute as @a run function ek:player/tick
execute as @e[tag=ek.tmp] run function ek:fx/tmp
kill @e[type=minecraft:item]
scoreboard players add #fixt ek 1
execute if score #fixt ek matches 20.. run function ek:ui/fix
execute unless score #state ek matches 1 run tp @e[tag=ek.curv] 0.5 300 0.5
execute if score #state ek matches 0 run function ek:lobby/tick
execute if score #state ek matches 1 run function ek:game/tick
execute if score #state ek matches 3 run function ek:result/tick
