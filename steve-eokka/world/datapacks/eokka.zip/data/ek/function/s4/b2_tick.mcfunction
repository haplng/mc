execute if score #at ek matches 24 run setblock 9 62 2 minecraft:obsidian
execute if score #at ek matches 24 run execute as @a at @s run playsound minecraft:block.stone.place master @s ~ ~ ~ 1 0.8
execute if score #at ek matches 24 run swing @e[tag=ek.steve,limit=1] mainhand
execute if score #at ek matches 48 run setblock 10 62 2 minecraft:obsidian
execute if score #at ek matches 48 run execute as @a at @s run playsound minecraft:block.stone.place master @s ~ ~ ~ 1 0.8
execute if score #at ek matches 48 run swing @e[tag=ek.steve,limit=1] mainhand
execute if score #at ek matches 72 run setblock 8 63 2 minecraft:obsidian
execute if score #at ek matches 72 run execute as @a at @s run playsound minecraft:block.stone.place master @s ~ ~ ~ 1 0.8
execute if score #at ek matches 72 run swing @e[tag=ek.steve,limit=1] mainhand
execute if score #at ek matches 96 run setblock 11 63 2 minecraft:obsidian
execute if score #at ek matches 96 run execute as @a at @s run playsound minecraft:block.stone.place master @s ~ ~ ~ 1 0.8
execute if score #at ek matches 96 run swing @e[tag=ek.steve,limit=1] mainhand
execute if score #at ek matches 120 run setblock 8 64 2 minecraft:obsidian
execute if score #at ek matches 120 run execute as @a at @s run playsound minecraft:block.stone.place master @s ~ ~ ~ 1 0.8
execute if score #at ek matches 120 run swing @e[tag=ek.steve,limit=1] mainhand
execute if score #at ek matches 144 run setblock 11 64 2 minecraft:obsidian
execute if score #at ek matches 144 run execute as @a at @s run playsound minecraft:block.stone.place master @s ~ ~ ~ 1 0.8
execute if score #at ek matches 144 run swing @e[tag=ek.steve,limit=1] mainhand
execute if score #at ek matches 168 run setblock 8 65 2 minecraft:obsidian
execute if score #at ek matches 168 run execute as @a at @s run playsound minecraft:block.stone.place master @s ~ ~ ~ 1 0.8
execute if score #at ek matches 168 run swing @e[tag=ek.steve,limit=1] mainhand
execute if score #at ek matches 192 run setblock 11 65 2 minecraft:obsidian
execute if score #at ek matches 192 run execute as @a at @s run playsound minecraft:block.stone.place master @s ~ ~ ~ 1 0.8
execute if score #at ek matches 192 run swing @e[tag=ek.steve,limit=1] mainhand
execute if score #at ek matches 216 run setblock 9 66 2 minecraft:obsidian
execute if score #at ek matches 216 run execute as @a at @s run playsound minecraft:block.stone.place master @s ~ ~ ~ 1 0.8
execute if score #at ek matches 216 run swing @e[tag=ek.steve,limit=1] mainhand
execute if score #at ek matches 240 run setblock 10 66 2 minecraft:obsidian
execute if score #at ek matches 240 run execute as @a at @s run playsound minecraft:block.stone.place master @s ~ ~ ~ 1 0.8
execute if score #at ek matches 240 run swing @e[tag=ek.steve,limit=1] mainhand
