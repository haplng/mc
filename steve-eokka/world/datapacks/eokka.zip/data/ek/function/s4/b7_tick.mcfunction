execute if score #at ek matches 12 run execute as @a at @s run playsound minecraft:block.portal.travel master @s ~ ~ ~ 0.4 1.2
execute if score #at ek matches 67 run execute at @e[tag=ek.steve,limit=1] run particle minecraft:portal ~ ~1 ~ 0.3 0.6 0.3 0.5 60 force
