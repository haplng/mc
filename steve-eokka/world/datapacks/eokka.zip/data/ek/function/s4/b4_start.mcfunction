data modify storage ek:s bstatus set value "조합대로 가는 중"
data modify storage ek:s status set value "조합대로 가는 중"
scoreboard players set #prog ek 50
tp @e[tag=ek.tgt,limit=1] -2.5 62 -3.5
scoreboard players set #tx ek -250
scoreboard players set #tz ek -350
