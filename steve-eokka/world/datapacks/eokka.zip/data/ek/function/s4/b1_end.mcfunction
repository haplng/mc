item replace entity @e[tag=ek.steve,limit=1] weapon.mainhand with minecraft:obsidian
