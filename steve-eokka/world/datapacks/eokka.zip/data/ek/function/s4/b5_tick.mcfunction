execute if score #at ek matches 24 run setblock 3 62 -2 minecraft:air destroy
execute if score #at ek matches 48 run setblock 4 62 -2 minecraft:air destroy
execute if score #at ek matches 72 run setblock 5 62 -2 minecraft:air destroy
execute if score #at ek matches 91 run execute as @a at @s run playsound minecraft:entity.generic.eat master @s ~ ~ ~ 1 1
execute if score #at ek matches 91 run execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"빵 +3",c:"white",s:"3"}
execute if score #m8 ek matches 0 run swing @e[tag=ek.steve,limit=1] mainhand
