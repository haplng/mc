data modify storage ek:s bstatus set value "포탈로 가는 중"
data modify storage ek:s status set value "포탈로 가는 중"
scoreboard players set #prog ek 75
tp @e[tag=ek.tgt,limit=1] 9.5 62 4.5
scoreboard players set #tx ek 950
scoreboard players set #tz ek 450
