data modify storage ek:s bstatus set value "부싯돌 나올 때까지 자갈 캐는 중"
data modify storage ek:s status set value "부싯돌 나올 때까지 자갈 캐는 중"
function ek:beat/flags_clear
scoreboard players set #f_busy ek 1
scoreboard players set #f_gravel ek 1
scoreboard players set #alen ek 53
execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing -2.5 61.5 11.5
item replace entity @e[tag=ek.steve,limit=1] weapon.mainhand with minecraft:diamond_pickaxe
