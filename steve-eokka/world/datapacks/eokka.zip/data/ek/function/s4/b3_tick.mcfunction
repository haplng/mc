execute if score #at ek matches 48 run function ek:s4/dig
execute if score #m6 ek matches 0 run swing @e[tag=ek.steve,limit=1] mainhand
execute if score #m6 ek matches 0 run execute as @a at @s run playsound minecraft:block.gravel.break master @s ~ ~ ~ 0.5 1
