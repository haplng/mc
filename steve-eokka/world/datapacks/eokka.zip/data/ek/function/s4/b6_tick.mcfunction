execute if score #at ek matches 19 run swing @e[tag=ek.steve,limit=1] mainhand
execute if score #at ek matches 19 run execute as @a at @s run playsound minecraft:item.flintandsteel.use master @s ~ ~ ~ 1 1
execute if score #at ek matches 19 run fill 9 63 2 10 65 2 minecraft:nether_portal[axis=x]
execute if score #at ek matches 19 run execute as @a at @s run playsound minecraft:block.portal.trigger master @s ~ ~ ~ 0.5 1
execute if score #at ek matches 38 run function ek:steve/say {t:"네더 가즈아"}
execute if score #at ek matches 38 run execute unless score #ho_lit ek matches 1 run function ek:game/ho_lit
