data modify storage ek:s bstatus set value "상자에서 흑요석 꺼내는 중"
data modify storage ek:s status set value "상자에서 흑요석 꺼내는 중"
function ek:beat/flags_clear
scoreboard players set #f_busy ek 1
scoreboard players set #alen ek 72
execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing -0.5 62.5 -4.5
execute as @a at @s run playsound minecraft:block.chest.open master @s ~ ~ ~ 1 1
