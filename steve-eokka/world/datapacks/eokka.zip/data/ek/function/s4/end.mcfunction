execute if score #beat ek matches 1 run return run function ek:s4/b1_end
execute if score #beat ek matches 2 run return run function ek:s4/b2_end
execute if score #beat ek matches 4 run return run function ek:s4/b4_end
