execute if score #beat ek matches 0 run return run function ek:s4/b0_act
execute if score #beat ek matches 1 run return run function ek:s4/b1_act
execute if score #beat ek matches 2 run return run function ek:s4/b2_act
execute if score #beat ek matches 3 run return run function ek:s4/b3_act
execute if score #beat ek matches 4 run return run function ek:s4/b4_act
execute if score #beat ek matches 5 run return run function ek:s4/b5_act
execute if score #beat ek matches 6 run return run function ek:s4/b6_act
execute if score #beat ek matches 7 run return run function ek:s4/b7_act
