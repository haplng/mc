data modify storage ek:s bstatus set value "집 도착"
data modify storage ek:s status set value "집 도착"
scoreboard players set #prog ek 0
function ek:beat/arrive
