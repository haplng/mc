item replace entity @e[tag=ek.steve,limit=1] weapon.mainhand with minecraft:flint_and_steel
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"부싯돌과 부시",c:"aqua",s:"3"}
