data modify storage ek:s bstatus set value "포탈 타는 중"
data modify storage ek:s status set value "포탈 타는 중"
function ek:beat/flags_clear
scoreboard players set #alen ek 72
