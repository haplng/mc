scoreboard players set #blen ek 8
scoreboard players set #armor ek 2
execute store result score #flint ek run random value 1..2
scoreboard players set #gk ek 0
