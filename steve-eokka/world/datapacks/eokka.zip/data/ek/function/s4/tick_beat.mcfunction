execute if score #beat ek matches 0 run return run function ek:s4/b0_tick
execute if score #beat ek matches 2 run return run function ek:s4/b2_tick
execute if score #beat ek matches 3 run return run function ek:s4/b3_tick
execute if score #beat ek matches 4 run return run function ek:s4/b4_tick
execute if score #beat ek matches 5 run return run function ek:s4/b5_tick
execute if score #beat ek matches 6 run return run function ek:s4/b6_tick
execute if score #beat ek matches 7 run return run function ek:s4/b7_tick
