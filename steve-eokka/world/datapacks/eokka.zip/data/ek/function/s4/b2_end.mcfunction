function ek:steve/say {t:"틀 완성. 아 부싯돌이 없네"}
