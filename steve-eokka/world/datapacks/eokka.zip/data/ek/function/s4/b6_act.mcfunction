data modify storage ek:s bstatus set value "포탈 점화!"
data modify storage ek:s status set value "포탈 점화!"
function ek:beat/flags_clear
scoreboard players set #f_frame ek 1
scoreboard players set #alen ek 96
execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing 10 64 2.5
item replace entity @e[tag=ek.steve,limit=1] weapon.mainhand with minecraft:flint_and_steel
