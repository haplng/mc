execute if score #beat ek matches 0 run return run function ek:s4/b0_start
execute if score #beat ek matches 1 run return run function ek:s4/b1_start
execute if score #beat ek matches 2 run return run function ek:s4/b2_start
execute if score #beat ek matches 3 run return run function ek:s4/b3_start
execute if score #beat ek matches 4 run return run function ek:s4/b4_start
execute if score #beat ek matches 5 run return run function ek:s4/b5_start
execute if score #beat ek matches 6 run return run function ek:s4/b6_start
execute if score #beat ek matches 7 run return run function ek:s4/b7_start
