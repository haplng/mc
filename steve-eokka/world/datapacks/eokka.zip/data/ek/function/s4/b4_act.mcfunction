data modify storage ek:s bstatus set value "부싯돌과 부시 만드는 중"
data modify storage ek:s status set value "부싯돌과 부시 만드는 중"
function ek:beat/flags_clear
scoreboard players set #f_busy ek 1
scoreboard players set #alen ek 60
execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing -2.5 62.5 -4.5
