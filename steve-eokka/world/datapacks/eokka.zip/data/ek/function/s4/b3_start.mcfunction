data modify storage ek:s bstatus set value "자갈 찾으러 가는 중"
data modify storage ek:s status set value "자갈 찾으러 가는 중"
scoreboard players set #prog ek 37
tp @e[tag=ek.tgt,limit=1] -2.5 62 10.5
scoreboard players set #tx ek -250
scoreboard players set #tz ek 1050
