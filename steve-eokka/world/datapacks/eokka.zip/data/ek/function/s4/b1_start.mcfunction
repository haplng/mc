data modify storage ek:s bstatus set value "상자로 가는 중"
data modify storage ek:s status set value "상자로 가는 중"
scoreboard players set #prog ek 12
tp @e[tag=ek.tgt,limit=1] -0.5 62 -3.5
scoreboard players set #tx ek -50
scoreboard players set #tz ek -350
