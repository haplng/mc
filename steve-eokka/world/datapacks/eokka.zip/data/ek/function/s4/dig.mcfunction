execute if score #gk ek matches 0 run setblock -4 61 11 minecraft:air destroy
execute if score #gk ek matches 1 run setblock -3 61 11 minecraft:air destroy
execute if score #gk ek matches 2 run setblock -2 61 11 minecraft:air destroy
execute if score #gk ek matches 3 run setblock -4 61 12 minecraft:air destroy
execute if score #gk ek matches 4 run setblock -3 61 12 minecraft:air destroy
execute if score #gk ek matches 5 run setblock -2 61 12 minecraft:air destroy
scoreboard players add #gk ek 1
execute if score #gk ek matches 6 run fill -4 61 11 -2 61 12 minecraft:gravel
execute if score #gk ek matches 6 run execute as @a at @s run playsound minecraft:block.gravel.break master @s ~ ~ ~ 1 0.7
execute if score #gk ek matches 6 run scoreboard players set #gk ek 0
execute if score #flint ek matches 1.. run return run function ek:s4/flint_miss
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"부싯돌!",c:"green",s:"3"}
execute as @a at @s run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 1 1
