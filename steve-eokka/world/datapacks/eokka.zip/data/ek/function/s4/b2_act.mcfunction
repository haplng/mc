data modify storage ek:s bstatus set value "포탈 틀 쌓는 중"
data modify storage ek:s status set value "포탈 틀 쌓는 중"
function ek:beat/flags_clear
scoreboard players set #f_busy ek 1
scoreboard players set #f_frame ek 1
scoreboard players set #alen ek 250
execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing 10 64 2.5
item replace entity @e[tag=ek.steve,limit=1] weapon.mainhand with minecraft:obsidian
