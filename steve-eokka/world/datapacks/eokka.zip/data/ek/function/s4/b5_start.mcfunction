data modify storage ek:s bstatus set value "밭으로 가는 중"
data modify storage ek:s status set value "밭으로 가는 중"
scoreboard players set #prog ek 62
tp @e[tag=ek.tgt,limit=1] 4.5 62 -0.5
scoreboard players set #tx ek 450
scoreboard players set #tz ek -50
