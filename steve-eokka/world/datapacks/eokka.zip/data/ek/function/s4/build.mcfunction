fill -14 58 -14 14 59 14 minecraft:stone
fill -14 60 -14 14 60 -14 minecraft:dirt
fill -14 60 -13 7 60 -13 minecraft:dirt
fill 11 60 -13 14 60 -13 minecraft:dirt
fill -14 60 -12 5 60 -11 minecraft:dirt
fill 13 60 -12 14 60 -11 minecraft:dirt
fill -14 60 -10 4 60 5 minecraft:dirt
fill 14 60 -10 14 60 14 minecraft:dirt
fill 5 60 -7 5 60 14 minecraft:dirt
fill 13 60 -7 13 60 14 minecraft:dirt
fill 6 60 -5 7 60 14 minecraft:dirt
fill 11 60 -5 12 60 14 minecraft:dirt
fill 8 60 -4 10 60 14 minecraft:dirt
fill -14 60 6 -12 60 7 minecraft:dirt
fill -6 60 6 4 60 7 minecraft:dirt
fill -14 60 8 -13 60 14 minecraft:dirt
fill -5 60 8 4 60 14 minecraft:dirt
fill -12 60 9 -12 60 14 minecraft:dirt
fill -6 60 9 -6 60 14 minecraft:dirt
fill -11 60 11 -7 60 14 minecraft:dirt
fill 8 60 -13 10 61 -5 minecraft:stone
fill 6 60 -12 7 61 -6 minecraft:stone
fill 11 60 -12 12 61 -6 minecraft:stone
fill 5 60 -10 5 61 -8 minecraft:stone
fill 13 60 -10 13 61 -8 minecraft:stone
fill 3 61 -4 5 61 -4 minecraft:farmland[moisture=7]
fill 3 61 -3 3 61 -2 minecraft:farmland[moisture=7]
fill 5 61 -3 5 61 -2 minecraft:farmland[moisture=7]
setblock 4 61 -2 minecraft:farmland[moisture=7]
fill -14 61 -14 14 61 -14 minecraft:grass_block
fill -14 61 -13 7 61 -13 minecraft:grass_block
fill 11 61 -13 14 61 -13 minecraft:grass_block
fill -14 61 -12 5 61 -11 minecraft:grass_block
fill 13 61 -12 14 61 -11 minecraft:grass_block
fill -14 61 -10 4 61 -5 minecraft:grass_block
fill 14 61 -10 14 61 14 minecraft:grass_block
fill 5 61 -7 5 61 -5 minecraft:grass_block
fill 13 61 -7 13 61 14 minecraft:grass_block
fill 6 61 -5 7 61 14 minecraft:grass_block
fill 11 61 -5 12 61 14 minecraft:grass_block
fill -14 61 -4 2 61 4 minecraft:grass_block
fill 8 61 -4 10 61 14 minecraft:grass_block
fill 3 61 -1 5 61 14 minecraft:grass_block
fill -14 61 5 -12 61 5 minecraft:grass_block
fill -6 61 5 2 61 5 minecraft:grass_block
fill -14 61 6 -13 61 6 minecraft:grass_block
fill -5 61 6 2 61 6 minecraft:grass_block
fill -14 61 7 -14 61 14 minecraft:grass_block
fill -4 61 7 2 61 10 minecraft:grass_block
fill -13 61 10 -13 61 14 minecraft:grass_block
fill -5 61 10 -5 61 14 minecraft:grass_block
fill -12 61 11 -12 61 14 minecraft:grass_block
fill -6 61 11 -6 61 14 minecraft:grass_block
fill -1 61 11 2 61 14 minecraft:grass_block
fill -11 61 12 -7 61 14 minecraft:grass_block
fill -4 61 13 -2 61 14 minecraft:grass_block
setblock -3 62 -5 minecraft:crafting_table
fill 8 62 -13 10 62 -12 minecraft:grass_block
fill 6 62 -12 7 62 -12 minecraft:grass_block
fill 11 62 -12 12 62 -12 minecraft:grass_block
fill 6 62 -11 6 62 -6 minecraft:grass_block
fill 12 62 -11 12 62 -6 minecraft:grass_block
fill 5 62 -10 5 62 -8 minecraft:grass_block
fill 13 62 -10 13 62 -8 minecraft:grass_block
fill 7 62 -6 11 62 -6 minecraft:grass_block
fill 8 62 -5 10 62 -5 minecraft:grass_block
fill -3 62 -12 -3 65 -12 minecraft:oak_log
fill -11 62 -10 -11 66 -10 minecraft:oak_log
fill 11 62 7 11 66 7 minecraft:oak_log
fill 2 62 9 2 65 9 minecraft:oak_log
fill -4 62 -6 0 63 -6 minecraft:oak_planks
fill 7 62 -11 11 62 -7 minecraft:stone
fill 7 63 -11 11 63 -11 minecraft:grass_block
fill 7 63 -10 7 63 -7 minecraft:grass_block
fill 11 63 -10 11 63 -7 minecraft:grass_block
fill 8 63 -7 10 63 -7 minecraft:grass_block
fill 8 63 -10 10 63 -8 minecraft:stone
fill 8 64 -10 10 64 -10 minecraft:grass_block
fill 8 64 -9 8 64 -8 minecraft:grass_block
fill 10 64 -9 10 64 -8 minecraft:grass_block
setblock 9 64 -8 minecraft:grass_block
fill -4 64 -14 -2 65 -13 minecraft:oak_leaves[persistent=true]
fill -5 64 -13 -5 65 -11 minecraft:oak_leaves[persistent=true]
fill -1 64 -13 -1 65 -11 minecraft:oak_leaves[persistent=true]
fill -4 64 -12 -4 65 -10 minecraft:oak_leaves[persistent=true]
fill -2 64 -12 -2 65 -10 minecraft:oak_leaves[persistent=true]
fill -3 64 -11 -3 65 -10 minecraft:oak_leaves[persistent=true]
fill 1 64 7 3 65 8 minecraft:oak_leaves[persistent=true]
fill 0 64 8 0 65 10 minecraft:oak_leaves[persistent=true]
fill 4 64 8 4 65 10 minecraft:oak_leaves[persistent=true]
fill 1 64 9 1 65 11 minecraft:oak_leaves[persistent=true]
fill 3 64 9 3 65 11 minecraft:oak_leaves[persistent=true]
fill 2 64 10 2 65 11 minecraft:oak_leaves[persistent=true]
setblock 9 64 -9 minecraft:stone
setblock 9 65 -9 minecraft:grass_block
fill -12 65 -12 -10 66 -11 minecraft:oak_leaves[persistent=true]
fill -13 65 -11 -13 66 -9 minecraft:oak_leaves[persistent=true]
fill -9 65 -11 -9 66 -9 minecraft:oak_leaves[persistent=true]
fill -12 65 -10 -12 66 -8 minecraft:oak_leaves[persistent=true]
fill -10 65 -10 -10 66 -8 minecraft:oak_leaves[persistent=true]
fill -11 65 -9 -11 66 -8 minecraft:oak_leaves[persistent=true]
fill 10 65 5 12 66 6 minecraft:oak_leaves[persistent=true]
fill 9 65 6 9 66 8 minecraft:oak_leaves[persistent=true]
fill 13 65 6 13 66 8 minecraft:oak_leaves[persistent=true]
fill 10 65 7 10 66 9 minecraft:oak_leaves[persistent=true]
fill 12 65 7 12 66 9 minecraft:oak_leaves[persistent=true]
fill 11 65 8 11 66 9 minecraft:oak_leaves[persistent=true]
fill -4 66 -13 -2 66 -11 minecraft:oak_leaves[persistent=true]
fill 1 66 8 3 66 10 minecraft:oak_leaves[persistent=true]
fill -3 67 -13 -3 67 -11 minecraft:oak_leaves[persistent=true]
setblock -4 67 -12 minecraft:oak_leaves[persistent=true]
setblock -2 67 -12 minecraft:oak_leaves[persistent=true]
fill -12 67 -11 -10 67 -9 minecraft:oak_leaves[persistent=true]
fill 10 67 6 12 67 8 minecraft:oak_leaves[persistent=true]
fill 2 67 8 2 67 10 minecraft:oak_leaves[persistent=true]
setblock 1 67 9 minecraft:oak_leaves[persistent=true]
setblock 3 67 9 minecraft:oak_leaves[persistent=true]
fill -11 68 -11 -11 68 -9 minecraft:oak_leaves[persistent=true]
setblock -12 68 -10 minecraft:oak_leaves[persistent=true]
setblock -10 68 -10 minecraft:oak_leaves[persistent=true]
fill 11 68 6 11 68 8 minecraft:oak_leaves[persistent=true]
setblock 10 68 7 minecraft:oak_leaves[persistent=true]
setblock 12 68 7 minecraft:oak_leaves[persistent=true]
fill -11 60 6 -7 60 10 minecraft:sand
setblock -12 60 8 minecraft:sand
setblock -6 60 8 minecraft:sand
fill -4 61 11 -2 61 12 minecraft:gravel
fill -11 61 5 -7 61 5 minecraft:sand
fill -12 61 6 -12 61 7 minecraft:sand
fill -6 61 6 -6 61 7 minecraft:sand
fill -13 61 7 -13 61 9 minecraft:sand
fill -5 61 7 -5 61 9 minecraft:sand
fill -12 61 9 -12 61 10 minecraft:sand
fill -6 61 9 -6 61 10 minecraft:sand
fill -11 61 11 -7 61 11 minecraft:sand
setblock -1 62 -5 minecraft:chest[facing=south]
setblock -8 62 -10 minecraft:dandelion
setblock 9 62 -3 minecraft:dandelion
setblock -8 62 4 minecraft:dandelion
setblock -2 62 4 minecraft:dandelion
setblock -5 62 6 minecraft:dandelion
setblock 0 62 6 minecraft:dandelion
setblock -4 62 8 minecraft:dandelion
setblock -2 62 8 minecraft:dandelion
setblock -12 62 13 minecraft:dandelion
setblock 6 62 13 minecraft:dandelion
setblock -2 62 -5 minecraft:furnace[facing=south]
setblock 4 62 -14 minecraft:poppy
setblock -11 62 -13 minecraft:poppy
setblock -9 62 -13 minecraft:poppy
setblock 3 62 -11 minecraft:poppy
setblock -14 62 -8 minecraft:poppy
setblock -4 62 -8 minecraft:poppy
setblock -9 62 -5 minecraft:poppy
setblock 3 62 -5 minecraft:poppy
setblock -9 62 -2 minecraft:poppy
setblock -2 62 2 minecraft:poppy
setblock 8 62 7 minecraft:poppy
setblock 6 62 8 minecraft:poppy
setblock -14 62 10 minecraft:poppy
setblock 5 62 11 minecraft:poppy
setblock 6 62 12 minecraft:poppy
setblock 2 62 1 minecraft:red_bed[part=foot,facing=east]
setblock 3 62 1 minecraft:red_bed[part=head,facing=east]
setblock -10 62 -14 minecraft:short_grass
setblock 7 62 -14 minecraft:short_grass
fill 10 62 -14 11 62 -14 minecraft:short_grass
setblock 14 62 -14 minecraft:short_grass
setblock 5 62 -13 minecraft:short_grass
setblock -9 62 -12 minecraft:short_grass
setblock -5 62 -9 minecraft:short_grass
fill -2 62 -9 -2 62 -8 minecraft:short_grass
setblock 2 62 -9 minecraft:short_grass
fill -8 62 -8 -7 62 -8 minecraft:short_grass
setblock 1 62 -8 minecraft:short_grass
fill 3 62 -8 4 62 -8 minecraft:short_grass
setblock 14 62 -8 minecraft:short_grass
fill -7 62 -7 -7 62 -6 minecraft:short_grass
setblock -5 62 -7 minecraft:short_grass
setblock -11 62 -6 minecraft:short_grass
setblock 3 62 -6 minecraft:short_grass
setblock -12 62 -5 minecraft:short_grass
fill 5 62 -5 6 62 -5 minecraft:short_grass
setblock 14 62 -5 minecraft:short_grass
setblock -14 62 -4 minecraft:short_grass
setblock -11 62 -4 minecraft:short_grass
setblock -1 62 -4 minecraft:short_grass
setblock 6 62 -4 minecraft:short_grass
setblock 0 62 -3 minecraft:short_grass
setblock 10 62 -3 minecraft:short_grass
fill 12 62 -3 12 62 -2 minecraft:short_grass
setblock -14 62 -2 minecraft:short_grass
fill -10 62 -2 -10 62 -1 minecraft:short_grass
setblock -7 62 -2 minecraft:short_grass
setblock -12 62 -1 minecraft:short_grass
fill -3 62 -1 -3 62 0 minecraft:short_grass
setblock -1 62 -1 minecraft:short_grass
setblock 2 62 -1 minecraft:short_grass
setblock -8 62 0 minecraft:short_grass
setblock 9 62 0 minecraft:short_grass
setblock 14 62 0 minecraft:short_grass
setblock -14 62 1 minecraft:short_grass
setblock -4 62 1 minecraft:short_grass
setblock 5 62 1 minecraft:short_grass
setblock 8 62 1 minecraft:short_grass
fill -6 62 2 -5 62 2 minecraft:short_grass
setblock -3 62 2 minecraft:short_grass
setblock 0 62 2 minecraft:short_grass
setblock 12 62 2 minecraft:short_grass
fill -13 62 3 -12 62 3 minecraft:short_grass
fill -9 62 3 -8 62 3 minecraft:short_grass
setblock -9 62 4 minecraft:short_grass
setblock -7 62 4 minecraft:short_grass
setblock 0 62 4 minecraft:short_grass
setblock 12 62 4 minecraft:short_grass
setblock 14 62 4 minecraft:short_grass
setblock -12 62 5 minecraft:short_grass
setblock -2 62 5 minecraft:short_grass
setblock 3 62 5 minecraft:short_grass
setblock 6 62 5 minecraft:short_grass
fill -14 62 6 -14 62 7 minecraft:short_grass
setblock 5 62 6 minecraft:short_grass
setblock 8 62 6 minecraft:short_grass
fill -3 62 7 -3 62 8 minecraft:short_grass
setblock -14 62 9 minecraft:short_grass
setblock 8 62 9 minecraft:short_grass
setblock -3 62 10 minecraft:short_grass
setblock 7 62 10 minecraft:short_grass
fill 11 62 10 12 62 10 minecraft:short_grass
setblock -12 62 11 minecraft:short_grass
setblock -14 62 12 minecraft:short_grass
fill 0 62 12 0 62 13 minecraft:short_grass
fill 2 62 12 3 62 12 minecraft:short_grass
fill 5 62 12 5 62 14 minecraft:short_grass
setblock 13 62 12 minecraft:short_grass
setblock -13 62 13 minecraft:short_grass
setblock 7 62 13 minecraft:short_grass
setblock -8 62 14 minecraft:short_grass
setblock 13 62 14 minecraft:short_grass
setblock 1 62 2 minecraft:torch
fill 3 62 -4 5 62 -4 minecraft:wheat[age=7]
fill 3 62 -3 3 62 -2 minecraft:wheat[age=7]
fill 5 62 -3 5 62 -2 minecraft:wheat[age=7]
setblock 4 62 -2 minecraft:wheat[age=7]
setblock 6 63 -10 minecraft:poppy
setblock 12 63 -8 minecraft:poppy
setblock 10 63 -12 minecraft:short_grass
setblock 6 63 -11 minecraft:short_grass
setblock 5 63 -9 minecraft:short_grass
fill 13 63 -9 13 63 -8 minecraft:short_grass
setblock 10 63 -6 minecraft:short_grass
setblock 9 63 -5 minecraft:short_grass
setblock 10 64 -11 minecraft:short_grass
setblock 11 64 -10 minecraft:short_grass
setblock 11 64 -8 minecraft:short_grass
setblock 9 64 -7 minecraft:short_grass
setblock 9 65 -10 minecraft:short_grass
setblock 4 61 -3 minecraft:water
fill -11 61 6 -7 61 10 minecraft:water
setblock -12 61 8 minecraft:water
setblock -6 61 8 minecraft:water
summon minecraft:sheep 7.5 62 6.5 {Tags:["ek.stg","ek.sheep"],NoAI:1b,PersistenceRequired:1b,Invulnerable:1b,Silent:1b,Rotation:[120f,0f]}
summon minecraft:sheep 9.5 62 7.5 {Tags:["ek.stg","ek.sheep"],NoAI:1b,PersistenceRequired:1b,Invulnerable:1b,Silent:1b,Rotation:[250f,0f]}
