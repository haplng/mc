scoreboard players remove #flint ek 1
scoreboard players set #at ek 0
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"자갈...",c:"gray",s:"3"}
execute store result score #r ek run random value 1..4
execute if score #r ek matches 1 run function ek:say/r1
