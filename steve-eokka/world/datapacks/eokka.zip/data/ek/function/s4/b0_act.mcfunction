data modify storage ek:s bstatus set value "집 도착"
data modify storage ek:s status set value "집 도착"
function ek:beat/flags_clear
scoreboard players set #alen ek 72
