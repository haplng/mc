data modify storage ek:s bstatus set value "식량 챙기는 중"
data modify storage ek:s status set value "식량 챙기는 중"
function ek:beat/flags_clear
scoreboard players set #f_busy ek 1
scoreboard players set #alen ek 96
execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing 4.5 62.5 -1.5
