execute if score #m10 ek matches 0 run particle minecraft:flame 1.5 60.6 3.1 0.1 0.1 0.05 0.01 3 force
execute if score #m10 ek matches 0 run execute as @a at @s run playsound minecraft:block.furnace.fire_crackle master @s ~ ~ ~ 0.6 1
