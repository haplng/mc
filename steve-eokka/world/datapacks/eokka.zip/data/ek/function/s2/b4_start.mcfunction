data modify storage ek:s bstatus set value "돌아 나오는 중"
data modify storage ek:s status set value "돌아 나오는 중"
scoreboard players set #f_dark ek 1
scoreboard players set #f_maze ek 1
scoreboard players set #prog ek 28
tp @e[tag=ek.tgt,limit=1] -4.5 60 2.5
scoreboard players set #tx ek -450
scoreboard players set #tz ek 250
