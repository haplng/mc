execute if score #at ek matches 19 run setblock -6 60 3 minecraft:torch
execute if score #at ek matches 19 run setblock 6 60 1 minecraft:torch
execute if score #at ek matches 19 run setblock 0 60 -4 minecraft:torch
execute if score #at ek matches 19 run execute as @a at @s run playsound minecraft:block.wood.place master @s ~ ~ ~ 1 1
execute if score #at ek matches 19 run swing @e[tag=ek.steve,limit=1] mainhand
execute if score #at ek matches 19 run function ek:steve/say {t:"횃불 넉넉하다"}
