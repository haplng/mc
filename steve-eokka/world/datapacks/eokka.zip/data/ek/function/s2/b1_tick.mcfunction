execute if score #at ek matches 14 run setblock 2 60 7 minecraft:torch
execute if score #at ek matches 14 run execute as @a at @s run playsound minecraft:block.wood.place master @s ~ ~ ~ 1 1
execute if score #at ek matches 14 run swing @e[tag=ek.steve,limit=1] mainhand
