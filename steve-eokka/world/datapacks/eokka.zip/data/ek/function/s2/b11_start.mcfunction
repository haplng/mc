data modify storage ek:s bstatus set value "철 장비 조합 중"
data modify storage ek:s status set value "철 장비 조합 중"
scoreboard players set #prog ek 78
tp @e[tag=ek.tgt,limit=1] 0.5 60 3.5
scoreboard players set #tx ek 50
scoreboard players set #tz ek 350
