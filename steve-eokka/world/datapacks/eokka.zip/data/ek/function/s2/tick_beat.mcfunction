execute if score #beat ek matches 0 run return run function ek:s2/b0_tick
execute if score #beat ek matches 1 run return run function ek:s2/b1_tick
execute if score #beat ek matches 3 run return run function ek:s2/b3_tick
execute if score #beat ek matches 4 run return run function ek:s2/b4_tick
execute if score #beat ek matches 5 run return run function ek:s2/b5_tick
execute if score #beat ek matches 8 run return run function ek:s2/b8_tick
execute if score #beat ek matches 10 run return run function ek:s2/b10_tick
execute if score #beat ek matches 11 run return run function ek:s2/b11_tick
