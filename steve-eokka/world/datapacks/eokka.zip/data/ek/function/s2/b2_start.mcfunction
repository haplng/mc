data modify storage ek:s bstatus set value "석탄 발견"
data modify storage ek:s status set value "석탄 발견"
scoreboard players set #f_dark ek 1
scoreboard players set #f_maze ek 1
scoreboard players set #prog ek 14
tp @e[tag=ek.tgt,limit=1] -3.5 60 3.5
scoreboard players set #tx ek -350
scoreboard players set #tz ek 350
