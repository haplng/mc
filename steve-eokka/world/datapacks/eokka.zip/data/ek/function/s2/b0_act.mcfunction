data modify storage ek:s bstatus set value "동굴 입구"
data modify storage ek:s status set value "동굴 입구"
function ek:beat/flags_clear
scoreboard players set #alen ek 60
