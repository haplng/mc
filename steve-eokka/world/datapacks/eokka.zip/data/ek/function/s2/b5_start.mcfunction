data modify storage ek:s bstatus set value "철 찾는 중"
data modify storage ek:s status set value "철 찾는 중"
scoreboard players set #f_dark ek 1
scoreboard players set #f_maze ek 1
scoreboard players set #prog ek 35
tp @e[tag=ek.tgt,limit=1] 12.5 60 0.5
scoreboard players set #tx ek 1250
scoreboard players set #tz ek 50
