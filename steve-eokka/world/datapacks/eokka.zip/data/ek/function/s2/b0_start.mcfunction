data modify storage ek:s bstatus set value "동굴 입구"
data modify storage ek:s status set value "동굴 입구"
scoreboard players set #prog ek 0
function ek:beat/arrive
