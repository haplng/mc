data modify storage ek:s bstatus set value "철 굽는 중"
data modify storage ek:s status set value "철 굽는 중"
function ek:beat/flags_clear
scoreboard players set #f_busy ek 1
scoreboard players set #f_dark ek 1
scoreboard players set #alen ek 192
execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing 1.5 60.5 2.5
setblock 1 60 2 minecraft:furnace[facing=south,lit=true]
setblock -1 60 2 minecraft:crafting_table
execute as @a at @s run playsound minecraft:block.stone.place master @s ~ ~ ~ 1 1
