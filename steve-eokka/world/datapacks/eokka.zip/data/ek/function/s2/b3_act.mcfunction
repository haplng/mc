data modify storage ek:s bstatus set value "석탄 캐는 중"
data modify storage ek:s status set value "석탄 캐는 중"
function ek:beat/flags_clear
scoreboard players set #f_busy ek 1
scoreboard players set #f_mine ek 1
scoreboard players set #f_dark ek 1
scoreboard players set #alen ek 116
item replace entity @e[tag=ek.steve,limit=1] weapon.mainhand with minecraft:stone_pickaxe
