execute if score #at ek matches 1 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing -12.5 61.5 1.5
execute if score #at ek matches 38 run setblock -13 61 1 minecraft:air destroy
execute if score #at ek matches 39 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing -12.5 60.5 1.5
execute if score #at ek matches 76 run setblock -13 60 1 minecraft:air destroy
execute if score #at ek matches 77 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing -12.5 60.5 0.5
execute if score #at ek matches 114 run setblock -13 60 0 minecraft:air destroy
execute if score #m6 ek matches 0 run swing @e[tag=ek.steve,limit=1] mainhand
execute if score #m6 ek matches 0 run execute as @a at @s run playsound minecraft:block.stone.hit master @s ~ ~ ~ 0.6 1
execute if score #at ek matches 1..38 if score #m6 ek matches 0 run particle minecraft:block{block_state:"minecraft:coal_ore"} -12.5 61.5 1.5 0.3 0.3 0.3 0 6 force
execute if score #at ek matches 39..76 if score #m6 ek matches 0 run particle minecraft:block{block_state:"minecraft:coal_ore"} -12.5 60.5 1.5 0.3 0.3 0.3 0 6 force
execute if score #at ek matches 77..114 if score #m6 ek matches 0 run particle minecraft:block{block_state:"minecraft:coal_ore"} -12.5 60.5 0.5 0.3 0.3 0.3 0 6 force
