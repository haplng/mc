fill 9 58 -14 9 58 -13 minecraft:andesite
fill -13 58 -13 -12 58 -13 minecraft:andesite
setblock 5 58 -13 minecraft:andesite
fill -6 58 -11 -5 58 -11 minecraft:andesite
setblock 9 58 -11 minecraft:andesite
fill -14 58 -10 -14 58 -9 minecraft:andesite
fill -9 58 -10 -8 58 -10 minecraft:andesite
setblock -5 58 -10 minecraft:andesite
setblock 14 58 -10 minecraft:andesite
setblock -6 58 -7 minecraft:andesite
setblock 6 58 -6 minecraft:andesite
fill -10 58 -4 -8 58 -4 minecraft:andesite
setblock 4 58 -4 minecraft:andesite
fill -4 58 -3 -4 59 -3 minecraft:andesite
fill 11 58 -3 11 59 -3 minecraft:andesite
setblock 5 58 -2 minecraft:andesite
fill 7 58 -2 8 58 -2 minecraft:andesite
setblock -7 58 -1 minecraft:andesite
setblock 14 58 2 minecraft:andesite
fill 9 58 3 9 59 3 minecraft:andesite
setblock 11 58 3 minecraft:andesite
fill -12 58 4 -11 58 4 minecraft:andesite
fill -9 58 4 -9 58 5 minecraft:andesite
setblock 7 58 5 minecraft:andesite
fill 9 58 5 9 59 5 minecraft:andesite
setblock -8 58 6 minecraft:andesite
fill 10 58 6 10 59 6 minecraft:andesite
setblock -5 58 7 minecraft:andesite
setblock 8 58 7 minecraft:andesite
setblock 3 58 8 minecraft:andesite
fill -11 58 9 -11 59 9 minecraft:andesite
setblock -2 58 9 minecraft:andesite
fill 11 58 9 11 58 10 minecraft:andesite
setblock 2 58 10 minecraft:andesite
setblock 4 58 10 minecraft:andesite
fill -7 58 11 -7 58 12 minecraft:andesite
setblock -3 58 12 minecraft:andesite
setblock 8 58 12 minecraft:andesite
setblock -5 58 13 minecraft:andesite
setblock -2 58 13 minecraft:andesite
setblock 1 58 13 minecraft:andesite
setblock 3 58 14 minecraft:andesite
fill -14 58 -14 -14 59 -14 minecraft:cobblestone
setblock 1 58 -14 minecraft:cobblestone
setblock 5 58 -14 minecraft:cobblestone
setblock 14 58 -14 minecraft:cobblestone
setblock -9 58 -13 minecraft:cobblestone
setblock -3 58 -13 minecraft:cobblestone
setblock 10 58 -13 minecraft:cobblestone
setblock 6 58 -12 minecraft:cobblestone
setblock -12 58 -11 minecraft:cobblestone
setblock 14 58 -11 minecraft:cobblestone
setblock -6 58 -9 minecraft:cobblestone
fill 13 58 -9 13 58 -8 minecraft:cobblestone
fill -11 58 -8 -11 59 -8 minecraft:cobblestone
setblock -7 58 -8 minecraft:cobblestone
setblock 9 58 -8 minecraft:cobblestone
setblock 14 58 -8 minecraft:cobblestone
fill -8 58 -7 -8 58 -6 minecraft:cobblestone
setblock 8 58 -7 minecraft:cobblestone
setblock 4 58 -6 minecraft:cobblestone
setblock 11 58 -5 minecraft:cobblestone
fill 8 58 -4 8 58 -3 minecraft:cobblestone
setblock -9 58 -3 minecraft:cobblestone
setblock 5 58 -3 minecraft:cobblestone
setblock -11 58 -2 minecraft:cobblestone
setblock -11 58 5 minecraft:cobblestone
fill 11 58 7 11 58 8 minecraft:cobblestone
setblock -10 58 9 minecraft:cobblestone
setblock 2 58 9 minecraft:cobblestone
setblock 7 58 9 minecraft:cobblestone
setblock -6 58 10 minecraft:cobblestone
setblock 0 58 10 minecraft:cobblestone
fill 10 58 10 10 59 10 minecraft:cobblestone
setblock -12 58 11 minecraft:cobblestone
setblock 5 58 11 minecraft:cobblestone
setblock 7 58 11 minecraft:cobblestone
setblock -4 58 12 minecraft:cobblestone
setblock -2 58 12 minecraft:cobblestone
fill 2 58 12 3 58 12 minecraft:cobblestone
setblock 0 58 13 minecraft:cobblestone
fill -14 58 14 -14 59 14 minecraft:cobblestone
fill -13 58 -14 0 59 -14 minecraft:stone
fill 2 58 -14 4 58 -7 minecraft:stone
fill 6 58 -14 8 59 -13 minecraft:stone
fill 10 58 -14 13 58 -14 minecraft:stone
fill -11 58 -13 -10 59 -9 minecraft:stone
fill -8 58 -13 -4 58 -12 minecraft:stone
fill -2 58 -13 -1 62 -13 minecraft:stone
fill 1 58 -13 1 58 12 minecraft:stone
fill 11 58 -13 14 58 -12 minecraft:stone
fill -14 58 -12 -12 58 -12 minecraft:stone
fill -9 58 -12 -9 60 -11 minecraft:stone
fill -3 58 -12 -2 58 -7 minecraft:stone
fill 0 58 -12 0 58 9 minecraft:stone
fill 5 58 -12 5 58 -4 minecraft:stone
fill 8 58 -12 10 60 -12 minecraft:stone
fill -14 58 -11 -13 60 -11 minecraft:stone
fill -8 58 -11 -7 58 -11 minecraft:stone
fill -4 58 -11 -4 58 -4 minecraft:stone
fill -1 58 -11 -1 58 9 minecraft:stone
fill 6 58 -11 8 58 -8 minecraft:stone
fill 10 58 -11 13 58 -11 minecraft:stone
fill -13 58 -10 -12 58 -6 minecraft:stone
fill -7 58 -10 -6 61 -10 minecraft:stone
fill 9 58 -10 9 60 -9 minecraft:stone
fill 11 58 -10 13 59 -10 minecraft:stone
fill -9 58 -9 -7 60 -9 minecraft:stone
fill -5 58 -9 -5 58 6 minecraft:stone
fill 10 58 -9 11 58 -6 minecraft:stone
fill 14 58 -9 14 61 -9 minecraft:stone
fill -10 58 -8 -8 58 -8 minecraft:stone
fill -6 58 -8 -6 66 -8 minecraft:stone
fill 12 58 -8 12 58 14 minecraft:stone
fill -14 58 -7 -14 58 13 minecraft:stone
fill -11 58 -7 -9 60 -7 minecraft:stone
fill -7 58 -7 -7 64 -7 minecraft:stone
fill 6 58 -7 7 61 -7 minecraft:stone
fill 9 58 -7 9 58 2 minecraft:stone
fill 13 58 -7 14 59 -5 minecraft:stone
fill -11 58 -6 -10 58 -5 minecraft:stone
fill -6 58 -6 -6 63 -6 minecraft:stone
fill 2 58 -6 3 59 -5 minecraft:stone
fill 7 58 -6 8 58 -5 minecraft:stone
fill -12 58 -5 -12 58 3 minecraft:stone
fill -9 58 -5 -7 58 -5 minecraft:stone
fill -3 58 -5 -2 58 8 minecraft:stone
fill 4 58 -5 4 59 -5 minecraft:stone
fill 6 58 -5 6 58 9 minecraft:stone
fill 10 58 -5 10 58 5 minecraft:stone
fill -13 58 -4 -13 58 5 minecraft:stone
fill -11 58 -4 -11 61 -3 minecraft:stone
fill -7 58 -4 -6 58 -2 minecraft:stone
fill 3 58 -4 3 58 7 minecraft:stone
fill 7 58 -4 7 58 -3 minecraft:stone
fill 11 58 -4 11 65 -4 minecraft:stone
fill 13 58 -4 13 58 -2 minecraft:stone
fill -10 58 -3 -10 58 8 minecraft:stone
fill -8 58 -3 -8 59 5 minecraft:stone
fill 2 58 -3 2 58 8 minecraft:stone
fill 4 58 -3 4 58 9 minecraft:stone
fill 14 58 -3 14 59 1 minecraft:stone
fill -9 58 -2 -9 58 3 minecraft:stone
fill -4 58 -2 -4 58 11 minecraft:stone
fill 11 58 -2 11 58 2 minecraft:stone
fill -11 58 -1 -11 58 3 minecraft:stone
fill -6 58 -1 -6 59 9 minecraft:stone
fill 5 58 -1 5 59 5 minecraft:stone
fill 8 58 -1 8 58 6 minecraft:stone
fill -7 58 0 -7 59 4 minecraft:stone
fill 7 58 0 7 59 4 minecraft:stone
fill 13 58 0 13 58 1 minecraft:stone
fill 13 58 3 14 58 14 minecraft:stone
fill 11 58 4 11 58 6 minecraft:stone
fill -12 58 5 -12 58 8 minecraft:stone
fill -11 58 6 -11 59 8 minecraft:stone
fill -9 58 6 -9 58 14 minecraft:stone
fill -7 58 6 -7 59 10 minecraft:stone
fill 7 58 6 7 58 8 minecraft:stone
fill 9 58 6 9 58 11 minecraft:stone
fill -13 58 7 -13 59 14 minecraft:stone
fill -8 58 7 -8 58 9 minecraft:stone
fill 5 58 7 5 59 10 minecraft:stone
fill 10 58 7 10 59 9 minecraft:stone
fill -5 58 8 -5 58 12 minecraft:stone
fill 8 58 8 8 58 11 minecraft:stone
fill -3 58 9 -3 59 11 minecraft:stone
fill 3 58 9 3 58 11 minecraft:stone
fill -11 58 10 -10 58 14 minecraft:stone
fill 7 58 10 7 59 10 minecraft:stone
fill -8 58 11 -8 59 14 minecraft:stone
fill -6 58 11 -6 58 14 minecraft:stone
fill -2 58 11 0 58 11 minecraft:stone
fill 2 58 11 2 62 11 minecraft:stone
fill 4 58 11 4 58 14 minecraft:stone
fill 6 58 11 6 59 14 minecraft:stone
fill 11 58 11 11 59 13 minecraft:stone
fill -12 58 12 -12 59 13 minecraft:stone
fill -1 58 12 0 58 12 minecraft:stone
fill 5 58 12 5 60 14 minecraft:stone
fill 7 58 12 7 59 14 minecraft:stone
fill 10 58 12 10 59 14 minecraft:stone
fill -7 58 13 -7 59 14 minecraft:stone
fill -4 58 13 -3 58 14 minecraft:stone
fill -1 58 13 -1 62 14 minecraft:stone
fill 2 58 13 3 60 13 minecraft:stone
fill 8 58 13 9 60 14 minecraft:stone
fill -5 58 14 -5 62 14 minecraft:stone
fill -2 58 14 -2 61 14 minecraft:stone
fill 0 58 14 2 59 14 minecraft:stone
setblock -14 58 -13 minecraft:tuff
setblock 0 58 -13 minecraft:tuff
setblock -1 58 -12 minecraft:tuff
setblock 7 58 -12 minecraft:tuff
setblock 10 58 -10 minecraft:tuff
setblock 12 58 -9 minecraft:tuff
setblock -14 58 -8 minecraft:tuff
setblock -9 58 -6 minecraft:tuff
setblock -7 58 -6 minecraft:tuff
fill -3 58 -6 -2 58 -6 minecraft:tuff
fill -13 58 -5 -13 59 -5 minecraft:tuff
fill -6 58 -5 -6 59 -5 minecraft:tuff
setblock 2 58 -4 minecraft:tuff
setblock 14 58 -4 minecraft:tuff
setblock 7 58 -1 minecraft:tuff
setblock 13 58 -1 minecraft:tuff
setblock 13 58 2 minecraft:tuff
setblock 9 58 4 minecraft:tuff
setblock -7 58 5 minecraft:tuff
setblock -13 58 6 minecraft:tuff
setblock 5 58 6 minecraft:tuff
fill -12 58 9 -12 58 10 minecraft:tuff
setblock -8 58 10 minecraft:tuff
fill -2 58 10 -1 58 10 minecraft:tuff
setblock 6 58 10 minecraft:tuff
setblock 10 58 11 minecraft:tuff
setblock 9 58 12 minecraft:tuff
setblock -12 58 14 minecraft:tuff
setblock 11 58 14 minecraft:tuff
setblock -4 59 -13 minecraft:andesite
setblock -8 59 -11 minecraft:andesite
setblock -6 59 -11 minecraft:andesite
fill 6 59 -11 6 60 -11 minecraft:andesite
setblock 13 59 -11 minecraft:andesite
setblock -12 59 -10 minecraft:andesite
fill 8 59 -10 8 59 -8 minecraft:andesite
setblock 10 59 -8 minecraft:andesite
setblock -10 59 -6 minecraft:andesite
fill -4 59 -5 -4 60 -5 minecraft:andesite
setblock 9 59 -5 minecraft:andesite
fill -14 59 -4 -13 59 -4 minecraft:andesite
fill -9 59 -4 -8 59 -4 minecraft:andesite
setblock 5 59 -4 minecraft:andesite
setblock 13 59 -4 minecraft:andesite
fill -7 59 -3 -7 60 -3 minecraft:andesite
setblock -13 59 -2 minecraft:andesite
setblock -11 59 -2 minecraft:andesite
setblock 6 59 -2 minecraft:andesite
setblock 8 59 -2 minecraft:andesite
setblock 13 59 -2 minecraft:andesite
setblock -12 59 -1 minecraft:andesite
setblock -13 59 0 minecraft:andesite
setblock -14 59 2 minecraft:andesite
setblock 8 59 3 minecraft:andesite
setblock 10 59 4 minecraft:andesite
setblock 14 59 4 minecraft:andesite
setblock -7 59 5 minecraft:andesite
fill 12 59 5 13 59 5 minecraft:andesite
setblock 6 59 6 minecraft:andesite
setblock 8 59 6 minecraft:andesite
setblock -8 59 7 minecraft:andesite
setblock 7 59 7 minecraft:andesite
setblock 9 59 7 minecraft:andesite
setblock -9 59 10 minecraft:andesite
setblock -6 59 10 minecraft:andesite
fill 8 59 11 8 61 11 minecraft:andesite
setblock -7 59 12 minecraft:andesite
setblock 9 59 12 minecraft:andesite
setblock 13 59 12 minecraft:andesite
setblock -6 59 13 minecraft:andesite
setblock -8 59 -13 minecraft:cobblestone
fill 13 59 -13 13 59 -12 minecraft:cobblestone
setblock -13 59 -12 minecraft:cobblestone
setblock -6 59 -12 minecraft:cobblestone
setblock -3 59 -12 minecraft:cobblestone
setblock -2 59 -10 minecraft:cobblestone
setblock 7 59 -10 minecraft:cobblestone
setblock -14 59 -9 minecraft:cobblestone
setblock -4 59 -6 minecraft:cobblestone
setblock -2 59 -6 minecraft:cobblestone
setblock 1 59 -6 minecraft:cobblestone
setblock 8 59 -6 minecraft:cobblestone
setblock -9 59 -5 minecraft:cobblestone
setblock -1 59 -5 minecraft:cobblestone
setblock -6 59 -3 minecraft:cobblestone
setblock -1 59 -3 minecraft:cobblestone
setblock -14 59 -2 minecraft:cobblestone
setblock -5 59 -2 minecraft:cobblestone
fill 2 59 -2 3 59 -2 minecraft:cobblestone
setblock 5 59 -2 minecraft:cobblestone
fill -11 59 -1 -11 59 0 minecraft:cobblestone
setblock 3 59 -1 minecraft:cobblestone
setblock 8 59 -1 minecraft:cobblestone
setblock -10 59 0 minecraft:cobblestone
setblock 13 59 0 minecraft:cobblestone
setblock -13 59 1 minecraft:cobblestone
setblock -9 59 1 minecraft:cobblestone
setblock -2 59 1 minecraft:cobblestone
setblock 2 59 1 minecraft:cobblestone
setblock -3 59 2 minecraft:cobblestone
setblock 4 59 2 minecraft:cobblestone
setblock 6 59 2 minecraft:cobblestone
setblock -4 59 3 minecraft:cobblestone
setblock -1 59 3 minecraft:cobblestone
fill 11 59 3 11 59 4 minecraft:cobblestone
setblock -12 59 4 minecraft:cobblestone
setblock -9 59 4 minecraft:cobblestone
fill 14 59 5 14 59 6 minecraft:cobblestone
setblock -12 59 6 minecraft:cobblestone
setblock -2 59 6 minecraft:cobblestone
setblock 0 59 6 minecraft:cobblestone
fill 2 59 6 2 59 7 minecraft:cobblestone
setblock 7 59 6 minecraft:cobblestone
setblock -5 59 7 minecraft:cobblestone
setblock -4 59 8 minecraft:cobblestone
fill -1 59 8 1 59 8 minecraft:cobblestone
fill 9 59 8 9 59 9 minecraft:cobblestone
setblock 3 59 9 minecraft:cobblestone
setblock 13 59 9 minecraft:cobblestone
setblock -6 59 11 minecraft:cobblestone
setblock 0 59 11 minecraft:cobblestone
setblock 4 59 11 minecraft:cobblestone
setblock -1 59 12 minecraft:cobblestone
setblock 1 59 12 minecraft:cobblestone
setblock 8 59 12 minecraft:cobblestone
setblock -10 59 13 minecraft:cobblestone
setblock -4 59 13 minecraft:cobblestone
setblock 4 59 14 minecraft:cobblestone
fill 1 59 -14 5 59 -13 minecraft:stone
fill 9 59 -14 11 59 -13 minecraft:stone
fill 13 59 -14 14 62 -14 minecraft:stone
fill -14 59 -13 -12 61 -13 minecraft:stone
fill -9 59 -13 -9 60 -13 minecraft:stone
fill -7 59 -13 -5 59 -13 minecraft:stone
fill -3 59 -13 -3 60 -13 minecraft:stone
fill 0 59 -13 0 59 -7 minecraft:stone
fill 14 59 -13 14 61 -10 minecraft:stone
setblock -14 59 -12 minecraft:stone
fill -12 59 -12 -12 60 -11 minecraft:stone
fill -8 59 -12 -7 63 -12 minecraft:stone
fill -5 59 -12 -4 59 -11 minecraft:stone
fill -2 59 -12 -1 59 -11 minecraft:stone
fill 1 59 -12 2 59 -7 minecraft:stone
fill 4 59 -12 7 60 -12 minecraft:stone
fill 11 59 -12 12 59 -11 minecraft:stone
fill -7 59 -11 -7 60 -11 minecraft:stone
setblock -3 59 -11 minecraft:stone
fill 3 59 -11 5 59 -7 minecraft:stone
fill 8 59 -11 10 60 -11 minecraft:stone
fill -14 59 -10 -13 59 -10 minecraft:stone
fill -9 59 -10 -8 60 -10 minecraft:stone
fill -5 59 -10 -5 62 -4 minecraft:stone
fill -1 59 -10 -1 59 -6 minecraft:stone
fill 6 59 -10 6 59 -8 minecraft:stone
fill 10 59 -10 10 64 -9 minecraft:stone
fill -13 59 -9 -12 59 -6 minecraft:stone
fill -6 59 -9 -6 62 -9 minecraft:stone
fill -2 59 -9 -2 59 -7 minecraft:stone
fill 7 59 -9 7 59 -8 minecraft:stone
fill 11 59 -9 13 59 -9 minecraft:stone
fill -14 59 -8 -14 59 -5 minecraft:stone
fill -9 59 -8 -7 61 -8 minecraft:stone
fill -4 59 -8 -3 59 -7 minecraft:stone
fill 9 59 -8 9 59 -6 minecraft:stone
fill 12 59 -8 14 59 -8 minecraft:stone
fill -8 59 -7 -8 59 -5 minecraft:stone
fill -6 59 -7 -6 62 -7 minecraft:stone
setblock 8 59 -7 minecraft:stone
fill 10 59 -7 12 59 -5 minecraft:stone
fill -11 59 -6 -11 61 -5 minecraft:stone
fill -9 59 -6 -9 65 -6 minecraft:stone
fill -7 59 -6 -7 61 -4 minecraft:stone
fill -3 59 -6 -3 59 1 minecraft:stone
fill 4 59 -6 7 60 -6 minecraft:stone
fill -12 59 -5 -12 59 -2 minecraft:stone
fill -10 59 -5 -10 60 -4 minecraft:stone
fill -2 59 -5 -2 59 0 minecraft:stone
fill 0 59 -5 1 59 -5 minecraft:stone
fill 5 59 -5 8 60 -5 minecraft:stone
setblock -6 59 -4 minecraft:stone
setblock -4 59 -4 minecraft:stone
fill -1 59 -4 0 59 -4 minecraft:stone
fill 2 59 -4 4 59 -3 minecraft:stone
fill 6 59 -4 10 59 -4 minecraft:stone
fill 12 59 -4 12 59 4 minecraft:stone
setblock 14 59 -4 minecraft:stone
fill -14 59 -3 -13 61 -3 minecraft:stone
fill -9 59 -3 -9 63 -2 minecraft:stone
fill 0 59 -3 1 59 3 minecraft:stone
fill 5 59 -3 5 63 -3 minecraft:stone
fill 8 59 -3 10 59 -3 minecraft:stone
fill 13 59 -3 13 63 -3 minecraft:stone
fill -10 59 -2 -10 59 -1 minecraft:stone
fill -7 59 -2 -6 60 -2 minecraft:stone
fill -4 59 -2 -4 59 2 minecraft:stone
fill -1 59 -2 -1 59 2 minecraft:stone
fill 4 59 -2 4 59 1 minecraft:stone
fill 7 59 -2 7 59 -1 minecraft:stone
fill 9 59 -2 11 59 -1 minecraft:stone
fill -14 59 -1 -13 64 -1 minecraft:stone
fill -7 59 -1 -7 64 -1 minecraft:stone
fill -5 59 -1 -5 59 6 minecraft:stone
fill 2 59 -1 2 59 0 minecraft:stone
fill 6 59 -1 6 59 1 minecraft:stone
setblock 13 59 -1 minecraft:stone
fill -14 59 0 -14 59 1 minecraft:stone
fill -12 59 0 -12 59 2 minecraft:stone
setblock -9 59 0 minecraft:stone
fill 3 59 0 3 59 8 minecraft:stone
fill 8 59 0 10 59 2 minecraft:stone
fill -11 59 1 -11 59 5 minecraft:stone
fill 11 59 1 11 59 2 minecraft:stone
fill 13 59 1 13 59 4 minecraft:stone
setblock -13 59 2 minecraft:stone
fill -10 59 2 -9 59 3 minecraft:stone
setblock -2 59 2 minecraft:stone
fill 2 59 2 2 59 5 minecraft:stone
fill 14 59 2 14 63 2 minecraft:stone
fill -14 59 3 -14 60 3 minecraft:stone
setblock -3 59 3 minecraft:stone
fill 4 59 3 4 59 10 minecraft:stone
fill 6 59 3 6 59 5 minecraft:stone
setblock 10 59 3 minecraft:stone
fill -13 59 4 -13 59 6 minecraft:stone
fill -10 59 4 -10 59 12 minecraft:stone
fill -4 59 4 -4 59 7 minecraft:stone
fill -2 59 4 0 59 5 minecraft:stone
fill 8 59 4 9 62 4 minecraft:stone
fill -14 59 5 -14 59 11 minecraft:stone
fill -9 59 5 -9 59 9 minecraft:stone
fill -3 59 5 -3 59 8 minecraft:stone
fill 1 59 5 1 59 7 minecraft:stone
fill 7 59 5 8 59 5 minecraft:stone
fill 10 59 5 11 62 5 minecraft:stone
fill -8 59 6 -8 64 6 minecraft:stone
fill -1 59 6 -1 59 7 minecraft:stone
fill 5 59 6 5 60 6 minecraft:stone
setblock 9 59 6 minecraft:stone
fill 11 59 6 13 59 8 minecraft:stone
fill -12 59 7 -12 62 11 minecraft:stone
fill -2 59 7 -2 59 9 minecraft:stone
setblock 0 59 7 minecraft:stone
fill 6 59 7 6 62 10 minecraft:stone
fill 14 59 7 14 59 14 minecraft:stone
fill -8 59 8 -8 61 10 minecraft:stone
fill -5 59 8 -5 60 10 minecraft:stone
fill 2 59 8 2 59 10 minecraft:stone
fill 7 59 8 8 59 9 minecraft:stone
fill -1 59 9 1 59 10 minecraft:stone
fill 11 59 9 12 60 10 minecraft:stone
fill -11 59 10 -11 59 14 minecraft:stone
fill -4 59 10 -4 59 12 minecraft:stone
fill 3 59 10 3 59 12 minecraft:stone
fill 8 59 10 9 60 10 minecraft:stone
fill -9 59 11 -9 59 13 minecraft:stone
fill -7 59 11 -7 62 11 minecraft:stone
fill -2 59 11 -1 59 11 minecraft:stone
fill 5 59 11 5 62 11 minecraft:stone
fill 9 59 11 10 59 11 minecraft:stone
fill 12 59 11 13 59 11 minecraft:stone
fill -6 59 12 -5 61 12 minecraft:stone
fill -3 59 12 -2 60 13 minecraft:stone
fill 0 59 12 0 62 13 minecraft:stone
fill 2 59 12 2 62 12 minecraft:stone
fill 4 59 12 4 59 13 minecraft:stone
fill 12 59 12 12 59 14 minecraft:stone
fill -14 59 13 -14 60 13 minecraft:stone
fill -5 59 13 -5 62 13 minecraft:stone
fill 1 59 13 1 62 13 minecraft:stone
fill 13 59 13 13 60 14 minecraft:stone
setblock -12 59 14 minecraft:stone
setblock -10 59 14 minecraft:stone
fill -6 59 14 -6 62 14 minecraft:stone
fill -4 59 14 -3 60 14 minecraft:stone
fill 3 59 14 3 60 14 minecraft:stone
fill 11 59 14 11 62 14 minecraft:stone
fill 12 59 -14 12 59 -13 minecraft:tuff
setblock 3 59 -12 minecraft:tuff
setblock 7 59 -11 minecraft:tuff
setblock -10 59 -8 minecraft:tuff
fill 11 59 -8 11 60 -8 minecraft:tuff
setblock -10 59 -3 minecraft:tuff
setblock -5 59 -3 minecraft:tuff
fill 6 59 -3 7 59 -3 minecraft:tuff
fill -13 59 3 -12 59 3 minecraft:tuff
setblock 14 59 3 minecraft:tuff
setblock -14 59 4 minecraft:tuff
setblock -12 59 5 minecraft:tuff
setblock 8 59 7 minecraft:tuff
setblock -4 59 9 minecraft:tuff
setblock -2 59 10 minecraft:tuff
setblock 13 59 10 minecraft:tuff
fill -5 59 11 -5 60 11 minecraft:tuff
setblock 1 59 11 minecraft:tuff
setblock 7 59 11 minecraft:tuff
setblock -14 59 12 minecraft:tuff
setblock -9 59 14 minecraft:tuff
fill -12 60 -14 -12 64 -14 minecraft:andesite
setblock -6 60 -14 minecraft:andesite
setblock 12 60 -14 minecraft:andesite
setblock -5 60 -13 minecraft:andesite
setblock 5 60 -13 minecraft:andesite
setblock -13 60 -12 minecraft:andesite
setblock -14 60 -10 minecraft:andesite
fill 12 60 -10 13 60 -10 minecraft:andesite
setblock -13 60 -9 minecraft:andesite
setblock -11 60 -8 minecraft:andesite
fill 8 60 -8 8 60 -7 minecraft:andesite
setblock -14 60 -7 minecraft:andesite
setblock -4 60 -6 minecraft:andesite
setblock -8 60 -4 minecraft:andesite
fill -6 60 -4 -6 61 -4 minecraft:andesite
setblock 9 60 -4 minecraft:andesite
fill -10 60 -3 -10 62 -3 minecraft:andesite
setblock 12 60 -3 minecraft:andesite
setblock 14 60 -3 minecraft:andesite
fill -12 60 -2 -12 61 -2 minecraft:andesite
setblock -14 60 1 minecraft:andesite
setblock -14 60 4 minecraft:andesite
fill -10 60 4 -10 61 4 minecraft:andesite
fill -11 60 5 -11 61 5 minecraft:andesite
setblock 14 60 5 minecraft:andesite
fill -9 60 7 -9 61 7 minecraft:andesite
setblock -6 60 8 minecraft:andesite
setblock -2 60 8 minecraft:andesite
setblock 2 60 8 minecraft:andesite
fill 4 60 8 4 60 9 minecraft:andesite
setblock 11 60 8 minecraft:andesite
fill 13 60 8 13 61 8 minecraft:andesite
setblock -13 60 9 minecraft:andesite
setblock -11 60 10 minecraft:andesite
setblock -7 60 10 minecraft:andesite
setblock -3 60 10 minecraft:andesite
setblock -4 60 11 minecraft:andesite
setblock 12 60 11 minecraft:andesite
setblock -8 60 12 minecraft:andesite
setblock 3 60 12 minecraft:andesite
setblock 11 60 12 minecraft:andesite
setblock 4 60 13 minecraft:andesite
setblock 10 60 13 minecraft:andesite
fill -13 60 14 -12 60 14 minecraft:andesite
setblock -7 60 14 minecraft:andesite
fill 1 60 14 1 61 14 minecraft:andesite
setblock 7 60 14 minecraft:andesite
fill -13 60 0 -13 60 1 minecraft:coal_ore
setblock -11 60 -14 minecraft:cobblestone
setblock 2 60 -13 minecraft:cobblestone
setblock 9 60 -13 minecraft:cobblestone
setblock -14 60 -12 minecraft:cobblestone
fill -10 60 -12 -10 60 -11 minecraft:cobblestone
setblock -1 60 -12 minecraft:cobblestone
setblock 11 60 -12 minecraft:cobblestone
setblock -6 60 -11 minecraft:cobblestone
setblock -13 60 -10 minecraft:cobblestone
setblock 12 60 -9 minecraft:cobblestone
setblock 7 60 -8 minecraft:cobblestone
setblock 13 60 -7 minecraft:cobblestone
setblock -8 60 -6 minecraft:cobblestone
setblock 9 60 -6 minecraft:cobblestone
setblock 4 60 -5 minecraft:cobblestone
setblock 10 60 -5 minecraft:cobblestone
setblock 14 60 -4 minecraft:cobblestone
setblock -8 60 -2 minecraft:cobblestone
setblock 7 60 -1 minecraft:cobblestone
setblock 13 60 2 minecraft:cobblestone
fill 7 60 4 7 60 5 minecraft:cobblestone
setblock 13 60 4 minecraft:cobblestone
setblock -13 60 5 minecraft:cobblestone
setblock -8 60 5 minecraft:cobblestone
fill -7 60 6 -7 60 8 minecraft:cobblestone
setblock 7 60 7 minecraft:cobblestone
setblock 13 60 7 minecraft:cobblestone
setblock -9 60 9 minecraft:cobblestone
fill -1 60 9 1 60 9 minecraft:cobblestone
setblock 10 60 9 minecraft:cobblestone
setblock -14 60 10 minecraft:cobblestone
setblock -6 60 10 minecraft:cobblestone
setblock -4 60 10 minecraft:cobblestone
setblock 3 60 10 minecraft:cobblestone
fill 7 60 10 7 61 10 minecraft:cobblestone
setblock 14 60 10 minecraft:cobblestone
setblock -2 60 11 minecraft:cobblestone
setblock 13 60 11 minecraft:cobblestone
setblock 6 60 13 minecraft:cobblestone
setblock -10 60 14 minecraft:cobblestone
setblock 6 60 -13 minecraft:copper_ore
setblock -13 60 2 minecraft:copper_ore
setblock -8 60 7 minecraft:copper_ore
fill 0 60 -13 1 60 -13 minecraft:iron_ore
fill 13 60 -1 13 60 1 minecraft:iron_ore
fill -14 60 -14 -13 62 -14 minecraft:stone
fill -10 60 -14 -7 60 -14 minecraft:stone
fill -5 60 -14 -3 60 -14 minecraft:stone
fill -1 60 -14 0 61 -14 minecraft:stone
fill 3 60 -14 11 60 -14 minecraft:stone
fill -11 60 -13 -10 63 -13 minecraft:stone
fill -8 60 -13 -6 61 -13 minecraft:stone
fill -4 60 -13 -4 60 -11 minecraft:stone
fill 3 60 -13 4 62 -13 minecraft:stone
fill 7 60 -13 8 61 -13 minecraft:stone
fill 10 60 -13 12 60 -13 minecraft:stone
fill -11 60 -12 -11 60 -10 minecraft:stone
fill -6 60 -12 -6 64 -12 minecraft:stone
fill -3 60 -12 -2 61 -12 minecraft:stone
fill 3 60 -12 3 65 -12 minecraft:stone
fill 12 60 -12 13 60 -11 minecraft:stone
fill -8 60 -11 -8 64 -11 minecraft:stone
setblock -5 60 -11 minecraft:stone
fill 7 60 -11 7 61 -9 minecraft:stone
fill 11 60 -11 11 60 -9 minecraft:stone
fill -12 60 -10 -12 60 -3 minecraft:stone
fill 8 60 -10 8 62 -9 minecraft:stone
fill -14 60 -9 -14 60 -8 minecraft:stone
fill -10 60 -9 -10 60 -8 minecraft:stone
fill 13 60 -9 13 61 -8 minecraft:stone
fill -13 60 -8 -13 64 -8 minecraft:stone
fill 9 60 -8 10 61 -7 minecraft:stone
fill -8 60 -7 -8 64 -7 minecraft:stone
fill -4 60 -7 -4 62 -7 minecraft:stone
fill 11 60 -7 12 60 -5 minecraft:stone
fill 14 60 -7 14 62 -5 minecraft:stone
fill -14 60 -6 -13 60 -4 minecraft:stone
fill -10 60 -6 -10 61 -6 minecraft:stone
fill -3 60 -6 -2 60 -4 minecraft:stone
fill 3 60 -6 3 64 -3 minecraft:stone
fill 13 60 -6 13 61 -4 minecraft:stone
fill -9 60 -5 -8 64 -5 minecraft:stone
fill -6 60 -5 -6 63 -5 minecraft:stone
fill 2 60 -5 2 61 -4 minecraft:stone
fill 9 60 -5 9 64 -5 minecraft:stone
setblock -9 60 -4 minecraft:stone
fill 4 60 -4 8 60 -4 minecraft:stone
fill 10 60 -4 10 61 -4 minecraft:stone
setblock 12 60 -4 minecraft:stone
fill -8 60 -3 -8 66 -3 minecraft:stone
fill -6 60 -3 -3 61 -3 minecraft:stone
fill 4 60 -3 4 62 -3 minecraft:stone
fill 6 60 -3 9 60 -3 minecraft:stone
fill 11 60 -3 11 64 -3 minecraft:stone
fill -14 60 -2 -13 64 -2 minecraft:stone
fill -11 60 -2 -10 60 -2 minecraft:stone
fill -5 60 -2 -5 61 -2 minecraft:stone
fill 5 60 -2 5 62 -2 minecraft:stone
fill 7 60 -2 8 63 -2 minecraft:stone
fill 12 60 -2 14 61 -2 minecraft:stone
fill -12 60 -1 -12 64 -1 minecraft:stone
fill -8 60 -1 -8 65 -1 minecraft:stone
fill 14 60 -1 14 60 1 minecraft:stone
fill -14 60 0 -14 64 0 minecraft:stone
fill -14 60 2 -14 62 2 minecraft:stone
fill 12 60 2 12 60 8 minecraft:stone
fill -13 60 3 -12 60 4 minecraft:stone
fill 8 60 3 9 63 3 minecraft:stone
fill 11 60 3 11 60 4 minecraft:stone
fill 13 60 3 14 60 3 minecraft:stone
fill -11 60 4 -11 63 4 minecraft:stone
fill -9 60 4 -7 60 4 minecraft:stone
fill 10 60 4 10 64 4 minecraft:stone
fill 14 60 4 14 63 4 minecraft:stone
fill -14 60 5 -14 61 9 minecraft:stone
fill -12 60 5 -12 63 6 minecraft:stone
fill -10 60 5 -9 61 6 minecraft:stone
setblock -7 60 5 minecraft:stone
fill 8 60 5 9 64 5 minecraft:stone
fill 13 60 5 13 62 6 minecraft:stone
fill -13 60 6 -13 60 8 minecraft:stone
setblock -11 60 6 minecraft:stone
fill -6 60 6 -5 61 7 minecraft:stone
fill 6 60 6 8 60 6 minecraft:stone
fill 10 60 6 11 60 7 minecraft:stone
fill 14 60 6 14 63 9 minecraft:stone
fill -4 60 7 -3 61 8 minecraft:stone
fill 3 60 7 5 61 7 minecraft:stone
fill 8 60 7 9 60 9 minecraft:stone
fill -11 60 8 -9 62 8 minecraft:stone
fill 3 60 8 3 60 9 minecraft:stone
fill 5 60 8 5 60 9 minecraft:stone
fill 10 60 8 10 64 8 minecraft:stone
fill -11 60 9 -10 61 9 minecraft:stone
fill -7 60 9 -6 63 9 minecraft:stone
fill -4 60 9 -4 61 9 minecraft:stone
fill -2 60 9 -2 62 10 minecraft:stone
fill 2 60 9 2 62 10 minecraft:stone
fill 7 60 9 7 63 9 minecraft:stone
fill 13 60 9 13 63 10 minecraft:stone
fill -13 60 10 -13 61 13 minecraft:stone
fill -10 60 10 -9 61 11 minecraft:stone
fill -1 60 10 1 60 11 minecraft:stone
fill 4 60 10 4 62 12 minecraft:stone
fill 10 60 10 10 61 11 minecraft:stone
fill -14 60 11 -14 62 12 minecraft:stone
fill -11 60 11 -11 62 11 minecraft:stone
fill -8 60 11 -8 62 11 minecraft:stone
fill -6 60 11 -6 61 11 minecraft:stone
fill -3 60 11 -3 61 11 minecraft:stone
fill 3 60 11 3 62 11 minecraft:stone
fill 6 60 11 7 60 12 minecraft:stone
fill 11 60 11 11 62 11 minecraft:stone
fill 14 60 11 14 60 14 minecraft:stone
fill -12 60 12 -12 61 12 minecraft:stone
fill -10 60 12 -10 60 13 minecraft:stone
fill -7 60 12 -7 60 13 minecraft:stone
setblock -1 60 12 minecraft:stone
fill 1 60 12 1 61 12 minecraft:stone
fill 9 60 12 9 62 12 minecraft:stone
fill 13 60 12 13 62 12 minecraft:stone
fill -11 60 13 -11 62 14 minecraft:stone
fill -9 60 13 -8 60 14 minecraft:stone
fill -4 60 13 -4 62 13 minecraft:stone
fill 7 60 13 7 61 13 minecraft:stone
fill 11 60 13 12 61 13 minecraft:stone
setblock -14 60 14 minecraft:stone
setblock 0 60 14 minecraft:stone
fill 2 60 14 2 62 14 minecraft:stone
fill 4 60 14 4 62 14 minecraft:stone
fill 6 60 14 6 62 14 minecraft:stone
setblock 10 60 14 minecraft:stone
fill 12 60 14 12 62 14 minecraft:stone
setblock -2 60 -14 minecraft:tuff
fill 1 60 -14 2 60 -14 minecraft:tuff
setblock 13 60 -13 minecraft:tuff
setblock -5 60 -12 minecraft:tuff
setblock -10 60 -10 minecraft:tuff
setblock -11 60 -9 minecraft:tuff
setblock 12 60 -8 minecraft:tuff
setblock 14 60 -8 minecraft:tuff
setblock -13 60 -7 minecraft:tuff
setblock 8 60 -6 minecraft:tuff
setblock 10 60 -6 minecraft:tuff
setblock -4 60 -4 minecraft:tuff
setblock 6 60 -2 minecraft:tuff
setblock 9 60 6 minecraft:tuff
fill -11 60 7 -10 60 7 minecraft:tuff
setblock 7 60 8 minecraft:tuff
setblock -3 60 9 minecraft:tuff
setblock 5 60 10 minecraft:tuff
setblock 9 60 11 minecraft:tuff
setblock -11 60 12 minecraft:tuff
setblock -9 60 12 minecraft:tuff
setblock -4 60 12 minecraft:tuff
setblock 8 60 12 minecraft:tuff
setblock 10 60 12 minecraft:tuff
setblock 12 60 12 minecraft:tuff
fill -12 60 13 -12 61 13 minecraft:tuff
setblock -6 60 13 minecraft:tuff
setblock -3 61 -14 minecraft:andesite
fill -9 61 -13 -9 61 -12 minecraft:andesite
setblock 12 61 -13 minecraft:andesite
setblock 5 61 -12 minecraft:andesite
setblock 7 61 -12 minecraft:andesite
setblock 9 61 -12 minecraft:andesite
fill -14 61 -11 -13 61 -11 minecraft:andesite
setblock -11 61 -11 minecraft:andesite
setblock -5 61 -11 minecraft:andesite
fill -10 61 -9 -9 61 -9 minecraft:andesite
setblock 12 61 -9 minecraft:andesite
setblock -14 61 -6 minecraft:andesite
setblock -2 61 -5 minecraft:andesite
setblock 5 61 -5 minecraft:andesite
setblock 11 61 -5 minecraft:andesite
setblock -9 61 -4 minecraft:andesite
setblock 6 61 -4 minecraft:andesite
setblock 9 61 -3 minecraft:andesite
setblock -7 61 -2 minecraft:andesite
setblock -13 61 0 minecraft:andesite
setblock 14 61 0 minecraft:andesite
fill -14 61 3 -14 62 3 minecraft:andesite
setblock 11 61 3 minecraft:andesite
setblock -7 61 5 minecraft:andesite
setblock -11 61 6 minecraft:andesite
setblock 6 61 6 minecraft:andesite
fill 10 61 6 11 61 6 minecraft:andesite
setblock -13 61 7 minecraft:andesite
setblock 10 61 7 minecraft:andesite
setblock 5 61 8 minecraft:andesite
setblock -14 61 10 minecraft:andesite
setblock 9 61 10 minecraft:andesite
setblock 7 61 11 minecraft:andesite
fill 13 61 11 14 61 11 minecraft:andesite
setblock -11 61 12 minecraft:andesite
setblock -7 61 12 minecraft:andesite
setblock 8 61 12 minecraft:andesite
fill -14 61 14 -14 62 14 minecraft:andesite
setblock -9 61 14 minecraft:andesite
setblock -4 61 14 minecraft:andesite
setblock 0 61 14 minecraft:andesite
setblock 10 61 14 minecraft:andesite
setblock -13 61 1 minecraft:coal_ore
setblock 10 61 -14 minecraft:cobblestone
setblock -3 61 -13 minecraft:cobblestone
setblock -11 61 -12 minecraft:cobblestone
setblock -12 61 -11 minecraft:cobblestone
setblock -7 61 -11 minecraft:cobblestone
setblock -4 61 -11 minecraft:cobblestone
fill -8 61 -10 -8 61 -9 minecraft:cobblestone
setblock -14 61 -9 minecraft:cobblestone
setblock 11 61 -9 minecraft:cobblestone
setblock -12 61 -7 minecraft:cobblestone
setblock -10 61 -7 minecraft:cobblestone
setblock 7 61 -5 minecraft:cobblestone
setblock 12 61 -4 minecraft:cobblestone
setblock -13 61 2 minecraft:cobblestone
setblock 12 61 2 minecraft:cobblestone
setblock -9 61 4 minecraft:cobblestone
setblock 7 61 5 minecraft:cobblestone
setblock 5 61 6 minecraft:cobblestone
setblock -11 61 7 minecraft:cobblestone
setblock 12 61 7 minecraft:cobblestone
setblock -7 61 8 minecraft:cobblestone
setblock 3 61 8 minecraft:cobblestone
setblock 9 61 8 minecraft:cobblestone
setblock 11 61 9 minecraft:cobblestone
setblock -5 61 10 minecraft:cobblestone
fill -1 61 10 1 61 10 minecraft:cobblestone
setblock -9 61 12 minecraft:cobblestone
setblock -1 61 12 minecraft:cobblestone
setblock -14 61 13 minecraft:cobblestone
setblock -2 61 13 minecraft:cobblestone
fill 2 61 13 2 62 13 minecraft:cobblestone
setblock 3 61 14 minecraft:cobblestone
setblock 5 61 14 minecraft:cobblestone
setblock 14 61 14 minecraft:cobblestone
setblock 12 61 -3 minecraft:copper_ore
setblock 1 61 -13 minecraft:iron_ore
setblock 13 61 0 minecraft:iron_ore
fill -11 61 -14 -11 63 -14 minecraft:stone
fill -9 61 -14 -4 62 -14 minecraft:stone
setblock -2 61 -14 minecraft:stone
fill 1 61 -14 9 61 -14 minecraft:stone
fill 11 61 -14 12 63 -14 minecraft:stone
fill -5 61 -13 -4 61 -12 minecraft:stone
setblock 0 61 -13 minecraft:stone
setblock 2 61 -13 minecraft:stone
fill 5 61 -13 6 62 -13 minecraft:stone
fill 9 61 -13 11 61 -13 minecraft:stone
fill 13 61 -13 13 61 -12 minecraft:stone
fill -14 61 -12 -12 61 -12 minecraft:stone
fill -10 61 -12 -10 64 -10 minecraft:stone
fill -1 61 -12 -1 64 -12 minecraft:stone
fill 4 61 -12 4 64 -12 minecraft:stone
fill 6 61 -12 6 61 -11 minecraft:stone
fill 8 61 -12 8 64 -12 minecraft:stone
fill 10 61 -12 12 61 -11 minecraft:stone
fill -9 61 -11 -9 63 -10 minecraft:stone
fill -6 61 -11 -6 64 -11 minecraft:stone
fill 9 61 -11 9 64 -10 minecraft:stone
fill -14 61 -10 -11 61 -10 minecraft:stone
fill 11 61 -10 13 61 -10 minecraft:stone
fill -13 61 -9 -11 63 -9 minecraft:stone
fill -7 61 -9 -7 64 -9 minecraft:stone
fill -14 61 -8 -14 64 -7 minecraft:stone
fill -12 61 -8 -10 61 -8 minecraft:stone
fill 7 61 -8 8 62 -8 minecraft:stone
fill 11 61 -8 12 61 -6 minecraft:stone
fill 14 61 -8 14 63 -8 minecraft:stone
fill -13 61 -7 -13 61 -4 minecraft:stone
fill -11 61 -7 -11 64 -7 minecraft:stone
fill -9 61 -7 -9 63 -7 minecraft:stone
fill 8 61 -7 8 61 -3 minecraft:stone
fill 13 61 -7 13 64 -7 minecraft:stone
fill -12 61 -6 -12 61 -3 minecraft:stone
setblock -8 61 -6 minecraft:stone
fill -4 61 -6 -2 64 -6 minecraft:stone
fill 4 61 -6 6 61 -6 minecraft:stone
fill 10 61 -6 10 63 -5 minecraft:stone
fill -14 61 -5 -14 62 -4 minecraft:stone
fill -4 61 -5 -3 61 -4 minecraft:stone
fill 4 61 -5 4 61 -4 minecraft:stone
fill 6 61 -5 6 62 -5 minecraft:stone
fill 12 61 -5 12 64 -5 minecraft:stone
setblock -10 61 -4 minecraft:stone
setblock -8 61 -4 minecraft:stone
fill -2 61 -4 -2 65 -4 minecraft:stone
fill 5 61 -4 5 64 -4 minecraft:stone
fill 7 61 -4 7 64 -3 minecraft:stone
fill 9 61 -4 9 62 -4 minecraft:stone
fill 14 61 -4 14 64 -4 minecraft:stone
fill -7 61 -3 -7 64 -3 minecraft:stone
fill 6 61 -3 6 64 -2 minecraft:stone
fill -11 61 -2 -11 64 -2 minecraft:stone
setblock -8 61 -2 minecraft:stone
setblock -6 61 -2 minecraft:stone
fill 7 61 -1 7 63 -1 minecraft:stone
fill 13 61 -1 14 61 -1 minecraft:stone
fill -14 61 1 -14 64 1 minecraft:stone
fill 13 61 1 14 61 1 minecraft:stone
fill 13 61 2 13 61 4 minecraft:stone
fill -13 61 3 -12 64 3 minecraft:stone
fill 12 61 3 12 64 4 minecraft:stone
fill -14 61 4 -13 61 4 minecraft:stone
fill -8 61 4 -7 61 4 minecraft:stone
fill 7 61 4 7 64 4 minecraft:stone
fill 11 61 4 11 64 4 minecraft:stone
fill -8 61 5 -8 64 5 minecraft:stone
fill 14 61 5 14 64 5 minecraft:stone
fill -13 61 6 -13 64 6 minecraft:stone
fill -7 61 6 -7 62 7 minecraft:stone
fill 7 61 6 9 61 7 minecraft:stone
fill 12 61 6 12 64 6 minecraft:stone
fill -10 61 7 -10 63 7 minecraft:stone
fill -8 61 7 -8 64 7 minecraft:stone
fill 11 61 7 11 64 8 minecraft:stone
fill 13 61 7 13 64 7 minecraft:stone
fill -13 61 8 -13 62 9 minecraft:stone
fill -6 61 8 -5 64 8 minecraft:stone
setblock -2 61 8 minecraft:stone
setblock 2 61 8 minecraft:stone
fill 4 61 8 4 63 9 minecraft:stone
fill 7 61 8 8 64 8 minecraft:stone
fill 12 61 8 12 61 12 minecraft:stone
fill -9 61 9 -9 64 9 minecraft:stone
fill -5 61 9 -5 64 9 minecraft:stone
fill -3 61 9 -3 61 10 minecraft:stone
fill 3 61 9 3 62 9 minecraft:stone
fill 5 61 9 5 64 10 minecraft:stone
fill 8 61 9 10 61 9 minecraft:stone
fill -11 61 10 -11 63 10 minecraft:stone
fill -7 61 10 -6 62 10 minecraft:stone
fill -4 61 10 -4 62 12 minecraft:stone
fill 8 61 10 8 63 10 minecraft:stone
setblock 11 61 10 minecraft:stone
fill 14 61 10 14 63 10 minecraft:stone
fill -5 61 11 -5 62 11 minecraft:stone
fill -2 61 11 1 61 11 minecraft:stone
fill 6 61 11 6 62 13 minecraft:stone
fill 9 61 11 9 62 11 minecraft:stone
fill -8 61 12 -8 61 14 minecraft:stone
fill -3 61 12 -2 62 12 minecraft:stone
fill 3 61 12 3 62 13 minecraft:stone
fill 5 61 12 5 62 13 minecraft:stone
fill 7 61 12 7 62 12 minecraft:stone
fill 10 61 12 11 62 12 minecraft:stone
fill 14 61 12 14 62 13 minecraft:stone
fill -10 61 13 -9 61 13 minecraft:stone
fill -7 61 13 -6 62 13 minecraft:stone
fill 4 61 13 4 62 13 minecraft:stone
fill 8 61 13 8 61 14 minecraft:stone
setblock 10 61 13 minecraft:stone
fill -13 61 14 -12 62 14 minecraft:stone
setblock -10 61 14 minecraft:stone
fill -7 61 14 -7 62 14 minecraft:stone
fill 7 61 14 7 62 14 minecraft:stone
fill 9 61 14 9 62 14 minecraft:stone
fill 13 61 14 13 62 14 minecraft:stone
setblock -10 61 -14 minecraft:tuff
setblock 8 61 -11 minecraft:tuff
setblock 13 61 -11 minecraft:tuff
setblock 9 61 -9 minecraft:tuff
setblock 7 61 -6 minecraft:tuff
setblock 9 61 -6 minecraft:tuff
setblock -10 61 -5 minecraft:tuff
setblock 14 61 -3 minecraft:tuff
setblock -10 61 -2 minecraft:tuff
setblock 14 61 3 minecraft:tuff
setblock -12 61 4 minecraft:tuff
setblock -13 61 5 minecraft:tuff
setblock 12 61 5 minecraft:tuff
setblock 3 61 10 minecraft:tuff
setblock -10 61 12 minecraft:tuff
fill -3 61 13 -3 61 14 minecraft:tuff
setblock 9 61 13 minecraft:tuff
setblock 13 61 13 minecraft:tuff
setblock 5 62 -14 minecraft:andesite
setblock -13 62 -13 minecraft:andesite
fill -9 62 -13 -9 63 -13 minecraft:andesite
fill -3 62 -13 -3 62 -12 minecraft:andesite
setblock 2 62 -13 minecraft:andesite
setblock 8 62 -13 minecraft:andesite
setblock -11 62 -12 minecraft:andesite
setblock -5 62 -12 minecraft:andesite
setblock 11 62 -12 minecraft:andesite
setblock 14 62 -12 minecraft:andesite
setblock -14 62 -11 minecraft:andesite
setblock 13 62 -11 minecraft:andesite
setblock -7 62 -10 minecraft:andesite
setblock 14 62 -9 minecraft:andesite
setblock -8 62 -8 minecraft:andesite
fill 13 62 -8 13 63 -8 minecraft:andesite
fill -13 62 -7 -13 62 -6 minecraft:andesite
setblock 7 62 -7 minecraft:andesite
fill -3 62 -5 -3 62 -4 minecraft:andesite
setblock 13 62 -5 minecraft:andesite
fill -13 62 -4 -13 62 -3 minecraft:andesite
setblock -11 62 -4 minecraft:andesite
setblock 10 62 -4 minecraft:andesite
setblock -6 62 -3 minecraft:andesite
setblock 8 62 -3 minecraft:andesite
setblock -13 62 1 minecraft:andesite
setblock 14 62 3 minecraft:andesite
setblock -13 62 4 minecraft:andesite
setblock -9 62 5 minecraft:andesite
setblock 9 62 6 minecraft:andesite
fill -6 62 7 -5 62 7 minecraft:andesite
setblock 8 62 7 minecraft:andesite
setblock -14 62 8 minecraft:andesite
setblock -8 62 8 minecraft:andesite
setblock 2 62 8 minecraft:andesite
setblock -4 62 9 minecraft:andesite
setblock 9 62 9 minecraft:andesite
setblock -13 62 10 minecraft:andesite
setblock -5 62 10 minecraft:andesite
fill -3 62 10 -3 62 11 minecraft:andesite
setblock 10 62 10 minecraft:andesite
setblock -10 62 11 minecraft:andesite
setblock -6 62 11 minecraft:andesite
setblock -12 62 12 minecraft:andesite
setblock 1 62 12 minecraft:andesite
setblock -13 62 13 minecraft:andesite
setblock -10 62 13 minecraft:andesite
setblock -8 62 13 minecraft:andesite
setblock 10 62 13 minecraft:andesite
setblock -2 62 14 minecraft:andesite
setblock 5 62 14 minecraft:andesite
setblock 14 62 14 minecraft:andesite
setblock 4 62 -14 minecraft:cobblestone
setblock 10 62 -13 minecraft:cobblestone
setblock 13 62 -13 minecraft:cobblestone
setblock -12 62 -12 minecraft:cobblestone
setblock -12 62 -10 minecraft:cobblestone
setblock 7 62 -9 minecraft:cobblestone
setblock -12 62 -8 minecraft:cobblestone
setblock 9 62 -8 minecraft:cobblestone
setblock 12 62 -8 minecraft:cobblestone
setblock 11 62 -7 minecraft:cobblestone
setblock -10 62 -6 minecraft:cobblestone
setblock -8 62 -6 minecraft:cobblestone
setblock 4 62 -5 minecraft:cobblestone
fill -12 62 -4 -12 63 -4 minecraft:cobblestone
setblock -10 62 -4 minecraft:cobblestone
setblock -7 62 -4 minecraft:cobblestone
setblock 2 62 -4 minecraft:cobblestone
fill -6 62 -2 -5 62 -2 minecraft:cobblestone
setblock 13 62 1 minecraft:cobblestone
setblock 13 62 3 minecraft:cobblestone
fill 12 62 5 12 63 5 minecraft:cobblestone
setblock 3 62 7 minecraft:cobblestone
setblock -3 62 8 minecraft:cobblestone
setblock -11 62 9 minecraft:cobblestone
fill 11 62 10 11 63 10 minecraft:cobblestone
fill -1 62 11 1 62 11 minecraft:cobblestone
setblock -5 62 12 minecraft:cobblestone
setblock 12 62 12 minecraft:cobblestone
setblock -12 62 13 minecraft:cobblestone
setblock 11 62 13 minecraft:cobblestone
setblock 8 62 14 minecraft:cobblestone
setblock -10 62 -14 minecraft:stone
fill -3 62 -14 -3 64 -14 minecraft:stone
fill 0 62 -14 0 66 -14 minecraft:stone
fill 2 62 -14 3 64 -14 minecraft:stone
fill 6 62 -14 10 62 -14 minecraft:stone
fill -14 62 -13 -14 63 -12 minecraft:stone
setblock -12 62 -13 minecraft:stone
fill -8 62 -13 -7 62 -13 minecraft:stone
fill -5 62 -13 -4 63 -13 minecraft:stone
setblock 1 62 -13 minecraft:stone
fill 7 62 -13 7 63 -10 minecraft:stone
fill 9 62 -13 9 62 -12 minecraft:stone
fill 11 62 -13 12 64 -13 minecraft:stone
fill 14 62 -13 14 63 -13 minecraft:stone
fill -13 62 -12 -13 62 -10 minecraft:stone
fill -9 62 -12 -9 66 -12 minecraft:stone
fill -4 62 -12 -4 64 -11 minecraft:stone
setblock -2 62 -12 minecraft:stone
fill 5 62 -12 6 62 -12 minecraft:stone
fill 10 62 -12 10 64 -11 minecraft:stone
fill 12 62 -12 13 64 -12 minecraft:stone
fill -12 62 -11 -11 62 -11 minecraft:stone
fill -7 62 -11 -7 64 -11 minecraft:stone
fill -5 62 -11 -5 64 -11 minecraft:stone
setblock 8 62 -11 minecraft:stone
fill 12 62 -11 12 63 -9 minecraft:stone
fill 14 62 -11 14 63 -10 minecraft:stone
fill -14 62 -10 -14 65 -9 minecraft:stone
setblock -11 62 -10 minecraft:stone
fill -8 62 -10 -8 64 -9 minecraft:stone
fill -6 62 -10 -6 64 -10 minecraft:stone
fill 11 62 -10 11 63 -8 minecraft:stone
fill -10 62 -9 -9 62 -8 minecraft:stone
setblock 9 62 -9 minecraft:stone
fill 13 62 -9 13 65 -9 minecraft:stone
fill -11 62 -8 -11 64 -8 minecraft:stone
setblock -7 62 -8 minecraft:stone
fill 10 62 -8 10 64 -7 minecraft:stone
fill -12 62 -7 -12 62 -5 minecraft:stone
fill -10 62 -7 -10 64 -7 minecraft:stone
fill 6 62 -7 6 63 -6 minecraft:stone
fill 8 62 -7 9 64 -6 minecraft:stone
fill 12 62 -7 12 64 -6 minecraft:stone
fill -14 62 -6 -14 64 -6 minecraft:stone
fill -7 62 -6 -7 64 -5 minecraft:stone
fill 4 62 -6 4 64 -6 minecraft:stone
fill 7 62 -6 7 63 -5 minecraft:stone
fill 11 62 -6 11 64 -6 minecraft:stone
fill 13 62 -6 13 65 -6 minecraft:stone
setblock -13 62 -5 minecraft:stone
fill -11 62 -5 -10 62 -5 minecraft:stone
fill -4 62 -5 -4 62 -3 minecraft:stone
fill -2 62 -5 -2 64 -5 minecraft:stone
setblock 2 62 -5 minecraft:stone
fill 5 62 -5 5 64 -5 minecraft:stone
fill 8 62 -5 8 62 -4 minecraft:stone
fill -9 62 -4 -9 65 -4 minecraft:stone
fill -6 62 -4 -6 65 -4 minecraft:stone
fill 4 62 -4 4 63 -4 minecraft:stone
fill 6 62 -4 6 64 -4 minecraft:stone
fill 12 62 -4 13 64 -4 minecraft:stone
fill -14 62 -3 -14 64 -3 minecraft:stone
fill -12 62 -3 -11 63 -3 minecraft:stone
fill -5 62 -3 -5 64 -3 minecraft:stone
fill -3 62 -3 -3 64 -3 minecraft:stone
setblock 9 62 -3 minecraft:stone
fill 12 62 -3 12 63 -3 minecraft:stone
fill 14 62 -3 14 62 -2 minecraft:stone
fill -10 62 -2 -10 65 -2 minecraft:stone
setblock -7 62 -2 minecraft:stone
fill 13 62 -1 13 63 -1 minecraft:stone
fill -13 62 0 -13 64 0 minecraft:stone
fill 14 62 0 14 62 1 minecraft:stone
fill -13 62 2 -13 64 2 minecraft:stone
fill 12 62 2 13 63 2 minecraft:stone
fill 11 62 3 11 64 3 minecraft:stone
fill -14 62 4 -14 63 7 minecraft:stone
setblock -12 62 4 minecraft:stone
fill -10 62 4 -9 62 4 minecraft:stone
fill -7 62 4 -7 62 5 minecraft:stone
setblock 13 62 4 minecraft:stone
fill -13 62 5 -13 64 5 minecraft:stone
fill -10 62 5 -10 65 6 minecraft:stone
fill 7 62 5 7 63 7 minecraft:stone
fill -9 62 6 -9 63 7 minecraft:stone
fill -6 62 6 -5 63 6 minecraft:stone
fill 5 62 6 6 64 6 minecraft:stone
fill 8 62 6 8 65 6 minecraft:stone
fill 10 62 6 11 64 6 minecraft:stone
fill -13 62 7 -13 64 7 minecraft:stone
setblock -11 62 7 minecraft:stone
fill -4 62 7 -3 64 7 minecraft:stone
fill 4 62 7 5 62 7 minecraft:stone
fill 9 62 7 10 62 7 minecraft:stone
fill 12 62 7 12 62 11 minecraft:stone
fill -7 62 8 -7 64 8 minecraft:stone
fill -4 62 8 -4 64 8 minecraft:stone
fill 3 62 8 3 64 8 minecraft:stone
fill 5 62 8 5 63 8 minecraft:stone
fill 9 62 8 9 64 8 minecraft:stone
setblock 13 62 8 minecraft:stone
fill -14 62 9 -14 64 9 minecraft:stone
setblock -10 62 9 minecraft:stone
fill -8 62 9 -8 64 10 minecraft:stone
fill -3 62 9 -3 66 9 minecraft:stone
fill 8 62 9 8 64 9 minecraft:stone
fill 10 62 9 11 63 9 minecraft:stone
fill -9 62 10 -9 62 14 minecraft:stone
fill 3 62 10 3 64 10 minecraft:stone
fill 7 62 10 7 62 11 minecraft:stone
fill -13 62 11 -13 62 12 minecraft:stone
setblock -2 62 11 minecraft:stone
fill 8 62 11 8 62 13 minecraft:stone
setblock 10 62 11 minecraft:stone
fill 13 62 11 14 62 11 minecraft:stone
fill -11 62 12 -10 62 12 minecraft:stone
fill -8 62 12 -6 62 12 minecraft:stone
setblock -1 62 12 minecraft:stone
setblock -14 62 13 minecraft:stone
fill -3 62 13 -2 62 13 minecraft:stone
setblock 9 62 13 minecraft:stone
fill 12 62 13 13 62 13 minecraft:stone
setblock -8 62 14 minecraft:stone
fill -4 62 14 -3 62 14 minecraft:stone
fill 0 62 14 1 62 14 minecraft:stone
setblock 3 62 14 minecraft:stone
setblock 10 62 14 minecraft:stone
fill -2 62 -14 -1 62 -14 minecraft:tuff
setblock 1 62 -14 minecraft:tuff
setblock -6 62 -13 minecraft:tuff
setblock 0 62 -13 minecraft:tuff
setblock 6 62 -11 minecraft:tuff
setblock 11 62 -11 minecraft:tuff
setblock 13 62 -10 minecraft:tuff
setblock -11 62 -6 minecraft:tuff
setblock 5 62 -6 minecraft:tuff
setblock 11 62 -5 minecraft:tuff
setblock -8 62 -4 minecraft:tuff
setblock -12 62 -2 minecraft:tuff
setblock -8 62 -2 minecraft:tuff
fill 12 62 -2 13 62 -2 minecraft:tuff
setblock 14 62 -1 minecraft:tuff
setblock 13 62 0 minecraft:tuff
setblock -8 62 4 minecraft:tuff
fill -11 62 5 -11 62 6 minecraft:tuff
setblock -2 62 8 minecraft:tuff
setblock -14 62 10 minecraft:tuff
setblock -10 62 10 minecraft:tuff
setblock 9 62 10 minecraft:tuff
setblock 7 62 13 minecraft:tuff
setblock -10 62 14 minecraft:tuff
setblock -13 63 -14 minecraft:andesite
fill -8 63 -14 -8 64 -14 minecraft:andesite
fill 4 63 -14 4 63 -13 minecraft:andesite
setblock -12 63 -13 minecraft:andesite
setblock -1 63 -13 minecraft:andesite
setblock 1 63 -13 minecraft:andesite
setblock 5 63 -13 minecraft:andesite
setblock -13 63 -12 minecraft:andesite
fill -11 63 -11 -11 63 -10 minecraft:andesite
fill -6 63 -9 -5 63 -9 minecraft:andesite
fill 8 63 -9 9 63 -8 minecraft:andesite
setblock -7 63 -8 minecraft:andesite
setblock -6 63 -7 minecraft:andesite
setblock -4 63 -7 minecraft:andesite
setblock 14 63 -6 minecraft:andesite
fill -13 63 -5 -12 63 -5 minecraft:andesite
setblock 2 63 -5 minecraft:andesite
setblock 6 63 -5 minecraft:andesite
setblock -13 63 -4 minecraft:andesite
setblock 5 63 -2 minecraft:andesite
fill 14 63 -1 14 63 0 minecraft:andesite
fill -9 63 4 -8 63 4 minecraft:andesite
fill 13 63 4 13 63 6 minecraft:andesite
setblock 5 63 7 minecraft:andesite
setblock -9 63 8 minecraft:andesite
fill -13 63 9 -13 64 9 minecraft:andesite
setblock -10 63 9 minecraft:andesite
setblock 3 63 9 minecraft:andesite
setblock -7 63 10 minecraft:andesite
setblock -3 63 10 minecraft:andesite
fill 6 63 10 7 63 10 minecraft:andesite
setblock -10 63 -14 minecraft:cobblestone
setblock 9 63 -14 minecraft:cobblestone
setblock -7 63 -13 minecraft:cobblestone
setblock 6 63 -12 minecraft:cobblestone
setblock -14 63 -11 minecraft:cobblestone
setblock 8 63 -11 minecraft:cobblestone
setblock 13 63 -11 minecraft:cobblestone
setblock -11 63 -5 minecraft:cobblestone
setblock -5 63 -5 minecraft:cobblestone
setblock 8 63 -5 minecraft:cobblestone
fill -14 63 -4 -14 64 -4 minecraft:cobblestone
setblock 9 63 -3 minecraft:cobblestone
fill -8 63 -2 -7 63 -2 minecraft:cobblestone
setblock 13 63 -2 minecraft:cobblestone
setblock 13 63 0 minecraft:cobblestone
setblock -14 63 2 minecraft:cobblestone
setblock -12 63 4 minecraft:cobblestone
fill -7 63 5 -7 63 6 minecraft:cobblestone
setblock -11 63 7 minecraft:cobblestone
setblock 4 63 7 minecraft:cobblestone
setblock 13 63 8 minecraft:cobblestone
setblock -12 63 9 minecraft:cobblestone
setblock -2 63 9 minecraft:cobblestone
setblock 2 63 10 minecraft:cobblestone
fill -1 63 12 1 63 12 minecraft:cobblestone
fill -14 63 11 -2 63 14 minecraft:dirt
fill 2 63 11 14 63 14 minecraft:dirt
fill -1 63 13 1 63 14 minecraft:dirt
fill -14 63 -14 -14 64 -14 minecraft:stone
fill -9 63 -14 -9 66 -14 minecraft:stone
fill -7 63 -14 -4 64 -14 minecraft:stone
fill -2 63 -14 -1 63 -14 minecraft:stone
setblock 1 63 -14 minecraft:stone
fill 5 63 -14 8 64 -14 minecraft:stone
fill 10 63 -14 10 63 -13 minecraft:stone
fill 14 63 -14 14 66 -14 minecraft:stone
fill -13 63 -13 -13 64 -13 minecraft:stone
fill -8 63 -13 -8 64 -13 minecraft:stone
setblock -6 63 -13 minecraft:stone
fill -3 63 -13 -2 64 -13 minecraft:stone
setblock 0 63 -13 minecraft:stone
fill 2 63 -13 3 63 -13 minecraft:stone
setblock 6 63 -13 minecraft:stone
setblock 8 63 -13 minecraft:stone
fill 13 63 -13 13 66 -13 minecraft:stone
fill -12 63 -12 -11 63 -12 minecraft:stone
fill -5 63 -12 -5 64 -12 minecraft:stone
fill -3 63 -12 -3 65 -12 minecraft:stone
setblock 5 63 -12 minecraft:stone
fill 9 63 -12 9 65 -12 minecraft:stone
fill 11 63 -12 11 64 -11 minecraft:stone
setblock 14 63 -12 minecraft:stone
fill -12 63 -11 -12 63 -10 minecraft:stone
setblock 6 63 -11 minecraft:stone
fill -7 63 -10 -7 64 -10 minecraft:stone
fill -5 63 -10 -5 65 -10 minecraft:stone
fill 8 63 -10 8 64 -10 minecraft:stone
fill 13 63 -10 13 64 -10 minecraft:stone
fill -10 63 -9 -9 64 -9 minecraft:stone
fill 7 63 -9 7 64 -7 minecraft:stone
fill 14 63 -9 14 64 -9 minecraft:stone
fill -12 63 -8 -12 64 -6 minecraft:stone
fill -9 63 -8 -8 64 -8 minecraft:stone
fill -5 63 -8 -5 64 -6 minecraft:stone
setblock 12 63 -8 minecraft:stone
fill -13 63 -7 -13 64 -6 minecraft:stone
fill 11 63 -7 11 64 -7 minecraft:stone
fill 14 63 -7 14 64 -7 minecraft:stone
fill -11 63 -6 -10 64 -6 minecraft:stone
fill -8 63 -6 -8 64 -6 minecraft:stone
setblock 5 63 -6 minecraft:stone
fill -14 63 -5 -14 64 -5 minecraft:stone
fill -10 63 -5 -10 63 -3 minecraft:stone
fill -4 63 -5 -3 64 -4 minecraft:stone
fill 4 63 -5 4 64 -5 minecraft:stone
fill 11 63 -5 11 64 -5 minecraft:stone
fill 13 63 -5 14 63 -5 minecraft:stone
fill -11 63 -4 -11 64 -4 minecraft:stone
fill -8 63 -4 -7 64 -4 minecraft:stone
fill 2 63 -4 2 64 -4 minecraft:stone
fill 8 63 -4 8 64 -3 minecraft:stone
fill 10 63 -4 10 64 -4 minecraft:stone
fill -13 63 -3 -13 65 -3 minecraft:stone
fill -6 63 -3 -6 64 -2 minecraft:stone
fill -12 63 -2 -12 64 -2 minecraft:stone
fill -5 63 -2 -5 64 -2 minecraft:stone
fill 12 63 -2 12 64 -2 minecraft:stone
fill -13 63 1 -13 64 1 minecraft:stone
fill 13 63 1 14 65 1 minecraft:stone
fill -14 63 3 -14 65 3 minecraft:stone
fill 13 63 3 14 64 3 minecraft:stone
setblock -13 63 4 minecraft:stone
fill -10 63 4 -10 65 4 minecraft:stone
setblock -7 63 4 minecraft:stone
fill 9 63 4 9 64 4 minecraft:stone
fill -11 63 5 -11 64 6 minecraft:stone
fill 10 63 5 10 64 5 minecraft:stone
setblock 9 63 6 minecraft:stone
fill -12 63 7 -12 64 8 minecraft:stone
fill -6 63 7 -5 64 7 minecraft:stone
fill 3 63 7 3 64 7 minecraft:stone
fill 6 63 7 6 63 9 minecraft:stone
fill 8 63 7 8 64 7 minecraft:stone
fill 10 63 7 10 64 7 minecraft:stone
fill 12 63 7 12 63 10 minecraft:stone
fill -13 63 8 -13 64 8 minecraft:stone
fill -11 63 8 -10 64 8 minecraft:stone
fill -8 63 8 -8 66 8 minecraft:stone
fill -3 63 8 -2 63 8 minecraft:stone
setblock -11 63 9 minecraft:stone
fill -4 63 9 -4 64 10 minecraft:stone
fill 9 63 9 9 63 10 minecraft:stone
fill -14 63 10 -12 63 10 minecraft:stone
fill -10 63 10 -9 64 10 minecraft:stone
fill -6 63 10 -5 64 10 minecraft:stone
setblock -2 63 10 minecraft:stone
fill 4 63 10 4 64 10 minecraft:stone
fill 10 63 10 10 64 10 minecraft:stone
setblock 13 63 -14 minecraft:tuff
setblock 9 63 -13 minecraft:tuff
setblock -2 63 -12 minecraft:tuff
fill -13 63 -11 -13 63 -10 minecraft:tuff
fill -10 63 -8 -10 64 -8 minecraft:tuff
setblock -5 63 -4 minecraft:tuff
setblock 9 63 -4 minecraft:tuff
setblock -4 63 -3 minecraft:tuff
setblock 4 63 -3 minecraft:tuff
fill 14 63 -3 14 63 -2 minecraft:tuff
setblock 8 63 4 minecraft:tuff
setblock -9 63 5 minecraft:tuff
setblock 11 63 5 minecraft:tuff
setblock -7 63 7 minecraft:tuff
setblock 9 63 7 minecraft:tuff
setblock -14 63 8 minecraft:tuff
fill 2 63 8 2 63 9 minecraft:tuff
setblock -11 64 -14 minecraft:andesite
setblock -2 64 -14 minecraft:andesite
setblock 1 64 -14 minecraft:andesite
setblock -10 64 -13 minecraft:andesite
setblock -5 64 -13 minecraft:andesite
setblock 6 64 -13 minecraft:andesite
fill 10 64 -13 10 65 -13 minecraft:andesite
setblock 14 64 -13 minecraft:andesite
setblock -14 64 -12 minecraft:andesite
setblock -12 64 -12 minecraft:andesite
setblock 5 64 -12 minecraft:andesite
setblock 6 64 -11 minecraft:andesite
setblock 13 64 -11 minecraft:andesite
setblock -12 64 -10 minecraft:andesite
setblock -9 64 -10 minecraft:andesite
setblock 12 64 -10 minecraft:andesite
setblock 8 64 -8 minecraft:andesite
fill -6 64 -6 -6 64 -5 minecraft:andesite
fill 5 64 -6 7 64 -6 minecraft:andesite
setblock -11 64 -5 minecraft:andesite
setblock 8 64 -5 minecraft:andesite
setblock 4 64 -4 minecraft:andesite
setblock -10 64 -3 minecraft:andesite
setblock 5 64 -3 minecraft:andesite
setblock 9 64 -3 minecraft:andesite
setblock 12 64 -3 minecraft:andesite
setblock 7 64 -2 minecraft:andesite
setblock 13 64 -1 minecraft:andesite
setblock 14 64 0 minecraft:andesite
setblock 12 64 2 minecraft:andesite
setblock 14 64 2 minecraft:andesite
setblock -13 64 4 minecraft:andesite
setblock -9 64 5 minecraft:andesite
setblock 7 64 5 minecraft:andesite
setblock -12 64 6 minecraft:andesite
setblock -6 64 6 minecraft:andesite
fill 14 64 6 14 64 7 minecraft:andesite
setblock 4 64 7 minecraft:andesite
setblock 6 64 7 minecraft:andesite
setblock -6 64 9 minecraft:andesite
setblock 9 64 9 minecraft:andesite
fill 11 64 9 11 64 10 minecraft:andesite
setblock -11 64 10 minecraft:andesite
setblock 14 64 10 minecraft:andesite
setblock 12 64 -14 minecraft:cobblestone
setblock -6 64 -13 minecraft:cobblestone
setblock 0 64 -13 minecraft:cobblestone
setblock 2 64 -13 minecraft:cobblestone
setblock 7 64 -13 minecraft:cobblestone
setblock -11 64 -12 minecraft:cobblestone
setblock -2 64 -12 minecraft:cobblestone
setblock 7 64 -10 minecraft:cobblestone
setblock 11 64 -10 minecraft:cobblestone
setblock -4 64 -7 minecraft:cobblestone
setblock 14 64 -5 minecraft:cobblestone
setblock -10 64 -4 minecraft:cobblestone
setblock -11 64 -3 minecraft:cobblestone
setblock -9 64 -3 minecraft:cobblestone
setblock 14 64 -3 minecraft:cobblestone
setblock 7 64 -1 minecraft:cobblestone
setblock -8 64 4 minecraft:cobblestone
setblock -14 64 6 minecraft:cobblestone
setblock 9 64 6 minecraft:cobblestone
fill -10 64 7 -9 64 7 minecraft:cobblestone
setblock -11 64 9 minecraft:cobblestone
setblock 4 64 9 minecraft:cobblestone
setblock 13 64 9 minecraft:cobblestone
setblock -14 64 10 minecraft:cobblestone
setblock 8 64 10 minecraft:cobblestone
setblock 12 64 10 minecraft:cobblestone
fill -14 64 11 -2 64 14 minecraft:grass_block
fill 2 64 11 14 64 14 minecraft:grass_block
fill -1 64 13 1 64 14 minecraft:grass_block
setblock -13 64 -14 minecraft:stone
fill -10 64 -14 -10 65 -14 minecraft:stone
fill -1 64 -14 -1 65 -13 minecraft:stone
fill 4 64 -14 4 64 -13 minecraft:stone
fill 9 64 -14 11 64 -14 minecraft:stone
setblock 13 64 -14 minecraft:stone
fill -14 64 -13 -14 65 -13 minecraft:stone
fill -12 64 -13 -11 64 -13 minecraft:stone
setblock -9 64 -13 minecraft:stone
setblock -4 64 -13 minecraft:stone
setblock 1 64 -13 minecraft:stone
setblock 3 64 -13 minecraft:stone
setblock 5 64 -13 minecraft:stone
setblock 9 64 -13 minecraft:stone
fill -13 64 -12 -13 64 -9 minecraft:stone
setblock -8 64 -12 minecraft:stone
fill 6 64 -12 7 64 -12 minecraft:stone
setblock -14 64 -11 minecraft:stone
fill -12 64 -11 -11 64 -11 minecraft:stone
setblock -9 64 -11 minecraft:stone
fill 7 64 -11 8 64 -11 minecraft:stone
setblock 12 64 -11 minecraft:stone
setblock -11 64 -10 minecraft:stone
setblock 14 64 -10 minecraft:stone
setblock -12 64 -9 minecraft:stone
fill -6 64 -9 -5 64 -9 minecraft:stone
setblock 8 64 -9 minecraft:stone
fill 11 64 -9 12 64 -9 minecraft:stone
setblock -7 64 -8 minecraft:stone
fill 9 64 -8 9 65 -8 minecraft:stone
setblock 11 64 -8 minecraft:stone
setblock 13 64 -8 minecraft:stone
setblock -6 64 -7 minecraft:stone
setblock 6 64 -7 minecraft:stone
fill 14 64 -6 14 65 -6 minecraft:stone
fill -13 64 -5 -12 64 -4 minecraft:stone
setblock -10 64 -5 minecraft:stone
fill -5 64 -5 -5 64 -4 minecraft:stone
setblock 2 64 -5 minecraft:stone
fill 6 64 -5 7 64 -5 minecraft:stone
setblock 10 64 -5 minecraft:stone
setblock 13 64 -5 minecraft:stone
setblock 9 64 -4 minecraft:stone
fill -12 64 -3 -12 65 -3 minecraft:stone
setblock -4 64 -3 minecraft:stone
setblock 4 64 -3 minecraft:stone
fill -9 64 -2 -7 64 -2 minecraft:stone
fill 5 64 -2 5 65 -2 minecraft:stone
setblock 8 64 -2 minecraft:stone
fill 13 64 -2 14 64 -2 minecraft:stone
setblock 14 64 -1 minecraft:stone
setblock 13 64 0 minecraft:stone
setblock -14 64 2 minecraft:stone
setblock 13 64 2 minecraft:stone
setblock 9 64 3 minecraft:stone
fill -14 64 4 -14 64 5 minecraft:stone
fill -12 64 4 -12 64 5 minecraft:stone
setblock -9 64 4 minecraft:stone
setblock 8 64 4 minecraft:stone
fill 13 64 4 13 64 6 minecraft:stone
fill -7 64 5 -7 64 7 minecraft:stone
fill 11 64 5 12 64 5 minecraft:stone
setblock -9 64 6 minecraft:stone
setblock -5 64 6 minecraft:stone
fill 7 64 6 7 64 7 minecraft:stone
fill -14 64 7 -14 64 8 minecraft:stone
fill -11 64 7 -11 66 7 minecraft:stone
setblock 5 64 7 minecraft:stone
setblock 9 64 7 minecraft:stone
fill 12 64 7 12 64 8 minecraft:stone
setblock -9 64 8 minecraft:stone
fill -2 64 8 -2 64 9 minecraft:stone
fill 2 64 8 2 64 10 minecraft:stone
setblock 4 64 8 minecraft:stone
fill 6 64 8 6 64 10 minecraft:stone
fill 13 64 8 14 65 8 minecraft:stone
fill -12 64 9 -12 64 10 minecraft:stone
fill -10 64 9 -10 65 9 minecraft:stone
fill -7 64 9 -7 64 10 minecraft:stone
setblock 3 64 9 minecraft:stone
fill 10 64 9 10 66 9 minecraft:stone
setblock 14 64 9 minecraft:stone
setblock -13 64 10 minecraft:stone
fill -3 64 10 -3 65 10 minecraft:stone
setblock 7 64 10 minecraft:stone
setblock 13 64 10 minecraft:stone
fill -7 64 -13 -7 64 -12 minecraft:tuff
setblock 8 64 -13 minecraft:tuff
fill 14 64 -12 14 64 -11 minecraft:tuff
setblock -11 64 -9 minecraft:tuff
setblock 9 64 -9 minecraft:tuff
setblock 12 64 -8 minecraft:tuff
setblock 14 64 -8 minecraft:tuff
setblock -9 64 -7 minecraft:tuff
setblock 10 64 -6 minecraft:tuff
setblock 13 64 -3 minecraft:tuff
setblock 8 64 3 minecraft:tuff
setblock -11 64 4 minecraft:tuff
setblock -7 64 4 minecraft:tuff
setblock 14 64 4 minecraft:tuff
setblock -3 64 8 minecraft:tuff
setblock 5 64 8 minecraft:tuff
setblock 7 64 9 minecraft:tuff
setblock 12 64 9 minecraft:tuff
setblock -2 64 10 minecraft:tuff
setblock 9 64 10 minecraft:tuff
setblock -13 65 -13 minecraft:andesite
setblock -10 65 -6 minecraft:andesite
setblock 6 65 -6 minecraft:andesite
setblock -14 65 -5 minecraft:andesite
setblock 8 65 -4 minecraft:andesite
setblock 11 65 7 minecraft:andesite
setblock 6 65 9 minecraft:andesite
setblock -8 65 -11 minecraft:cobblestone
setblock 9 65 -6 minecraft:cobblestone
setblock -13 65 -4 minecraft:cobblestone
setblock 6 65 -2 minecraft:cobblestone
setblock -12 65 3 minecraft:cobblestone
setblock 9 65 4 minecraft:cobblestone
setblock -6 65 7 minecraft:cobblestone
setblock 7 65 7 minecraft:cobblestone
setblock -7 65 8 minecraft:cobblestone
setblock 12 65 9 minecraft:cobblestone
setblock 11 65 10 minecraft:cobblestone
fill -12 65 -14 -12 66 -14 minecraft:stone
setblock -7 65 -14 minecraft:stone
setblock -4 65 -14 minecraft:stone
setblock 3 65 -14 minecraft:stone
fill 9 65 -14 9 66 -14 minecraft:stone
setblock 11 65 -14 minecraft:stone
setblock -10 65 -13 minecraft:stone
setblock -3 65 -13 minecraft:stone
setblock 2 65 -13 minecraft:stone
setblock 12 65 -13 minecraft:stone
setblock -14 65 -12 minecraft:stone
fill 10 65 -12 10 66 -12 minecraft:stone
setblock 14 65 -12 minecraft:stone
setblock -10 65 -11 minecraft:stone
setblock -4 65 -11 minecraft:stone
setblock 7 65 -11 minecraft:stone
fill -9 65 -10 -9 66 -10 minecraft:stone
setblock 12 65 -10 minecraft:stone
fill -5 65 -9 -5 65 -7 minecraft:stone
setblock 11 65 -9 minecraft:stone
setblock 14 65 -8 minecraft:stone
setblock -13 65 -7 minecraft:stone
setblock 12 65 -7 minecraft:stone
fill -4 65 -6 -3 65 -6 minecraft:stone
setblock 3 65 -6 minecraft:stone
setblock -12 65 -5 minecraft:stone
fill -8 65 -5 -8 65 -4 minecraft:stone
setblock -6 65 -5 minecraft:stone
setblock -3 65 -5 minecraft:stone
setblock 14 65 -5 minecraft:stone
setblock -5 65 -4 minecraft:stone
fill 3 65 -4 3 65 -3 minecraft:stone
fill -10 65 -3 -10 66 -3 minecraft:stone
setblock -6 65 -3 minecraft:stone
fill 5 65 -3 5 66 -3 minecraft:stone
setblock 9 65 -3 minecraft:stone
setblock -13 65 -1 minecraft:stone
setblock 7 65 -1 minecraft:stone
fill 13 65 4 13 65 5 minecraft:stone
fill -7 65 5 -7 65 6 minecraft:stone
setblock 12 65 5 minecraft:stone
setblock -11 65 6 minecraft:stone
setblock 6 65 6 minecraft:stone
fill 9 65 6 10 65 6 minecraft:stone
setblock -14 65 7 minecraft:stone
setblock -12 65 7 minecraft:stone
fill -10 65 7 -10 66 7 minecraft:stone
setblock -3 65 7 minecraft:stone
fill -2 65 8 -2 66 8 minecraft:stone
fill 7 65 8 7 65 9 minecraft:stone
setblock 12 65 8 minecraft:stone
fill -13 65 9 -12 65 9 minecraft:stone
setblock -4 65 9 minecraft:stone
setblock 5 65 9 minecraft:stone
fill 13 65 9 13 66 9 minecraft:stone
setblock -11 65 10 minecraft:stone
setblock -9 65 10 minecraft:stone
setblock 2 65 10 minecraft:stone
setblock 12 65 10 minecraft:stone
setblock 14 65 10 minecraft:stone
setblock 8 65 -9 minecraft:tuff
setblock 7 65 -6 minecraft:tuff
setblock 2 65 -4 minecraft:tuff
setblock 14 65 -4 minecraft:tuff
setblock 12 65 -3 minecraft:tuff
setblock -5 65 10 minecraft:tuff
setblock -13 66 -3 minecraft:andesite
setblock -14 66 3 minecraft:andesite
setblock 13 66 8 minecraft:andesite
setblock -14 66 -12 minecraft:cobblestone
setblock -3 66 -12 minecraft:cobblestone
setblock -13 66 -1 minecraft:cobblestone
fill -5 66 -9 -5 66 -8 minecraft:stone
setblock 13 66 1 minecraft:stone
setblock -12 66 3 minecraft:stone
setblock -7 66 6 minecraft:stone
setblock 10 66 6 minecraft:stone
setblock -6 66 7 minecraft:stone
setblock -12 66 9 minecraft:stone
setblock 7 66 9 minecraft:stone
setblock 12 66 9 minecraft:stone
setblock -10 66 -6 minecraft:tuff
setblock 14 66 -6 minecraft:tuff
setblock 0 59 -6 minecraft:gravel
setblock 1 59 -4 minecraft:gravel
setblock -9 59 -1 minecraft:gravel
setblock 11 59 0 minecraft:gravel
setblock -10 59 1 minecraft:gravel
setblock -2 59 3 minecraft:gravel
setblock -3 59 4 minecraft:gravel
setblock 1 59 4 minecraft:gravel
setblock 5 60 -8 minecraft:pointed_dripstone[thickness=tip,vertical_direction=up]
setblock -4 60 -1 minecraft:pointed_dripstone[thickness=tip,vertical_direction=up]
setblock 6 60 5 minecraft:pointed_dripstone[thickness=tip,vertical_direction=up]
setblock 3 60 6 minecraft:pointed_dripstone[thickness=tip,vertical_direction=up]
fill -4 59 -10 -3 59 -9 minecraft:lava
