data modify storage ek:s bstatus set value "더 안쪽으로 가는 중"
data modify storage ek:s status set value "더 안쪽으로 가는 중"
scoreboard players set #f_dark ek 1
scoreboard players set #f_maze ek 1
scoreboard players set #prog ek 57
tp @e[tag=ek.tgt,limit=1] 1.5 60 -11.5
scoreboard players set #tx ek 150
scoreboard players set #tz ek -1150
