execute if score #at ek matches 1 run function ek:steve/say {t:"용암 옆이네. 조심조심"}
execute if score #at ek matches 1 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing 1.5 61.5 -12.5
execute if score #at ek matches 48 run setblock 1 61 -13 minecraft:air destroy
execute if score #at ek matches 49 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing 1.5 60.5 -12.5
execute if score #at ek matches 96 run setblock 1 60 -13 minecraft:air destroy
execute if score #at ek matches 97 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing 0.5 60.5 -12.5
execute if score #at ek matches 144 run setblock 0 60 -13 minecraft:air destroy
execute if score #m6 ek matches 0 run swing @e[tag=ek.steve,limit=1] mainhand
execute if score #m6 ek matches 0 run execute as @a at @s run playsound minecraft:block.stone.hit master @s ~ ~ ~ 0.6 1
execute if score #at ek matches 1..48 if score #m6 ek matches 0 run particle minecraft:block{block_state:"minecraft:iron_ore"} 1.5 61.5 -12.5 0.3 0.3 0.3 0 6 force
execute if score #at ek matches 49..96 if score #m6 ek matches 0 run particle minecraft:block{block_state:"minecraft:iron_ore"} 1.5 60.5 -12.5 0.3 0.3 0.3 0 6 force
execute if score #at ek matches 97..144 if score #m6 ek matches 0 run particle minecraft:block{block_state:"minecraft:iron_ore"} 0.5 60.5 -12.5 0.3 0.3 0.3 0 6 force
