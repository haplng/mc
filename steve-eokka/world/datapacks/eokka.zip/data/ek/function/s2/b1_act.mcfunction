data modify storage ek:s bstatus set value "횃불 꽂는 중"
data modify storage ek:s status set value "횃불 꽂는 중"
function ek:beat/flags_clear
scoreboard players set #f_dark ek 1
scoreboard players set #alen ek 29
