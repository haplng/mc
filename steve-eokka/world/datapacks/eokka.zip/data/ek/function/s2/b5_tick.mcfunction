execute if score #at ek matches 1 run function ek:steve/say {t:"철이다! 4개"}
execute if score #at ek matches 1 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing 13.5 61.5 0.5
execute if score #at ek matches 48 run setblock 13 61 0 minecraft:air destroy
execute if score #at ek matches 49 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing 13.5 60.5 0.5
execute if score #at ek matches 96 run setblock 13 60 0 minecraft:air destroy
execute if score #at ek matches 97 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing 13.5 60.5 -0.5
execute if score #at ek matches 144 run setblock 13 60 -1 minecraft:air destroy
execute if score #at ek matches 145 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing 13.5 60.5 1.5
execute if score #at ek matches 192 run setblock 13 60 1 minecraft:air destroy
execute if score #m6 ek matches 0 run swing @e[tag=ek.steve,limit=1] mainhand
execute if score #m6 ek matches 0 run execute as @a at @s run playsound minecraft:block.stone.hit master @s ~ ~ ~ 0.6 1
execute if score #at ek matches 1..48 if score #m6 ek matches 0 run particle minecraft:block{block_state:"minecraft:iron_ore"} 13.5 61.5 0.5 0.3 0.3 0.3 0 6 force
execute if score #at ek matches 49..96 if score #m6 ek matches 0 run particle minecraft:block{block_state:"minecraft:iron_ore"} 13.5 60.5 0.5 0.3 0.3 0.3 0 6 force
execute if score #at ek matches 97..144 if score #m6 ek matches 0 run particle minecraft:block{block_state:"minecraft:iron_ore"} 13.5 60.5 -0.5 0.3 0.3 0.3 0 6 force
execute if score #at ek matches 145..192 if score #m6 ek matches 0 run particle minecraft:block{block_state:"minecraft:iron_ore"} 13.5 60.5 1.5 0.3 0.3 0.3 0 6 force
