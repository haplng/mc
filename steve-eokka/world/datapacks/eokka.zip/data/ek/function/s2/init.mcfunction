scoreboard players set #blen ek 14
scoreboard players set #armor ek 0
