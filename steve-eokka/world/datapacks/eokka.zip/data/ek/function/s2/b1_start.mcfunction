data modify storage ek:s bstatus set value "동굴로 내려가는 중"
data modify storage ek:s status set value "동굴로 내려가는 중"
scoreboard players set #f_dark ek 1
scoreboard players set #prog ek 7
tp @e[tag=ek.tgt,limit=1] 0.5 60 7.5
scoreboard players set #tx ek 50
scoreboard players set #tz ek 750
