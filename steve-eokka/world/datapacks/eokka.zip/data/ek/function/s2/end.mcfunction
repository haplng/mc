execute if score #beat ek matches 11 run return run function ek:s2/b11_end
