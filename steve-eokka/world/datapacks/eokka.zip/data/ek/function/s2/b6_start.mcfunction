data modify storage ek:s bstatus set value "더 안쪽으로 가는 중"
data modify storage ek:s status set value "더 안쪽으로 가는 중"
scoreboard players set #f_dark ek 1
scoreboard players set #f_maze ek 1
scoreboard players set #prog ek 42
tp @e[tag=ek.tgt,limit=1] 0.5 60 1.5
scoreboard players set #tx ek 50
scoreboard players set #tz ek 150
