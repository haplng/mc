execute if score #at ek matches 12 run function ek:steve/say {t:"동굴 입장. 철 나와라"}
execute if score #m10 ek matches 0 run execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ ~50 ~
