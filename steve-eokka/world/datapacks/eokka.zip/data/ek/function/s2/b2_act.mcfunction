data modify storage ek:s bstatus set value "석탄 발견"
data modify storage ek:s status set value "석탄 발견"
function ek:beat/flags_clear
scoreboard players set #f_dark ek 1
scoreboard players set #f_maze ek 1
scoreboard players set #alen ek 1
