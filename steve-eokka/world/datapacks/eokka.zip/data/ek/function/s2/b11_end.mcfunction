item replace entity @e[tag=ek.steve,limit=1] weapon.mainhand with minecraft:iron_pickaxe
scoreboard players set #armor ek 1
function ek:steve/equip
execute at @e[tag=ek.steve,limit=1] positioned ~ ~2.6 ~ run function ek:fx/popup {t:"철 곡괭이 · 철 흉갑 · 양동이",c:"aqua",s:"3"}
function ek:steve/say {t:"철 장비 완성. 이제 다이아"}
execute unless score #ho_iron ek matches 1 run function ek:game/ho_iron
