data modify storage ek:s bstatus set value "철 장비 조합 중"
data modify storage ek:s status set value "철 장비 조합 중"
function ek:beat/flags_clear
scoreboard players set #f_busy ek 1
scoreboard players set #f_dark ek 1
scoreboard players set #alen ek 72
execute as @e[tag=ek.steve,limit=1] at @s run tp @s ~ ~ ~ facing -0.5 60.5 2.5
