data modify storage ek:s bstatus set value "더 깊은 굴을 찾는 중"
data modify storage ek:s status set value "더 깊은 굴을 찾는 중"
scoreboard players set #f_dark ek 1
scoreboard players set #f_maze ek 1
scoreboard players set #prog ek 92
tp @e[tag=ek.tgt,limit=1] 5.5 60 -10.5
scoreboard players set #tx ek 550
scoreboard players set #tz ek -1050
