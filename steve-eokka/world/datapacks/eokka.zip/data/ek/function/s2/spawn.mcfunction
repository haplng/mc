execute positioned 0.5 65 13.5 run function ek:steve/summon
item replace entity @e[tag=ek.steve,limit=1] weapon.mainhand with minecraft:stone_pickaxe
