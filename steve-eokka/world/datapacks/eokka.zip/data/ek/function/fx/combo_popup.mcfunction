$execute positioned 0.5 74.5 0.5 run function ek:fx/popup {t:"$(c)콤보!",c:"gold",s:"3.5"}
$data modify storage ek:s ab.combo set value "   $(c)콤보"
execute as @a at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.8 1.5
