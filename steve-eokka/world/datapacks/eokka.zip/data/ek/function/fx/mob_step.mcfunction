execute if entity @s[tag=!ek.fast] facing entity @e[tag=ek.steve,limit=1] feet rotated ~ 0 run tp @s ^ ^ ^0.17 ~ ~
execute if entity @s[tag=ek.fast] facing entity @e[tag=ek.steve,limit=1] feet rotated ~ 0 run tp @s ^ ^ ^0.3 ~ ~
execute at @s unless block ~ ~ ~ #ek:pass run return run tp @s ~ ~1 ~
execute at @s if block ~ ~-1 ~ #ek:pass run tp @s ~ ~-1 ~
