$summon text_display ~ ~ ~ {Tags:["ek.tmp","ek.rise","ek.new"],billboard:"center",line_width:400,background:0,shadow:1b,view_range:4f,brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[$(s)f,$(s)f,$(s)f]},text:{text:"$(t)",color:"$(c)",bold:true}}
scoreboard players set @e[tag=ek.new] ek.life 45
tag @e[tag=ek.new] remove ek.new
