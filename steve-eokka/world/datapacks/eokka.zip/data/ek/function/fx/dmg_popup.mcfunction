$execute positioned 0.5 71 0.5 run function ek:fx/popup {t:"멘탈 -$(n)",c:"red",s:"4.5"}
