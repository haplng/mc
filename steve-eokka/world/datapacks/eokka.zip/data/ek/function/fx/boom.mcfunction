particle minecraft:explosion_emitter ~ ~1 ~ 0 0 0 0 1 force
execute as @a at @s run playsound minecraft:entity.generic.explode master @s ~ ~ ~ 0.9 1
