scoreboard players remove @s ek.life 1
execute if entity @s[tag=ek.rise] at @s run tp @s ~ ~0.06 ~
execute if score @s ek.life matches ..0 run function ek:fx/vanish
