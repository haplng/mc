tp @s 0 -300 0
kill @s
