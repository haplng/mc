fill -14 58 -14 14 86 14 minecraft:air replace minecraft:fire
execute as @e[tag=ek.steve] run data merge entity @s {Fire:0s}
