execute as @e[tag=ek.chase] at @s unless entity @e[tag=ek.steve,distance=..1.5] run function ek:fx/mob_step
