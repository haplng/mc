scoreboard objectives add ek dummy
scoreboard objectives add ek.life dummy
scoreboard objectives add ek.cd dummy
scoreboard objectives add ek.zm dummy
scoreboard objectives add ek.rd dummy
scoreboard objectives add ek.mh dummy
scoreboard objectives add ek.use minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives remove ek.sn
team add ek
team modify ek collisionRule never
team modify ek seeFriendlyInvisibles false
scoreboard players set #c2 ek 2
scoreboard players set #c3 ek 3
scoreboard players set #c4 ek 4
scoreboard players set #c5 ek 5
scoreboard players set #c6 ek 6
scoreboard players set #c8 ek 8
scoreboard players set #c10 ek 10
scoreboard players set #c20 ek 20
scoreboard players set #c25 ek 25
scoreboard players set #c100 ek 100
scoreboard players set #c10000 ek 10000
scoreboard players set #pct ek 100
execute unless score #aimx ek matches 1.. run scoreboard players set #aimx ek 100
gamerule send_command_feedback false
gamerule advance_time false
gamerule advance_weather false
gamerule spawn_mobs false
gamerule spawn_monsters false
gamerule mob_griefing false
gamerule block_drops false
gamerule mob_drops false
gamerule entity_drops false
gamerule fall_damage false
gamerule fire_damage false
gamerule drowning_damage false
gamerule show_death_messages false
gamerule show_advancement_messages false
gamerule keep_inventory true
gamerule immediate_respawn true
gamerule random_tick_speed 0
gamerule max_command_sequence_length 1000000
gamerule max_block_modifications 100000
gamerule locator_bar false
gamerule spawn_phantoms false
gamerule fire_spread_radius_around_player 0
gamerule spawner_blocks_work false
gamerule command_block_output false
gamerule spawn_wandering_traders false
gamerule spawn_patrols false
gamerule lava_source_conversion false
gamerule allow_entering_nether_using_portals false
bossbar add ek:prog ""
bossbar add ek:mental ""
bossbar add ek:energy ""
bossbar set ek:prog color blue
bossbar set ek:prog max 100
bossbar set ek:mental color green
bossbar set ek:mental max 200
bossbar set ek:energy color yellow
bossbar set ek:energy style notched_10
bossbar set ek:energy max 100
execute unless score #runs ek matches 0.. run scoreboard players set #runs ek 0
execute unless score #wins ek matches 0.. run scoreboard players set #wins ek 0
execute unless score #best ek matches 0.. run scoreboard players set #best ek 0
execute unless score #state ek matches 0.. run scoreboard players set #state ek 0
execute unless score #intr ek matches 0.. run scoreboard players set #intr ek 0
execute unless score #abt ek matches 0.. run scoreboard players set #abt ek 0
execute unless score #bubt ek matches 0.. run scoreboard players set #bubt ek 0
execute unless score #drop ek matches 0.. run scoreboard players set #drop ek 0
execute unless score #dropt ek matches 0.. run scoreboard players set #dropt ek 0
execute unless score #dcard ek matches 0.. run scoreboard players set #dcard ek 0
execute unless score #dcost ek matches 0.. run scoreboard players set #dcost ek 0
execute unless score #idle ek matches 0.. run scoreboard players set #idle ek 0
execute unless score #idlek ek matches 0.. run scoreboard players set #idlek ek 0
execute unless score #wild ek matches 0.. run scoreboard players set #wild ek 0
execute unless score #lucky ek matches 0.. run scoreboard players set #lucky ek 0
execute unless score #box ek matches 0.. run scoreboard players set #box ek 0
execute unless score #boxlife ek matches 0.. run scoreboard players set #boxlife ek 0
execute unless score #npt ek matches 0.. run scoreboard players set #npt ek 0
execute unless score #cur ek matches 0.. run scoreboard players set #cur ek 0
execute unless score #lock ek matches 0.. run scoreboard players set #lock ek 0
execute unless score #near ek matches 0.. run scoreboard players set #near ek 0
execute unless score #moving ek matches 0.. run scoreboard players set #moving ek 0
execute unless score #tier ek matches 0.. run scoreboard players set #tier ek 0
execute unless score #nthrow ek matches 0.. run scoreboard players set #nthrow ek 0
execute unless score #nhit ek matches 0.. run scoreboard players set #nhit ek 0
execute unless score #pace ek matches 0.. run scoreboard players set #pace ek 0
execute unless score #aimed ek matches 0.. run scoreboard players set #aimed ek 0
execute unless score #am ek matches 0.. run scoreboard players set #am ek 0
execute unless score #amprev ek matches 0.. run scoreboard players set #amprev ek 0
execute unless score #idlecd ek matches 0.. run scoreboard players set #idlecd ek 0
execute unless score #boxt ek matches 0.. run scoreboard players set #boxt ek 0
execute unless score #boxhint ek matches 0.. run scoreboard players set #boxhint ek 0
execute unless score #mod ek matches 0.. run scoreboard players set #mod ek 0
execute unless score #ex ek matches 0.. run scoreboard players set #ex ek 0
execute unless score #halt ek matches 0.. run scoreboard players set #halt ek 0
execute unless score #dash ek matches 0.. run scoreboard players set #dash ek 0
execute unless score #ddodge ek matches 0.. run scoreboard players set #ddodge ek 0
execute unless score #noticed ek matches 0.. run scoreboard players set #noticed ek 0
execute unless score #built ek matches 1 run function ek:setup/start
