title @a actionbar {"text":"지금은 쓸 수 없는 카드야.","color":"gray"}
scoreboard players set #abt ek 30
execute as @a at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
