title @a actionbar {"text":"판 안쪽을 바라보고 던져.","color":"gray"}
scoreboard players set #abt ek 30
execute as @a at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
