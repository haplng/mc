title @a actionbar {"text":"기력이 부족해.","color":"red"}
scoreboard players set #abt ek 30
execute as @a at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.7 0.6
