clear @a
function ek:cards/put
