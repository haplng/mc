scoreboard players add #ncards ek 1
function ek:game/energy_bar
execute as @a at @s run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.5 1.2
