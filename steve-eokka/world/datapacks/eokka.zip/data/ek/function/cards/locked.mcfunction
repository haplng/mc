title @a actionbar {"text":"아직 잠긴 카드야.","color":"gray"}
scoreboard players set #abt ek 30
