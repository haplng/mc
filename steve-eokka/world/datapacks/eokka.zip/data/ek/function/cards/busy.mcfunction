title @a actionbar {"text":"지금은 억까 연출 중이야. 끝나고 써.","color":"gray"}
scoreboard players set #abt ek 30
