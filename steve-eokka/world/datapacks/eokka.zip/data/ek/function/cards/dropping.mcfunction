title @a actionbar {"text":"먼저 던진 게 아직 떨어지는 중이야.","color":"gray"}
scoreboard players set #abt ek 20
