execute if score #stage ek matches 1 run function ek:cards/put_s1
execute if score #stage ek matches 2 run function ek:cards/put_s2
execute if score #stage ek matches 3 run function ek:cards/put_s3
execute if score #stage ek matches 4 run function ek:cards/put_s4
execute if score #stage ek matches 5 run function ek:cards/put_s5
execute if score #stage ek matches 6 run function ek:cards/put_s6
execute if score #stage ek matches 7 run function ek:cards/put_s7
