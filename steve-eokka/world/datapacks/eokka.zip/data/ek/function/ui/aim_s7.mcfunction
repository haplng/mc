execute if score #sl ek matches 5 run function ek:ui/aim_on {f:"ek:c/anvil/radii"}
