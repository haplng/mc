scoreboard players operation #amprev ek = #am ek
data modify entity @e[tag=ek.curv,limit=1] text set value {text:"◎",color:"white",bold:true}
execute if score #am ek matches 3 run data modify entity @e[tag=ek.curv,limit=1] text set value {text:"◎",color:"gold",bold:true}
execute if score #am ek matches 4 run data modify entity @e[tag=ek.curv,limit=1] text set value {text:"◎",color:"yellow",bold:true}
execute if score #am ek matches 5 run data modify entity @e[tag=ek.curv,limit=1] text set value {text:"◎",color:"green",bold:true}
execute if score #am ek matches 7 run data modify entity @e[tag=ek.curv,limit=1] text set value {text:"◎",color:"light_purple",bold:true}
