scoreboard players set #am ek 1
execute if score #cur ek matches 1 run function ek:ui/aimtier
execute if score #drop ek matches 1 run scoreboard players set #am ek 6
