execute if score #sl ek matches 3 run function ek:ui/aim_on {f:"ek:c/creeper/radii"}
execute if score #sl ek matches 4 if score #runs ek matches 1.. run function ek:ui/aim_on {f:"ek:c/thunder/radii"}
execute if score #sl ek matches 5 run function ek:ui/aim_on {f:"ek:c/anvil/radii"}
