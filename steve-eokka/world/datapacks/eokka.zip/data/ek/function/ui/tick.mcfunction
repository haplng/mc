execute if score #abt ek matches 1.. run scoreboard players remove #abt ek 1
execute as @a run function ek:ui/ab
