execute if score #sl ek matches 0 if score #f_busy ek matches 1 run scoreboard players set #hint ek 1
execute if score #sl ek matches 1 if score #f_mine ek matches 1 run scoreboard players set #hint ek 1
execute if score #sl ek matches 2 if score #f_dark ek matches 1 if score #f_busy ek matches 1 run scoreboard players set #hint ek 1
execute if score #sl ek matches 3 if score #f_mine ek matches 1 run scoreboard players set #hint ek 1
execute if score #sl ek matches 4 if score #f_maze ek matches 1 run scoreboard players set #hint ek 1
