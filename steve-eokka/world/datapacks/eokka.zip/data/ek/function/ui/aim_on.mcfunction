$function $(f)
scoreboard players set #aimed ek 1
