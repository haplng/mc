execute if score #sl ek matches 0 if score #f_bridge ek matches 1 run scoreboard players set #hint ek 1
execute if score #sl ek matches 0 if score #f_high ek matches 1 run scoreboard players set #hint ek 1
execute if score #sl ek matches 1 if score #f_aim ek matches 1 run scoreboard players set #hint ek 1
execute if score #sl ek matches 2 if score #f_bed ek matches 1 run scoreboard players set #hint ek 1
execute if score #sl ek matches 3 if score #f_bed ek matches 1 run scoreboard players set #hint ek 1
execute if score #sl ek matches 3 if score #f_perch ek matches 1 run scoreboard players set #hint ek 1
execute if score #sl ek matches 4 if score #wins ek matches 1.. if score #f_high ek matches 1 run scoreboard players set #hint ek 1
