scoreboard players set #fixt ek 0
function ek:player/fix
execute if score #state ek matches 0 run execute as @a run function ek:lobby/put
execute if score #state ek matches 1 run function ek:cards/put
execute if score #state ek matches 3 if score #rt ek matches 160.. as @a run function ek:result/put
