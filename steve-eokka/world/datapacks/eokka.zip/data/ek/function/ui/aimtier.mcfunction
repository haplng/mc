scoreboard players set #am ek 2
execute unless entity @e[tag=ek.steve] run return 0
execute as @e[tag=ek.cur,limit=1] run function ek:aim/dist
function ek:drop/tier
execute if score #tier ek matches 1 run scoreboard players set #am ek 3
execute if score #tier ek matches 2 run scoreboard players set #am ek 4
execute if score #tier ek matches 3 run scoreboard players set #am ek 5
