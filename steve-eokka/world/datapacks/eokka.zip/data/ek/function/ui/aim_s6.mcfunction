execute if score #sl ek matches 1 run function ek:ui/aim_on {f:"ek:c/silverfish/radii"}
execute if score #sl ek matches 3 run function ek:ui/aim_on {f:"ek:c/creeper/radii"}
execute if score #sl ek matches 4 if score #wins ek matches 1.. run function ek:ui/aim_on {f:"ek:c/floor/radii"}
execute if score #sl ek matches 5 run function ek:ui/aim_on {f:"ek:c/anvil/radii"}
