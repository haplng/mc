execute if score #sl ek matches 0 run function ek:ui/aim_on {f:"ek:c/creeper/radii"}
execute if score #sl ek matches 1 run function ek:ui/aim_on {f:"ek:c/gravel/radii"}
execute if score #sl ek matches 2 run function ek:ui/aim_on {f:"ek:c/zombies/radii"}
execute if score #sl ek matches 5 run function ek:ui/aim_on {f:"ek:c/anvil/radii"}
