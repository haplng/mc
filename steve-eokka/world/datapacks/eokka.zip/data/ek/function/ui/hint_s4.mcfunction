execute if score #sl ek matches 0 if score #f_gravel ek matches 1 run scoreboard players set #hint ek 1
execute if score #sl ek matches 1 if score #f_frame ek matches 1 run scoreboard players set #hint ek 1
execute if score #sl ek matches 2 if score #f_nobed ek matches 1 run scoreboard players set #hint ek 1
execute if score #sl ek matches 2 if score #f_frame ek matches 1 run scoreboard players set #hint ek 1
execute if score #sl ek matches 3 if score #f_busy ek matches 1 run scoreboard players set #hint ek 1
execute if score #sl ek matches 4 if score #runs ek matches 1.. if score #f_busy ek matches 1 run scoreboard players set #hint ek 1
