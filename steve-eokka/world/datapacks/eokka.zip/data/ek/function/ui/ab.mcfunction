execute store result score #sl ek run data get entity @s SelectedItemSlot
scoreboard players set #hint ek 0
execute if score #stage ek matches 1 run function ek:ui/hint_s1
execute if score #stage ek matches 2 run function ek:ui/hint_s2
execute if score #stage ek matches 3 run function ek:ui/hint_s3
execute if score #stage ek matches 4 run function ek:ui/hint_s4
execute if score #stage ek matches 5 run function ek:ui/hint_s5
execute if score #stage ek matches 6 run function ek:ui/hint_s6
execute if score #stage ek matches 7 run function ek:ui/hint_s7
execute if score #sl ek matches ..5 if score #wild ek matches 1 run scoreboard players set #hint ek 2
execute if score #sl ek matches ..5 if score #lucky ek matches 1 run scoreboard players set #hint ek 3
execute if score #intr ek matches 1.. run scoreboard players set #hint ek 0
data modify storage ek:s ab.star set value ""
execute if score #hint ek matches 1 run data modify storage ek:s ab.star set value "   ★ 지금이 노림수!"
execute if score #hint ek matches 2 run data modify storage ek:s ab.star set value "   ★ 딴짓 중! 아무 카드나 노림수"
execute if score #hint ek matches 3 run data modify storage ek:s ab.star set value "   ★ 행운! 다음 억까는 노림수"
scoreboard players set #aimed ek 0
execute if score #stage ek matches 1 run function ek:ui/aim_s1
execute if score #stage ek matches 2 run function ek:ui/aim_s2
execute if score #stage ek matches 3 run function ek:ui/aim_s3
execute if score #stage ek matches 4 run function ek:ui/aim_s4
execute if score #stage ek matches 5 run function ek:ui/aim_s5
execute if score #stage ek matches 6 run function ek:ui/aim_s6
execute if score #stage ek matches 7 run function ek:ui/aim_s7
scoreboard players set #am ek 0
execute if score #aimed ek matches 1 run function ek:ui/aimstate
execute if entity @e[tag=ek.box,tag=ek.pick] run scoreboard players set #am ek 7
execute unless score #am ek = #amprev ek run function ek:ui/curcolor
execute if score #abt ek matches 0 run function ek:ui/show
