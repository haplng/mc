Generator for the map datapack (Minecraft Java 26.3).

gen/build.py    writes the datapack and checks every command against the 26.3 command tree
                (needs the command tree, registries and blocks json of 26.3 in ref/)
gen/world.py    packs it into a world folder
gen/v2.py       aiming and throwing, the mount, Steve's distractions, lucky boxes, stage twists, the HUD line

The tests run against a real 26.3 dedicated server (tools/rcon.py, tools/live.py):
tools/deploy.py     zip the pack into the test world and /reload it, print what the server complains about
tools/livecards.py  use every card in every beat of every stage (needs the small helper pack "ekt" in the test world)
tools/livev2.py     distractions, noticing falling objects, stage twists, the sniping bonus
tools/botv2.py      a fake protocol player: mount, zoom, the look-at cursor, throws, lucky boxes, relog
tools/liveplay.py   a scripted 'decent player' that plays whole runs, to see how far a run goes with the current balance
tools/sim.py, playtest.py, batch.py, cardtest.py are the older offline interpreter tests; they do not know the aiming rules.

26.3 notes that cost time:
* loot conditions (also inline in "execute if predicate {...}") use the key "type", not "condition";
  the player sub-predicate is written {"minecraft:type_specific/player":{input:{sneak:true}}}
* block states in entity NBT are {id:..,properties:..} or a plain string, not {Name:..}
* a predicate FILE that fails to parse stops the whole world from loading, so the pack ships none
* the visible ender dragon must not be NoAI (it would not follow teleports on the client); logic moves the ek.dragon marker
* a mount is only steerable when it is tamed and wears something in the saddle slot
